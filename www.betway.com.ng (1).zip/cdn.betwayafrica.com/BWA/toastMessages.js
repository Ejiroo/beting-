function initToast() {
    var CmsDomain = "https://cms1.betwayafrica.com/gmapi";
    var culture = "en-us";
    var lang = "en";
    var region = "ZZ";
    lang = getCookie("Language").split("-")[0];
    if (window.location.host.indexOf("www.betway.co.za") > -1) {
        region = "ZA";
    } else if (window.location.host.indexOf("www.betway.com.ng") > -1) {
        region = "NG";
    } else if (window.location.host.indexOf("www.betway.com.gh") > -1) {
        region = "GH";
    } else if (window.location.host.indexOf("www.betway.co.ke") > -1) {
        region = "KE";
    } else if (window.location.host.indexOf("www.betway.co.zm") > -1) {
        region = "ZM";
    } else if (window.location.host.indexOf("www.betway.co.tz") > -1) {
        region = "TZ";
    } else if (window.location.host.indexOf("www.betway.ug") > -1) {
        region = "UG";
    }

    function ClearOldToasts(toast) {
        var toasts = JSON.parse(localStorage.getItem('toastMessagesHistoryV3'));
        if (toasts) {
            var currentDate = new Date(toast.CurrentDateTime);
            localStorage.setItem('toastMessagesHistoryV3', JSON.stringify(toasts.filter(el => new Date(el.Expiry) > currentDate || el.Expiry === null)));
        }
    }

    function makeAjaxCall(verb, url, params, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            var DONE = 4;
            var OK = 200;
            if (xhr.readyState === DONE) {
                var response = {
                    error: null,
                    data: null,
                    responseCode: null
                };
                response.responseCode = xhr.status;
                if (xhr.status === OK) {
                    try {
                        response.data = JSON.parse(xhr.responseText);
                    } catch {};
                } else {
                    response.responseCode = xhr.responseText;
                }
                callback(response);
            }
        };
        xhr.open(verb, url);
        if (params) {
            xhr.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            xhr.send(JSON.stringify(params));
        } else {
            xhr.send();
        }
    }

    function getToastMessages() {
        var getToastCallBack = function(e) {
            if (e.data.length !== 0) {
                window.toastMessages = e.data;
                showToastMessages();
            }
        }
        makeAjaxCall("GET", CmsDomain + "/Site/ToastMessage?host=cms1.betwayafrica.com&culture=" + culture + "&regionCode=" + region, null, getToastCallBack);
    }

    function ToastContentCallBack(e) {
        if (e.data.content) {
            displayToast(e.data.content);
        }
    }

    function sendTrackingInfo(message, messageId) {
        if (dataLayer) {
            dataLayer.push({
                'event': 'ToastMessageEvent',
                'ToastMessage': message,
                'ToastMessageId': messageId
            });
        }
    }

    function addClickevents() {
        $('#toast-' + window.currentToast.MessageId + ' .close').click(function() {
            sendTrackingInfo("Toast Close", window.currentToast.MessageId);
            getToastMessages();
        });
        $('[toast-cta]').click(function() {
            sendTrackingInfo("Click Value " + $(this).attr("toast-cta"), window.currentToast.MessageId);
        });
        $('[add-Tag-To-Account]').click(function() {
            var addTagRequest = {
                "accountId": promoDetails.upid,
                "tagName": $(this).attr("tag-name"),
                "value": $(this).attr("tag-value"),
                "countryCode": promoDetails.brandCode
            }
            makeAjaxCall("POST", "https://api.betwayafrica.com/api/v1/Tagging/AddTagToVuvuzelaAccount?regionID=1", addTagRequest, null);
            if ($(this).attr("redirect-value")) {
                window.location.href = $(this).attr("redirect-value");
            } else {
                window.location.href = "/";
            }
        });
    }

    function displayToast(content) {
        document.getElementsByTagName("BODY")[0].insertAdjacentHTML('beforeend', content);
        setTimeout(function() {
            addClickevents();
            var options = {
                'backdrop': 'static',
                'show': 'false'
            }
            $('#toast-' + window.currentToast.MessageId).modal(options);
            $('#toast-' + window.currentToast.MessageId).modal('show');
            sendTrackingInfo("Toast Show", window.currentToast.MessageId);
            var standalone = window.navigator.standalone,
                userAgent = window.navigator.userAgent.toLowerCase(),
                safari = /safari/.test(userAgent),
                ios = /iphone|ipod|ipad/.test(userAgent);
            if (ios) {
                if (!standalone && safari) {} else if (!standalone && !safari) {
                    $("#appIcons").hide();
                };
            } else {
                if (userAgent.includes('wv')) {
                    $("#appIcons").hide();
                } else {}
            };
            if (isIOS || IsAndroid) {
                $("#appIcons").hide();
            }
            if ($("#toastAppDownload")) {
                $("#toastAppDownload").attr("href", "https://content.betwayafrica.com/ad-hoc/app-launch/?" + getCookie("BTAGCOOKIE") + "&" + getCookie("OriginalQueryString") + "&toastdownload=1");
            }
        }, 500);
    }

    function showToastMessages() {
        var toasts = applyBusinessLogicToMessages(window.toastMessages);
        if (toasts.length !== 0) {
            var toast = toasts[0];
            window.currentToast = toast;
            updateToastmessageHistory(window.currentToast);
            makeAjaxCall("GET", CmsDomain + "/Content/cmsget/?host=cms1.betwayafrica.com&route=" + toast.PagePath + "&lang=" + lang, null, ToastContentCallBack);
        }
    }

    function getToastMessageHistory() {
        return JSON.parse(localStorage.getItem('toastMessagesHistoryV3'));
    }

    function updateToastmessageHistory(toast) {
        var messageHistory = JSON.parse(localStorage.getItem('toastMessagesHistoryV3'));
        if (!messageHistory) {
            messageHistory = [];
        }
        var toastHistoryItem = {};
        toastHistoryItem.MessageId = toast.MessageId;
        if (toast.Occurrence === "Daily") {
            var date = new Date(toast.CurrentDateTime);
            date.setDate(date.getDate() + 1);
            date = date.setHours(0, 0, 0, 0);
            toastHistoryItem.Expiry = date;
        } else if (toast.Occurrence === "Weekly") {
            var date = new Date(toast.CurrentDateTime);
            date.setDate(date.getDate() + 7);
            date = date.setHours(0, 0, 0, 0);
            toastHistoryItem.Expiry = date;
        } else {
            toastHistoryItem.Expiry = null;
        }
        messageHistory.push(toastHistoryItem);
        localStorage.setItem('toastMessagesHistoryV3', JSON.stringify(messageHistory));
    }

    function applyBusinessLogicToMessages(toasts) {
        var filteredMessages = [];
        var loggedIn = document.cookie.toLowerCase().indexOf("lemony") > -1;
        for (i = 0; i < toasts.length; i++) {
            var valid = true;
            var toast = toasts[i];
            if (toast.Path !== null && window.location.pathname.indexOf(toast.Path) === -1) {
                valid = false;
            }
            if (toast.Datafree === false && (window.location.host.indexOf(".datafree.co") > -1 || window.location.host.indexOf(".datafree.ng") > -1)) {
                valid = false;
            }
            if (loggedIn === true && toast.State === "Logged Out") {
                valid = false;
            }
            if (loggedIn === false && toast.State === "Logged In") {
                valid = false;
            }
            if (loggedIn === true) {
                var includeTagsMatch = false;
                if (toast.IncludedAccountTags) {
                    var tags = toast.IncludedAccountTags.split(";");
                    for (y = 0; y < tags.length; y++) {
                        var toastTag = tags[y];
                        toastTag = toastTag.split("=");
                        for (x = 0; x < window.AccountTags.length; x++) {
                            var accountTag = window.AccountTags[x];
                            if (toastTag.length === 2) {
                                if (accountTag.tagName === toastTag[0] && accountTag.value === toastTag[1]) {
                                    includeTagsMatch = true;
                                }
                            } else {
                                if (accountTag.tagName === toastTag[0]) {
                                    includeTagsMatch = true;
                                }
                            }
                        }
                    }
                    if (includeTagsMatch === false) {
                        valid = false;
                    }
                }
                var excludeTagsMatch = false;
                if (toast.ExcludedAccountTags) {
                    var tags = toast.ExcludedAccountTags.split(";");
                    for (y = 0; y < tags.length; y++) {
                        var toastTag = tags[y];
                        toastTag = toastTag.split("=");
                        for (x = 0; x < window.AccountTags.length; x++) {
                            var accountTag = window.AccountTags[x];
                            if (toastTag.length === 2) {
                                if (accountTag.tagName === toastTag[0] && accountTag.value === toastTag[1]) {
                                    excludeTagsMatch = true;
                                }
                            } else {
                                if (accountTag.tagName === toastTag[0]) {
                                    excludeTagsMatch = true;
                                }
                            }
                        }
                    }
                    if (excludeTagsMatch === true) {
                        valid = false;
                    }
                }
            }
            var clearOldToasts = ClearOldToasts(toast);
            var messageHistory = getToastMessageHistory();
            if (messageHistory) {
                for (y = 0; y < messageHistory.length; y++) {
                    try {
                        var t = messageHistory[y].MessageId;
                        if (t === toast.MessageId) {
                            valid = false;
                            break;
                        }
                    } catch (ex) {
                        localStorage.removeItem('toastMessagesHistoryV3');
                    }
                }
            }
            if (valid === true) {
                filteredMessages.push(toast);
            }
        }
        return filteredMessages;
    }
    if (document.cookie.toLowerCase().indexOf("lemony") > -1) {
        var AccountTags = sessionStorage.getItem("AccountTags");
        if (!AccountTags) {
            makeAjaxCall("GET", "https://api.betwayafrica.com/api/v1/Tagging/GetVuvuzelaAccountTags?AccountId=" + promoDetails.upid, null, setAccountTags);
        } else {
            window.AccountTags = JSON.parse(AccountTags);
            getToastMessages();
        }
    } else {
        getToastMessages();
    }

    function setAccountTags(e) {
        if (e.data) {
            window.AccountTags = e.data;
            sessionStorage.setItem("AccountTags", JSON.stringify(e.data));
        }
        getToastMessages();
    }
    $("[loadToastMessage]").click(function(e) {
        e.preventDefault();
        if (!window.currentToast) {
            window.currentToast = {};
            window.currentToast.MessageId = $(this).attr("toast-id");
        }
        makeAjaxCall("GET", CmsDomain + "/Content/cmsget/?host=cms1.betwayafrica.com&route=" + $(this).attr("toast-route") + "&lang=" + lang, null, ToastContentCallBack);
    });
    window.loadBetwayTv = function() {
        if (document.cookie.toLowerCase().indexOf("lemony") > -1) {
            $(".Tvpromo").remove();
            var script = document.createElement('script');
            script.src = "https://promotions.betwayafrica.com/assets/tvpromo.js";
            document.getElementById('toast-' + window.currentToast.MessageId).appendChild(script);
        } else {
            window.location.href = "/prime-time/?login=1";
        }
    }
}
if (navigator.userAgent.indexOf("MiniProgram") > -1 || navigator.userAgent.indexOf("AliApp") > -1) {} else {
    initToast();
}
var userObj = window.promoDetails;
window.promoUserDetails = {
    AccountId: userObj.upid,
    BrandCode: userObj.brandCode,
    CultureCode: getCookie("Language").split("-")[0],
    CountryCode: userObj.brandCode,
};

function countDownStart() {
    var countDownDate = new Date('July 19, 2023 08:00:00').getTime();
    var x = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;
        var days = Math.floor(distance / (1000 * 60 * 60 * 24));
        var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        document.getElementById('days').textContent = days.toString().padStart(2, '0');
        document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
        if (distance < 0) {
            clearInterval(x);
            document.getElementById('days').textContent = '00';
            document.getElementById('hours').textContent = '00';
        }
    }, 1000);
}