function MarketingInit() {
    function getParameterByName(name, url) {
        if (!url)
            url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results)
            return null;
        if (!results[2])
            return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }
    if (promoDetails.upid !== "00000000-0000-0000-0000-000000000000" && !sessionStorage.getItem("MkSession")) {
        var regionID;
        switch (window.location.host) {
            case "www.betway.co.za":
                regionID = 1;
                break;
            case "betway.betwayzero.co.za":
                regionID = 1;
                break;
            case "www.betway.com.gh":
                regionID = 2;
                break;
            case "www.betway.co.ke":
                regionID = 3;
                break;
            case "www.betway.ug":
                regionID = 4;
                break;
            case "www.betway.com.ng":
                regionID = 5;
                break;
            case "betway.datafree.ng":
                regionID = 5;
                break;
            case "www.betway.co.zm":
                regionID = 6;
                break;
            case "www.betway.co.tz":
                regionID = 7;
                break;
            default:
                regionID = 0
        }
        var sessiongObject = {
            platformID: null,
            regionID: regionID,
            vendorAccountID: null,
            dataFree: false,
            bannerTag: null,
            queryParamString: null,
            ipAddress: null,
            countryCode: null,
            userAgent: navigator.userAgent,
            isMobile: false,
            isTable: false,
            deviceOsName: null,
            deviceBrowserName: null,
            deviceBrowserVersion: null,
            sessionTrackingToken: null
        }
        if (window.location.host.indexOf("betway.datafree") > -1 || window.location.host.indexOf("betway.betwayzero") > -1) {
            sessiongObject.dataFree = true;
        }
        try {
            if (window.dataLayer !== null) {
                window.dataLayer.push({
                    event: "AuthenticationEvent",
                    accountId: promoDetails.upid
                });
            }
        } catch (err) {}

        function httpGetAsync(theUrl) {
            var xmlHttp = new XMLHttpRequest();
            xmlHttp.onreadystatechange = function() {
                if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                    var deviceInfo = JSON.parse(xmlHttp.responseText);
                    var AppType = getParameterByName("appType");
                    if (!AppType) {
                        AppType = "web";
                    }
                    if (AppType.toLowerCase() === "ios") {
                        sessiongObject.platformID = 3;
                    } else if (AppType.toLowerCase() === "android") {
                        sessiongObject.platformID = 4;
                    } else if (AppType.toLowerCase() === "huawei") {
                        sessiongObject.platformID = 5;
                    } else if (deviceInfo.deviceInfo.IsMobile === true || deviceInfo.deviceInfo.IsTablet === true) {
                        sessiongObject.platformID = 1;
                    } else if (deviceInfo.deviceInfo.IsMobile === false) {
                        sessiongObject.platformID = 2;
                    }
                    sessiongObject.countryCode = deviceInfo.countryCode;
                    sessiongObject.isMobile = deviceInfo.deviceInfo.IsMobile;
                    sessiongObject.isTable = deviceInfo.deviceInfo.IsTablet;
                    sessiongObject.deviceOsName = deviceInfo.deviceInfo.DeviceOsName;
                    sessiongObject.deviceBrowserName = deviceInfo.deviceInfo.DeviceBrowserName;
                    sessiongObject.deviceBrowserVersion = deviceInfo.deviceInfo.DeviceBrowserVersion;
                    sessiongObject.ipAddress = "";
                    sessiongObject.vendorAccountID = promoDetails.upid;
                    sessiongObject.bannerTag = getCookie("BTAGCOOKIE");
                    sessiongObject.queryParamString = getCookie("OriginalQueryString");
                    sessiongObject.sessionTrackingToken = window.sessionStorage.getItem('sessionTrackingTokenEncoded');
                    sessiongObject.sessionMetaData = [{
                        cookieName: "REFERRERBTAGCOOKIE",
                        cookieValue: getCookie("REFERRERBTAGCOOKIE"),
                        cookieDomain: ""
                    }, {
                        cookieName: "MT",
                        cookieValue: getCookie("MT"),
                        cookieDomain: ""
                    }, {
                        cookieName: "ST",
                        cookieValue: getCookie("ST"),
                        cookieDomain: ""
                    }];
                    var xhr = new XMLHttpRequest();
                    var url = "https://api.betwayafrica.com/api/v1/Marketing/AddMarketingSession";
                    xhr.open("POST", url, true);
                    xhr.setRequestHeader("Content-Type", "application/json");
                    xhr.timeout = 2000;
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            sessionStorage.setItem("MkSession", true);
                        }
                    };
                    var data = JSON.stringify(sessiongObject);
                    xhr.send(data);
                    if (!window.thkdlhgd) {
                        setTimeout((function(d, src) {
                            var script = d.createElement("script");
                            script.type = "text/javascript";
                            script.defer = "defer";
                            script.async = true;
                            script.onload = function() {
                                window.thkdlhgd.prgssdw("info.betway.co.za", "b5upb58k", window.sessionStorage.getItem('sessionTrackingTokenEncoded'), "101");
                            };
                            script.src = src;
                            (d.getElementsByTagName("body")[0]).appendChild(script);
                        })(document, "https://cdn.betwayafrica.com/BWA/lntk.js"), 50);
                    } else {
                        window.thkdlhgd.prgssdw("info.betway.co.za", "b5upb58k", window.sessionStorage.getItem('sessionTrackingTokenEncoded'), "101");
                    }
                }
            }
            xmlHttp.open("GET", theUrl, true);
            xmlHttp.send(null);
        }
        if (regionID !== 0) {
            httpGetAsync("https://info.betwayafrica.com/api/v1/RequestInfo");
        }
    }

    function marketingOptIn() {
        var optin = getParameterByName("optin");
        if (!optin) {
            optin = localStorage.setItem("MkOptIn", optin);
        }
        if (optin) {
            if (promoDetails.upid === "00000000-0000-0000-0000-000000000000") {
                localStorage.setItem("MkOptIn", optin);
            } else {
                if (optin) {
                    doOptIn(optin, getParameterByName("source"));
                    localStorage.removeItem("MkOptIn");
                }
            }
        }
    }

    function marketingTagAssign() {
        var currentTags = {};
        var mKtags = [];
        var tagname = getParameterByName("tagname");
        var tagvalue = getParameterByName("tagvalue");
        if (tagname && promoDetails.upid && promoDetails.upid !== "00000000-0000-0000-0000-000000000000") {
            var regionID;
            switch (window.location.host) {
                case "www.betway.co.za":
                    regionID = 'ZA';
                    break;
                case "betway.betwayzero.co.za":
                    regionID = 'ZA';
                    break;
                case "www.betway.com.gh":
                    regionID = 'GH';
                    break;
                case "www.betway.co.ke":
                    regionID = 'KE';
                    break;
                case "www.betway.ug":
                    regionID = 'UG';
                    break;
                case "www.betway.com.ng":
                    regionID = 'NG';
                    break;
                case "betway.datafree.ng":
                    regionID = 'NG';
                    break;
                case "www.betway.co.zm":
                    regionID = 'ZM';
                    break;
                case "www.betway.co.tz":
                    regionID = 'TZ';
                    break;
                default:
                    regionID = ''
            }
            if (sessionStorage.getItem("MkFiredTags")) {
                mKtags = JSON.parse(sessionStorage.getItem("MkFiredTags"));
            }
            if (mKtags.filter(t => t === tagname).length === 0) {
                doTagAssignment(regionID, promoDetails.upid, tagname, tagvalue);
                currentTags[tagname] = tagvalue;
                if (sessionStorage.getItem("AccountTags") === '[]') {
                    sessionStorage.removeItem("AccountTags");
                }
                mKtags = [...mKtags, tagname];
                sessionStorage.setItem("MkFiredTags", JSON.stringify(mKtags));
            }
        }
    }

    function doTagAssignment(regionCode, accountId, tagName, tagValue) {
        var xhr = new XMLHttpRequest();
        var url = `https://api.betwayafrica.com/api/v1/Tagging/AddorEditTagOnVuvuzelaAccount?regionCode=${regionCode}`;
        xhr.open("POST", url, true);
        xhr.timeout = 2000;
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {}
        };
        var data = JSON.stringify({
            accountId: accountId,
            tagName: tagName,
            value: tagValue
        });
        xhr.send(data);
    }

    function doOptIn(optin, source) {
        launch_toast();
        var xhr = new XMLHttpRequest();
        var url = "https://api.betwayafrica.com/api/v1/Marketing/InsertMarketingOptIn";
        xhr.open("POST", url, true);
        xhr.timeout = 2000;
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {}
        };
        var data = JSON.stringify({
            vendorAccountID: promoDetails.upid,
            optinName: optin,
            source: source,
            countryCode: promoDetails.brandCode
        });
        xhr.send(data);
    }
    marketingOptIn();
    try {
        marketingTagAssign();
    } catch (marketingTagAssignErr) {}
}

function launch_toast() {
    var x = document.getElementById("toast")
    x.className = "show";
    setTimeout(function() {
        x.className = x.className.replace("show", "");
    }, 5000);
}

function AddMarketingSessionById(accountId) {
    if (accountId !== "00000000-0000-0000-0000-000000000000") {
        var regionID;
        switch (window.location.host) {
            case "www.betway.co.za":
                regionID = 1;
                break;
            case "bet.free.betway.co.za":
                regionID = 1;
                break;
            case "betway.datafree.co":
                regionID = 1;
                break;
            case "www.betway.com.gh":
                regionID = 2;
                break;
            case "www.betway.co.ke":
                regionID = 3;
                break;
            case "www.betway.ug":
                regionID = 4;
                break;
            case "www.betway.com.ng":
                regionID = 5;
                break;
            case "betway.datafree.ng":
                regionID = 5;
                break;
            case "www.betway.co.zm":
                regionID = 6;
                break;
            case "www.betway.co.tz":
                regionID = 7;
                break;
            default:
                regionID = 0
        }
        var sessiongObject = {
            platformID: null,
            regionID: regionID,
            vendorAccountID: accountId,
            dataFree: false,
            bannerTag: null,
            queryParamString: null,
            ipAddress: null,
            countryCode: null,
            userAgent: navigator.userAgent,
            isMobile: false,
            isTable: false,
            deviceOsName: null,
            deviceBrowserName: null,
            deviceBrowserVersion: null,
            sessionTrackingToken: null
        }
        if (window.location.host.indexOf("betway.betwayzero") > -1) {
            sessiongObject.dataFree = true;
        }

        function httpGet2Async(theUrl) {
            var xmlHttp = new XMLHttpRequest();
            xmlHttp.onreadystatechange = function() {
                if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                    var deviceInfo = JSON.parse(xmlHttp.responseText);
                    var AppType = getParameterByName("appType");
                    if (!AppType) {
                        AppType = "web";
                    }
                    if (AppType.toLowerCase() === "ios") {
                        sessiongObject.platformID = 3;
                    } else if (AppType.toLowerCase() === "android") {
                        sessiongObject.platformID = 4;
                    } else if (AppType.toLowerCase() === "huawei") {
                        sessiongObject.platformID = 5;
                    } else if (AppType.toLowerCase() === "googleplay") {
                        sessiongObject.platformID = 6;
                    } else if (deviceInfo.deviceInfo.IsMobile === true || deviceInfo.deviceInfo.IsTablet === true) {
                        sessiongObject.platformID = 1;
                    } else if (deviceInfo.deviceInfo.IsMobile === false) {
                        sessiongObject.platformID = 2;
                    }
                    sessiongObject.countryCode = deviceInfo.countryCode;
                    sessiongObject.isMobile = deviceInfo.deviceInfo.IsMobile;
                    sessiongObject.isTable = deviceInfo.deviceInfo.IsTablet;
                    sessiongObject.deviceOsName = deviceInfo.deviceInfo.DeviceOsName;
                    sessiongObject.deviceBrowserName = deviceInfo.deviceInfo.DeviceBrowserName;
                    sessiongObject.deviceBrowserVersion = deviceInfo.deviceInfo.DeviceBrowserVersion;
                    sessiongObject.ipAddress = "";
                    sessiongObject.bannerTag = getCookie("BTAGCOOKIE");
                    sessiongObject.queryParamString = getCookie("OriginalQueryString");
                    sessiongObject.sessionTrackingToken = window.sessionStorage.getItem('sessionTrackingTokenEncoded');
                    var xhr = new XMLHttpRequest();
                    var url = "https://api.betwayafrica.com/api/v1/Marketing/AddMarketingSession";
                    xhr.open("POST", url, true);
                    xhr.setRequestHeader("Content-Type", "application/json");
                    xhr.timeout = 2000;
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            sessionStorage.setItem("MkSession", true);
                        }
                    };
                    xhr.send(data);
                    if (!window.thkdlhgd) {
                        setTimeout((function(d, src) {
                            var script = d.createElement("script");
                            script.type = "text/javascript";
                            script.defer = "defer";
                            script.async = true;
                            script.onload = function() {
                                window.thkdlhgd.prgssdw("info.betway.co.za", "b5upb58k", window.sessionStorage.getItem('sessionTrackingTokenEncoded'), "101");
                            };
                            script.src = src;
                            (d.getElementsByTagName("body")[0]).appendChild(script);
                        })(document, "https://cdn.betwayafrica.com/BWA/lntk.js"), 50);
                    } else {
                        window.thkdlhgd.prgssdw("info.betway.co.za", "b5upb58k", window.sessionStorage.getItem('sessionTrackingTokenEncoded'), "101");
                    }
                }
            }
            xmlHttp.open("GET", theUrl, true);
            xmlHttp.send(null);
        }
        if (regionID !== 0) {
            httpGet2Async("https://info.betwayafrica.com/api/v1/RequestInfo");
        }
    }
}

function ProfileInit(forceHash = null) {
    function fwgfwegrgerwgre(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function __nwdoivfvoeu(theUrl) {
        function fuowhdfhwdouifvhaddProfiler(hash) {
            try {
                if (!window.thkdlhgd) {
                    window.dataLayer.push({
                        "event": "TmxProfileEvent",
                        "result": `thkdlhgd is null`
                    });
                }
                window.thkdlhgd.prgssdw("info.betway.co.za", "b5upb58k", hash, "101");
                window.dataLayer.push({
                    "event": "TmxProfileEvent",
                    "result": `Executed info.betway.co.za - b5upb58k - 101`
                });
                var smd = JSON.parse(window.sessionStorage.sessionMetaData);
                smd.profiled = "true";
                window.sessionStorage.sessionMetaData = JSON.stringify(smd);
            } catch (e) {
                console.log('info.betway.co.za', e);
                window.dataLayer.push({
                    "event": "TmxProfileEvent",
                    "result": `Profile Error - ${e}`
                });
            }
        }

        function getParameterByName(name, url) {
            if (!url)
                url = window.location.href;
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results)
                return null;
            if (!results[2])
                return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        }
        var xmlHttp = new XMLHttpRequest();
        xmlHttp.onreadystatechange = function() {
            if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
                var di = JSON.parse(xmlHttp.responseText);
                var platformId = 0;
                var AppType = getParameterByName("appType");
                if (!AppType) {
                    AppType = "web";
                }
                if (AppType.toLowerCase() === "ios") {
                    platformId = 3;
                } else if (AppType.toLowerCase() === "android") {
                    platformId = 4;
                } else if (AppType.toLowerCase() === "huawei") {
                    platformId = 5;
                } else if (AppType.toLowerCase() === "googleplay") {
                    platformId = 6;
                } else if (di.deviceInfo.IsMobile === true || di.deviceInfo.IsTablet === true) {
                    platformId = 1;
                } else if (di.deviceInfo.IsMobile === false) {
                    platformId = 2;
                }
                try {
                    var smd = JSON.parse(window.sessionStorage.sessionMetaData);
                    smd.sessionTrackingToken = di['hash'].toLowerCase();
                    smd.uip = di['IpAddress'];
                    smd.platformId = String(platformId);
                    window.sessionStorage.sessionMetaData = JSON.stringify(smd);
                    window.sessionStorage.setItem('sessionTrackingTokenEncoded', di['hash'].toLowerCase())
                    window.dataLayer.push({
                        "event": "TmxProfileEvent",
                        "result": `loaded toolkit.js`
                    });
                    fuowhdfhwdouifvhaddProfiler(di['hash'].toLowerCase());
                } catch (e) {
                    window.dataLayer.push({
                        "event": "TmxProfileEvent",
                        "result": `Error when trying to load https://cdn.betwayafrica.com/BWA/lntk.js`
                    });
                }
            }
        }
        xmlHttp.open("GET", theUrl, true);
        xmlHttp.send(null);
    }
    try {
        if (!window.sessionStorage.sessionMetaData) {
            window.sessionStorage.sessionMetaData = window.sessionStorage.sessionMetaData = '{}';
        }
        if (promoDetails.brandCode === 'ZA' || window.location.host.indexOf("betway.co.za") > -1 || window.location.host.indexOf("betway.datafree") > -1 || window.location.host.indexOf("betway.betwayzero") > -1) {
            var regionID;
            switch (window.location.host) {
                case "www.betway.co.za":
                case "betway.betwayzero.co.za":
                    regionID = 1;
                    break;
                case "www.betway.com.gh":
                    regionID = 2;
                    break;
                case "www.betway.co.ke":
                    regionID = 3;
                    break;
                case "www.betway.ug":
                    regionID = 4;
                    break;
                case "www.betway.com.ng":
                case "betway.datafree.ng":
                    regionID = 5;
                    break;
                case "www.betway.co.zm":
                    regionID = 6;
                    break;
                case "www.betway.co.tz":
                    regionID = 7;
                    break;
                default:
                    regionID = 0
            }
            var urlParams = new URLSearchParams(window.location.search.toLowerCase());
            var smd = JSON.parse(window.sessionStorage.sessionMetaData);
            if (urlParams.get('afid')) {
                smd.appsflyerId = urlParams.get('afid');
            }
            if (urlParams.get('apptype')) {
                smd.platformName = urlParams.get('apptype');
            }
            if (!smd.date) {
                smd.date = new Date().toISOString();
            }
            if (!smd.isSynapse) {
                smd.isSynapse = window.location.host === '' ? 'false' : 'true';
            }
            if (!smd.latestRefererBannerTag) {
                smd.latestRefererBannerTag = fwgfwegrgerwgre("REFERRERBTAGCOOKIE");
            }
            if (!smd.regionId) {
                smd.regionId = String(regionID);
            }
            if (!smd.datafree) {
                smd.datafree = String((window.location.host.indexOf("betway.datafree") > -1 || window.location.host.indexOf("betway.betwayzero.co.za") > -1));
            }
            if (!smd.hostname) {
                smd.hostname = window.location.host;
            }
            if (!smd.btag) {
                smd.btag = fwgfwegrgerwgre("BTAGCOOKIE");
            }
            if (!smd.queryString) {
                smd.queryString = fwgfwegrgerwgre("OriginalQueryString");
            }
            if (smd !== JSON.parse(window.sessionStorage.sessionMetaData)) {
                window.sessionStorage.sessionMetaData = JSON.stringify(smd);
            }
            if (!smd.profiled || smd.profiled !== "true") {
                __nwdoivfvoeu("https://info.betwayafrica.com/api/v1/RequestInfo");
            }
        }
    } catch (e) {
        console.log('ProfileInit', e)
        window.dataLayer.push({
            "event": "TmxProfileEvent",
            "result": `ProfileInit Error - ${e}`
        });
    }
}
if (!window.thkdlhgd) {
    setTimeout((function(d, src) {
        var script = d.createElement("script");
        script.type = "text/javascript";
        script.defer = "defer";
        script.async = true;
        script.onload = function() {
            ProfileInit();
            setTimeout(MarketingInit, 500);
        };
        script.src = src;
        (d.getElementsByTagName("body")[0]).appendChild(script);
    })(document, "https://cdn.betwayafrica.com/BWA/lntk.js"), 50);
} else {
    ProfileInit();
    setTimeout(MarketingInit, 500);
}
if (!(window.location.host.indexOf("betway.datafree") > -1 || window.location.host.indexOf("betway.betwayzero.co.za") > -1)) {
    $("<style>").prop("type", "text/css").html("#toast,#toast #desc{color:#fff;white-space:nowrap}#toast{visibility:hidden;max-width:50px;height:50px;margin:auto;background-color:#333;text-align:center;border-radius:2px;position:fixed;z-index:1;left:0;right:0;bottom:70px;font-size:17px}#toast #OptInImg{width:50px;height:50px;float:left;background-color:#111;color:#fff;background-image:url(https://cms1.betwayafrica.com/medialibraries/content.gmgamingsystems.com/GlobalIcons/common/ic-tick.png);background-size:35px 35px;background-repeat:no-repeat;background-position:center}#toast #desc{padding:16px;overflow:hidden}#toast.show{visibility:visible;-webkit-animation:.5s fadein,.5s .5s expand,3s 1s stay,.5s 2s shrink,.5s 2.5s fadeout;animation:.5s fadein,.5s .5s expand,3s 1s stay,.5s 4s shrink,.5s 4.5s fadeout}@-webkit-keyframes fadein{from{bottom:0;opacity:0}to{bottom:30px;opacity:1}}@keyframes fadein{from{bottom:0;opacity:0}to{bottom:30px;opacity:1}}@-webkit-keyframes expand{from{min-width:50px}to{min-width:350px}}@keyframes expand{from{min-width:50px}to{min-width:350px}}@-webkit-keyframes stay{from,to{min-width:350px}}@keyframes stay{from,to{min-width:350px}}@-webkit-keyframes shrink{from{min-width:350px}to{min-width:50px}}@keyframes shrink{from{min-width:350px}to{min-width:50px}}@-webkit-keyframes fadeout{from{bottom:30px;opacity:1}to{bottom:60px;opacity:0}}@keyframes fadeout{from{bottom:30px;opacity:1}to{bottom:60px;opacity:0}}").appendTo("head");
    $("body").prepend('<div id="toast"><div id="OptInImg"></div><div id="desc">Successfully opted into promotion.</div></div>');
}