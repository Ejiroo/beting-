function getParameterByName(name, url) {
    if (!url)
        url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results)
        return null;
    if (!results[2])
        return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
if (getParameterByName("launchbanking") === "1") {
    $("#depositBtnInline").click();
}
var isIOS = false;
var IsAndroid = false;
if (getParameterByName("isIosApp") === "false") {
    IsAndroid = true;
    sessionStorage.setItem("IsApp", "Andriod");
}
if (getParameterByName("isIosApp") === "true") {
    isIOS = true;
    sessionStorage.setItem("IsApp", "IOS");
}
if (sessionStorage.getItem("IsApp") === "IOS") {
    isIOS = true;
}
if (sessionStorage.getItem("IsApp") === "Andriod") {
    IsAndroid = true;
}
if (isIOS || IsAndroid || sessionStorage.getItem("IsApp")) {
    var script = document.createElement('script');
    script.async = true;
    script.src = "https://cdn.betwayafrica.com/BWA/app.js";
    document.head.appendChild(script);
}

function setIntervalBtagX() {
    var x = 0;
    var intervalID = window.setInterval(function() {
        if (getCookie("BTAGCOOKIE")) {
            BannerTagsReady();
            window.clearInterval(intervalID);
        }
        if (++x === 20) {
            window.clearInterval(intervalID);
        }
    }, 500);
}
setIntervalBtagX();
if (getCookie("OriginalQueryString") === "") {
    function setCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + (value || "") + expires + "; path=/";
    }
    var t = window.location.href.split("?");
    2 === t.length ? setCookie("OriginalQueryString", t[1], 7) : setCookie("OriginalQueryString", "/", 7);
};
setTimeout(function() {
    if (getCookie("BTAGCOOKIE") === "") {
        var parts = location.hostname.split('.');
        var subdomain = parts.shift();
        var upperleveldomain = parts.join('.');
        var OriginUrl = window.location.href;
        var domain = upperleveldomain;

        function Set_Cookie(name, value, days) {
            var current_date = new Date;
            current_date.setTime(current_date.getTime() + 24 * 60 * 60 * 1000 * days);
            document.cookie = name + "=" + value + ";domain=" + domain + ";samesite=No Restriction;secure=true;path=/;expires=" + current_date.toGMTString();
        }

        function getParameterByName(name, url) {
            if (!url)
                url = window.location.href.toLowerCase();
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results)
                return null;
            if (!results[2])
                return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        }
        var t = getParameterByName("btag");
        Set_Cookie("BTAGCOOKIE", t, 7);
        Set_Cookie("OriginalQueryString", "/", 7);
    };
}, 10000);

function BannerTagsReady() {
    if (window.location.host.indexOf(".com.ng") > -1) {
        setInterval(function() {
            $('[href="https://betway.datafree.ng"]').each(function() {
                $(this).removeAttr("target");
                $(this).attr("href", "https://betway.datafree.ng/?btag=" + getCookie("BTAGCOOKIE"));
            });
        }, 2000)
    };
    if (window.location.host.indexOf(".co.za") > -1) {
        setInterval(function() {
            $('[href="https://betway.datafree.co"]').each(function() {
                $(this).removeAttr("target");
                $(this).attr("href", "https://betway.datafree.co/?btag=" + getCookie("BTAGCOOKIE"));
            });
        }, 2000)
    };
    setAppLink();
}
if (window.location.host == "www.betway.co.za" && promoDetails.upid !== "00000000-0000-0000-0000-000000000000") {
    window.parent.postMessage("navigat-to-core", '*');
}
if (window.location.host == "www.betway.co.za") {
    function checkForPPC() {
        function getParameterByName(name, url = window.location.href) {
            name = name.replace(/[\[\]]/g, '\\$&');
            var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                results = regex.exec(url);
            if (!results) return '';
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
        }
        if ((document.referrer.indexOf("offers.betway.co.za") > -1 || getParameterByName("btag").indexOf("P72188") > -1 || getParameterByName("btag").indexOf("P73300") > -1) || sessionStorage.getItem("PPC") || getParameterByName("ppc")) {
            sessionStorage.setItem("PPC", true)
            ppcLogic();
        }
    }
    checkForPPC();
    window.addEventListener("message", (event) => {
        if (event.data === 'ppc') {
            sessionStorage.setItem("PPC", true);
            ppcLogic();
            window.parent.postMessage("hide-offers-loader", '*');
        }
    }, false);

    function ppcLogic() {
        if (sessionStorage.getItem("PPC")) {
            if (window.location.pathname.indexOf("/luckynumbers") > -1 || window.location.pathname.indexOf("/lobby/casinogames") > -1 || window.location.pathname.indexOf("/betgames") > -1 || window.location.pathname === '/') {
                window.location.href = "/sport";
            }
            setInterval(function() {
                $(".nav-link-item-betgames").attr('style', 'display: none !important');
                $(".nav-link-item-luckynumbers").attr('style', 'display: none !important');
                $(".banner-row ").attr('style', 'display: none !important');
                $(".nav-link-item-livegames").attr('style', 'display: none !important');
                $(".nav-link-item-casinogames").attr('style', 'display: none !important');
                $(".nav-link-item-betwayjackpots").attr('style', 'display: none !important');
                $(".nav-link-item-aviator").attr('style', 'display: none !important');
                $('[src="https://cdn2.betway.co.za/contentfiles/Sportsbook/betwaysouthafrica/Banners/SA_CasinoWelcomeOffer_ImageUpdate_Desktop.jpg"]').parent().parent().attr('style', 'display: none !important');
                $('[href="https://www.betway.co.za/spins"]').parent().attr('style', 'display: none !important');
                $("#Sport_13d6b9aa-add4-4629-8ade-5ab388a6d664,#Sport_5ef8ddee-c43e-4c6e-968d-0b7e0f7c3590,#Sport_b0a77d74-70aa-44e8-8735-6e3def87c65a").attr('style', 'display: none !important');
                $("#ragingCarouselParent").attr('style', 'display: none !important');
            }, 1000)
            $("<style>").prop("type", "text/css").html("#Sport_13d6b9aa-add4-4629-8ade-5ab388a6d664,#Sport_5ef8ddee-c43e-4c6e-968d-0b7e0f7c3590,.nav-link-item-betgames,.nav-link-item-luckynumbers,.nav-link-item-livegames,#ragingCarouselParent,.nav-link-item-casinogames,#Sport_00000000-0000-0000-da7a-000000550070,#Sport_fb4d1bdd-6883-441f-97ba-4e3b24ab0aef,#navbar_betgames,#navbar_livegames,#navbar_luckynumbers{display:none!important;opacity:0;width: 0;}").appendTo("head");
            document.querySelectorAll('[href="https://www.betway.co.za/lobby/livegames"]').forEach(function(child) {
                var parent = child.parentNode;
                parent.removeChild(child);
                parent.innerHTML = document.querySelectorAll('[href="https://www.betway.co.za/?register=1"]')[0].innerHTML;
            });
        }
    }
}

function setAppLink() {
    var OrginalQueryString = getCookie("OriginalQueryString");
    if (OrginalQueryString === "/") {
        OrginalQueryString = "";
    }

    function getCookie(name) {
        var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
        return v ? v[2] : null;
    }
    var queryString = decodeURIComponent(getCookie("OriginalQueryString"));
    if (queryString.indexOf("btag=&") > -1) {
        queryString = queryString.replace("btag=", "btag=" + getCookie("BTAGCOOKIE"));
    } else if (queryString.indexOf("btag=") == -1) {
        queryString = queryString + "&btag=" + getCookie("BTAGCOOKIE")
    }
    var appUrl;
    if (window.location.host == "www.betway.co.za" || window.location.host == "betway.datafree.co" || window.location.host == "qa.betway.co.za" || window.location.host == "uat.betway.co.za" || window.location.host == "bet.freedev.betway.co.za") {
        if (navigator.userAgent.indexOf("MiniProgram") > -1 || navigator.userAgent.indexOf("AliApp") > -1) {
            var script = document.createElement('script');
            script.async = true;
            script.src = "https://cdn.betwayafrica.com/BWA/vodapay.js";
            document.head.appendChild(script);
            var script2 = document.createElement('script');
            script2.async = true;
            script2.src = "https://gw.alipayobjects.com/os/??s/prod/web-view/common-15524.js,s/prod/web-view/index-16274.js";
            document.head.appendChild(script2);
        }
        if (localStorage.getItem("currentSportId") === "85ad9d37-fca2-44ae-a9e7-ebbee9a5ef31") {
            $("#Sport_00000000-0000-0000-da7a-000000550001").click()
        }
        appUrl = "https://appdownload.betwayafrica.com/?link=https://www.betway.co.za/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + OrginalQueryString + "&apn=com.betwayafrica.za&afl=https://cdn.betwayafrica.com/app/za/index.html";
        appUrl = appUrl.replace("&&", "&");
        try {
            setInterval(() => {
                try {
                    if (document.querySelector('.app-store-container')) {
                        document.querySelector('.app-store-container').addEventListener('click', () => {
                            window.location.href = appUrl + "&isi=1274057509&ibi=com.betway.sa"
                        });
                    }
                } catch (ex) {}
            }, 5000)
            $('.app-store-desc')[0].href = appUrl + "&isi=1274057509&ibi=com.betway.sa";
            $('.app-downlod-icons a')[0].href = appUrl + "&isi=1274057509&ibi=com.betway.sa";
            $('.app-downlod-icons a')[1].href = appUrl + "&isi=1274057509&ibi=com.betway.sa";
            $('.app-downlod-icons a')[2].href = "https://appgallery.cloud.huawei.com/ag/n/app/C102309905?channelId=Web+Download&referrer=https%3A%2F%2Fbetway.co.za%2F%3Fbtag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "&id=f5723873ffb8454cb868895c541469c3&s=61D53E4D649579A96CFDB7087A8B2B311CD6C733033EC70A1F60A2FE850D6808&detailType=0&v=&callType=AGDLINK&installType=0000";
        } catch (ex) {}
        setTimeout(function() {
            window.onload = function(e) {
                if ($("#Sport_85ad9d37-fca2-44ae-a9e7-ebbee9a5ef31").hasClass("active")) {
                    $("#Sport_00000000-0000-0000-da7a-000000550001").click()
                }
            };
        }, 2000);
        if (isIOS) {
            function getParameterByName(name, url) {
                if (!url)
                    url = window.location.href;
                name = name.replace(/[\[\]]/g, '\\$&');
                var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
                    results = regex.exec(url);
                if (!results)
                    return null;
                if (!results[2])
                    return '';
                return decodeURIComponent(results[2].replace(/\+/g, ' '));
            }
        }
    } else if (window.location.host == "www.betway.com.gh") {
        appUrl = "https://appdownload.betwayafrica.com/?link=https://www.betway.com.gh/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + getCookie("OriginalQueryString") + "&apn=com.betwayafrica.gh&afl=https://cdn.betwayafrica.com/app/gh/index.html";
        appUrl = appUrl.replace("&&", "&");
        try {
            $('.app-downlod-icons a')[0].href = appUrl + "&isi=1361024170&ibi=Betway.Betway.Ghana&efr=1";
            $('.app-downlod-icons a')[1].href = appUrl + "&isi=1361024170&ibi=Betway.Betway.Ghana&efr=1";
            $('.app-downlod-icons a')[2].href = "https://appgallery.cloud.huawei.com/ag/n/app/C103850673?channelId=Web+Download&referrer=https%3A%2F%2Fbetway.com.gh%2F%3Fbtag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "&id=d20e76a6becb43428b8258ae54ae0636&s=11E2D8E90C7D93D6882B71F976152431B9FB0925C9578167DA2999476871235A&detailType=0&v=&callType=AGDLINK&installType=0000"
            document.querySelector('.app-store-container').addEventListener('click', () => {
                window.location.href = appUrl + "&isi=1361024170&ibi=Betway.Betway.Ghana&efr=1"
            });
        } catch (ex) {}
    } else if (window.location.host == "www.betway.com.ng") {
        appUrl = "https://info.betwayafrica.com/api/v1/AppDownload/?btag=" + encodeURI(getCookie("BTAGCOOKIE")) + "&" + getCookie("OriginalQueryString")
        appUrl = appUrl.replace("&&", "&");
        try {
            $('.app-store-desc').href = appUrl;
            $('.app-downlod-icons a')[0].href = appUrl;
            $('.app-downlod-icons a')[1].href = appUrl;
            $('.app-downlod-icons a')[2].href = appUrl;
            document.querySelector('.app-store-container').addEventListener('click', () => {
                window.location.href = appUrl
            });
        } catch (ex) {}
    } else if (window.location.host == "www.betway.co.ke") {
        appUrl = "https://appdownload.betwayafrica.com/?link=https://www.betway.co.ke/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + getCookie("OriginalQueryString") + "&apn=com.betwayafrica.ke&afl=https://cdn.betwayafrica.com/app/ke/index.html";
        appUrl = appUrl.replace("&&", "&");
        try {
            $('.app-downlod-icons a')[0].href = appUrl + "&isi=1324433430&ibi=com.betwa.kenya";
            $('.app-downlod-icons a')[1].href = appUrl + "&isi=1324433430&ibi=com.betwa.kenya";
            $('.app-downlod-icons a')[2].href = "https://appgallery.cloud.huawei.com/ag/n/app/C104766015?channelId=Web+Download&referrer=https%3A%2F%2Fbetway.co.ke%2F%3Fbtag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "&id=975e1ed3cbeb4207acde75bd760e76e2&s=DD6D99827439AC0CB31AD76032003122F91586D9A7901362D9C4C3089D7F535A&detailType=0&v=&callType=AGDLINK&installType=0000"
            document.querySelector('.app-store-container').addEventListener('click', () => {
                window.location.href = appUrl + "&isi=1324433430&ibi=com.betwa.kenya"
            });
        } catch (ex) {}
    } else if (window.location.host == "www.betway.ug") {
        appUrl = "https://appdownload.betwayafrica.com/?link=https://www.betway.ug/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + getCookie("OriginalQueryString") + "&apn=com.betwayafrica.ug&afl=https://cdn.betwayafrica.com/app/ug/index.html";
        appUrl = appUrl.replace("&&", "&");
        $('.app-downlod-icons a')[0].href = appUrl + "&isi=1361509142&ibi=theRangers.Betway&efr=1";
        $('.app-downlod-icons a')[1].href = appUrl + "&isi=1361509142&ibi=theRangers.Betway&efr=1";
        $('.app-downlod-icons a')[2].href = ""
        $("#nav-link-container .padding--top-lg").hide()
        $($(".footerColumn")[4]).hide();
        $($(".footer-social-icon")[2]).hide();
    } else if (window.location.host == "www.betway.co.zm") {
        appUrl = "https://appdownload.betwayafrica.com/?link=https://www.betway.co.zm/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + getCookie("OriginalQueryString") + "&apn=betway.zambia&afl=https://cdn.betwayafrica.com/app/zm/index.html";
        appUrl = appUrl.replace("&&", "&");
        try {
            $('.app-store-desc')[0].href = appUrl + "&isi=1513149768&ibi=com.betway.zm&efr=1";
            $('.app-downlod-icons a')[0].href = appUrl + "&isi=1513149768&ibi=com.betway.zm&efr=1";
            $('.app-downlod-icons a')[1].href = appUrl + "&isi=1513149768&ibi=com.betway.zm&efr=1";
            $('.app-downlod-icons a')[2].href = "https://appgallery.cloud.huawei.com/ag/n/app/C103884101?channelId=Web+Download&referrer=https%3A%2F%2Fbetway.co.zm%2F%3Fbtag%3D{btag}&id=fce43c525d124acab320c225c715a618&s=C8CDE8C8452DC97BD3BBD881F53844004E0849FC93BDAA91705619D80D4F7B35&detailType=0&v=&callType=AGDLINK&installType=0000"
            document.querySelector('.app-store-container').addEventListener('click', () => {
                window.location.href = appUrl + "&isi=1513149768&ibi=com.betway.zm&efr=1"
            });
        } catch (ex) {}
    }
}
if ((getParameterByName("register") !== "1") && window.location.host.indexOf("betway.datafree.co") !== 0 && window.location.host.indexOf("bet.freedev.betway.co.za") !== 0) {
    if (sessionStorage.getItem("PPC")) {} else {
        var script = document.createElement('script');
        script.async = true;
        script.src = "https://cdn.betwayafrica.com/BWA/toastMessages.js";
        document.head.appendChild(script);
    }
}
if (window.location.host === "www.betway.co.ke") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=afb7e249-0d8e-4b4e-95c7-a4558c27fb62";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
if (window.location.host === "www.betway.co.zm") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=717a3593-330b-4079-889e-abc478791513";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
if (window.location.host === "www.betway.co.tz") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=e0871faa-55c8-4e58-bbec-55e71a449606";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
if (window.location.host === "www.betway.com.ng") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=eabaa340-9d01-4633-a032-ca9914d173f6";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
if (window.location.host === "www.betway.co.za" || window.location.host === "bet.free.betway.co.za") {
    if (promoDetails.upid === 'b046e71f-c6ac-e711-80df-00155d001f46') {
        var script = document.createElement('script');
        script.src = "https://livechat-betway.connexone.co.uk/widget?connid=a54498ed-ed6b-4c7a-8a4f-c25053986fc0";
        script.id = "livechat-betway";
        script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
        document.head.appendChild(script);
    } else {
        var script = document.createElement('script');
        script.src = "https://livechat-betway.connexone.co.uk/widget?connid=bb127d31-f13d-4a78-b883-7c03ce0f0cb6";
        script.id = "livechat-betway";
        script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
        document.head.appendChild(script);
    }
}
if (window.location.host === "www.betway.com.gh") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=221f4d74-3311-409d-9a7c-2c4be480e539";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
if (window.location.host === "uat.betway.co.za") {
    var script = document.createElement('script');
    script.src = "https://livechat-betway.connexone.co.uk/widget?connid=a54498ed-ed6b-4c7a-8a4f-c25053986fc0";
    script.id = "livechat-betway";
    script.setAttribute("data-socket-uri", "https://livechat-betway.connexone.co.uk");
    document.head.appendChild(script);
}
setInterval(function() {
    $("#cx-chat-btn").remove();
}, 200);
$("<style>").prop("type", "text/css").html("#cx-nudge,#cx-chat{display:none}").appendTo("body");
window.__CONNEXONE_LIVECHAT_HOOKS__ = {
    onLoad: function() {
        $("#cx-nudge").hide();
        $("#cx-chat").hide();
    },
    onWidgetClosed: function() {
        $("#cx-nudge").hide();
        $("#cx-chat").hide();
    },
    onWidgetHidden: function() {
        $("#cx-nudge").hide();
        $("#cx-chat").hide();
    },
    onWidgetOpened: async function() {
        if (window.location.host === "uat.betway.co.za" && promoDetails.upid !== "00000000-0000-0000-0000-000000000000") {
            const response = await fetch("/HorseRacing/GetuserData");
            const userdata = await response.json();
            __CONNEXONE_LIVECHAT__.authenticateCustomer({
                "lead_reference": accNo,
                "case_reference": promoDetails.upid,
                "source_reference": userdata.Token
            }, () => {
                console.log('Authenticated with connexone, opening chat');
                $("#cx-chat").show();
                $("#cx-nudge").show();
            }, () => console.log('Could not authenticate with connexone'));
        } else {
            $("#cx-nudge").show();
            $("#cx-chat").show();
        }
    },
    onWidgetShown: function() {},
};

function _liveChat(n, t, i, r, u) {
    window.__CONNEXONE_LIVECHAT__.openWidget();
}
if (getParameterByName("AddToBetSlip")) {
    var outComes = getParameterByName("AddToBetSlip").split(';')
    for (let i = 0; i < outComes.length; i++) {
        window.addToBetslip(outComes[i]);
    }
}
if (window.location.href.toLowerCase().indexOf('https://www.betway.co.za/horseracing') > -1 || window.location.href.toLowerCase().indexOf('https://www.betway.co.za/horseracing') > -1) {
    if (isIOS || IsAndroid || sessionStorage.getItem("IsApp")) {
        var t = document.createElement("style");
        var n = document.createTextNode("#dynamicContent,#footer,.mb-footer-container {display:none!important}#lobbyIframe{height: calc(93vh)!important;}");
        t.appendChild(n)
        document.getElementsByTagName("head")[0].appendChild(t);
    } else {
        var t = document.createElement("style");
        var n = document.createTextNode("#dynamicContent,#footer,.mb-footer-container {display:none!important}#lobbyIframe{height: calc(100vh - 230.5px)!important;}");
        t.appendChild(n)
        document.getElementsByTagName("head")[0].appendChild(t);
    }
}
document.getElementsByTagName('body')[0].style.overflow = 'inherit'
if (window.location.pathname.indexOf('lobby') > -1) {
    setInterval(function() {
        if ($('#lobbyIframe').attr('src') === '') {
            lobby.initIframeResizer()
        }
    }, 1000)
}
if (window.location.host == "www.betway.com.gh") {
    setInterval(function() {
        if ($('a[href*="new.betway.com.gh/?bookingCode"]').length > 0) {
            $('a[href*="new.betway.com.gh/?bookingCode"]').attr('href', $('a[href*="new.betway.com.gh/?bookingCode"]').attr('href').replace('new.betway.com.gh', 'www.betway.com.gh/Home/SwitchSite'))
        }
    }, 1000)
    if (getParameterByName("bookingCode")) {
        window.location.href = 'https://www.betway.com.gh/Home/SwitchSite/?bookingCode=' + getParameterByName("bookingCode")
    }
}