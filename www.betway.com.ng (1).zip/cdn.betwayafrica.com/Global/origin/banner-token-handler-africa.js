function ApplyOriginLogic() {
    var parts = location.hostname.split('.');
    var subdomain = parts.shift();
    var upperleveldomain = parts.join('.');
    var OriginUrl = window.location.href;
    var domain = upperleveldomain;
    var urlParams = {};
    var info_api = 'https://info.betwayafrica.com/api/v1.0'
    var isSecure = window.location.protocol.match(/https/g) ? true : false;
    var tagAndTrackVersion = 13;
    var match, pl = /\+/g,
        search = /([^&=]+)=?([^&]*)/g,
        decode = function(s) {
            return decodeURIComponent(s.replace(pl, " "));
        },
        query = window.location.search.substring(1);
    while (match = search.exec(query)) {
        urlParams[decode(match[1])] = decode(match[2]);
    }
    var tagAndTrackStorageObject = JSON.parse(localStorage.getItem("tagAndTrack"));
    if (urlParams.btagoverride) {
        setCookie('BTAGCOOKIE', urlParams.btagoverride, 7);
        SetQueryStringParams();
        return
    }
    if (!tagAndTrackStorageObject || tagAndTrackStorageObject.version !== tagAndTrackVersion) {
        removeCookie('BTAGCOOKIE');
        removeCookie('REFERRERBTAGCOOKIE');
        removeCookie('MT');
        removeCookie('ST');
    }
    var current_btag = getCookie('BTAGCOOKIE');
    var master_token = getCookie('MT');
    var session_token = getCookie('ST');
    var current_referrer_btag = getCookie('REFERRERBTAGCOOKIE');
    if (document.location.pathname.indexOf('/blog') > -1) {
        removeCookie('BTAGCOOKIE');
        removeCookie('REFERRERBTAGCOOKIE');
        removeCookie('MT');
        removeCookie('ST');
    } else {
        if (current_btag === undefined || current_btag === null || current_btag.trim() === "") {
            getBannerTag();
        } else {
            if (current_referrer_btag === undefined || current_referrer_btag === null || current_referrer_btag.trim() === "") {
                getReferrerBannerTag();
            }
        }
        if (!master_token || !session_token) {
            getOriginToken();
        }
    }

    function getDomainName(hostName) {
        return hostName.substring(hostName.lastIndexOf(".", hostName.lastIndexOf(".") - 1) + 1);
    }

    function getOriginToken() {
        const request = new XMLHttpRequest();
        request.open('GET', `${info_api}/Origin/Tokens`);
        request.send();
        request.onload = async function() {
            const res = JSON.parse(this.response);
            if (window.location.host.indexOf(".co.mz") > -1) {} else {
                var ipAddress = res['Ip'];
                try {
                    var tempIp = ipAddress.split(".")
                    ipAddress = tempIp[0] + tempIp[1] + tempIp[2];
                } catch (ex) {}
                setCookie('ST', res['SessionToken']);
            }
            if (!master_token) {
                setCookie('MT', res['MasterToken'], 1825);
            }
        }
    }

    function getBannerTag() {
        try {
            const referrer = document.referrer.replace(/\?.*/gm, '') || window.location.origin;
            const request = new XMLHttpRequest();
            while (match = search.exec(query)) {
                urlParams[decode(match[1])] = decode(match[2]);
            }
            if (urlParams.btag && urlParams.btag.trim() === "") {
                urlParams.btag = undefined;
            }
            if (!urlParams.btag && sessionStorage.getItem('bannerTag')) {
                urlParams.btag = sessionStorage.getItem('bannerTag');
            }
            request.open('GET', `${info_api}/Origin/BannerTag?request.referringUrl=${referrer}`);
            request.setRequestHeader("X-OT-Origin", window.location.origin);
            request.send();
            request.onload = function() {
                const res = JSON.parse(this.response);
                tagAndTrackStorageObject = {
                    bannerTag: undefined,
                    version: tagAndTrackVersion
                }
                if ((urlParams.btag && urlParams.btag !== undefined && !current_btag)) {
                    tagAndTrackStorageObject.bannerTag = urlParams.btag;
                    setCookie('BTAGCOOKIE', urlParams.btag, 7);
                    setSessionCookie('REFERRERBTAGCOOKIE', urlParams.btag);
                    SetQueryStringParams();
                } else if ((!current_btag) && !urlParams.btag) {
                    tagAndTrackStorageObject.bannerTag = res['BannerTagString'];
                    setCookie('BTAGCOOKIE', res['BannerTagString'], 7);
                    setSessionCookie('REFERRERBTAGCOOKIE', res['BannerTagString']);
                    SetQueryStringParams();
                } else {
                    tagAndTrackStorageObject.bannerTag = "No Tag";
                    setCookie('BTAGCOOKIE', "No Tag", 1);
                    setSessionCookie('REFERRERBTAGCOOKIE', "No Tag");
                    SetQueryStringParams();
                }
                localStorage.setItem("tagAndTrack", JSON.stringify(tagAndTrackStorageObject));
            }
            request.onerror = function(e) {
                setTimeout(ApplyOriginLogic(), 3000);
            };
            request.onabort = function(e) {
                setTimeout(ApplyOriginLogic(), 3000);
            }
            request.timeout = function(e) {
                setTimeout(ApplyOriginLogic(), 3000);
            }
        } catch (err) {
            tagAndTrackStorageObject.bannerTag = err.message;
            setCookie('BTAGCOOKIE', err.message, 1);
            SetQueryStringParams();
        }
    }

    function getReferrerBannerTag() {
        try {
            const referrer = document.referrer.replace(/\?.*/gm, '') || window.location.origin;
            const request = new XMLHttpRequest();
            if (urlParams.btag && urlParams.btag.trim() === "") {
                urlParams.btag = undefined;
            }
            request.open('GET', `${info_api}/Origin/BannerTag?request.referringUrl=${referrer}`);
            request.setRequestHeader("X-OT-Origin", window.location.origin);
            request.send();
            request.onload = function() {
                const res = JSON.parse(this.response);
                if ((urlParams.btag && urlParams.btag !== undefined && !current_referrer_btag)) {
                    setSessionCookie('REFERRERBTAGCOOKIE', urlParams.btag);
                } else if ((!current_referrer_btag) && !urlParams.btag) {
                    setSessionCookie('REFERRERBTAGCOOKIE', res['BannerTagString']);
                } else {
                    setSessionCookie('REFERRERBTAGCOOKIE', "No Tag");
                }
            }
        } catch (err) {
            tagAndTrackStorageObject.bannerTag = err.message;
            setSessionCookie('REFERRERBTAGCOOKIE', err.message);
            SetQueryStringParams();
        }
    }

    function SetQueryStringParams() {
        if (sessionStorage.getItem('OriginalQueryString')) {
            setCookie("OriginalQueryString", sessionStorage.getItem('OriginalQueryString'), 7)
        } else {
            var websiteUrl = window.location.href;

            function removeURLParameter(url, parameter) {
                var urlparts = url.split('?');
                if (urlparts.length >= 2) {
                    var prefix = encodeURIComponent(parameter) + '=';
                    var pars = urlparts[1].split(/[&;]/g);
                    for (var i = pars.length; i-- > 0;) {
                        if (pars[i].lastIndexOf(prefix, 0) !== -1) {
                            pars.splice(i, 1);
                        }
                    }
                    return urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : '');
                }
                return url;
            }
            websiteUrl = removeURLParameter(websiteUrl, "mobileNumber");
            websiteUrl = removeURLParameter(websiteUrl, "email");
            websiteUrl = removeURLParameter(websiteUrl, "firstName");
            websiteUrl = removeURLParameter(websiteUrl, "lastName");
            websiteUrl = removeURLParameter(websiteUrl, "MobileNumber");
            websiteUrl = removeURLParameter(websiteUrl, "Email");
            websiteUrl = removeURLParameter(websiteUrl, "FirstName");
            websiteUrl = removeURLParameter(websiteUrl, "LastName");
            var t = websiteUrl.split("?");
            2 === t.length ? setCookie("OriginalQueryString", t[1], 7) : setCookie("OriginalQueryString", "/", 7);
        }
    }

    function getCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    function setCookie(name, value, days) {
        var current_date = new Date;
        current_date.setTime(current_date.getTime() + 24 * 60 * 60 * 1000 * days);
        if (isSecure) {
            document.cookie = name + "=" + value + ";domain=" + domain + ";samesite=None;secure=true;path=/;expires=" + current_date.toGMTString();
        } else {
            document.cookie = name + "=" + value + ";domain=" + domain + ";samesite=No Restriction;path=/;expires=" + current_date.toGMTString();
        }
    }

    function setSessionCookie(name, value) {
        if (isSecure) {
            document.cookie = name + "=" + value + ";domain=" + domain + ";samesite=None;secure=true;path=/;expires=0";
        } else {
            document.cookie = name + "=" + value + ";domain=" + domain + ";samesite=samesite=No Restriction;path=/;expires=0";
        }
    }

    function removeCookie(name) {
        if (getCookie(name)) {
            document.cookie = name + "=" +
                ((domain) ? ";domain=" + domain : "") +
                ";expires=Thu, 01 Jan 1970 00:00:01 GMT";
            document.cookie = name + "=" + ("" || "") + ";expires=Thu, 01 Jan 1970 00:00:01 GMT" + "; path=/";
        }
    }

    function logError(message) {
        message = message + " " + window.location.href;

        function makeAjaxCall(verb, url, params, callback) {
            var xhr = new XMLHttpRequest();
            xhr.timeout = 2000;
            xhr.onreadystatechange = function() {
                var DONE = 4;
                var OK = 200;
                if (xhr.readyState === DONE) {
                    var response = {
                        error: null,
                        data: null,
                        responseCode: null
                    };
                    response.responseCode = xhr.status;
                    if (xhr.status === OK) {
                        response.data = JSON.parse(xhr.responseText);
                    } else {
                        response.responseCode = xhr.responseText;
                    }
                    callback(response);
                }
            };
            xhr.open(verb, url);
            if (params) {
                xhr.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                xhr.send(JSON.stringify(params));
            } else {
                xhr.send();
            }
        }
        var params = {
            "level": "Error",
            "messageTemplate": "{0}",
            "message": message,
            "exceptions": [],
            "fields": {
                "_department": "itdigitalchannels",
                "_applicationType": "website",
                "_applicationName": "bannertags",
                "environment": "Production"
            }
        };
        var callback = function() {};
        makeAjaxCall("POST", "https://loggingapi.gmgamingsystems.com/api/v1/logstash/log", params, callback);
    }

    function loadMarketingJs() {
        if ((window.location.host !== "www.betway.co.mz" && window.location.host !== "www.betway.co.tz" && window.location.host !== "www.betway.mw") && sessionStorage.getItem("mkLoaded") === "false") {
            var script = document.createElement('script');
            script.async = true;
            script.src = "https://cdn.betwayafrica.com/BWA/client.js";
            document.head.appendChild(script);
            sessionStorage.setItem("mkLoaded", true);
        }
    }
    var marketingInterval = setInterval(function() {
        if (getCookie('BTAGCOOKIE') && getCookie('MT') && getCookie('ST')) {
            if (typeof promoDetails !== "undefined") {
                loadMarketingJs();
            }
            clearInterval(marketingInterval);
        }
    }, 200);
}

function setIntervalOriginTracking(callback, delay, repetitions) {
    var x = 0;
    var intervalID = window.setInterval(function() {
        callback();
        if (++x === repetitions) {
            window.clearInterval(intervalID);
        }
    }, delay);
}
sessionStorage.setItem("mkLoaded", false);
setIntervalOriginTracking(function() {
    ApplyOriginLogic();
}, 5000, 10);
ApplyOriginLogic();