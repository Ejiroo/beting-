function toCamelCase(n) {
    return n.replace(/(?:^\w|[A-Z]|\b\w)/g, function(n, t) {
        return t == 0 ? n.toLowerCase() : n.toUpperCase()
    }).replace(/\s+/g, "")
}(function(n) {
    n.forEach(function(n) {
        n.hasOwnProperty("prepend") || Object.defineProperty(n, "prepend", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: function() {
                var t = Array.prototype.slice.call(arguments),
                    n = document.createDocumentFragment();
                t.forEach(function(t) {
                    var i = t instanceof Node;
                    n.appendChild(i ? t : document.createTextNode(String(t)))
                });
                this.insertBefore(n, this.firstChild)
            }
        })
    })
})([Element.prototype, Document.prototype, DocumentFragment.prototype]);
var betwayTV = {
    generateList: function() {
        try {
            pat.get("/BetwayTV/GetStreamingMatches").done(function(n) {
                var i = n.MatchList,
                    r = i.reduce(function(n, t) {
                        return n[t.SportTitle] = n[t.SportTitle] || [], n[t.SportTitle].push(t), n
                    }, Object.create(null)),
                    t;
                (sessionStorage.getItem("streamList") == "" || sessionStorage.getItem("streamList") == null || sessionStorage.getItem("streamList") == []) && sessionStorage.setItem("streamList", JSON.stringify(r));
                t = $("#betwayTV");
                (!0 || typeof t != "undefined") && betwayTV.createStreamlist()
            })
        } catch (n) {
            console.log(n)
        }
    },
    displayStreamer: function(n, t, i, r, u) {
        if (n == null || n === "") return betwayTV.requestStreamingUrlForEvent(u, t, i, r);
        sessionStorage.setItem("Sport", toCamelCase(i));
        sessionStorage.setItem("Event", t);
        sessionStorage.setItem("EventId", u);
        sessionStorage.setItem("Multimarket", r);
        document.querySelector(".playerControls > .streamMoreBets").setAttribute("onclick", 'location.href="' + r + '"');
        $.getScript("/bundles/avvpl-player.js").done(function() {
            betwayTV.initStreamer(n)
        })
    },
    requestStreamingUrlForEvent: function(n, t, i, r) {
        try {
            if (n == null || n == "") return;
            pat.get("/BetwayTV/GetStreamLink", {
                eventId: n,
                mobileDevice: isMobile
            }).done(function(u) {
                console.log(u);
                var f = "";
                f = u;
                console.log(f);
                betwayTV.displayStreamer(f, t, i, r, n)
            })
        } catch (u) {
            console.log(u)
        }
    },
    removePlayer: function() {
        $(".sravvpl_wrapper").remove();
        $("#betwayTvContainer").hide();
        sessionStorage.removeItem("startStreaming");
        sessionStorage.removeItem("streamSrc")
    },
    initStreamer: function(n) {
        var u = window.width <= 768,
            i, r, t;
        u ? $("#betwayTvContainer").addClass("mobile") : $("#betwayTvContainer").addClass("desktop");
        i = {
            id: "betwayTvPlayer",
            allowFullScreen: sessionStorage.getItem("fullScreen"),
            autoplay: !0,
            mute: !0
        };
        r = document.querySelector(".sravvpl_wrapper");
        typeof r == "undefined" || r == null ? (t = new avvpl.setupPlayer(i), t.load(n, "video/webm"), sessionStorage.setItem("startStreaming", "true"), sessionStorage.setItem("streamSrc", n), $(".matchedEvent") !== "undefined" && $(".matchedEvent").html(sessionStorage.getItem("Event"))) : (betwayTV.removePlayer(), t = new avvpl.setupPlayer(i), t.load(n, "video/webm"), sessionStorage.setItem("streamSrc", n), $(".matchedEvent") !== "undefined" && $(".matchedEvent").html(sessionStorage.getItem("Event")));
        $("#betwayTV").modal("hide");
        $("#betwayTvContainer").attr("style", "display: flex; justify-content: center; align-items: center; flex-direction: column;")
    },
    createDropdown: function() {
        var e = JSON.parse(sessionStorage.getItem("streamList")),
            i, r, t, u, n, f;
        for (z in e) {
            for (i = e[z].sort(function(n, t) {
                    var i = n.Competition,
                        r = t.Competition;
                    return i < r ? -1 : i > r ? 1 : 0
                }), r = document.createElement("optgroup"), r.setAttribute("id", "streamingList"), r.setAttribute("class", toCamelCase(z)), r.setAttribute("label", z), t = 0; t < i.length; t++) u = i[t].SportTitle, n = document.createElement("option"), n.setAttribute("class", "streamingItem ellips"), n.setAttribute("id", i[t].EventId), n.setAttribute("data-url", ""), n.setAttribute("data-eventTitle", i[t].EventTitle), n.setAttribute("data-sportTitle", i[t].SportTitle), n.setAttribute("data-friendlyUrl", i[t].FriendlyUrl), n.setAttribute("data-eventId", i[t].EventId), n.innerHTML = "<span class='ellips'>" + i[t].EventTitle + "<\/span>", language.translateAtRuntime(n, "BetwayTVDialog", {
                "data-translate-key": language.generateKey(i[t].EventTitle)
            }), f = document.createElement("i"), f.setAttribute("class", "sportsEventTile img-" + toCamelCase(u)), n.value = "<i class='sportsEventTile img -" + toCamelCase(u) + "'><\/i>", n.prepend(f), r.appendChild(n);
            document.querySelector("#streamSelection").appendChild(r)
        }
    },
    createStreamlist: function() {
        var h = document.querySelector(".streamingList-container"),
            c = JSON.parse(sessionStorage.getItem("streamList")),
            t, r, n, e, i, o, u, s, f, l;
        if (!0 || typeof h != "undefined")
            for (z in c) {
                for (t = c[z].sort(function(n, t) {
                        var i = n.Competition,
                            r = t.Competition;
                        return i < r ? -1 : i > r ? 1 : 0
                    }), r = document.createElement("ul"), r.setAttribute("id", "streamingList"), r.setAttribute("class", toCamelCase(z)), n = 0; n < t.length; n++) e = t[n].SportTitle, i = document.createElement("li"), i.setAttribute("class", "streamingItem ellips"), i.setAttribute("data-url", ""), i.setAttribute("data-eventTitle", t[n].EventTitle), i.setAttribute("data-sportTitle", t[n].SportTitle), i.setAttribute("data-friendlyUrl", t[n].FriendlyUrl), i.setAttribute("data-eventId", t[n].EventId), i.setAttribute("onclick", "betwayTV.displayStreamer('','" + t[n].EventTitle + "','" + t[n].SportTitle + "','" + t[n].FriendlyUrl + "','" + t[n].EventId + "')"), o = document.createElement("div"), o.setAttribute("class", "streamIcon pull-right"), o.innerHTML = "<span class='fa fa-video-camera icon-clicked'><\/span>", u = document.createElement("button"), u.setAttribute("class", "pull-right streamMoreBets"), u.innerHTML = "More<\/br>Bets", language.translateAtRuntime(u, "BetwayTVDialog", {
                    "data-translate-key": "MoreBets"
                }), u.setAttribute("onclick", 'location.href="' + t[n].FriendlyUrl + '"'), s = document.createElement("i"), s.setAttribute("class", "sportsEventTile img-" + toCamelCase(e)), i.innerHTML = "<span class='matchName ellips'>" + t[n].EventTitle + "<\/span>", i.appendChild(o), i.prepend(s), i.appendChild(u), r.appendChild(i);
                f = document.createElement("div");
                f.setAttribute("class", "streamHeading");
                f.innerHTML = e;
                language.translateAtRuntime(f, "BetwayTVDialog", {
                    "data-translate-key": language.generateKey(e)
                });
                r.prepend(f);
                l = document.querySelector(".loadingStreams");
                l && (document.querySelector(".loadingStreams").style.display = "none");
                h.appendChild(r)
            }
    },
    resizeStreamVideo: function() {
        if ($("#videoResizeDisplay").hasClass("media-resize-mini")) {
            var t = $(window).width() / 2,
                n = $(window).height() / 2,
                i = n - 100;
            document.getElementById("betwayTvContainer").style.width = t + "px";
            document.getElementById("betwayTvContainer").style.height = n - 50 + "px";
            $(".sravvpl_wrapper").attr("style", "height:" + (n - 100) + "px !important; width:" + t + "px !important");
            $("#videoResizeDisplay").addClass("media-resize-maxi");
            $("#videoResizeDisplay").removeClass("media-resize-mini")
        } else document.getElementById("betwayTvContainer").style.width = "290px", document.getElementById("betwayTvContainer").style.height = "212.5px", $(".sravvpl_wrapper").css("height", "157.5px"), $(".sravvpl_wrapper").css("width", "280px"), $(".sravvpl_wrapper").removeAttr("style"), $("#videoResizeDisplay").removeClass("media-resize-maxi"), $("#videoResizeDisplay").addClass("media-resize-mini"), $(".player-container").css("height", null), $(".player-position").css("height", null), $("#screen-size").css("margin-top", "4px")
    },
    getUrlParameter: function(n) {
        for (var u = window.location.search.substring(1), r = u.split("&"), t, i = 0; i < r.length; i++)
            if (t = r[i].split("="), t[0] === n) return t[1] === undefined ? !0 : decodeURIComponent(t[1])
    }
};
$(function() {
    function r(n) {
        var t = n.offset().top,
            i = $(window).scrollTop();
        return t - i
    }
    var n, i, t;
    $(window).width() <= 768 ? (sessionStorage.setItem("fullScreen", "true"), sessionStorage.setItem("Mobile", !0)) : (sessionStorage.setItem("fullScreen", "false"), sessionStorage.setItem("Mobile", !1));
    n = $(".mg-streamer-toggle");
    (typeof n != null || typeof n != "undefined") && n.attr("id") == sessionStorage.getItem("EventId") && n.addClass("active");
    i = $("#betwayTV");
    $("#betwayTV").one("shown.bs.modal", function() {
        betwayTV.generateList()
    });
    sessionStorage.getItem("startStreaming") == "true" && $.getScript("/bundles/avvpl-player.js").done(function() {
        var n = sessionStorage.getItem("streamSrc"),
            t = sessionStorage.getItem("Multimarket");
        $(".playerControls > .streamMoreBets").attr("onclick", 'location.href="' + t + '"; sessionStorage.setItem("startStreaming","true")');
        betwayTV.initStreamer(n)
    });
    $("#streamSelection").change(function() {
        var n = $("#streamSelection option:selected").attr("data-url"),
            t = $("#streamSelection option:selected").attr("data-eventTitle"),
            i = $("#streamSelection option:selected").attr("data-sportTitle"),
            r = $("#streamSelection option:selected").attr("data-friendlyUrl"),
            u = $("#streamSelection option:selected").attr("data-eventId");
        betwayTV.displayStreamer(n, t, i, r, u)
    });
    t = $(".betwayTvContainer");
    t.draggable({
        stop: function(n, t) {
            var i = r(t.helper);
            t.helper.css("position", "fixed");
            t.helper.css("top", i + "px")
        }
    })
})