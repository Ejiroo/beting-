function GenerateThousandSeperatorVisualElement(n, t) {
    var i = $(n).clone(!1),
        r;
    i.attr("type", "text");
    i.hasClass("SeperatorkeepEvents") || (i.removeAttr("onchange"), i.removeAttr("onkeyup"));
    i.removeClass("numberSeperatorMask");
    i.attr("id", t.attr("id") + "label");
    thousandSeperatorDataObjs[t.attr("id")] = new visualObj(i.attr("id"));
    t.hide();
    t.is("input") ? (i.attr("id") == "potentialReturnWithStretchVallabel" ? (r = String(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })), r.length >= 11 ? i.val(String(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }))).slice(0, r.length - 3) : i.val(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }))) : i.val(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })), i.attr("inputmode", "decimal")) : i.attr("id") == "potentialReturnWithStretchVallabel" ? (r = String(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })), r.length >= 11 ? i.html(String(Number(t.val()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }))).slice(0, r.length - 3) : i.html(Number(t.html()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }))) : i.html(Number(t.html()).toLocaleString("en", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }));
    $(n).after(i);
    i.is("input") && (i.keyup(function(n) {
        var r = n.which,
            u, s;
        if (r === 13) {
            n.preventDefault();
            this.blur();
            return
        }(r === 32 || r === 13 || r === 188 || r === 186) && this.blur();
        var f = i.val().match(/\./g || []),
            h = f === null ? !1 : f.length > 1 || f.length < 1,
            c = f === null ? !1 : f.length === 1;
        h && (r === 190 || r === 110 || r === 229) && this.blur();
        u = countDecimals(i.val());
        u > 2 && (u = 2);
        var l = i.val().length,
            o = i.prop("selectionStart"),
            a = i.val().length - o > 3,
            e = Number(ReplaceAll(i.val(), ",", ""));
        t.val(e);
        s = c && u === 0 ? e.toLocaleString("en", {
            minimumFractionDigits: u,
            maximumFractionDigits: u
        }) + "." : e.toLocaleString("en", {
            minimumFractionDigits: u,
            maximumFractionDigits: u
        });
        i.val(s);
        t.trigger("change");
        UpdateVisualElementsOnBetslip();
        SetCaretPosition(i.attr("id"), i.val().length - l + o)
    }), i.blur(function() {
        var n;
        t.is("input") ? i.attr("id") == "potentialReturnWithStretchVallabel" ? (n = String(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })), n.length >= 11 ? i.val(String(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))).slice(0, n.length - 3) : i.val(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))) : i.val(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })) : i.attr("id") == "potentialReturnWithStretchVallabel" ? (n = String(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })), n.length >= 11 ? i.html(String(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))).slice(0, n.length - 3) : i.html(Number(t.val()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))) : i.html(Number(t.html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))
    }));
    miniBetslip()
}

function visualObj(n) {
    this.VisualElementName = n
}

function UpdateVisualElementsOnBetslip() {
    !checkForLite() && isThousandSeperatorEnabled && Object.keys(thousandSeperatorDataObjs).forEach(function(n) {
        var r = -1.01,
            i = -2.01,
            t, f, o, e, s, u;
        $("#" + thousandSeperatorDataObjs[n].VisualElementName).is("input") ? (r = ReplaceAll($("#" + thousandSeperatorDataObjs[n].VisualElementName).val(), ",", ""), i = $("#" + n).val()) : (r = ReplaceAll($("#" + thousandSeperatorDataObjs[n].VisualElementName).html(), ",", ""), i = $("#" + n).html());
        t = 0;
        $("#" + thousandSeperatorDataObjs[n].VisualElementName).prop("readonly") ? t = 2 : (t = $("#" + thousandSeperatorDataObjs[n].VisualElementName).is("input") ? countDecimals($("#" + thousandSeperatorDataObjs[n].VisualElementName).val()) : countDecimals($("#" + thousandSeperatorDataObjs[n].VisualElementName).html()), t > 2 && (t = 2));
        f = r === undefined ? null : r.match(/\./g || []);
        o = f === null ? !1 : f.length === 1;
        o && t === 0 && (e = i.match(/\./g || []), e !== null && e ? (s = i.indexOf(".") + 1, i = i.substring(0, s)) : i += ".");
        i !== r && ((i === "NaN" || r === "NaN") && console.log("thousand separator error: " + i + " objval: " + r + " converted elementVal: " + Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: t,
            maximumFractionDigits: t
        })), $("#" + thousandSeperatorDataObjs[n].VisualElementName).is("input") ? thousandSeperatorDataObjs[n].VisualElementName == "potentialReturnWithStretchVallabel" ? (u = String(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })), u.length >= 11 ? $("#" + thousandSeperatorDataObjs[n].VisualElementName).val(String(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })).slice(0, u.length - 3)) : $("#" + thousandSeperatorDataObjs[n].VisualElementName).val(Number($("#" + n).val()).toLocaleString("en", {
            minimumFractionDigits: t,
            maximumFractionDigits: t
        }))) : $("#" + thousandSeperatorDataObjs[n].VisualElementName).val(Number($("#" + n).val()).toLocaleString("en", {
            minimumFractionDigits: t,
            maximumFractionDigits: t
        })) : thousandSeperatorDataObjs[n].VisualElementName == "potentialReturnWithStretchVallabel" ? (u = String(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })), u.length >= 11 ? $("#" + thousandSeperatorDataObjs[n].VisualElementName).html(String(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })).slice(0, u.length - 3)) : $("#" + thousandSeperatorDataObjs[n].VisualElementName).html(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }))) : $("#" + thousandSeperatorDataObjs[n].VisualElementName).html(Number($("#" + n).html()).toLocaleString("en", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })))
    });
    miniBetslip()
}

function SetCaretPosition(n, t) {
    var i = document.getElementById(n),
        r;
    i.value = i.value;
    i !== null && (i.createTextRange ? (r = i.createTextRange(), r.move("character", t), r.select()) : i.selectionStart || i.selectionStart === 0 ? (i.focus(), i.setSelectionRange(t, t)) : i.focus())
}

function ReplaceAll(n, t, i) {
    if (t === i || n === undefined) return n;
    for (var r = n, u = r.indexOf(t); u != -1;) r = r.replace(t, i), u = r.indexOf(t);
    return r
}

function toggleStakeReturnVisibility(n) {
    $("#BetslipItem-" + n).find(".toggle-stake-return").hasClass("hidden") ? ($("#BetslipItem-" + n).find(".toggle-stake-return").removeClass("hidden"), $("#betslipAmountsToggle" + n).toggleClass("md-angle-down-13 md-angle-up-13")) : ($("#BetslipItem-" + n).find(".toggle-stake-return").addClass("hidden"), $("#betslipAmountsToggle" + n).toggleClass("md-angle-up-13 md-angle-down-13"))
}
var mybetslip = {
        isMobileDevice: function() {
            return typeof orientation != "undefined" || navigator.userAgent.indexOf("IEMobile") !== -1
        },
        isInViewport: function(n) {
            if (n) {
                var t = n.getBoundingClientRect();
                return t.top >= 0 && t.left >= 0 && t.bottom <= (window.innerHeight || document.documentElement.clientHeight) && t.right <= (window.innerWidth || document.documentElement.clientWidth)
            }
            return null
        },
        checkForPotVisVisible: function(n, t) {
            var i = GetBetslipOption("IsSingleBet") === !0;
            mybetslip.isInViewport(t) || i ? n.hide(500) : mybetslip.isInViewport(t) === !1 ? n.show(500) : n.hide(500);
            $(".betslip-overlay-container").length && $(".betslip-overlay-container").is(":hidden") && n.hide(500)
        },
        checkIt: function() {
            mybetslip.checkForPotVisVisible(potVis, winnings)
        },
        processIfIsMobile: function() {
            var r = GetBetslipOption("IsSingleBet") === !0,
                t, n, i;
            if (isMobile === !1 && window.innerHeight <= 1080) {
                t = $(".potReturn");
                n = document.getElementById("txtKeepBetsContainer");
                (typeof n == "undefined" || n === null) && (n = document.getElementById("placeCashBet"));
                document.getElementById("betslip-container").setAttribute("style", "margin-bottom: 0px !important");
                document.querySelector(".betslip-body").setAttribute("style", "overflow: visible; flex-shrink: 0;");
                document.querySelector(".betslip-body").setAttribute("style", "flex-shrink:1; overflow: visible; height: unset");
                window.onload = function() {
                    mybetslip.checkForPotVisVisible(t, n)
                };
                document.querySelector("#headerBtnBetslip").addEventListener("click", function() {
                    mybetslip.checkForPotVisVisible(t, n)
                }, !1);
                document.querySelector(".betslip-overlay-container").addEventListener("scroll", function() {
                    mybetslip.checkForPotVisVisible(t, n)
                });
                $(".btn-bettingmatch").each(function() {
                    $(this).on("click", function() {
                        mybetslip.checkForPotVisVisible(t, n)
                    })
                });
                i = document.getElementById("clear_line");
                i && i.addEventListener("click", mybetslip.checkIt, !1);
                $(".potReturn").on("click", function() {
                    $(".betslip-overlay-container").animate({
                        scrollTop: $(".betslip-overlay-container").prop("scrollHeight")
                    }, 1e3)
                });
                $("#sb_id").on("click", function() {
                    t.hide(500)
                });
                $("#mb_id").on("click", function() {
                    BetslipContainsBuildABet() || t.show(500)
                })
            }
        },
        handleWagerKeyPress: function(n) {
            n.keyCode === 13 && (n.preventDefault(), n.currentTarget.blur());
            UpdatePotentialSingleReturn(n.currentTarget.id.replace("wagerAmount", ""))
        },
        chooseMe: function(n) {
            $(n).find("input:checkbox:first").click()
        },
        DoEmptyCheck: function() {
            this.val === "" && (this.value = parseFloat(GetBetslipOption("MinBetAmount")).toFixed(2), UpdateVisualElementsOnBetslip())
        },
        betslipScroll: function() {
            var n = $(".potReturn"),
                t = document.querySelector(".header-container").offsetHeight,
                i = document.querySelector(".betslip-header").offsetHeight,
                r = t + i + "px";
            $(".betslip-overlay-container").attr("style", "max-height: calc(100vh - " + r + " - 10px); overflow: scroll");
            $(n).attr("style", "width:93%; position:absolute;")
        },
        showSportsBonusQualifyingCriteriaModal: function() {
            $("#SportsBonusQualifyingCriteriaModal").modal()
        },
        updateBetslipCount: function() {
            var n = JSON.parse(GetBetslip());
            n.length !== null && global.PostAppMessage('{ "message" : "BetslipCount", "data" : { "Count" :' + n.length + "} }")
        }
    },
    countDecimals;
$(document).ready(function() {
    var n, t;
    isMobile === !0 && $(".potReturn").hide();
    window.innerHeight >= 861 && $(".potReturn").hide();
    mybetslip.processIfIsMobile();
    mybetslip.betslipScroll();
    n = GetBetslipOption("IsSingleBet") === !0;
    $("#mb_id").removeClass("active liveInPlayClr");
    $("#sb_id").removeClass("active liveInPlayClr");
    n ? $("#sb_id").addClass("active") : $("#mb_id").addClass("active");
    $("#wagerAmount").keyup(function(n) {
        var t = n.which;
        t === 13 && n.preventDefault();
        (t === 32 || t === 13 || t === 188 || t === 186) && this.blur();
        UpdatePotentialReturn();
        UpdateVisualElementsOnBetslip()
    });
    $("#chkKeepBets").on("click", function() {
        $(this).is(":checked") ? global.setCookie("KeepBets", "checked") : global.setCookie("KeepBets", "")
    });
    (typeof GetBetslip() != "undefined" && GetBetslip() !== null && GetBetslip() !== "{}" || document.getElementById("chkKeepBets") !== null && document.getElementById("chkKeepBets").checked === !0) && mybets.toggleToBetslip("betslipHeader");
    t = parseFloat(localStorage.getItem("sportsBonusMaxPayoutLimit"));
    SetBetslipOption("MinBetAmount", minBetAmount);
    SetBetslipOption("MinimumFreeBet", minimumFreeBet);
    SetBetslipOption("HasFreeBets", hasFreeBets);
    SetBetslipOption("MaxBetAmount", maxBetAmount);
    SetBetslipOption("MaxPayoutMultiple", maxPayoutMultiple);
    SetBetslipOption("FreeBetMaxPayoutMultiple", freeBetMaxPayoutMultiple);
    SetBetslipOption("MaxPayoutSingle", maxPayoutSingle);
    SetBetslipOption("PotentialReturnName", potentialReturnName);
    SetBetslipOption("TotalReturnName", totalReturnName);
    SetBetslipOption("SingleFreebetId", "");
    SetBetslipOption("maxBetsPerBetslips", maxBetsPerBetslips);
    SetBetslipOption("AccountHasFica", accountHasFica);
    SetBetslipOption("StretchOfferApplied", "00000000-0000-0000-0000-000000000000");
    SetBetslipOption("SportsBonusMaximumPayout", t);
    isNaN(parseFloat(GetBetslipOption("InitialStake"))) && SetBetslipOption("InitialStake", parseFloat(minBetAmount).toFixed(2));
    isNaN(parseFloat(GetBetslipOption("WagerAmount"))) && SetBetslipOption("WagerAmount", minBetAmount);
    typeof GetBetslipOption("IsSingleBet") == "undefined" && SetBetslipOption("IsSingleBet", !1);
    UpdatePotentialReturn();
    enableWagerTax && checkWager();
    enableTax && (IsStretchEnabled() && (stretchBoostedAmount = parseFloat(document.getElementById("boostedAmount").value)), winningsTax());
    UpdateVisualElementsOnBetslip()
});
setTimeout(function() {
    setInterval(function() {
        $(".numberSeperatorMask").each((n, t) => {
            var i, r, u;
            !checkForLite() && isThousandSeperatorEnabled && (i = $(t), thousandSeperatorDataObjs[i.attr("id")] == null ? GenerateThousandSeperatorVisualElement(t, i) : (r = i.attr("id"), u = $("#" + thousandSeperatorDataObjs[r].VisualElementName).length == 0, i.is(":visible") && thousandSeperatorDataObjs[i.attr("id")].VisualElementName != undefined && !$("#" + thousandSeperatorDataObjs[i.attr("id")].VisualElementName).is(":visible") && $("#" + thousandSeperatorDataObjs[i.attr("id")].VisualElementName).length > 0 ? ($("#" + thousandSeperatorDataObjs[i.attr("id")].VisualElementName).toggle(), i.toggle(), UpdateVisualElementsOnBetslip()) : i.is(":visible") && u && GenerateThousandSeperatorVisualElement(t, i)))
        })
    }, 150)
}, 1500);
countDecimals = function(n) {
    return Math.floor(n) !== n && n !== undefined && n.indexOf(".") > -1 ? n.toString().split(".")[1].length || 0 : 0
}