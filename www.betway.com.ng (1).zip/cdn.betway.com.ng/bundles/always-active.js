$(document).ready(function() {
    function u(n) {
        f("#footer-realtime-clock", t, n)
    }

    function e(t) {
        f("#footer-sessiontime-clock", n, t)
    }

    function f(n, t, i) {
        t.setSeconds(t.getSeconds() + i);
        $(n).text(r(t.getHours()) + ":" + r(t.getMinutes()) + ":" + r(t.getSeconds()))
    }

    function r(n) {
        return n < 10 ? "0" + n : n
    }
    var i = $("#footer-realtime-clock").text().split(":"),
        t = new Date,
        n;
    t.setHours(i[0]);
    t.setMinutes(i[1]);
    t.setSeconds(i[2]);
    u(0);
    $("#footer-sessiontime-clock") !== undefined && $("#footer-sessiontime-clock").length > 0 && (n = new Date, n.setHours(0), n.setMinutes(0), n.setSeconds(0), n.setMilliseconds(Math.abs(currentDateTime - loggedInDateTime)));
    setInterval(function() {
        u(1);
        n && e(1)
    }, 1e3)
})