var buildABetGuid = "00000000-0000-0000-da7a-000000710003",
    currentEventId = "00000000-0000-0000-0000-000000000000",
    isBuildABet = !1,
    enableLogging = !1,
    buildABet = {
        isBuildABetActive: function() {
            return isBuildABet
        },
        setBuildABetActive: function(n) {
            var i = n ? "block" : "none",
                t;
            isBuildABet = n;
            t = document.getElementById("buildABetItemsContainer");
            typeof t != "undefined" && t !== null && (document.getElementById("buildABetBetslipContainer").style.display = i, document.querySelector(".buildABet-notice").style.display = i, buildABet.setToggleVisibleStates(!n), t.children.length === 0 && (typeof buildABet != "undefined" || buildABet !== null) && (buildABet.toggleBuildABetBetslip(), buildABet.collapseBuildABetTempBetslip()))
        },
        inBuildABetTab: function() {
            var n = document.getElementById("buildABetItemsContainer");
            return typeof n != "undefined" && n !== null
        },
        setToggleVisibleStates: function(n) {
            n ? ($("#_AllOutcomes .outcome-pricedecimal, .bolt-icon-outcome-mb, .bolt-icon-market-mb").removeClass("hidden"), $(".co-img-white").removeClass("hidden"), $("#_AllOutcomes .buildabet-pricedecimal").addClass("hidden"), $("#_AllOutcomes .outcome-title").removeClass("buildabet-outcome-title")) : ($("#_AllOutcomes .outcome-pricedecimal, .bolt-icon-outcome-mb, .bolt-icon-market-mb").addClass("hidden"), $(".co-img-white").addClass("hidden"), $("#_AllOutcomes .buildabet-pricedecimal").removeClass("hidden"), $("#_AllOutcomes .outcome-title").addClass("buildabet-outcome-title"))
        },
        getAbailableSelections: function(n, t) {
            document.getElementById(buildABetGuid) && document.getElementById(buildABetGuid).classList.add("disableElement");
            pat.get("/BuildABet/GetAvailableSelections", {
                srFeedId: n,
                eventId: t
            }).done(function(n) {
                buildABet.getAbailableSelections_Compelte(n, t)
            })
        },
        getAbailableSelections_Compelte: function(n, t) {
            var i = JSON.parse(n);
            i.AvailableSelections !== null && typeof i.AvailableSelections != "undefined" ? SetBuildABetStorage(JSON.stringify(i)) : SetBuildABetStorage("");
            currentEventId = t;
            document.getElementById(buildABetGuid) && document.getElementById(buildABetGuid).classList.remove("disableElement");
            buildABet.setTmpBetslipSelectionFromStorage(t);
            ClearBuildABetTmpForExpiredEvents()
        },
        getCalculatedOdds: function(n, t, i, r, u) {
            homePage.showOverlay();
            pat.post("/BuildABet/CalculateOdds", {
                buildABetSelections: n,
                eventId: t.EventId
            }).done(function(f) {
                buildABet.validateSelection_Complete(f, t, i, r, u);
                homePage.closeOverlay();
                enableLogging && buildABet.logSelectionsRequest(n)
            })
        },
        logSelectionsRequest: function(n) {
            var t = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
            t = t + '<selections xmlns="http://schemas.sportradar.com/custombet/v1/endpoints" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://schemas.sportradar.com/custombet/v1/endpoints http://schemas.sportradar.com/custombet/v1/endpoints/Selections.xsd">';
            $.each(n, function(n, i) {
                t = t + '<selection id="sr:match:' + i.EventId + '" market_id="' + i.MarketId + '" specifiers="' + i.Specifiers + '" outcome_id="' + i.OutcomeId + '" />'
            });
            t = t + "<\/selections>";
            console.log("Selections: ", t)
        },
        toggleBuildABetBetslip: function() {
            document.getElementById("buildABet-error").style.display = "none";
            $("#moremarketsToggle-buildABetBetslipItems").hasClass("fa-angle-down") ? $("#moremarketsToggle-buildABetBetslipItems").removeClass("fa-angle-down").addClass("fa-angle-up") : $("#moremarketsToggle-buildABetBetslipItems").removeClass("fa-angle-up").addClass("fa-angle-down")
        },
        collapseBuildABetTempBetslip: function() {
            document.getElementById("buildABetTempBetslipToggle") === null && returm;
            document.getElementById("buildABetBetslipItems") === null && returm;
            var n = document.getElementById("buildABetBetslipItems").getAttribute("aria-expanded");
            n = n == "true" ? "false" : "true";
            document.getElementById("buildABetBetslipItems").setAttribute("aria-expanded", n);
            document.getElementById("buildABetBetslipItems") && (document.getElementById("buildABetTempBetslipToggle").classList.contains("collapsed") && document.getElementById("buildABetBetslipItems").style.contains("height: 0px;") ? document.getElementById("buildABetBetslipItems").classList.add("in") : document.getElementById("buildABetBetslipItems").classList.remove("in"))
        },
        setTmpBetslipSelectionFromStorage: function(n) {
            var r = GetBuildABetTmpBetslipStorage(),
                i = parseFloat("0.00").toFixed(2),
                u, t;
            r === "" || r === "{}" ? buildABet.toggleBuildABetBetslip() : (u = JSON.parse(r), t = u.find(t => t.EventId == n), t ? ($.each(t.GroupChildItems, function(n, t) {
                buildABet.generateTmpBetslipItem(t)
            }), i = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(t.PriceDecimal) : parseFloat(t.PriceDecimal).toFixed(2)) : (buildABet.toggleBuildABetBetslip(), typeof t != "undefined" && (i = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(t.PriceDecimal) : parseFloat(t.PriceDecimal).toFixed(2))), document.getElementById("buildABetBetslipOdds").innerText = "(Total Odds: " + (typeof t == "undefined" ? "0" : i) + ")", language.translateAtRuntime(document.getElementById("buildABetBetslipOdds"), "BuildABetContent", {
                "data-translate-key": "TotalOdds",
                "data-translate-type": "generic-html",
                "data-translate-value-0": i
            }), document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText = typeof t == "undefined" ? "0 Selections" : t.GroupChildItems.length + " Selection" + (t.GroupChildItems.length > 1 ? "s" : ""), language.translateAtRuntime(document.getElementById("buildABetTmpBetslipSelectionsHeader"), "BuildABetContent", {
                "data-translate-key": "Selections",
                "data-translate-type": "generic-html",
                "data-translate-value-0": t.GroupChildItems.length
            }), document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText === "0 Selections" ? $("#removeAllSelections").hide() : $("#removeAllSelections").show())
        },
        applyAvailableSelections: function() {
            var t = GetBuildABetStorage(),
                i = 0,
                n;
            t !== "" && t !== "null" ? (n = JSON.parse(t), n.AvailableSelections.Markets.length > 0 && (currentEventId == "00000000-0000-0000-0000-000000000000" && (currentEventId = n.EventId), $("#_AllOutcomes .search-link").each(function() {
                var f = $(this).attr("data-market"),
                    t = $(this).attr("data-srMarketFeedId"),
                    r = buildABet.getSRAvailableMarkets(n.AvailableSelections, t),
                    u;
                $(this).find(".acc-header123").addClass("in");
                $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up");
                typeof t == "undefined" || !r || r.length <= 0 ? $(this).hide() : (u = t.split("|"), $.each(u, function(n, t) {
                    i = buildABet.filterMarketsOutcomes(f, t, r)
                }))
            })), i === 0 ? (selectedBuildnBetEvent = n.EventId, buildABet.hideAllSelections()) : buildABet.setBuildABetOutcomeBtns(n)) : buildABet.hideAllSelections()
        },
        setBuildABetOutcomeBtns: function(n) {
            var t = GetBuildABetTmpBetslipStorage(),
                r, i;
            t !== "" && t !== "{}" && (r = JSON.parse(t), i = r.find(t => t.IsGroupHeader && t.EventId == n.EventId), i ? SetOutcomeButtonsFromBSItems(i.GroupChildItems) : SetOutcomeButtonsFromBSItems(null))
        },
        getSRAvailableMarkets: function(n, t) {
            if (typeof t == "undefined") return "undefined";
            var r = t.split("|"),
                i = [];
            return $.each(r, function(t, r) {
                if (r) {
                    var u = r.split("~"),
                        f = n.Markets.find(n => n.Id == u[0] && (n.Specifiers == null || n.Specifiers == u[1]));
                    f && i.push(f)
                }
            }), i
        },
        filterMarketsOutcomes: function(n, t, i) {
            var r = 0,
                u = t.split("~"),
                o = u[0],
                s = u[1],
                f = i.find(n => n.Id == o && (n.Specifiers == null || n.Specifiers == s)),
                e;
            return f ? (e = f.Outcomes, $("#header-" + n + ' [data-srMarketFeedId="' + t + '"]').each(function() {
                var n = $(this).attr("data-srOutcomeFeedId"),
                    t = e.find(t => t == n);
                t ? r++ : $(this).addClass("disableElement")
            })) : $("#" + n + ' [data-srMarketFeedId="' + t + '"]').each(function() {
                $(this).addClass("disableElement")
            }), r
        },
        hideAllSelections: function() {
            selectedBuildnBetEvent = "";
            $("#_AllOutcomes .search-link").each(function() {
                $(this).hide()
            });
            $("#empty-group").show();
            $("#empty-group .alert-box").show()
        },
        addToTempBetslip: function(n, t, i, r) {
            var e = r != null ? r : GetBuildABetTmpBetslipStorage(),
                f, u, o = i != null,
                s, h;
            if (currentEventId == "00000000-0000-0000-0000-000000000000" && (currentEventId = t), document.getElementById("buildABet-error") != null && (document.getElementById("buildABet-error").style.display = "none"), e === "" || e === "{}") u = buildBetGroupHeader("", "", 0, n.Sport, "Build a Bet", n.EventTitle, n.StartDate, n.EventId, n.IsLiveInPlay, n.FeedDataTypeId, n.AllowEarlyCO, !1, buildABetGuid, t, n), o || buildABet.validateSelection(n, [u], u, i);
            else {
                if (f = r ? r : JSON.parse(e), u = f.find(n => n.IsGroupHeader && n.EventId == t), u)
                    if (s = u.GroupChildItems.find(t => t.OutcomeId == n.OutcomeId), s) {
                        if (u.GroupChildItems.length == 1) return f.splice(f.indexOf(u), 1), SetOutcomeButtonsFromBSItems(null), buildABet.addToTempBetslip_Complete(n, f), !0;
                        u.GroupChildItems.splice(u.GroupChildItems.indexOf(s), 1)
                    } else u.GroupChildItems.push(n);
                else o || (h = document.getElementById("buildABetItemsContainer"), h.children.length === 0 && (buildABet.toggleBuildABetBetslip(), buildABet.collapseBuildABetTempBetslip(), document.getElementById("buildABetBetslipItems").classList.add("in"))), u = buildBetGroupHeader("", "", 0, n.Sport, "Build a Bet", n.EventTitle, n.StartDate, n.EventId, n.IsLiveInPlay, n.FeedDataTypeId, n.AllowEarlyCO, !1, buildABetGuid, t, n), f.push(u);
                o || buildABet.validateSelection(n, f, u, i)
            }
        },
        validateSelection: function(n, t, i, r) {
            var u = [],
                e = !1,
                f = r != null;
            if (i) {
                if (i.GroupChildItems.length >= 11) return f || buildABet.createAnim(".buildABet-notice", "warn", "You have exceeded the maximum of 10 Build A Bet selections.Please revise your bet and try again"), !1;
                $.each(i.GroupChildItems, function(n, t) {
                    var i = r != null ? r : buildABet.getSelectionsObjFromOutcome(t),
                        f = u.find(n => n.MarketId == i.MarketId && n.Specifiers == i.Specifiers);
                    return u.push(i), f ? (e = !0, !1) : void 0
                })
            }
            e ? f || buildABet.createAnim(".buildABet-notice", "warn", "Invalid selection: more than one outcome per market line.") : buildABet.getCalculatedOdds(u, n, t, i, f)
        },
        validateSelection_Complete: function(n, t, i, r, u) {
            var f = JSON.parse(n),
                e;
            typeof f != "undefined" && f.CalcResult != null ? (enableLogging = f.EnableLogging, e = f.CalcResult, e.ValidSelections ? (r.OutcomeId = f.ResultGuid, r.PriceDecimal = e.Odds, r.GroupHeaderId = f.OutcomesHash, t.GroupHeaderId = r.GroupHeaderId, $.each(r.GroupChildItems, function(n, t) {
                t.GroupHeaderId = r.GroupHeaderId
            }), buildABet.addToTempBetslip_Complete(t, i), SetOutcomeButtonsFromBSItems(r.GroupChildItems)) : u || buildABet.createAnim(".buildABet-notice", "error", buildABet.getCustomizedErrorMessage(t, e.ErrorMessage))) : u || buildABet.createAnim(".buildABet-notice", "error", "Unable to validate selection.")
        },
        getSelectionsObjFromOutcome: function(n) {
            var t = $("#" + n.OutcomeId),
                i = t.attr("data-srmarketfeedid").split("~"),
                r = t.attr("data-srEntityId"),
                u = t.attr("data-srOutcomeFeedId"),
                f = i[0],
                e = i[1];
            return {
                EventId: r,
                MarketId: f,
                Specifiers: e,
                OutcomeId: u
            }
        },
        getCustomizedErrorMessage: function(n, t) {
            const i = "Selected market is unavailable";
            return t == null || t.includes(i) ? `${i}: ${n.Title} - ${n.MarketTitle}` : t
        },
        addToTempBetslip_Complete: function(n, t) {
            var i = t.find(t => t.IsGroupHeader && t.GroupHeaderId == n.GroupHeaderId),
                e = typeof i == "undefined" ? i : i.GroupChildItems.find(t => t.OutcomeId == n.OutcomeId),
                u = parseFloat("0.00").toFixed(2),
                r, f;
            i && e ? (u = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(i.PriceDecimal) : parseFloat(i.PriceDecimal).toFixed(2), buildABet.generateTmpBetslipItem(n)) : (r = document.getElementById("buildABetItemsContainer"), f = document.getElementById("buildABetItem-" + n.OutcomeId), r && f && r.removeChild(f), r && r.children.length === 0 && (buildABet.toggleBuildABetBetslip(), buildABet.collapseBuildABetTempBetslip()), typeof i != "undefined" && (u = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(i.PriceDecimal) : parseFloat(i.PriceDecimal).toFixed(2)));
            SetBuildABetTmpBetslipStorage(JSON.stringify(t));
            document.getElementById("buildABetBetslipOdds") && (document.getElementById("buildABetBetslipOdds").innerText = "(Total Odds: " + (typeof i == "undefined" ? "0" : u) + ")", language.translateAtRuntime(document.getElementById("buildABetBetslipOdds"), "BuildABetContent", {
                "data-translate-key": "TotalOdds",
                "data-translate-type": "generic-html",
                "data-translate-value-0": u
            }));
            document.getElementById("buildABetTmpBetslipSelectionsHeader") && (document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText = typeof i == "undefined" ? "0 Selections" : i.GroupChildItems.length + " Selection" + (i.GroupChildItems.length > 1 ? "s" : ""), language.translateAtRuntime(document.getElementById("buildABetTmpBetslipSelectionsHeader"), "BuildABetContent", {
                "data-translate-key": "Selections",
                "data-translate-type": "generic-html",
                "data-translate-value-0": typeof i == "undefined" ? "0" : i.GroupChildItems.length
            }));
            document.getElementById("buildABetTmpBetslipSelectionsHeader") && (document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText === "0 Selections" ? $("#removeAllSelections").hide() : $("#removeAllSelections").show())
        },
        generateTmpBetslipItem: function(n) {
            var i = document.getElementById("buildABetTempBetslipItemsTemplate"),
                t, r;
            i !== null && typeof i != "undefined" && (t = i.innerHTML, t = t.split("%outcomeId%").join(n.OutcomeId), t = t.split("%eventId%").join(n.EventId), t = t.split("%outcomeTitle%").join(n.Title), t = t.split("%marketTitle%").join(n.MarketTitle), r = document.createElement("buildABetSelectedOutcome-" + n.OutcomeId), r.innerHTML = t, document.getElementById("buildABetItemsContainer").appendChild(r.childNodes[1]))
        },
        removeBetItem: function(n, t) {
            var r;
            if (document.getElementById("buildABet-error").style.display = "none", r = GetBuildABetTmpBetslipStorage(), r !== "" && r !== "{}") {
                var f = JSON.parse(r),
                    i = f.find(t => t.IsGroupHeader && t.EventId == n),
                    u = typeof i == "undefined" ? i : i.GroupChildItems.find(n => n.OutcomeId == t);
                i && u && buildABet.addToTempBetslip(u, i.EventId)
            }
        },
        addTempSelectionToBetslip: function(n, t) {
            var u, e, r, f, i;
            buildABet.switchToSingleBet();
            document.getElementById("buildABet-error") != null && (document.getElementById("buildABet-error").style.display = "none");
            u = n ? t : GetBuildABetTmpBetslipStorage();
            u !== "" && u !== "[]" && (e = n ? t : JSON.parse(u), r = n ? e.find(n => n.IsGroupHeader) : e.find(n => n.IsGroupHeader && n.EventId == currentEventId), r && r.GroupChildItems ? (f = GetBetslip(), i = null, f !== "" && f !== "{}" && (i = JSON.parse(f), i.length !== null && typeof i.length != "undefined" && i.length > 0 && (mainBetslipHeaderItem = i.find(n => n.IsGroupHeader && n.GroupHeaderId == r.GroupHeaderId))), i !== null && typeof mainBetslipHeaderItem != "undefined" && mainBetslipHeaderItem !== null ? n || buildABet.createAnim(".buildABet-notice", "warn", "Your betslip already contains a Build a Bet with these selections.") : r.GroupChildItems.length <= 1 ? n || buildABet.createAnim(".buildABet-notice", "warn", "You need a minimum of 2 Build a Bet selections before adding to betslip.") : (SetBetslipOption("IsSingleBet", !0), i == null && (i = []), enableBetslipLimitError(i.length) ? buildABet.createAnim(".buildABet-notice", "warn", document.getElementById("maxBetsPerBetslipsError").value) : (r.PriceDecimal = parseFloat(r.PriceDecimal).toFixed(2), i.push(r), mybets.toggleToBetslip(""), SetBetslip(i), UpdateBetslipFullVersion(), n || buildABet.createAnim(".buildABet-notice", "success", "Added to Betslip successfully")))) : document.getElementById("buildABet-error") != null && (document.getElementById("buildABet-error").style.display = "", document.getElementById("buildABet-error").innerText = "You need a minimum of 2 Build a Bet selections before adding to betslip.", language.translateAtRuntime(document.getElementById("buildABet-error"), "BuildABetContent", {
                "data-translate-key": language.generateKey("YouNeedAMinimumOf2BuildABetSelectionsBeforeAddingToBetslip")
            })));
            mybetslip.updateBetslipCount();
            buildABet.toggleBookABetButton(i)
        },
        toggleBookABetButton: function(n) {
            if (!checkForLite()) {
                let t = _.findWhere(n, {
                    Title: ""
                });
                t && n.length > 1 || !t && n.length < 2 ? $("#generateBookingCode").prop("disabled", !0) : $("#generateBookingCode").prop("disabled", !1)
            }
        },
        switchToSingleBet: function() {
            ToggleBetslip(document.getElementById("sb_id"))
        },
        createAnim: function(n, t, i) {
            var r = document.querySelector(n),
                u = document.createElement("i"),
                f;
            u.setAttribute("aria-hidden", "true");
            t == "success" ? (r.style.background = "#00a826", r.style.color = "#fff", r.innerText = i, language.translateAtRuntime($(r), "BuildABetContent", {
                "data-translate-key": language.generateKey(i)
            }), u.setAttribute("class", "fa fa-check-circle"), r.prepend(u), f = 1500) : t == "error" ? (r.style.background = "#E60000", r.style.color = "#fff", r.innerText = i, language.translateAtRuntime($(r), "BuildABetContent", {
                "data-translate-key": language.generateKey(i)
            }), u.setAttribute("class", "fa fa-times-circle"), r.prepend(u), f = 5e3) : t == "warn" && (r.style.background = "#FFC421", r.style.color = "#333", r.innerText = i, language.translateAtRuntime($(r), "BuildABetContent", {
                "data-translate-key": language.generateKey(i)
            }), u.setAttribute("class", "fa fa-exclamation-circle"), r.prepend(u), f = 3e3);
            $(n).animate({
                bottom: "170px",
                display: "flex"
            }, 1e3, function() {
                $(n).delay(f).animate({
                    bottom: "0px",
                    display: "none"
                }, 1e3)
            })
        },
        animOut: function(n) {
            $(n).animate({
                bottom: "0px",
                display: "none"
            }, 1e3)
        },
        clearAll: function() {
            var t, n, i;
            document.getElementById("buildABet-error").style.display = "none";
            t = GetBuildABetTmpBetslipStorage();
            t !== "" && t !== "[]" && (n = JSON.parse(t), i = n.find(n => n.IsGroupHeader && n.EventId == currentEventId), i && (n.splice(n.indexOf(i), 1), SetBuildABetTmpBetslipStorage(JSON.stringify(n))));
            buildABet.clearSelections();
            buildABet.toggleBuildABetBetslip();
            buildABet.collapseBuildABetTempBetslip()
        },
        clearSelections: function() {
            var n, i, t;
            for (SetOutcomeButtonsFromBSItems(null), n = document.getElementById("buildABetItemsContainer"), i = n.children.length, t = 0; t < i; t++) n.removeChild(n.children[0]);
            document.getElementById("buildABetBetslipOdds").innerText = "(Total Odds: 0)";
            language.translateAtRuntime(document.getElementById("buildABetBetslipOdds"), "BuildABetContent", {
                "data-translate-key": "TotalOdds",
                "data-translate-type": "generic-html",
                "data-translate-value-0": parseFloat(0).toFixed(2)
            });
            document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText = "0 Selections";
            language.translateAtRuntime(document.getElementById("buildABetTmpBetslipSelectionsHeader"), "BuildABetContent", {
                "data-translate-key": "Selections",
                "data-translate-type": "generic-html",
                "data-translate-value-0": 0
            });
            document.getElementById("buildABetTmpBetslipSelectionsHeader").innerText === "0 Selections" ? $("#removeAllSelections").hide() : $("#removeAllSelections").show()
        },
        changeOddsFormat: function(n) {
            var i, r, t;
            document.getElementById("buildABetBetslipOdds") && currentEventId !== "00000000-0000-0000-0000-000000000000" && (i = GetBuildABetTmpBetslipStorage(), i !== "" && i.length > 2 && (r = JSON.parse(i), t = r.find(n => n.EventId == currentEventId), t && (odds = n === "fraction" ? oddsFormatter.convertFromDecimalToFraction(t.PriceDecimal) : parseFloat(t.PriceDecimal).toFixed(2), document.getElementById("buildABetBetslipOdds").innerText = "(Total Odds: " + (typeof t == "undefined" ? "0" : odds) + ")", language.translateAtRuntime(document.getElementById("buildABetBetslipOdds"), "BuildABetContent", {
                "data-translate-key": "TotalOdds",
                "data-translate-type": "generic-html",
                "data-translate-value-0": odds
            }))))
        }
    },
    pat;
$("document").ready(function() {
    var n = JSON.parse(GetBetslip());
    buildABet.toggleBookABetButton(n)
});
pat = {},
    function() {
        function n(n, t, i, r, u) {
            typeof u == "undefined" && (u = !0);
            var f = "application/x-www-form-urlencoded",
                e = null;
            return typeof t == "undefined" && (t = null), typeof i != "undefined" && (typeof i.contentType != "undefined" && (f = i.contentType), typeof i.dataType != "undefined" && (e = i.dataType)), $.ajax({
                url: n,
                type: r,
                dataType: e,
                contentType: f,
                data: t,
                async: u,
                cache: !0,
                complete: function() {},
                success: function() {},
                error: function(n, t, i) {
                    console.log("Error: ", i)
                }
            })
        }
        pat.get = function(t, i, r) {
            return $.when(n(t, i, r, "GET"))
        };
        pat.post = function(t, i, r) {
            return $.when(n(t, i, r, "POST"))
        };
        pat.getSync = function(t, i, r) {
            return $.when(n(t, i, r, "GET", !1))
        };
        pat.postSync = function(t, i, r) {
            return $.when(n(t, i, r, "POST", !1))
        }
    }()