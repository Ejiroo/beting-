var fasearch = !1,
    currentTabId = "00000000-0000-0000-0000-000000000000",
    timeout, searchTimeout, marketGrouping;
$(document).ready(function() {
    $(window).unbind("scroll", marketGrouping.scrollBind);
    localStorage.removeItem("00000000-0000-0000-da7a-000000710001accordPageNum")
});
marketGrouping = {
    expandGroups: function(n) {
        $("#selectButton").hasClass("open") ? ($("#" + n).hide(), $("#selectButton").removeClass("open").attr("aria-expanded", "false")) : ($("#" + n).show(), $("#selectButton").addClass("open").attr("aria-expanded", "true"))
    },
    expandGroups1: function(n) {
        $("#selectButton1").hasClass("open") ? ($("#" + n).hide(), $("#selectButton1").removeClass("open").attr("aria-expanded", "false")) : ($("#" + n).show(), $("#selectButton1").addClass("open").attr("aria-expanded", "true"))
    },
    toggleMultimarketAccordion: function(n, t) {
        if (n === "anchor" && ($("#accordion.widget-angle").hasClass("fa-angle-up") ? $("#accordion.fa").removeClass("fa-angle-up").addClass("fa-angle-down") : $("#accordion.fa").removeClass("fa-angle-down").addClass("fa-angle-up")), t === "outrights") {
            var i = $(".accordionArrows");
            $("#" + n).prev().find(i).hasClass("fa-angle-down") ? ($("#" + n).prev().find(i).removeClass("fa-angle-down").addClass("fa-angle-up"), $("#" + n).addClass("in")) : ($("#" + n).prev().find(i).removeClass("fa-angle-up").addClass("fa-angle-down"), $("#" + n).removeClass("in"))
        } else currentTabId === "00000000-0000-0000-da7a-000000710003" && $("#_AllOutcomes .search-link").each(function() {
            $(this).find(".acc-header123").removeClass("in");
            $(this).find(".accordionArrows").removeClass("fa-angle-up").addClass("fa-angle-down")
        }), $("#" + n).hasClass("fa-angle-up") ? $("#" + n).removeClass("fa-angle-up").addClass("fa-angle-down") : $("#" + n).removeClass("fa-angle-down").addClass("fa-angle-up");
        setTimeout(function() {
            var n = !1;
            $(".acc-header123").each(function(t, i) {
                (i.className.indexOf("collapsing") > -1 || i.className.indexOf("in") > -1) && (n = !0)
            });
            n ? $("#expand-Acc").css("display", "block").attr("onclick", "events.closeAccordions()").attr("value", "Collapse").text("Collapse") : $("#expand-Acc").css("display", "block").attr("onclick", "events.openAccordions()").attr("value", "Expand").text("Expand")
        }, 500)
    },
    bindListeners: function() {
        $(".mg-tab, .button").click(function() {
            $(".mg-tab span,.mg-tab select").removeClass("selected");
            $(this).children("span, select").addClass("selected");
            var n = $(this).attr("id");
            n === "selectButton" && (n = $("#extra-groups .selected").attr("id"))
        })
    },
    FilterTabs: function(n, t) {
        var u, e, r, i, o, f;
        if (currentTabId = n, typeof buildABet != "undefined" && buildABet.inBuildABetTab() && (buildABet.setBuildABetActive(!1), n !== "00000000-0000-0000-da7a-000000710003" && SetOutcomeButtons()), u = localStorage.getItem("loadedAllMarkets"), $(".search-link").show(), $("#multimarketTabPages #_AllOutcomes .accordionArrows").removeClass("fa-angle-up").addClass("fa-angle-down"), e = "#multimarketTabPages #_AllOutcomes .acc-header123", $(e).removeClass("in"), $("#empty-group").hide(), $("#empty-favorite-group").hide(), r = 0, i = 0, n !== "00000000-0000-0000-da7a-000000710001" && n !== "00000000-0000-0000-da7a-000000710002" && n !== "00000000-0000-0000-da7a-000000710003" && n !== "00000000-0000-0000-da7a-000000710099") return $("#loadMore").hide(), $("#_AllOutcomes .search-link").each(function() {
            $(this).attr("data-marketgroups").indexOf(n) === -1 ? $(this).hide() : (i++, r++, i <= 5 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up")))
        }), r === 0 && ($("#empty-group").show(), $("#empty-group .alert-box").show()), !0;
        if (n === "00000000-0000-0000-da7a-000000710002") return i = 0, o = typeof t == "undefined" || isNaN(t) ? 10 : parseInt(t), $("#_AllOutcomes .search-link").each(function() {
            i++;
            r++;
            i <= 5 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"));
            i > o && $(this).hide()
        }), $(window).unbind("scroll"), $("#loadMore").hide(), !0;
        if (n === "00000000-0000-0000-da7a-000000710001" && (typeof u == "undefined" || u == null || u == "false")) return i = 0, $("#_AllOutcomes .search-link").each(function() {
            var u, t;
            i++;
            r++;
            i <= 5 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"));
            u = parseInt(localStorage.getItem(n + "accordPageNum"));
            (isNaN(u) || typeof u == "undefined" || u == null) && (u = 1);
            t = localStorage.getItem("accordMaxPageSize");
            t = typeof t == "undefined" || t == null || isNaN(parseInt(t)) || parseInt(t) <= 0 ? 20 : parseInt(t);
            (u = 1) && (t = 30);
            i > u * t && $(this).hide()
        }), $(window).unbind("scroll"), f = localStorage.getItem("lastIsLazyLoaded"), f == null || typeof f == "undefined" ? $("#loadMore").show() : f == "true" && $("#loadMore").hide(), !0;
        if (n === "00000000-0000-0000-da7a-000000710099") return i = 0, applyFavorites(), $("#loadMore").hide(), $("#_AllOutcomes .search-link").hide(), $('#_AllOutcomes .search-link[data-is-markettype-favorite="true"]').each(function() {
            i++;
            r++;
            $(this).show();
            i <= 5 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"));
            var n = localStorage.getItem("accordMaxPageSize");
            n = typeof n == "undefined" || n == null || isNaN(parseInt(n)) || parseInt(n) <= 0 ? 20 : parseInt(n);
            r == 0 && $("#empty-favorite-group").hide()
        }), $(window).unbind("scroll"), this.showOnlyFavorites(), !0;
        if (n === "00000000-0000-0000-da7a-000000710003" && typeof buildABet != "undefined") return i = 0, buildABet.setBuildABetActive(!0), buildABet.applyAvailableSelections(), $("#_AllOutcomes .search-link").each(function() {
            i++;
            i > 1 ? ($(this).find(".acc-header123").removeClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-up").addClass("fa-angle-down")) : ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"))
        }), $("#loadMore").hide(), !0;
        $("#_AllOutcomes .search-link").each(function() {
            if (i++, r++, i <= 5) $(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up");
            else return !0
        })
    },
    addToCurrentMarketTypeDictionary: function(n, t) {
        var i = localStorage.getItem("_eventId");
        typeof i != "undefined" && i != n && (marketGrouping.listCurrentMarketTypes = [], localStorage.removeItem("_multiMarketTypesData"));
        $(t).each(function() {
            var n = $(this).attr("data-markettype"),
                t = $(this).attr("data-marketTitle"),
                i = $(this).attr("data-market-sortindex");
            t != null && typeof t != "undefined" && n != null && typeof n != "undefined" && marketGrouping.listCurrentMarketTypes.push({
                marketTypeId: n,
                marketSortIndex: i,
                marketTitle: t
            })
        })
    },
    retrieveEventMarketGroupsForUpdate: function(n) {
        try {
            var t = $("#multimarketTabPages").parent().attr("id"),
                i = $("#" + t).attr("data-markettypecategory");
            return pat.get("/Bet/EventMultiMarket", {
                eventId: t,
                FeedDataTypeId: i,
                isPopular: !1,
                pageNum: n,
                isFullView: !1
            }).done(function(n) {
                if (n == null || $("div", n).length <= 20) {
                    $(window).unbind("scroll");
                    $("#loaderText").html("End of results");
                    $("#loader").fadeOut(850);
                    $("#loadMore").hide();
                    localStorage.setItem("lastIsLazyLoaded", !0);
                    return
                }
                $("#_AllOutcomes .container-panel").append(n);
                marketGrouping.addToCurrentMarketTypeDictionary(t, $(n, "#_AllOutcomes .search-link"));
                marketGrouping.invokePageUpdate();
                $("#loader").hide();
                $("#loadMore").show()
            })
        } catch (r) {
            console.log('An unexpected error occurred in "marketGrouping => retrieveEventMarketGroupsForUpdate()", details: ' + r);
            $("#loader").hide();
            $("#loadMore").show()
        }
    },
    invokePageUpdate: function() {
        var n, r, u, o, s, f;
        try {
            if (n = localStorage.getItem("accordionTabID"), typeof n == "undefined" || n == null) return;
            var t = 0,
                e = 0,
                i = localStorage.getItem("accordMaxPageSize");
            i = typeof i == "undefined" || i == null || isNaN(parseInt(i)) || parseInt(i) <= 0 ? 20 : parseInt(i);
            r = 0;
            u = parseInt(localStorage.getItem(n + "accordPageNum"));
            typeof u != "undefined" && u >= 1 ? (r = u + 1, localStorage.setItem(n + "accordPageNum", r)) : (r = 1, localStorage.setItem(n + "accordPageNum", r));
            o = 0;
            s = i * r;
            n === "00000000-0000-0000-da7a-000000710001" ? (f = $("#mtSearch").val(), $("#_AllOutcomes .search-link").each(function() {
                t++;
                f != "" && typeof f != "undefined" ? $(this).attr("data-marketTitle").toUpperCase().indexOf(f.toUpperCase()) != -1 ? ($(this).show(), $("#mtSearch").val() ? $("#searchclear").show() : $("#searchclear").hide()) : $(this).hide() : t > o && t <= s ? (e++, $(this).show(), t <= 15 && r <= 1 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"))) : $(this).hide()
            })) : n == "00000000-0000-0000-da7a-000000710099" ? marketGrouping.showOnlyFavorites() : n !== "00000000-0000-0000-da7a-000000710001" && n !== "00000000-0000-0000-da7a-000000710002" && ($("#_AllOutcomes .search-link").each(function() {
                $(this).attr("data-marketgroups").indexOf(n) === -1 ? $(this).hide() : (t++, t > o && t <= s ? (e++, $(this).show(), t <= 5 && ($(this).find(".acc-header123").addClass("in"), $(this).find(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up"))) : $(this).hide())
            }), e === 0 && ($("#empty-group").show(), $("#empty-group .alert-box").show()))
        } catch (h) {
            console.log('An unexpected error occurred in "marketGrouping => invokePageUpdate()", details: ' + h)
        }
    },
    scrollBind: function() {
        try {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                var r = 2,
                    u = Math.trunc($(this).scrollTop() + $(this).height()),
                    i = !1,
                    f = typeof buildABet != "undefined" && buildABet.isBuildABetActive(),
                    t, n;
                if (isMobileDevice == !1 && u < $(document).height() + r && u > $(document).height() - r && !f ? i = !0 : isMobileDevice && $(this).scrollTop() > $("#groupViewContainer")[0].scrollHeight / 2 && !f && (i = !0), i) {
                    if ($(window).unbind("scroll"), $("#loadMore").hide(), $("#loader").fadeIn(300), t = localStorage.getItem("accordionTabID"), typeof t == "undefined" || t == null) return;
                    n = 1;
                    n = parseInt(localStorage.getItem(t + "accordPageNum"));
                    typeof n != "undefined" && n > 1 ? marketGrouping.retrieveEventMarketGroupsForUpdate(n) : (marketGrouping.invokePageUpdate(), $("#loadMore").show(), $("#loader").hide())
                }
            }, 50)
        } catch (n) {
            console.log('An unexpected error occurred in "marketGrouping => scrollBind()", details: ' + n)
        }
    },
    ApplyLazyLoad: function() {
        var n, t;
        try {
            if (n = localStorage.getItem("accordionTabID"), typeof n == "undefined" || n == null) return;
            $(window).bind("scroll", marketGrouping.scrollBind);
            t = parseInt(localStorage.getItem(n + "accordPageNum"));
            (isNaN(t) || typeof t == "undefined" || t == null) && marketGrouping.invokePageUpdate()
        } catch (i) {
            console.log('An unexpected error occurred in "marketGrouping => ApplyLazyLoad()", details: ' + i)
        }
    },
    listAllMarketTypes: [],
    listCurrentMarketTypes: [],
    searchMarkets: function(n) {
        var i = 0,
            t = 0,
            u, f, r;
        try {
            $(window).unbind("scroll");
            marketGrouping.listCurrentMarketTypes.forEach(function(t) {
                t.marketTitle.toUpperCase().indexOf(n.toUpperCase()) != -1 && i++
            });
            marketGrouping.listAllMarketTypes.forEach(function(i) {
                i.MarketTitle.toUpperCase().indexOf(n.toUpperCase()) != -1 && t++
            });
            i != t && t > 0 ? (u = $("#multimarketTabPages").parent().attr("id"), f = $("#" + u).attr("data-markettypecategory"), pat.get("/Bet/EventMultiMarket", {
                eventId: u,
                FeedDataTypeId: f,
                isPopular: !1,
                searchCriteria: $("#mtSearch").val().toLowerCase(),
                isFullView: !1
            }).done(function(t) {
                $("#_AllOutcomes .container-panel").html(t);
                marketGrouping.FilterTabs("00000000-0000-0000-da7a-000000710001");
                fasearch && $("#mtSearch").focus();
                $(".search-link").each(function() {
                    $(this).attr("data-marketTitle").toUpperCase().indexOf(n.toUpperCase()) != -1 ? $(this).show() : $(this).hide()
                });
                homePage.closeOverlay()
            }), console.log("Match not found, making svr request. Current = " + i + " All = " + t)) : ($("#_AllOutcomes .container-panel").html(localStorage.getItem("_multiMarketTypesData")), marketGrouping.FilterTabs("00000000-0000-0000-da7a-000000710001"), r = localStorage.getItem("lastIsLazyLoaded"), r == null || typeof r == "undefined" ? $("#loadMore").show() : r == "true" && $("#loadMore").hide(), console.log("Match found, just filter page. Current = " + i + " All = " + t), homePage.closeOverlay())
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => searchMarkets()", details: ' + e)
        }
    },
    resetGroups: function() {
        var h, v, e, t, u, s, n, l, f, c, i, o;
        buttonGroupsCount = 15;
        var y = $(".mg-tabs").find(".button"),
            p = $(".mg-tabs").find("li"),
            r = [],
            a = !1;
        for (y.each(function() {
                if ($(this).attr("id") == constId.BuildABet && (a = !0), this.id !== "selectButton") {
                    var n = {
                        id: $(this).attr("id"),
                        title: $(this).children().first().text(),
                        isSelected: $(this).children().first().hasClass("selected"),
                        className: $(this).attr("class")
                    };
                    r.push(n)
                }
            }), screen.width <= 768 && isMobileMultiMarketLayout && (buttonGroupsCount = a ? 1 : 0), p.each(function() {
                var n = {
                    id: $(this).attr("id"),
                    title: $(this).text(),
                    isSelected: $(this).hasClass("selected")
                };
                r.push(n)
            }), h = document.getElementsByClassName("mg-tabs")[0], v = r.length > buttonGroupsCount, $(h).empty(), e = 0; e < buttonGroupsCount; e++) {
            if (e === r.length) return;
            t = r[e];
            t.id !== "" && (u = document.createElement("div"), u.id = t.id, u.className = t.className, t.className || (u.className = "mg-tab tab-" + (e + 1).toString() + " button"), u.setAttribute("onClick", "switchTab('" + t.id + "');marketGrouping.closeDd();"), s = document.createElement("span"), s.textContent = t.title, language.translateAtRuntime(s, "ContentHeaders", {
                "data-translate-key": language.generateKey(t.title)
            }), t.isSelected && $(s).addClass("selected"), u.appendChild(s), h.appendChild(u))
        }
        if (v) {
            for (n = document.createElement("div"), n.className = "mg-tab mg-dropdown", n.id = "selectButton", n.setAttribute("type", "button"), n.setAttribute("aria-expanded", "true"), n.setAttribute("onclick", "marketGrouping.expandGroups('extra-groups');"), l = document.createElement("span"), l.textContent = "More...", n.appendChild(l), f = document.createElement("ul"), f.setAttribute("role", "menu"), f.setAttribute("id", "extra-groups"), f.setAttribute("aria-labelledby", "selectButton"), f.className = "dropdown-menu", c = buttonGroupsCount; c < r.length; c++) i = r[c], i.id !== "" && i.id !== "selectButton" && (o = document.createElement("li"), o.id = i.id, o.textContent = i.title, i.isSelected && ($(n).find("span").first().addClass("selected"), $(o).addClass("selected"), $(n).find("span").first().text(i.title)), o.setAttribute("onclick", "switchTab('" + i.id + "', true); marketGrouping.expandGroups('extra-groups'); "), f.appendChild(o));
            n.appendChild(f);
            h.appendChild(n)
        }
    },
    closeDd: function() {
        $("#extra-groups").hide();
        $("#selectButton").removeClass("open");
        $("#selectButton").attr("aria-expanded", "false")
    },
    SetRegionFilterAndReload: function(n, t) {
        filterLeaguesByRegionId(n, t, "@Model.breadCrumbFeedDataTypeId")
    },
    PinLiveStreamVideo: function(n, t) {
        $.session.set("url", n);
        $.session.set("isMobile", t)
    },
    handleSBVgrouping: function() {
        var n = [];
        $('[data-groupsbv="True"]').each(function() {
            n.push($(this).data().markettype)
        });
        n.forEach(n => {
            var t = $('[data-markettype="' + n + '"]'),
                r, i;
            if (t.length > 1) {
                for (r = "", i = 1; i < t.length; i++) r += $($(t)[i]).find(".panel-body").html(), $($(t)[i]).remove();
                $($(t)[0]).find(".panel-body").append(r)
            }
        })
    },
    showOnlyFavorites: function() {
        var n;
        if (isAccountFavoriteEnabled) {
            var t = document.querySelectorAll("div[data-markettype-favorite-parent]"),
                i = localStorage.getItem("accountFavorites"),
                r = 0;
            if (i != null && i != "" && t.length > 0)
                for (n = 0; n < t.length; n++) t[n].getAttribute("data-is-markettype-favorite") == "true" ? (t[n].style.display = "", r++) : t[n].style.display = "none";
            r == 0 ? $("#empty-favorite-group").show() : $("#empty-favorite-group").hide()
        }
    },
    removeDuplicateMarkets: function() {
        var t = [],
            n, i;
        for ($("#_AllOutcomes div .row.search-link").each(function() {
                t.push($(this).data().market)
            }), n = 0; n < t.length; n++) i = $('.row[data-market="' + t[n] + '"]'), i.length > 1 && i[1].remove()
    }
};
$(document).ready(function() {
    var t = 0,
        n;
    $("#_AllOutcomes .acc-header123").each(function() {
        t++;
        t <= 5 && $(this).addClass("in")
    });
    n = 0;
    $("#_AllOutcomes .accordionArrows").each(function() {
        n++;
        n <= 5 && ($(this).removeClass("fa fa-angle-down"), $(this).addClass("fa fa-angle-up"))
    });
    window.addEventListener("resize", marketGrouping.resetGroups);
    marketGrouping.resetGroups();
    marketGrouping.bindListeners();
    $("#multi-head").hasClass("inPlayBg") && $(".event-heading").css("line-height", "27px");
    (document.location.pathname.indexOf("/bet/eventmultimarket") && $("#multi-head").hasClass("inPlayBg")) === !0 ? $("#mainBody").addClass("yellow") : $("#mainBody").removeClass("yellow")
})