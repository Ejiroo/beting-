(function(a) {
    var b = "unobtrusiveAjaxClick",
        d = "unobtrusiveAjaxClickTarget",
        h = "unobtrusiveValidation";

    function c(d, b) {
        var a = window,
            c = (d || "").split(".");
        while (a && c.length) a = a[c.shift()];
        if (typeof a === "function") return a;
        b.push(d);
        return Function.constructor.apply(null, b)
    }

    function e(a) {
        return a === "GET" || a === "POST"
    }

    function g(b, a) {
        !e(a) && b.setRequestHeader("X-HTTP-Method-Override", a)
    }

    function i(c, b, e) {
        var d;
        if (e.indexOf("application/x-javascript") !== -1) return;
        d = (c.getAttribute("data-ajax-mode") || "").toUpperCase();
        a(c.getAttribute("data-ajax-update")).each(function(e, c) {
            switch (d) {
                case "BEFORE":
                    a(c).prepend(b);
                    break;
                case "AFTER":
                    a(c).append(b);
                    break;
                case "REPLACE-WITH":
                    a(c).replaceWith(b);
                    break;
                default:
                    a(c).html(b)
            }
        })
    }

    function f(b, d) {
        var j, k, f, h;
        j = b.getAttribute("data-ajax-confirm");
        if (j && !window.confirm(j)) return;
        k = a(b.getAttribute("data-ajax-loading"));
        h = parseInt(b.getAttribute("data-ajax-loading-duration"), 10) || 0;
        a.extend(d, {
            type: b.getAttribute("data-ajax-method") || undefined,
            url: b.getAttribute("data-ajax-url") || undefined,
            cache: !!b.getAttribute("data-ajax-cache"),
            beforeSend: function(d) {
                var a;
                g(d, f);
                a = c(b.getAttribute("data-ajax-begin"), ["xhr"]).apply(b, arguments);
                a !== false && k.show(h);
                return a
            },
            complete: function() {
                k.hide(h);
                c(b.getAttribute("data-ajax-complete"), ["xhr", "status"]).apply(b, arguments)
            },
            success: function(a, e, d) {
                i(b, a, d.getResponseHeader("Content-Type") || "text/html");
                c(b.getAttribute("data-ajax-success"), ["data", "status", "xhr"]).apply(b, arguments)
            },
            error: function() {
                c(b.getAttribute("data-ajax-failure"), ["xhr", "status", "error"]).apply(b, arguments)
            }
        });
        d.data.push({
            name: "X-Requested-With",
            value: "XMLHttpRequest"
        });
        f = d.type.toUpperCase();
        if (!e(f)) {
            d.type = "POST";
            d.data.push({
                name: "X-HTTP-Method-Override",
                value: f
            })
        }
        a.ajax(d)
    }

    function j(c) {
        var b = a(c).data(h);
        return !b || !b.validate || b.validate()
    }
    a(document).on("click", "a[data-ajax=true]", function(a) {
        a.preventDefault();
        f(this, {
            url: this.href,
            type: "GET",
            data: []
        })
    });
    a(document).on("click", "form[data-ajax=true] input[type=image]", function(c) {
        var g = c.target.name,
            e = a(c.target),
            f = a(e.parents("form")[0]),
            d = e.offset();
        f.data(b, [{
            name: g + ".x",
            value: Math.round(c.pageX - d.left)
        }, {
            name: g + ".y",
            value: Math.round(c.pageY - d.top)
        }]);
        setTimeout(function() {
            f.removeData(b)
        }, 0)
    });
    a(document).on("click", "form[data-ajax=true] :submit", function(e) {
        var g = e.currentTarget.name,
            f = a(e.target),
            c = a(f.parents("form")[0]);
        c.data(b, g ? [{
            name: g,
            value: e.currentTarget.value
        }] : []);
        c.data(d, f);
        setTimeout(function() {
            c.removeData(b);
            c.removeData(d)
        }, 0)
    });
    a(document).on("submit", "form[data-ajax=true]", function(h) {
        var e = a(this).data(b) || [],
            c = a(this).data(d),
            g = c && c.hasClass("cancel");
        h.preventDefault();
        if (!g && !j(this)) return;
        f(this, {
            url: this.action,
            type: this.method || "GET",
            data: e.concat(a(this).serializeArray())
        })
    })
})(jQuery);;
/*!
 * Bootstrap v3.3.7 (http://getbootstrap.com)
 * Copyright 2011-2016 Twitter, Inc.
 * Licensed under the MIT license
 */
if ("undefined" == typeof jQuery) throw new Error("Bootstrap's JavaScript requires jQuery"); + function(a) {
    "use strict";
    var b = a.fn.jquery.split(" ")[0].split(".");
    if (b[0] < 2 && b[1] < 9 || 1 == b[0] && 9 == b[1] && b[2] < 1 || b[0] > 3) throw new Error("Bootstrap's JavaScript requires jQuery version 1.9.1 or higher, but lower than version 4")
}(jQuery), + function(a) {
    "use strict";

    function b() {
        var a = document.createElement("bootstrap"),
            b = {
                WebkitTransition: "webkitTransitionEnd",
                MozTransition: "transitionend",
                OTransition: "oTransitionEnd otransitionend",
                transition: "transitionend"
            };
        for (var c in b)
            if (void 0 !== a.style[c]) return {
                end: b[c]
            };
        return !1
    }
    a.fn.emulateTransitionEnd = function(b) {
        var c = !1,
            d = this;
        a(this).one("bsTransitionEnd", function() {
            c = !0
        });
        var e = function() {
            c || a(d).trigger(a.support.transition.end)
        };
        return setTimeout(e, b), this
    }, a(function() {
        a.support.transition = b(), a.support.transition && (a.event.special.bsTransitionEnd = {
            bindType: a.support.transition.end,
            delegateType: a.support.transition.end,
            handle: function(b) {
                if (a(b.target).is(this)) return b.handleObj.handler.apply(this, arguments)
            }
        })
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var c = a(this),
                e = c.data("bs.alert");
            e || c.data("bs.alert", e = new d(this)), "string" == typeof b && e[b].call(c)
        })
    }
    var c = '[data-dismiss="alert"]',
        d = function(b) {
            a(b).on("click", c, this.close)
        };
    d.VERSION = "3.3.7", d.TRANSITION_DURATION = 150, d.prototype.close = function(b) {
        function c() {
            g.detach().trigger("closed.bs.alert").remove()
        }
        var e = a(this),
            f = e.attr("data-target");
        f || (f = e.attr("href"), f = f && f.replace(/.*(?=#[^\s]*$)/, ""));
        var g = a("#" === f ? [] : f);
        b && b.preventDefault(), g.length || (g = e.closest(".alert")), g.trigger(b = a.Event("close.bs.alert")), b.isDefaultPrevented() || (g.removeClass("in"), a.support.transition && g.hasClass("fade") ? g.one("bsTransitionEnd", c).emulateTransitionEnd(d.TRANSITION_DURATION) : c())
    };
    var e = a.fn.alert;
    a.fn.alert = b, a.fn.alert.Constructor = d, a.fn.alert.noConflict = function() {
        return a.fn.alert = e, this
    }, a(document).on("click.bs.alert.data-api", c, d.prototype.close)
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.button"),
                f = "object" == typeof b && b;
            e || d.data("bs.button", e = new c(this, f)), "toggle" == b ? e.toggle() : b && e.setState(b)
        })
    }
    var c = function(b, d) {
        this.$element = a(b), this.options = a.extend({}, c.DEFAULTS, d), this.isLoading = !1
    };
    c.VERSION = "3.3.7", c.DEFAULTS = {
        loadingText: "loading..."
    }, c.prototype.setState = function(b) {
        var c = "disabled",
            d = this.$element,
            e = d.is("input") ? "val" : "html",
            f = d.data();
        b += "Text", null == f.resetText && d.data("resetText", d[e]()), setTimeout(a.proxy(function() {
            d[e](null == f[b] ? this.options[b] : f[b]), "loadingText" == b ? (this.isLoading = !0, d.addClass(c).attr(c, c).prop(c, !0)) : this.isLoading && (this.isLoading = !1, d.removeClass(c).removeAttr(c).prop(c, !1))
        }, this), 0)
    }, c.prototype.toggle = function() {
        var a = !0,
            b = this.$element.closest('[data-toggle="buttons"]');
        if (b.length) {
            var c = this.$element.find("input");
            "radio" == c.prop("type") ? (c.prop("checked") && (a = !1), b.find(".active").removeClass("active"), this.$element.addClass("active")) : "checkbox" == c.prop("type") && (c.prop("checked") !== this.$element.hasClass("active") && (a = !1), this.$element.toggleClass("active")), c.prop("checked", this.$element.hasClass("active")), a && c.trigger("change")
        } else this.$element.attr("aria-pressed", !this.$element.hasClass("active")), this.$element.toggleClass("active")
    };
    var d = a.fn.button;
    a.fn.button = b, a.fn.button.Constructor = c, a.fn.button.noConflict = function() {
        return a.fn.button = d, this
    }, a(document).on("click.bs.button.data-api", '[data-toggle^="button"]', function(c) {
        var d = a(c.target).closest(".btn");
        b.call(d, "toggle"), a(c.target).is('input[type="radio"], input[type="checkbox"]') || (c.preventDefault(), d.is("input,button") ? d.trigger("focus") : d.find("input:visible,button:visible").first().trigger("focus"))
    }).on("focus.bs.button.data-api blur.bs.button.data-api", '[data-toggle^="button"]', function(b) {
        a(b.target).closest(".btn").toggleClass("focus", /^focus(in)?$/.test(b.type))
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.carousel"),
                f = a.extend({}, c.DEFAULTS, d.data(), "object" == typeof b && b),
                g = "string" == typeof b ? b : f.slide;
            e || d.data("bs.carousel", e = new c(this, f)), "number" == typeof b ? e.to(b) : g ? e[g]() : f.interval && e.pause().cycle()
        })
    }
    var c = function(b, c) {
        this.$element = a(b), this.$indicators = this.$element.find(".carousel-indicators"), this.options = c, this.paused = null, this.sliding = null, this.interval = null, this.$active = null, this.$items = null, this.options.keyboard && this.$element.on("keydown.bs.carousel", a.proxy(this.keydown, this)), "hover" == this.options.pause && !("ontouchstart" in document.documentElement) && this.$element.on("mouseenter.bs.carousel", a.proxy(this.pause, this)).on("mouseleave.bs.carousel", a.proxy(this.cycle, this))
    };
    c.VERSION = "3.3.7", c.TRANSITION_DURATION = 600, c.DEFAULTS = {
        interval: 5e3,
        pause: "hover",
        wrap: !0,
        keyboard: !0
    }, c.prototype.keydown = function(a) {
        if (!/input|textarea/i.test(a.target.tagName)) {
            switch (a.which) {
                case 37:
                    this.prev();
                    break;
                case 39:
                    this.next();
                    break;
                default:
                    return
            }
            a.preventDefault()
        }
    }, c.prototype.cycle = function(b) {
        return b || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(a.proxy(this.next, this), this.options.interval)), this
    }, c.prototype.getItemIndex = function(a) {
        return this.$items = a.parent().children(".item"), this.$items.index(a || this.$active)
    }, c.prototype.getItemForDirection = function(a, b) {
        var c = this.getItemIndex(b),
            d = "prev" == a && 0 === c || "next" == a && c == this.$items.length - 1;
        if (d && !this.options.wrap) return b;
        var e = "prev" == a ? -1 : 1,
            f = (c + e) % this.$items.length;
        return this.$items.eq(f)
    }, c.prototype.to = function(a) {
        var b = this,
            c = this.getItemIndex(this.$active = this.$element.find(".item.active"));
        if (!(a > this.$items.length - 1 || a < 0)) return this.sliding ? this.$element.one("slid.bs.carousel", function() {
            b.to(a)
        }) : c == a ? this.pause().cycle() : this.slide(a > c ? "next" : "prev", this.$items.eq(a))
    }, c.prototype.pause = function(b) {
        return b || (this.paused = !0), this.$element.find(".next, .prev").length && a.support.transition && (this.$element.trigger(a.support.transition.end), this.cycle(!0)), this.interval = clearInterval(this.interval), this
    }, c.prototype.next = function() {
        if (!this.sliding) return this.slide("next")
    }, c.prototype.prev = function() {
        if (!this.sliding) return this.slide("prev")
    }, c.prototype.slide = function(b, d) {
        var e = this.$element.find(".item.active"),
            f = d || this.getItemForDirection(b, e),
            g = this.interval,
            h = "next" == b ? "left" : "right",
            i = this;
        if (f.hasClass("active")) return this.sliding = !1;
        var j = f[0],
            k = a.Event("slide.bs.carousel", {
                relatedTarget: j,
                direction: h
            });
        if (this.$element.trigger(k), !k.isDefaultPrevented()) {
            if (this.sliding = !0, g && this.pause(), this.$indicators.length) {
                this.$indicators.find(".active").removeClass("active");
                var l = a(this.$indicators.children()[this.getItemIndex(f)]);
                l && l.addClass("active")
            }
            var m = a.Event("slid.bs.carousel", {
                relatedTarget: j,
                direction: h
            });
            return a.support.transition && this.$element.hasClass("slide") ? (f.addClass(b), f[0].offsetWidth, e.addClass(h), f.addClass(h), e.one("bsTransitionEnd", function() {
                f.removeClass([b, h].join(" ")).addClass("active"), e.removeClass(["active", h].join(" ")), i.sliding = !1, setTimeout(function() {
                    i.$element.trigger(m)
                }, 0)
            }).emulateTransitionEnd(c.TRANSITION_DURATION)) : (e.removeClass("active"), f.addClass("active"), this.sliding = !1, this.$element.trigger(m)), g && this.cycle(), this
        }
    };
    var d = a.fn.carousel;
    a.fn.carousel = b, a.fn.carousel.Constructor = c, a.fn.carousel.noConflict = function() {
        return a.fn.carousel = d, this
    };
    var e = function(c) {
        var d, e = a(this),
            f = a(e.attr("data-target") || (d = e.attr("href")) && d.replace(/.*(?=#[^\s]+$)/, ""));
        if (f.hasClass("carousel")) {
            var g = a.extend({}, f.data(), e.data()),
                h = e.attr("data-slide-to");
            h && (g.interval = !1), b.call(f, g), h && f.data("bs.carousel").to(h), c.preventDefault()
        }
    };
    a(document).on("click.bs.carousel.data-api", "[data-slide]", e).on("click.bs.carousel.data-api", "[data-slide-to]", e), a(window).on("load", function() {
        a('[data-ride="carousel"]').each(function() {
            var c = a(this);
            b.call(c, c.data())
        })
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        var c, d = b.attr("data-target") || (c = b.attr("href")) && c.replace(/.*(?=#[^\s]+$)/, "");
        return a(d)
    }

    function c(b) {
        return this.each(function() {
            var c = a(this),
                e = c.data("bs.collapse"),
                f = a.extend({}, d.DEFAULTS, c.data(), "object" == typeof b && b);
            !e && f.toggle && /show|hide/.test(b) && (f.toggle = !1), e || c.data("bs.collapse", e = new d(this, f)), "string" == typeof b && e[b]()
        })
    }
    var d = function(b, c) {
        this.$element = a(b), this.options = a.extend({}, d.DEFAULTS, c), this.$trigger = a('[data-toggle="collapse"][href="#' + b.id + '"],[data-toggle="collapse"][data-target="#' + b.id + '"]'), this.transitioning = null, this.options.parent ? this.$parent = this.getParent() : this.addAriaAndCollapsedClass(this.$element, this.$trigger), this.options.toggle && this.toggle()
    };
    d.VERSION = "3.3.7", d.TRANSITION_DURATION = 350, d.DEFAULTS = {
        toggle: !0
    }, d.prototype.dimension = function() {
        var a = this.$element.hasClass("width");
        return a ? "width" : "height"
    }, d.prototype.show = function() {
        if (!this.transitioning && !this.$element.hasClass("in")) {
            var b, e = this.$parent && this.$parent.children(".panel").children(".in, .collapsing");
            if (!(e && e.length && (b = e.data("bs.collapse"), b && b.transitioning))) {
                var f = a.Event("show.bs.collapse");
                if (this.$element.trigger(f), !f.isDefaultPrevented()) {
                    e && e.length && (c.call(e, "hide"), b || e.data("bs.collapse", null));
                    var g = this.dimension();
                    this.$element.removeClass("collapse").addClass("collapsing")[g](0).attr("aria-expanded", !0), this.$trigger.removeClass("collapsed").attr("aria-expanded", !0), this.transitioning = 1;
                    var h = function() {
                        this.$element.removeClass("collapsing").addClass("collapse in")[g](""), this.transitioning = 0, this.$element.trigger("shown.bs.collapse")
                    };
                    if (!a.support.transition) return h.call(this);
                    var i = a.camelCase(["scroll", g].join("-"));
                    this.$element.one("bsTransitionEnd", a.proxy(h, this)).emulateTransitionEnd(d.TRANSITION_DURATION)[g](this.$element[0][i])
                }
            }
        }
    }, d.prototype.hide = function() {
        if (!this.transitioning && this.$element.hasClass("in")) {
            var b = a.Event("hide.bs.collapse");
            if (this.$element.trigger(b), !b.isDefaultPrevented()) {
                var c = this.dimension();
                this.$element[c](this.$element[c]())[0].offsetHeight, this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded", !1), this.$trigger.addClass("collapsed").attr("aria-expanded", !1), this.transitioning = 1;
                var e = function() {
                    this.transitioning = 0, this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")
                };
                return a.support.transition ? void this.$element[c](0).one("bsTransitionEnd", a.proxy(e, this)).emulateTransitionEnd(d.TRANSITION_DURATION) : e.call(this)
            }
        }
    }, d.prototype.toggle = function() {
        this[this.$element.hasClass("in") ? "hide" : "show"]()
    }, d.prototype.getParent = function() {
        return a(this.options.parent).find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]').each(a.proxy(function(c, d) {
            var e = a(d);
            this.addAriaAndCollapsedClass(b(e), e)
        }, this)).end()
    }, d.prototype.addAriaAndCollapsedClass = function(a, b) {
        var c = a.hasClass("in");
        a.attr("aria-expanded", c), b.toggleClass("collapsed", !c).attr("aria-expanded", c)
    };
    var e = a.fn.collapse;
    a.fn.collapse = c, a.fn.collapse.Constructor = d, a.fn.collapse.noConflict = function() {
        return a.fn.collapse = e, this
    }, a(document).on("click.bs.collapse.data-api", '[data-toggle="collapse"]', function(d) {
        var e = a(this);
        e.attr("data-target") || d.preventDefault();
        var f = b(e),
            g = f.data("bs.collapse"),
            h = g ? "toggle" : e.data();
        c.call(f, h)
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        var c = b.attr("data-target");
        c || (c = b.attr("href"), c = c && /#[A-Za-z]/.test(c) && c.replace(/.*(?=#[^\s]*$)/, ""));
        var d = c && a(c);
        return d && d.length ? d : b.parent()
    }

    function c(c) {
        c && 3 === c.which || (a(e).remove(), a(f).each(function() {
            var d = a(this),
                e = b(d),
                f = {
                    relatedTarget: this
                };
            e.hasClass("open") && (c && "click" == c.type && /input|textarea/i.test(c.target.tagName) && a.contains(e[0], c.target) || (e.trigger(c = a.Event("hide.bs.dropdown", f)), c.isDefaultPrevented() || (d.attr("aria-expanded", "false"), e.removeClass("open").trigger(a.Event("hidden.bs.dropdown", f)))))
        }))
    }

    function d(b) {
        return this.each(function() {
            var c = a(this),
                d = c.data("bs.dropdown");
            d || c.data("bs.dropdown", d = new g(this)), "string" == typeof b && d[b].call(c)
        })
    }
    var e = ".dropdown-backdrop",
        f = '[data-toggle="dropdown"]',
        g = function(b) {
            a(b).on("click.bs.dropdown", this.toggle)
        };
    g.VERSION = "3.3.7", g.prototype.toggle = function(d) {
        var e = a(this);
        if (!e.is(".disabled, :disabled")) {
            var f = b(e),
                g = f.hasClass("open");
            if (c(), !g) {
                "ontouchstart" in document.documentElement && !f.closest(".navbar-nav").length && a(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(a(this)).on("click", c);
                var h = {
                    relatedTarget: this
                };
                if (f.trigger(d = a.Event("show.bs.dropdown", h)), d.isDefaultPrevented()) return;
                e.trigger("focus").attr("aria-expanded", "true"), f.toggleClass("open").trigger(a.Event("shown.bs.dropdown", h))
            }
            return !1
        }
    }, g.prototype.keydown = function(c) {
        if (/(38|40|27|32)/.test(c.which) && !/input|textarea/i.test(c.target.tagName)) {
            var d = a(this);
            if (c.preventDefault(), c.stopPropagation(), !d.is(".disabled, :disabled")) {
                var e = b(d),
                    g = e.hasClass("open");
                if (!g && 27 != c.which || g && 27 == c.which) return 27 == c.which && e.find(f).trigger("focus"), d.trigger("click");
                var h = " li:not(.disabled):visible a",
                    i = e.find(".dropdown-menu" + h);
                if (i.length) {
                    var j = i.index(c.target);
                    38 == c.which && j > 0 && j--, 40 == c.which && j < i.length - 1 && j++, ~j || (j = 0), i.eq(j).trigger("focus")
                }
            }
        }
    };
    var h = a.fn.dropdown;
    a.fn.dropdown = d, a.fn.dropdown.Constructor = g, a.fn.dropdown.noConflict = function() {
        return a.fn.dropdown = h, this
    }, a(document).on("click.bs.dropdown.data-api", c).on("click.bs.dropdown.data-api", ".dropdown form", function(a) {
        a.stopPropagation()
    }).on("click.bs.dropdown.data-api", f, g.prototype.toggle).on("keydown.bs.dropdown.data-api", f, g.prototype.keydown).on("keydown.bs.dropdown.data-api", ".dropdown-menu", g.prototype.keydown)
}(jQuery), + function(a) {
    "use strict";

    function b(b, d) {
        return this.each(function() {
            var e = a(this),
                f = e.data("bs.modal"),
                g = a.extend({}, c.DEFAULTS, e.data(), "object" == typeof b && b);
            f || e.data("bs.modal", f = new c(this, g)), "string" == typeof b ? f[b](d) : g.show && f.show(d)
        })
    }
    var c = function(b, c) {
        this.options = c, this.$body = a(document.body), this.$element = a(b), this.$dialog = this.$element.find(".modal-dialog"), this.$backdrop = null, this.isShown = null, this.originalBodyPad = null, this.scrollbarWidth = 0, this.ignoreBackdropClick = !1, this.options.remote && this.$element.find(".modal-content").load(this.options.remote, a.proxy(function() {
            this.$element.trigger("loaded.bs.modal")
        }, this))
    };
    c.VERSION = "3.3.7", c.TRANSITION_DURATION = 300, c.BACKDROP_TRANSITION_DURATION = 150, c.DEFAULTS = {
        backdrop: !0,
        keyboard: !0,
        show: !0
    }, c.prototype.toggle = function(a) {
        return this.isShown ? this.hide() : this.show(a)
    }, c.prototype.show = function(b) {
        var d = this,
            e = a.Event("show.bs.modal", {
                relatedTarget: b
            });
        this.$element.trigger(e), this.isShown || e.isDefaultPrevented() || (this.isShown = !0, this.checkScrollbar(), this.setScrollbar(), this.$body.addClass("modal-open"), this.escape(), this.resize(), this.$element.on("click.dismiss.bs.modal", '[data-dismiss="modal"]', a.proxy(this.hide, this)), this.$dialog.on("mousedown.dismiss.bs.modal", function() {
            d.$element.one("mouseup.dismiss.bs.modal", function(b) {
                a(b.target).is(d.$element) && (d.ignoreBackdropClick = !0)
            })
        }), this.backdrop(function() {
            var e = a.support.transition && d.$element.hasClass("fade");
            d.$element.parent().length || d.$element.appendTo(d.$body), d.$element.show().scrollTop(0), d.adjustDialog(), e && d.$element[0].offsetWidth, d.$element.addClass("in"), d.enforceFocus();
            var f = a.Event("shown.bs.modal", {
                relatedTarget: b
            });
            e ? d.$dialog.one("bsTransitionEnd", function() {
                d.$element.trigger("focus").trigger(f)
            }).emulateTransitionEnd(c.TRANSITION_DURATION) : d.$element.trigger("focus").trigger(f)
        }))
    }, c.prototype.hide = function(b) {
        b && b.preventDefault(), b = a.Event("hide.bs.modal"), this.$element.trigger(b), this.isShown && !b.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.resize(), a(document).off("focusin.bs.modal"), this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"), this.$dialog.off("mousedown.dismiss.bs.modal"), a.support.transition && this.$element.hasClass("fade") ? this.$element.one("bsTransitionEnd", a.proxy(this.hideModal, this)).emulateTransitionEnd(c.TRANSITION_DURATION) : this.hideModal())
    }, c.prototype.enforceFocus = function() {
        a(document).off("focusin.bs.modal").on("focusin.bs.modal", a.proxy(function(a) {
            document === a.target || this.$element[0] === a.target || this.$element.has(a.target).length || this.$element.trigger("focus")
        }, this))
    }, c.prototype.escape = function() {
        this.isShown && this.options.keyboard ? this.$element.on("keydown.dismiss.bs.modal", a.proxy(function(a) {
            27 == a.which && this.hide()
        }, this)) : this.isShown || this.$element.off("keydown.dismiss.bs.modal")
    }, c.prototype.resize = function() {
        this.isShown ? a(window).on("resize.bs.modal", a.proxy(this.handleUpdate, this)) : a(window).off("resize.bs.modal")
    }, c.prototype.hideModal = function() {
        var a = this;
        this.$element.hide(), this.backdrop(function() {
            a.$body.removeClass("modal-open"), a.resetAdjustments(), a.resetScrollbar(), a.$element.trigger("hidden.bs.modal")
        })
    }, c.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
    }, c.prototype.backdrop = function(b) {
        var d = this,
            e = this.$element.hasClass("fade") ? "fade" : "";
        if (this.isShown && this.options.backdrop) {
            var f = a.support.transition && e;
            if (this.$backdrop = a(document.createElement("div")).addClass("modal-backdrop " + e).appendTo(this.$body), this.$element.on("click.dismiss.bs.modal", a.proxy(function(a) {
                    return this.ignoreBackdropClick ? void(this.ignoreBackdropClick = !1) : void(a.target === a.currentTarget && ("static" == this.options.backdrop ? this.$element[0].focus() : this.hide()))
                }, this)), f && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), !b) return;
            f ? this.$backdrop.one("bsTransitionEnd", b).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION) : b()
        } else if (!this.isShown && this.$backdrop) {
            this.$backdrop.removeClass("in");
            var g = function() {
                d.removeBackdrop(), b && b()
            };
            a.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one("bsTransitionEnd", g).emulateTransitionEnd(c.BACKDROP_TRANSITION_DURATION) : g()
        } else b && b()
    }, c.prototype.handleUpdate = function() {
        this.adjustDialog()
    }, c.prototype.adjustDialog = function() {
        var a = this.$element[0].scrollHeight > document.documentElement.clientHeight;
        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && a ? this.scrollbarWidth : "",
            paddingRight: this.bodyIsOverflowing && !a ? this.scrollbarWidth : ""
        })
    }, c.prototype.resetAdjustments = function() {
        this.$element.css({
            paddingLeft: "",
            paddingRight: ""
        })
    }, c.prototype.checkScrollbar = function() {
        var a = window.innerWidth;
        if (!a) {
            var b = document.documentElement.getBoundingClientRect();
            a = b.right - Math.abs(b.left)
        }
        this.bodyIsOverflowing = document.body.clientWidth < a, this.scrollbarWidth = this.measureScrollbar()
    }, c.prototype.setScrollbar = function() {
        var a = parseInt(this.$body.css("padding-right") || 0, 10);
        this.originalBodyPad = document.body.style.paddingRight || "", this.bodyIsOverflowing && this.$body.css("padding-right", a + this.scrollbarWidth)
    }, c.prototype.resetScrollbar = function() {
        this.$body.css("padding-right", this.originalBodyPad)
    }, c.prototype.measureScrollbar = function() {
        var a = document.createElement("div");
        a.className = "modal-scrollbar-measure", this.$body.append(a);
        var b = a.offsetWidth - a.clientWidth;
        return this.$body[0].removeChild(a), b
    };
    var d = a.fn.modal;
    a.fn.modal = b, a.fn.modal.Constructor = c, a.fn.modal.noConflict = function() {
        return a.fn.modal = d, this
    }, a(document).on("click.bs.modal.data-api", '[data-toggle="modal"]', function(c) {
        var d = a(this),
            e = d.attr("href"),
            f = a(d.attr("data-target") || e && e.replace(/.*(?=#[^\s]+$)/, "")),
            g = f.data("bs.modal") ? "toggle" : a.extend({
                remote: !/#/.test(e) && e
            }, f.data(), d.data());
        d.is("a") && c.preventDefault(), f.one("show.bs.modal", function(a) {
            a.isDefaultPrevented() || f.one("hidden.bs.modal", function() {
                d.is(":visible") && d.trigger("focus")
            })
        }), b.call(f, g, this)
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.tooltip"),
                f = "object" == typeof b && b;
            !e && /destroy|hide/.test(b) || (e || d.data("bs.tooltip", e = new c(this, f)), "string" == typeof b && e[b]())
        })
    }
    var c = function(a, b) {
        this.type = null, this.options = null, this.enabled = null, this.timeout = null, this.hoverState = null, this.$element = null, this.inState = null, this.init("tooltip", a, b)
    };
    c.VERSION = "3.3.7", c.TRANSITION_DURATION = 150, c.DEFAULTS = {
        animation: !0,
        placement: "top",
        selector: !1,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: "hover focus",
        title: "",
        delay: 0,
        html: !1,
        container: !1,
        viewport: {
            selector: "body",
            padding: 0
        }
    }, c.prototype.init = function(b, c, d) {
        if (this.enabled = !0, this.type = b, this.$element = a(c), this.options = this.getOptions(d), this.$viewport = this.options.viewport && a(a.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : this.options.viewport.selector || this.options.viewport), this.inState = {
                click: !1,
                hover: !1,
                focus: !1
            }, this.$element[0] instanceof document.constructor && !this.options.selector) throw new Error("`selector` option must be specified when initializing " + this.type + " on the window.document object!");
        for (var e = this.options.trigger.split(" "), f = e.length; f--;) {
            var g = e[f];
            if ("click" == g) this.$element.on("click." + this.type, this.options.selector, a.proxy(this.toggle, this));
            else if ("manual" != g) {
                var h = "hover" == g ? "mouseenter" : "focusin",
                    i = "hover" == g ? "mouseleave" : "focusout";
                this.$element.on(h + "." + this.type, this.options.selector, a.proxy(this.enter, this)), this.$element.on(i + "." + this.type, this.options.selector, a.proxy(this.leave, this))
            }
        }
        this.options.selector ? this._options = a.extend({}, this.options, {
            trigger: "manual",
            selector: ""
        }) : this.fixTitle()
    }, c.prototype.getDefaults = function() {
        return c.DEFAULTS
    }, c.prototype.getOptions = function(b) {
        return b = a.extend({}, this.getDefaults(), this.$element.data(), b), b.delay && "number" == typeof b.delay && (b.delay = {
            show: b.delay,
            hide: b.delay
        }), b
    }, c.prototype.getDelegateOptions = function() {
        var b = {},
            c = this.getDefaults();
        return this._options && a.each(this._options, function(a, d) {
            c[a] != d && (b[a] = d)
        }), b
    }, c.prototype.enter = function(b) {
        var c = b instanceof this.constructor ? b : a(b.currentTarget).data("bs." + this.type);
        return c || (c = new this.constructor(b.currentTarget, this.getDelegateOptions()), a(b.currentTarget).data("bs." + this.type, c)), b instanceof a.Event && (c.inState["focusin" == b.type ? "focus" : "hover"] = !0), c.tip().hasClass("in") || "in" == c.hoverState ? void(c.hoverState = "in") : (clearTimeout(c.timeout), c.hoverState = "in", c.options.delay && c.options.delay.show ? void(c.timeout = setTimeout(function() {
            "in" == c.hoverState && c.show()
        }, c.options.delay.show)) : c.show())
    }, c.prototype.isInStateTrue = function() {
        for (var a in this.inState)
            if (this.inState[a]) return !0;
        return !1
    }, c.prototype.leave = function(b) {
        var c = b instanceof this.constructor ? b : a(b.currentTarget).data("bs." + this.type);
        if (c || (c = new this.constructor(b.currentTarget, this.getDelegateOptions()), a(b.currentTarget).data("bs." + this.type, c)), b instanceof a.Event && (c.inState["focusout" == b.type ? "focus" : "hover"] = !1), !c.isInStateTrue()) return clearTimeout(c.timeout), c.hoverState = "out", c.options.delay && c.options.delay.hide ? void(c.timeout = setTimeout(function() {
            "out" == c.hoverState && c.hide()
        }, c.options.delay.hide)) : c.hide()
    }, c.prototype.show = function() {
        var b = a.Event("show.bs." + this.type);
        if (this.hasContent() && this.enabled) {
            this.$element.trigger(b);
            var d = a.contains(this.$element[0].ownerDocument.documentElement, this.$element[0]);
            if (b.isDefaultPrevented() || !d) return;
            var e = this,
                f = this.tip(),
                g = this.getUID(this.type);
            this.setContent(), f.attr("id", g), this.$element.attr("aria-describedby", g), this.options.animation && f.addClass("fade");
            var h = "function" == typeof this.options.placement ? this.options.placement.call(this, f[0], this.$element[0]) : this.options.placement,
                i = /\s?auto?\s?/i,
                j = i.test(h);
            j && (h = h.replace(i, "") || "top"), f.detach().css({
                top: 0,
                left: 0,
                display: "block"
            }).addClass(h).data("bs." + this.type, this), this.options.container ? f.appendTo(this.options.container) : f.insertAfter(this.$element), this.$element.trigger("inserted.bs." + this.type);
            var k = this.getPosition(),
                l = f[0].offsetWidth,
                m = f[0].offsetHeight;
            if (j) {
                var n = h,
                    o = this.getPosition(this.$viewport);
                h = "bottom" == h && k.bottom + m > o.bottom ? "top" : "top" == h && k.top - m < o.top ? "bottom" : "right" == h && k.right + l > o.width ? "left" : "left" == h && k.left - l < o.left ? "right" : h, f.removeClass(n).addClass(h)
            }
            var p = this.getCalculatedOffset(h, k, l, m);
            this.applyPlacement(p, h);
            var q = function() {
                var a = e.hoverState;
                e.$element.trigger("shown.bs." + e.type), e.hoverState = null, "out" == a && e.leave(e)
            };
            a.support.transition && this.$tip.hasClass("fade") ? f.one("bsTransitionEnd", q).emulateTransitionEnd(c.TRANSITION_DURATION) : q()
        }
    }, c.prototype.applyPlacement = function(b, c) {
        var d = this.tip(),
            e = d[0].offsetWidth,
            f = d[0].offsetHeight,
            g = parseInt(d.css("margin-top"), 10),
            h = parseInt(d.css("margin-left"), 10);
        isNaN(g) && (g = 0), isNaN(h) && (h = 0), b.top += g, b.left += h, a.offset.setOffset(d[0], a.extend({
            using: function(a) {
                d.css({
                    top: Math.round(a.top),
                    left: Math.round(a.left)
                })
            }
        }, b), 0), d.addClass("in");
        var i = d[0].offsetWidth,
            j = d[0].offsetHeight;
        "top" == c && j != f && (b.top = b.top + f - j);
        var k = this.getViewportAdjustedDelta(c, b, i, j);
        k.left ? b.left += k.left : b.top += k.top;
        var l = /top|bottom/.test(c),
            m = l ? 2 * k.left - e + i : 2 * k.top - f + j,
            n = l ? "offsetWidth" : "offsetHeight";
        d.offset(b), this.replaceArrow(m, d[0][n], l)
    }, c.prototype.replaceArrow = function(a, b, c) {
        this.arrow().css(c ? "left" : "top", 50 * (1 - a / b) + "%").css(c ? "top" : "left", "")
    }, c.prototype.setContent = function() {
        var a = this.tip(),
            b = this.getTitle();
        a.find(".tooltip-inner")[this.options.html ? "html" : "text"](b), a.removeClass("fade in top bottom left right")
    }, c.prototype.hide = function(b) {
        function d() {
            "in" != e.hoverState && f.detach(), e.$element && e.$element.removeAttr("aria-describedby").trigger("hidden.bs." + e.type), b && b()
        }
        var e = this,
            f = a(this.$tip),
            g = a.Event("hide.bs." + this.type);
        if (this.$element.trigger(g), !g.isDefaultPrevented()) return f.removeClass("in"), a.support.transition && f.hasClass("fade") ? f.one("bsTransitionEnd", d).emulateTransitionEnd(c.TRANSITION_DURATION) : d(), this.hoverState = null, this
    }, c.prototype.fixTitle = function() {
        var a = this.$element;
        (a.attr("title") || "string" != typeof a.attr("data-original-title")) && a.attr("data-original-title", a.attr("title") || "").attr("title", "")
    }, c.prototype.hasContent = function() {
        return this.getTitle()
    }, c.prototype.getPosition = function(b) {
        b = b || this.$element;
        var c = b[0],
            d = "BODY" == c.tagName,
            e = c.getBoundingClientRect();
        null == e.width && (e = a.extend({}, e, {
            width: e.right - e.left,
            height: e.bottom - e.top
        }));
        var f = window.SVGElement && c instanceof window.SVGElement,
            g = d ? {
                top: 0,
                left: 0
            } : f ? null : b.offset(),
            h = {
                scroll: d ? document.documentElement.scrollTop || document.body.scrollTop : b.scrollTop()
            },
            i = d ? {
                width: a(window).width(),
                height: a(window).height()
            } : null;
        return a.extend({}, e, h, i, g)
    }, c.prototype.getCalculatedOffset = function(a, b, c, d) {
        return "bottom" == a ? {
            top: b.top + b.height,
            left: b.left + b.width / 2 - c / 2
        } : "top" == a ? {
            top: b.top - d,
            left: b.left + b.width / 2 - c / 2
        } : "left" == a ? {
            top: b.top + b.height / 2 - d / 2,
            left: b.left - c
        } : {
            top: b.top + b.height / 2 - d / 2,
            left: b.left + b.width
        }
    }, c.prototype.getViewportAdjustedDelta = function(a, b, c, d) {
        var e = {
            top: 0,
            left: 0
        };
        if (!this.$viewport) return e;
        var f = this.options.viewport && this.options.viewport.padding || 0,
            g = this.getPosition(this.$viewport);
        if (/right|left/.test(a)) {
            var h = b.top - f - g.scroll,
                i = b.top + f - g.scroll + d;
            h < g.top ? e.top = g.top - h : i > g.top + g.height && (e.top = g.top + g.height - i)
        } else {
            var j = b.left - f,
                k = b.left + f + c;
            j < g.left ? e.left = g.left - j : k > g.right && (e.left = g.left + g.width - k)
        }
        return e
    }, c.prototype.getTitle = function() {
        var a, b = this.$element,
            c = this.options;
        return a = b.attr("data-original-title") || ("function" == typeof c.title ? c.title.call(b[0]) : c.title)
    }, c.prototype.getUID = function(a) {
        do a += ~~(1e6 * Math.random()); while (document.getElementById(a));
        return a
    }, c.prototype.tip = function() {
        if (!this.$tip && (this.$tip = a(this.options.template), 1 != this.$tip.length)) throw new Error(this.type + " `template` option must consist of exactly 1 top-level element!");
        return this.$tip
    }, c.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
    }, c.prototype.enable = function() {
        this.enabled = !0
    }, c.prototype.disable = function() {
        this.enabled = !1
    }, c.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    }, c.prototype.toggle = function(b) {
        var c = this;
        b && (c = a(b.currentTarget).data("bs." + this.type), c || (c = new this.constructor(b.currentTarget, this.getDelegateOptions()), a(b.currentTarget).data("bs." + this.type, c))), b ? (c.inState.click = !c.inState.click, c.isInStateTrue() ? c.enter(c) : c.leave(c)) : c.tip().hasClass("in") ? c.leave(c) : c.enter(c)
    }, c.prototype.destroy = function() {
        var a = this;
        clearTimeout(this.timeout), this.hide(function() {
            a.$element.off("." + a.type).removeData("bs." + a.type), a.$tip && a.$tip.detach(), a.$tip = null, a.$arrow = null, a.$viewport = null, a.$element = null
        })
    };
    var d = a.fn.tooltip;
    a.fn.tooltip = b, a.fn.tooltip.Constructor = c, a.fn.tooltip.noConflict = function() {
        return a.fn.tooltip = d, this
    }
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.popover"),
                f = "object" == typeof b && b;
            !e && /destroy|hide/.test(b) || (e || d.data("bs.popover", e = new c(this, f)), "string" == typeof b && e[b]())
        })
    }
    var c = function(a, b) {
        this.init("popover", a, b)
    };
    if (!a.fn.tooltip) throw new Error("Popover requires tooltip.js");
    c.VERSION = "3.3.7", c.DEFAULTS = a.extend({}, a.fn.tooltip.Constructor.DEFAULTS, {
        placement: "right",
        trigger: "click",
        content: "",
        template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    }), c.prototype = a.extend({}, a.fn.tooltip.Constructor.prototype), c.prototype.constructor = c, c.prototype.getDefaults = function() {
        return c.DEFAULTS
    }, c.prototype.setContent = function() {
        var a = this.tip(),
            b = this.getTitle(),
            c = this.getContent();
        a.find(".popover-title")[this.options.html ? "html" : "text"](b), a.find(".popover-content").children().detach().end()[this.options.html ? "string" == typeof c ? "html" : "append" : "text"](c), a.removeClass("fade top bottom left right in"), a.find(".popover-title").html() || a.find(".popover-title").hide()
    }, c.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    }, c.prototype.getContent = function() {
        var a = this.$element,
            b = this.options;
        return a.attr("data-content") || ("function" == typeof b.content ? b.content.call(a[0]) : b.content)
    }, c.prototype.arrow = function() {
        return this.$arrow = this.$arrow || this.tip().find(".arrow")
    };
    var d = a.fn.popover;
    a.fn.popover = b, a.fn.popover.Constructor = c, a.fn.popover.noConflict = function() {
        return a.fn.popover = d, this
    }
}(jQuery), + function(a) {
    "use strict";

    function b(c, d) {
        this.$body = a(document.body), this.$scrollElement = a(a(c).is(document.body) ? window : c), this.options = a.extend({}, b.DEFAULTS, d), this.selector = (this.options.target || "") + " .nav li > a", this.offsets = [], this.targets = [], this.activeTarget = null, this.scrollHeight = 0, this.$scrollElement.on("scroll.bs.scrollspy", a.proxy(this.process, this)), this.refresh(), this.process()
    }

    function c(c) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.scrollspy"),
                f = "object" == typeof c && c;
            e || d.data("bs.scrollspy", e = new b(this, f)), "string" == typeof c && e[c]()
        })
    }
    b.VERSION = "3.3.7", b.DEFAULTS = {
        offset: 10
    }, b.prototype.getScrollHeight = function() {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    }, b.prototype.refresh = function() {
        var b = this,
            c = "offset",
            d = 0;
        this.offsets = [], this.targets = [], this.scrollHeight = this.getScrollHeight(), a.isWindow(this.$scrollElement[0]) || (c = "position", d = this.$scrollElement.scrollTop()), this.$body.find(this.selector).map(function() {
            var b = a(this),
                e = b.data("target") || b.attr("href"),
                f = /^#./.test(e) && a(e);
            return f && f.length && f.is(":visible") && [
                [f[c]().top + d, e]
            ] || null
        }).sort(function(a, b) {
            return a[0] - b[0]
        }).each(function() {
            b.offsets.push(this[0]), b.targets.push(this[1])
        })
    }, b.prototype.process = function() {
        var a, b = this.$scrollElement.scrollTop() + this.options.offset,
            c = this.getScrollHeight(),
            d = this.options.offset + c - this.$scrollElement.height(),
            e = this.offsets,
            f = this.targets,
            g = this.activeTarget;
        if (this.scrollHeight != c && this.refresh(), b >= d) return g != (a = f[f.length - 1]) && this.activate(a);
        if (g && b < e[0]) return this.activeTarget = null, this.clear();
        for (a = e.length; a--;) g != f[a] && b >= e[a] && (void 0 === e[a + 1] || b < e[a + 1]) && this.activate(f[a])
    }, b.prototype.activate = function(b) {
        this.activeTarget = b, this.clear();
        var c = this.selector + '[data-target="' + b + '"],' + this.selector + '[href="' + b + '"]',
            d = a(c).parents("li").addClass("active");
        d.parent(".dropdown-menu").length && (d = d.closest("li.dropdown").addClass("active")), d.trigger("activate.bs.scrollspy")
    }, b.prototype.clear = function() {
        a(this.selector).parentsUntil(this.options.target, ".active").removeClass("active")
    };
    var d = a.fn.scrollspy;
    a.fn.scrollspy = c, a.fn.scrollspy.Constructor = b, a.fn.scrollspy.noConflict = function() {
        return a.fn.scrollspy = d, this
    }, a(window).on("load.bs.scrollspy.data-api", function() {
        a('[data-spy="scroll"]').each(function() {
            var b = a(this);
            c.call(b, b.data())
        })
    })
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.tab");
            e || d.data("bs.tab", e = new c(this)), "string" == typeof b && e[b]()
        })
    }
    var c = function(b) {
        this.element = a(b)
    };
    c.VERSION = "3.3.7", c.TRANSITION_DURATION = 150, c.prototype.show = function() {
        var b = this.element,
            c = b.closest("ul:not(.dropdown-menu)"),
            d = b.data("target");
        if (d || (d = b.attr("href"), d = d && d.replace(/.*(?=#[^\s]*$)/, "")), !b.parent("li").hasClass("active")) {
            var e = c.find(".active:last a"),
                f = a.Event("hide.bs.tab", {
                    relatedTarget: b[0]
                }),
                g = a.Event("show.bs.tab", {
                    relatedTarget: e[0]
                });
            if (e.trigger(f), b.trigger(g), !g.isDefaultPrevented() && !f.isDefaultPrevented()) {
                var h = a(d);
                this.activate(b.closest("li"), c), this.activate(h, h.parent(), function() {
                    e.trigger({
                        type: "hidden.bs.tab",
                        relatedTarget: b[0]
                    }), b.trigger({
                        type: "shown.bs.tab",
                        relatedTarget: e[0]
                    })
                })
            }
        }
    }, c.prototype.activate = function(b, d, e) {
        function f() {
            g.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !1), b.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded", !0), h ? (b[0].offsetWidth, b.addClass("in")) : b.removeClass("fade"), b.parent(".dropdown-menu").length && b.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded", !0), e && e()
        }
        var g = d.find("> .active"),
            h = e && a.support.transition && (g.length && g.hasClass("fade") || !!d.find("> .fade").length);
        g.length && h ? g.one("bsTransitionEnd", f).emulateTransitionEnd(c.TRANSITION_DURATION) : f(), g.removeClass("in")
    };
    var d = a.fn.tab;
    a.fn.tab = b, a.fn.tab.Constructor = c, a.fn.tab.noConflict = function() {
        return a.fn.tab = d, this
    };
    var e = function(c) {
        c.preventDefault(), b.call(a(this), "show")
    };
    a(document).on("click.bs.tab.data-api", '[data-toggle="tab"]', e).on("click.bs.tab.data-api", '[data-toggle="pill"]', e)
}(jQuery), + function(a) {
    "use strict";

    function b(b) {
        return this.each(function() {
            var d = a(this),
                e = d.data("bs.affix"),
                f = "object" == typeof b && b;
            e || d.data("bs.affix", e = new c(this, f)), "string" == typeof b && e[b]()
        })
    }
    var c = function(b, d) {
        this.options = a.extend({}, c.DEFAULTS, d), this.$target = a(this.options.target).on("scroll.bs.affix.data-api", a.proxy(this.checkPosition, this)).on("click.bs.affix.data-api", a.proxy(this.checkPositionWithEventLoop, this)), this.$element = a(b), this.affixed = null, this.unpin = null, this.pinnedOffset = null, this.checkPosition()
    };
    c.VERSION = "3.3.7", c.RESET = "affix affix-top affix-bottom", c.DEFAULTS = {
        offset: 0,
        target: window
    }, c.prototype.getState = function(a, b, c, d) {
        var e = this.$target.scrollTop(),
            f = this.$element.offset(),
            g = this.$target.height();
        if (null != c && "top" == this.affixed) return e < c && "top";
        if ("bottom" == this.affixed) return null != c ? !(e + this.unpin <= f.top) && "bottom" : !(e + g <= a - d) && "bottom";
        var h = null == this.affixed,
            i = h ? e : f.top,
            j = h ? g : b;
        return null != c && e <= c ? "top" : null != d && i + j >= a - d && "bottom"
    }, c.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset) return this.pinnedOffset;
        this.$element.removeClass(c.RESET).addClass("affix");
        var a = this.$target.scrollTop(),
            b = this.$element.offset();
        return this.pinnedOffset = b.top - a
    }, c.prototype.checkPositionWithEventLoop = function() {
        setTimeout(a.proxy(this.checkPosition, this), 1)
    }, c.prototype.checkPosition = function() {
        if (this.$element.is(":visible")) {
            var b = this.$element.height(),
                d = this.options.offset,
                e = d.top,
                f = d.bottom,
                g = Math.max(a(document).height(), a(document.body).height());
            "object" != typeof d && (f = e = d), "function" == typeof e && (e = d.top(this.$element)), "function" == typeof f && (f = d.bottom(this.$element));
            var h = this.getState(g, b, e, f);
            if (this.affixed != h) {
                null != this.unpin && this.$element.css("top", "");
                var i = "affix" + (h ? "-" + h : ""),
                    j = a.Event(i + ".bs.affix");
                if (this.$element.trigger(j), j.isDefaultPrevented()) return;
                this.affixed = h, this.unpin = "bottom" == h ? this.getPinnedOffset() : null, this.$element.removeClass(c.RESET).addClass(i).trigger(i.replace("affix", "affixed") + ".bs.affix")
            }
            "bottom" == h && this.$element.offset({
                top: g - b - f
            })
        }
    };
    var d = a.fn.affix;
    a.fn.affix = b, a.fn.affix.Constructor = c, a.fn.affix.noConflict = function() {
        return a.fn.affix = d, this
    }, a(window).on("load", function() {
        a('[data-spy="affix"]').each(function() {
            var c = a(this),
                d = c.data();
            d.offset = d.offset || {}, null != d.offsetBottom && (d.offset.bottom = d.offsetBottom), null != d.offsetTop && (d.offset.top = d.offsetTop), b.call(c, d)
        })
    })
}(jQuery);;
! function(e) {
    function n(n, t, s) {
        if (s) {
            if ("object" != typeof n && (n = {}), "boolean" != typeof n.isMenu) {
                var o = s.children();
                n.isMenu = 1 == o.length && o.is(t.panelNodetype)
            }
            return n
        }
        return n = e.extend(!0, {}, e[a].defaults, n), ("top" == n.position || "bottom" == n.position) && ("back" == n.zposition || "next" == n.zposition) && (e[a].deprecated('Using position "' + n.position + '" in combination with zposition "' + n.zposition + '"', 'zposition "front"'), n.zposition = "front"), n
    }

    function t(n) {
        return n = e.extend(!0, {}, e[a].configuration, n), "string" != typeof n.pageSelector && (n.pageSelector = "> " + n.pageNodetype), n
    }

    function s() {
        r.$wndw = e(window), r.$html = e("html"), r.$body = e("body"), r.$allMenus = e(), e.each([d, c, u], function(e, n) {
            n.add = function(e) {
                e = e.split(" ");
                for (var t in e) n[e[t]] = n.mm(e[t])
            }
        }), d.mm = function(e) {
            return "mm-" + e
        }, d.add("menu ismenu panel list subtitle selected label spacer current highest hidden page blocker modal background opened opening subopened subopen fullsubopen subclose"), d.umm = function(e) {
            return "mm-" == e.slice(0, 3) && (e = e.slice(3)), e
        }, c.mm = function(e) {
            return "mm-" + e
        }, c.add("parent style"), u.mm = function(e) {
            return e + ".mm"
        }, u.add("toggle open opening opened close closing closed update setPage setSelected transitionend webkitTransitionEnd mousedown touchstart mouseup touchend scroll touchmove click keydown keyup resize"), r.$wndw.on(u.keydown, function(e) {
            return r.$html.hasClass(d.opened) && 9 == e.keyCode ? (e.preventDefault(), !1) : void 0
        });
        var n = 0;
        r.$wndw.on(u.resize, function(e, t) {
            if (t || r.$html.hasClass(d.opened)) {
                var s = r.$wndw.height();
                s != n && (n = s, r.$page.css("min-height", s))
            }
        }), e[a]._c = d, e[a]._d = c, e[a]._e = u, e[a].glbl = r
    }

    function o(n, t) {
        if (n.hasClass(d.current)) return !1;
        var s = e("." + d.panel, t),
            o = s.filter("." + d.current);
        return s.removeClass(d.highest).removeClass(d.current).not(n).not(o).addClass(d.hidden), n.hasClass(d.opened) ? o.addClass(d.highest).removeClass(d.opened).removeClass(d.subopened) : (n.addClass(d.highest), o.addClass(d.subopened)), n.removeClass(d.hidden).removeClass(d.subopened).addClass(d.current).addClass(d.opened), "open"
    }

    function i(e, n, t) {
        var s = !1,
            o = function() {
                s || n.call(e[0]), s = !0
            };
        e.one(u.transitionend, o), e.one(u.webkitTransitionEnd, o), setTimeout(o, 1.1 * t)
    }
    var a = "mmenu",
        l = "4.2.0";
    if (!e[a]) {
        var r = {
                $wndw: null,
                $html: null,
                $body: null,
                $page: null,
                $blck: null,
                $allMenus: null
            },
            d = {},
            c = {},
            u = {},
            p = 0,
            h = 0;
        e[a] = function(e, n, t) {
                return r.$allMenus = r.$allMenus.add(e), this.$menu = e, this.opts = n, this.conf = t, this.serialnr = p++, this._init(), this
            }, e[a].prototype = {
                open: function() {
                    var e = this;
                    return this._openSetup(), setTimeout(function() {
                        e._openFinish()
                    }, 50), "open"
                },
                _openSetup: function() {
                    h = r.$wndw.scrollTop(), this.$menu.addClass(d.current), r.$allMenus.not(this.$menu).trigger(u.close), r.$page.data(c.style, r.$page.attr("style") || ""), r.$wndw.trigger(u.resize, [!0]), this.opts.modal && r.$html.addClass(d.modal), this.opts.moveBackground && r.$html.addClass(d.background), "left" != this.opts.position && r.$html.addClass(d.mm(this.opts.position)), "back" != this.opts.zposition && r.$html.addClass(d.mm(this.opts.zposition)), this.opts.classes && r.$html.addClass(this.opts.classes), r.$html.addClass(d.opened), this.$menu.addClass(d.opened)
                },
                _openFinish: function() {
                    var e = this;
                    i(r.$page, function() {
                        e.$menu.trigger(u.opened)
                    }, this.conf.transitionDuration), r.$html.addClass(d.opening), this.$menu.trigger(u.opening)
                },
                close: function() {
                    var e = this;
                    return i(r.$page, function() {
                        e.$menu.removeClass(d.current).removeClass(d.opened), r.$html.removeClass(d.opened).removeClass(d.modal).removeClass(d.background).removeClass(d.mm(e.opts.position)).removeClass(d.mm(e.opts.zposition)), e.opts.classes && r.$html.removeClass(e.opts.classes), r.$wndw.off(u.resize).off(u.keydown), r.$page.attr("style", r.$page.data(c.style)), e.$menu.trigger(u.closed)
                    }, this.conf.transitionDuration), r.$html.removeClass(d.opening), this.$menu.trigger(u.closing), "close"
                },
                _init: function() {
                    if (this.opts = n(this.opts, this.conf, this.$menu), this.direction = this.opts.slidingSubmenus ? "horizontal" : "vertical", this._initPage(r.$page), this._initMenu(), this._initBlocker(), this._initPanles(), this._initLinks(), this._initOpenClose(), this._bindCustomEvents(), e[a].addons)
                        for (var t = 0; t < e[a].addons.length; t++) "function" == typeof this["_addon_" + e[a].addons[t]] && this["_addon_" + e[a].addons[t]]()
                },
                _bindCustomEvents: function() {
                    var n = this;
                    this.$menu.off(u.open + " " + u.close + " " + u.setPage + " " + u.update).on(u.open + " " + u.close + " " + u.setPage + " " + u.update, function(e) {
                        e.stopPropagation()
                    }), this.$menu.on(u.open, function(t) {
                        return e(this).hasClass(d.current) ? (t.stopImmediatePropagation(), !1) : n.open()
                    }).on(u.close, function(t) {
                        return e(this).hasClass(d.current) ? n.close() : (t.stopImmediatePropagation(), !1)
                    }).on(u.setPage, function(e, t) {
                        n._initPage(t), n._initOpenClose()
                    });
                    var t = this.$menu.find(this.opts.isMenu && "horizontal" != this.direction ? "ul, ol" : "." + d.panel);
                    t.off(u.toggle + " " + u.open + " " + u.close).on(u.toggle + " " + u.open + " " + u.close, function(e) {
                        e.stopPropagation()
                    }), "horizontal" == this.direction ? t.on(u.open, function() {
                        return o(e(this), n.$menu)
                    }) : t.on(u.toggle, function() {
                        var n = e(this);
                        return n.triggerHandler(n.parent().hasClass(d.opened) ? u.close : u.open)
                    }).on(u.open, function() {
                        return e(this).parent().addClass(d.opened), "open"
                    }).on(u.close, function() {
                        return e(this).parent().removeClass(d.opened), "close"
                    })
                },
                _initBlocker: function() {
                    var n = this;
                    r.$blck || (r.$blck = e('<div id="' + d.blocker + '" />').appendTo(r.$body)), r.$blck.off(u.touchstart).on(u.touchstart, function(e) {
                        e.preventDefault(), e.stopPropagation(), r.$blck.trigger(u.mousedown)
                    }).on(u.mousedown, function(e) {
                        e.preventDefault(), r.$html.hasClass(d.modal) || n.$menu.trigger(u.close)
                    })
                },
                _initPage: function(n) {
                    n || (n = e(this.conf.pageSelector, r.$body), n.length > 1 && (e[a].debug("Multiple nodes found for the page-node, all nodes are wrapped in one <" + this.conf.pageNodetype + ">."), n = n.wrapAll("<" + this.conf.pageNodetype + " />").parent())), n.addClass(d.page), r.$page = n
                },
                _initMenu: function() {
                    this.conf.clone && (this.$menu = this.$menu.clone(!0), this.$menu.add(this.$menu.find("*")).filter("[id]").each(function() {
                        e(this).attr("id", d.mm(e(this).attr("id")))
                    })), this.$menu.contents().each(function() {
                        3 == e(this)[0].nodeType && e(this).remove()
                    }), this.$menu.prependTo("body").addClass(d.menu), this.$menu.addClass(d.mm(this.direction)), this.opts.classes && this.$menu.addClass(this.opts.classes), this.opts.isMenu && this.$menu.addClass(d.ismenu), "left" != this.opts.position && this.$menu.addClass(d.mm(this.opts.position)), "back" != this.opts.zposition && this.$menu.addClass(d.mm(this.opts.zposition))
                },
                _initPanles: function() {
                    var n = this;
                    this.__refactorClass(e("." + this.conf.listClass, this.$menu), "list"), this.opts.isMenu && e("ul, ol", this.$menu).not(".mm-nolist").addClass(d.list);
                    var t = e("." + d.list + " > li", this.$menu);
                    this.__refactorClass(t.filter("." + this.conf.selectedClass), "selected"), this.__refactorClass(t.filter("." + this.conf.labelClass), "label"), this.__refactorClass(t.filter("." + this.conf.spacerClass), "spacer"), t.off(u.setSelected).on(u.setSelected, function(n, s) {
                        n.stopPropagation(), t.removeClass(d.selected), "boolean" != typeof s && (s = !0), s && e(this).addClass(d.selected)
                    }), this.__refactorClass(e("." + this.conf.panelClass, this.$menu), "panel"), this.$menu.children().filter(this.conf.panelNodetype).add(this.$menu.find("." + d.list).children().children().filter(this.conf.panelNodetype)).addClass(d.panel);
                    var s = e("." + d.panel, this.$menu);
                    s.each(function(t) {
                        var s = e(this),
                            o = s.attr("id") || d.mm("m" + n.serialnr + "-p" + t);
                        s.attr("id", o)
                    }), s.find("." + d.panel).each(function() {
                        var t = e(this),
                            s = t.is("ul, ol") ? t : t.find("ul ,ol").first(),
                            o = t.parent(),
                            i = o.find("> a, > span"),
                            a = o.closest("." + d.panel);
                        if (t.data(c.parent, o), o.parent().is("." + d.list)) {
                            var l = e('<a class="' + d.subopen + '" href="#' + t.attr("id") + '" />').insertBefore(i);
                            i.is("a") || l.addClass(d.fullsubopen), "horizontal" == n.direction && s.prepend('<li class="' + d.subtitle + '"><a class="' + d.subclose + '" href="#' + a.attr("id") + '">' + i.text() + "</a></li>")
                        }
                    });
                    var o = "horizontal" == this.direction ? u.open : u.toggle;
                    if (s.each(function() {
                            var t = e(this),
                                s = t.attr("id");
                            e('a[href="#' + s + '"]', n.$menu).off(u.click).on(u.click, function(e) {
                                e.preventDefault(), t.trigger(o)
                            })
                        }), "horizontal" == this.direction) {
                        var i = e("." + d.list + " > li." + d.selected, this.$menu);
                        i.add(i.parents("li")).parents("li").removeClass(d.selected).end().each(function() {
                            var n = e(this),
                                t = n.find("> ." + d.panel);
                            t.length && (n.parents("." + d.panel).addClass(d.subopened), t.addClass(d.opened))
                        }).closest("." + d.panel).addClass(d.opened).parents("." + d.panel).addClass(d.subopened)
                    } else e("li." + d.selected, this.$menu).addClass(d.opened).parents("." + d.selected).removeClass(d.selected);
                    var a = s.filter("." + d.opened);
                    a.length || (a = s.first()), a.addClass(d.opened).last().addClass(d.current), "horizontal" == this.direction && s.find("." + d.panel).appendTo(this.$menu)
                },
                _initLinks: function() {
                    var n = this;
                    e("." + d.list + " > li > a", this.$menu).not("." + d.subopen).not("." + d.subclose).not('[rel="external"]').not('[target="_blank"]').off(u.click).on(u.click, function(t) {
                        var s = e(this),
                            o = s.attr("href");
                        n.__valueOrFn(n.opts.onClick.setSelected, s) && s.parent().trigger(u.setSelected);
                        var i = n.__valueOrFn(n.opts.onClick.preventDefault, s, "#" == o.slice(0, 1));
                        i && t.preventDefault(), n.__valueOrFn(n.opts.onClick.blockUI, s, !i) && r.$html.addClass(d.blocking), n.__valueOrFn(n.opts.onClick.close, s, i) && n.$menu.triggerHandler(u.close)
                    })
                },
                _initOpenClose: function() {
                    var n = this,
                        t = this.$menu.attr("id");
                    t && t.length && (this.conf.clone && (t = d.umm(t)), e('a[href="#' + t + '"]').off(u.click).on(u.click, function(e) {
                        e.preventDefault(), n.$menu.trigger(u.open)
                    }));
                    var t = r.$page.attr("id");
                    t && t.length && e('a[href="#' + t + '"]').off(u.click).on(u.click, function(e) {
                        e.preventDefault(), n.$menu.trigger(u.close)
                    })
                },
                __valueOrFn: function(e, n, t) {
                    return "function" == typeof e ? e.call(n[0]) : "undefined" == typeof e && "undefined" != typeof t ? t : e
                },
                __refactorClass: function(e, n) {
                    e.removeClass(this.conf[n + "Class"]).addClass(d[n])
                }
            }, e.fn[a] = function(o, i) {
                return r.$wndw || s(), o = n(o, i), i = t(i), this.each(function() {
                    var n = e(this);
                    n.data(a) || n.data(a, new e[a](n, o, i))
                })
            }, e[a].version = l, e[a].defaults = {
                position: "left",
                zposition: "back",
                moveBackground: !0,
                slidingSubmenus: !0,
                modal: !1,
                classes: "",
                onClick: {
                    setSelected: !0
                }
            }, e[a].configuration = {
                preventTabbing: !0,
                panelClass: "Panel",
                listClass: "List",
                selectedClass: "Selected",
                labelClass: "Label",
                spacerClass: "Spacer",
                pageNodetype: "div",
                panelNodetype: "ul, ol, div",
                transitionDuration: 400
            },
            function() {
                var n = window.document,
                    t = window.navigator.userAgent,
                    s = (document.createElement("div").style, "ontouchstart" in n),
                    o = "WebkitOverflowScrolling" in n.documentElement.style,
                    i = function() {
                        return t.indexOf("Android") >= 0 ? 2.4 > parseFloat(t.slice(t.indexOf("Android") + 8)) : !1
                    }();
                e[a].support = {
                    touch: s,
                    oldAndroidBrowser: i,
                    overflowscrolling: function() {
                        return s ? o ? !0 : i ? !1 : !0 : !0
                    }()
                }
            }(), e[a].debug = function() {}, e[a].deprecated = function(e, n) {
                "undefined" != typeof console && "undefined" != typeof console.warn && console.warn("MMENU: " + e + " is deprecated, use " + n + " instead.")
            }
    }
}(jQuery);;
(function() {
    function n(n) {
        function t(t, r, e, u, i, o) {
            for (; i >= 0 && o > i; i += n) {
                var a = u ? u[i] : i;
                e = r(e, t[a], a, t)
            }
            return e
        }
        return function(r, e, u, i) {
            e = b(e, i, 4);
            var o = !k(r) && m.keys(r),
                a = (o || r).length,
                c = n > 0 ? 0 : a - 1;
            return arguments.length < 3 && (u = r[o ? o[c] : c], c += n), t(r, e, u, o, c, a)
        }
    }

    function t(n) {
        return function(t, r, e) {
            r = x(r, e);
            for (var u = O(t), i = n > 0 ? 0 : u - 1; i >= 0 && u > i; i += n)
                if (r(t[i], i, t)) return i;
            return -1
        }
    }

    function r(n, t, r) {
        return function(e, u, i) {
            var o = 0,
                a = O(e);
            if ("number" == typeof i) n > 0 ? o = i >= 0 ? i : Math.max(i + a, o) : a = i >= 0 ? Math.min(i + 1, a) : i + a + 1;
            else if (r && i && a) return i = r(e, u), e[i] === u ? i : -1;
            if (u !== u) return i = t(l.call(e, o, a), m.isNaN), i >= 0 ? i + o : -1;
            for (i = n > 0 ? o : a - 1; i >= 0 && a > i; i += n)
                if (e[i] === u) return i;
            return -1
        }
    }

    function e(n, t) {
        var r = I.length,
            e = n.constructor,
            u = m.isFunction(e) && e.prototype || a,
            i = "constructor";
        for (m.has(n, i) && !m.contains(t, i) && t.push(i); r--;) i = I[r], i in n && n[i] !== u[i] && !m.contains(t, i) && t.push(i)
    }
    var u = this,
        i = u._,
        o = Array.prototype,
        a = Object.prototype,
        c = Function.prototype,
        f = o.push,
        l = o.slice,
        s = a.toString,
        p = a.hasOwnProperty,
        h = Array.isArray,
        v = Object.keys,
        g = c.bind,
        y = Object.create,
        d = function() {},
        m = function(n) {
            return n instanceof m ? n : this instanceof m ? void(this._wrapped = n) : new m(n)
        };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = m), exports._ = m) : u._ = m, m.VERSION = "1.8.3";
    var b = function(n, t, r) {
            if (t === void 0) return n;
            switch (null == r ? 3 : r) {
                case 1:
                    return function(r) {
                        return n.call(t, r)
                    };
                case 2:
                    return function(r, e) {
                        return n.call(t, r, e)
                    };
                case 3:
                    return function(r, e, u) {
                        return n.call(t, r, e, u)
                    };
                case 4:
                    return function(r, e, u, i) {
                        return n.call(t, r, e, u, i)
                    }
            }
            return function() {
                return n.apply(t, arguments)
            }
        },
        x = function(n, t, r) {
            return null == n ? m.identity : m.isFunction(n) ? b(n, t, r) : m.isObject(n) ? m.matcher(n) : m.property(n)
        };
    m.iteratee = function(n, t) {
        return x(n, t, 1 / 0)
    };
    var _ = function(n, t) {
            return function(r) {
                var e = arguments.length;
                if (2 > e || null == r) return r;
                for (var u = 1; e > u; u++)
                    for (var i = arguments[u], o = n(i), a = o.length, c = 0; a > c; c++) {
                        var f = o[c];
                        t && r[f] !== void 0 || (r[f] = i[f])
                    }
                return r
            }
        },
        j = function(n) {
            if (!m.isObject(n)) return {};
            if (y) return y(n);
            d.prototype = n;
            var t = new d;
            return d.prototype = null, t
        },
        w = function(n) {
            return function(t) {
                return null == t ? void 0 : t[n]
            }
        },
        A = Math.pow(2, 53) - 1,
        O = w("length"),
        k = function(n) {
            var t = O(n);
            return "number" == typeof t && t >= 0 && A >= t
        };
    m.each = m.forEach = function(n, t, r) {
        t = b(t, r);
        var e, u;
        if (k(n))
            for (e = 0, u = n.length; u > e; e++) t(n[e], e, n);
        else {
            var i = m.keys(n);
            for (e = 0, u = i.length; u > e; e++) t(n[i[e]], i[e], n)
        }
        return n
    }, m.map = m.collect = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = Array(u), o = 0; u > o; o++) {
            var a = e ? e[o] : o;
            i[o] = t(n[a], a, n)
        }
        return i
    }, m.reduce = m.foldl = m.inject = n(1), m.reduceRight = m.foldr = n(-1), m.find = m.detect = function(n, t, r) {
        var e;
        return e = k(n) ? m.findIndex(n, t, r) : m.findKey(n, t, r), e !== void 0 && e !== -1 ? n[e] : void 0
    }, m.filter = m.select = function(n, t, r) {
        var e = [];
        return t = x(t, r), m.each(n, function(n, r, u) {
            t(n, r, u) && e.push(n)
        }), e
    }, m.reject = function(n, t, r) {
        return m.filter(n, m.negate(x(t)), r)
    }, m.every = m.all = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i] : i;
            if (!t(n[o], o, n)) return !1
        }
        return !0
    }, m.some = m.any = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i] : i;
            if (t(n[o], o, n)) return !0
        }
        return !1
    }, m.contains = m.includes = m.include = function(n, t, r, e) {
        return k(n) || (n = m.values(n)), ("number" != typeof r || e) && (r = 0), m.indexOf(n, t, r) >= 0
    }, m.invoke = function(n, t) {
        var r = l.call(arguments, 2),
            e = m.isFunction(t);
        return m.map(n, function(n) {
            var u = e ? t : n[t];
            return null == u ? u : u.apply(n, r)
        })
    }, m.pluck = function(n, t) {
        return m.map(n, m.property(t))
    }, m.where = function(n, t) {
        return m.filter(n, m.matcher(t))
    }, m.findWhere = function(n, t) {
        return m.find(n, m.matcher(t))
    }, m.max = function(n, t, r) {
        var e, u, i = -1 / 0,
            o = -1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++) e = n[a], e > i && (i = e)
        } else t = x(t, r), m.each(n, function(n, r, e) {
            u = t(n, r, e), (u > o || u === -1 / 0 && i === -1 / 0) && (i = n, o = u)
        });
        return i
    }, m.min = function(n, t, r) {
        var e, u, i = 1 / 0,
            o = 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++) e = n[a], i > e && (i = e)
        } else t = x(t, r), m.each(n, function(n, r, e) {
            u = t(n, r, e), (o > u || 1 / 0 === u && 1 / 0 === i) && (i = n, o = u)
        });
        return i
    }, m.shuffle = function(n) {
        for (var t, r = k(n) ? n : m.values(n), e = r.length, u = Array(e), i = 0; e > i; i++) t = m.random(0, i), t !== i && (u[i] = u[t]), u[t] = r[i];
        return u
    }, m.sample = function(n, t, r) {
        return null == t || r ? (k(n) || (n = m.values(n)), n[m.random(n.length - 1)]) : m.shuffle(n).slice(0, Math.max(0, t))
    }, m.sortBy = function(n, t, r) {
        return t = x(t, r), m.pluck(m.map(n, function(n, r, e) {
            return {
                value: n,
                index: r,
                criteria: t(n, r, e)
            }
        }).sort(function(n, t) {
            var r = n.criteria,
                e = t.criteria;
            if (r !== e) {
                if (r > e || r === void 0) return 1;
                if (e > r || e === void 0) return -1
            }
            return n.index - t.index
        }), "value")
    };
    var F = function(n) {
        return function(t, r, e) {
            var u = {};
            return r = x(r, e), m.each(t, function(e, i) {
                var o = r(e, i, t);
                n(u, e, o)
            }), u
        }
    };
    m.groupBy = F(function(n, t, r) {
        m.has(n, r) ? n[r].push(t) : n[r] = [t]
    }), m.indexBy = F(function(n, t, r) {
        n[r] = t
    }), m.countBy = F(function(n, t, r) {
        m.has(n, r) ? n[r]++ : n[r] = 1
    }), m.toArray = function(n) {
        return n ? m.isArray(n) ? l.call(n) : k(n) ? m.map(n, m.identity) : m.values(n) : []
    }, m.size = function(n) {
        return null == n ? 0 : k(n) ? n.length : m.keys(n).length
    }, m.partition = function(n, t, r) {
        t = x(t, r);
        var e = [],
            u = [];
        return m.each(n, function(n, r, i) {
            (t(n, r, i) ? e : u).push(n)
        }), [e, u]
    }, m.first = m.head = m.take = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[0] : m.initial(n, n.length - t)
    }, m.initial = function(n, t, r) {
        return l.call(n, 0, Math.max(0, n.length - (null == t || r ? 1 : t)))
    }, m.last = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[n.length - 1] : m.rest(n, Math.max(0, n.length - t))
    }, m.rest = m.tail = m.drop = function(n, t, r) {
        return l.call(n, null == t || r ? 1 : t)
    }, m.compact = function(n) {
        return m.filter(n, m.identity)
    };
    var S = function(n, t, r, e) {
        for (var u = [], i = 0, o = e || 0, a = O(n); a > o; o++) {
            var c = n[o];
            if (k(c) && (m.isArray(c) || m.isArguments(c))) {
                t || (c = S(c, t, r));
                var f = 0,
                    l = c.length;
                for (u.length += l; l > f;) u[i++] = c[f++]
            } else r || (u[i++] = c)
        }
        return u
    };
    m.flatten = function(n, t) {
        return S(n, t, !1)
    }, m.without = function(n) {
        return m.difference(n, l.call(arguments, 1))
    }, m.uniq = m.unique = function(n, t, r, e) {
        m.isBoolean(t) || (e = r, r = t, t = !1), null != r && (r = x(r, e));
        for (var u = [], i = [], o = 0, a = O(n); a > o; o++) {
            var c = n[o],
                f = r ? r(c, o, n) : c;
            t ? (o && i === f || u.push(c), i = f) : r ? m.contains(i, f) || (i.push(f), u.push(c)) : m.contains(u, c) || u.push(c)
        }
        return u
    }, m.union = function() {
        return m.uniq(S(arguments, !0, !0))
    }, m.intersection = function(n) {
        for (var t = [], r = arguments.length, e = 0, u = O(n); u > e; e++) {
            var i = n[e];
            if (!m.contains(t, i)) {
                for (var o = 1; r > o && m.contains(arguments[o], i); o++);
                o === r && t.push(i)
            }
        }
        return t
    }, m.difference = function(n) {
        var t = S(arguments, !0, !0, 1);
        return m.filter(n, function(n) {
            return !m.contains(t, n)
        })
    }, m.zip = function() {
        return m.unzip(arguments)
    }, m.unzip = function(n) {
        for (var t = n && m.max(n, O).length || 0, r = Array(t), e = 0; t > e; e++) r[e] = m.pluck(n, e);
        return r
    }, m.object = function(n, t) {
        for (var r = {}, e = 0, u = O(n); u > e; e++) t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r
    }, m.findIndex = t(1), m.findLastIndex = t(-1), m.sortedIndex = function(n, t, r, e) {
        r = x(r, e, 1);
        for (var u = r(t), i = 0, o = O(n); o > i;) {
            var a = Math.floor((i + o) / 2);
            r(n[a]) < u ? i = a + 1 : o = a
        }
        return i
    }, m.indexOf = r(1, m.findIndex, m.sortedIndex), m.lastIndexOf = r(-1, m.findLastIndex), m.range = function(n, t, r) {
        null == t && (t = n || 0, n = 0), r = r || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = Array(e), i = 0; e > i; i++, n += r) u[i] = n;
        return u
    };
    var E = function(n, t, r, e, u) {
        if (!(e instanceof t)) return n.apply(r, u);
        var i = j(n.prototype),
            o = n.apply(i, u);
        return m.isObject(o) ? o : i
    };
    m.bind = function(n, t) {
        if (g && n.bind === g) return g.apply(n, l.call(arguments, 1));
        if (!m.isFunction(n)) throw new TypeError("Bind must be called on a function");
        var r = l.call(arguments, 2),
            e = function() {
                return E(n, e, t, this, r.concat(l.call(arguments)))
            };
        return e
    }, m.partial = function(n) {
        var t = l.call(arguments, 1),
            r = function() {
                for (var e = 0, u = t.length, i = Array(u), o = 0; u > o; o++) i[o] = t[o] === m ? arguments[e++] : t[o];
                for (; e < arguments.length;) i.push(arguments[e++]);
                return E(n, r, this, this, i)
            };
        return r
    }, m.bindAll = function(n) {
        var t, r, e = arguments.length;
        if (1 >= e) throw new Error("bindAll must be passed function names");
        for (t = 1; e > t; t++) r = arguments[t], n[r] = m.bind(n[r], n);
        return n
    }, m.memoize = function(n, t) {
        var r = function(e) {
            var u = r.cache,
                i = "" + (t ? t.apply(this, arguments) : e);
            return m.has(u, i) || (u[i] = n.apply(this, arguments)), u[i]
        };
        return r.cache = {}, r
    }, m.delay = function(n, t) {
        var r = l.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r)
        }, t)
    }, m.defer = m.partial(m.delay, m, 1), m.throttle = function(n, t, r) {
        var e, u, i, o = null,
            a = 0;
        r || (r = {});
        var c = function() {
            a = r.leading === !1 ? 0 : m.now(), o = null, i = n.apply(e, u), o || (e = u = null)
        };
        return function() {
            var f = m.now();
            a || r.leading !== !1 || (a = f);
            var l = t - (f - a);
            return e = this, u = arguments, 0 >= l || l > t ? (o && (clearTimeout(o), o = null), a = f, i = n.apply(e, u), o || (e = u = null)) : o || r.trailing === !1 || (o = setTimeout(c, l)), i
        }
    }, m.debounce = function(n, t, r) {
        var e, u, i, o, a, c = function() {
            var f = m.now() - o;
            t > f && f >= 0 ? e = setTimeout(c, t - f) : (e = null, r || (a = n.apply(i, u), e || (i = u = null)))
        };
        return function() {
            i = this, u = arguments, o = m.now();
            var f = r && !e;
            return e || (e = setTimeout(c, t)), f && (a = n.apply(i, u), i = u = null), a
        }
    }, m.wrap = function(n, t) {
        return m.partial(t, n)
    }, m.negate = function(n) {
        return function() {
            return !n.apply(this, arguments)
        }
    }, m.compose = function() {
        var n = arguments,
            t = n.length - 1;
        return function() {
            for (var r = t, e = n[t].apply(this, arguments); r--;) e = n[r].call(this, e);
            return e
        }
    }, m.after = function(n, t) {
        return function() {
            return --n < 1 ? t.apply(this, arguments) : void 0
        }
    }, m.before = function(n, t) {
        var r;
        return function() {
            return --n > 0 && (r = t.apply(this, arguments)), 1 >= n && (t = null), r
        }
    }, m.once = m.partial(m.before, 2);
    var M = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        I = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    m.keys = function(n) {
        if (!m.isObject(n)) return [];
        if (v) return v(n);
        var t = [];
        for (var r in n) m.has(n, r) && t.push(r);
        return M && e(n, t), t
    }, m.allKeys = function(n) {
        if (!m.isObject(n)) return [];
        var t = [];
        for (var r in n) t.push(r);
        return M && e(n, t), t
    }, m.values = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++) e[u] = n[t[u]];
        return e
    }, m.mapObject = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = u.length, o = {}, a = 0; i > a; a++) e = u[a], o[e] = t(n[e], e, n);
        return o
    }, m.pairs = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++) e[u] = [t[u], n[t[u]]];
        return e
    }, m.invert = function(n) {
        for (var t = {}, r = m.keys(n), e = 0, u = r.length; u > e; e++) t[n[r[e]]] = r[e];
        return t
    }, m.functions = m.methods = function(n) {
        var t = [];
        for (var r in n) m.isFunction(n[r]) && t.push(r);
        return t.sort()
    }, m.extend = _(m.allKeys), m.extendOwn = m.assign = _(m.keys), m.findKey = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = 0, o = u.length; o > i; i++)
            if (e = u[i], t(n[e], e, n)) return e
    }, m.pick = function(n, t, r) {
        var e, u, i = {},
            o = n;
        if (null == o) return i;
        m.isFunction(t) ? (u = m.allKeys(o), e = b(t, r)) : (u = S(arguments, !1, !1, 1), e = function(n, t, r) {
            return t in r
        }, o = Object(o));
        for (var a = 0, c = u.length; c > a; a++) {
            var f = u[a],
                l = o[f];
            e(l, f, o) && (i[f] = l)
        }
        return i
    }, m.omit = function(n, t, r) {
        if (m.isFunction(t)) t = m.negate(t);
        else {
            var e = m.map(S(arguments, !1, !1, 1), String);
            t = function(n, t) {
                return !m.contains(e, t)
            }
        }
        return m.pick(n, t, r)
    }, m.defaults = _(m.allKeys, !0), m.create = function(n, t) {
        var r = j(n);
        return t && m.extendOwn(r, t), r
    }, m.clone = function(n) {
        return m.isObject(n) ? m.isArray(n) ? n.slice() : m.extend({}, n) : n
    }, m.tap = function(n, t) {
        return t(n), n
    }, m.isMatch = function(n, t) {
        var r = m.keys(t),
            e = r.length;
        if (null == n) return !e;
        for (var u = Object(n), i = 0; e > i; i++) {
            var o = r[i];
            if (t[o] !== u[o] || !(o in u)) return !1
        }
        return !0
    };
    var N = function(n, t, r, e) {
        if (n === t) return 0 !== n || 1 / n === 1 / t;
        if (null == n || null == t) return n === t;
        n instanceof m && (n = n._wrapped), t instanceof m && (t = t._wrapped);
        var u = s.call(n);
        if (u !== s.call(t)) return !1;
        switch (u) {
            case "[object RegExp]":
            case "[object String]":
                return "" + n == "" + t;
            case "[object Number]":
                return +n !== +n ? +t !== +t : 0 === +n ? 1 / +n === 1 / t : +n === +t;
            case "[object Date]":
            case "[object Boolean]":
                return +n === +t
        }
        var i = "[object Array]" === u;
        if (!i) {
            if ("object" != typeof n || "object" != typeof t) return !1;
            var o = n.constructor,
                a = t.constructor;
            if (o !== a && !(m.isFunction(o) && o instanceof o && m.isFunction(a) && a instanceof a) && "constructor" in n && "constructor" in t) return !1
        }
        r = r || [], e = e || [];
        for (var c = r.length; c--;)
            if (r[c] === n) return e[c] === t;
        if (r.push(n), e.push(t), i) {
            if (c = n.length, c !== t.length) return !1;
            for (; c--;)
                if (!N(n[c], t[c], r, e)) return !1
        } else {
            var f, l = m.keys(n);
            if (c = l.length, m.keys(t).length !== c) return !1;
            for (; c--;)
                if (f = l[c], !m.has(t, f) || !N(n[f], t[f], r, e)) return !1
        }
        return r.pop(), e.pop(), !0
    };
    m.isEqual = function(n, t) {
        return N(n, t)
    }, m.isEmpty = function(n) {
        return null == n ? !0 : k(n) && (m.isArray(n) || m.isString(n) || m.isArguments(n)) ? 0 === n.length : 0 === m.keys(n).length
    }, m.isElement = function(n) {
        return !(!n || 1 !== n.nodeType)
    }, m.isArray = h || function(n) {
        return "[object Array]" === s.call(n)
    }, m.isObject = function(n) {
        var t = typeof n;
        return "function" === t || "object" === t && !!n
    }, m.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(n) {
        m["is" + n] = function(t) {
            return s.call(t) === "[object " + n + "]"
        }
    }), m.isArguments(arguments) || (m.isArguments = function(n) {
        return m.has(n, "callee")
    }), "function" != typeof /./ && "object" != typeof Int8Array && (m.isFunction = function(n) {
        return "function" == typeof n || !1
    }), m.isFinite = function(n) {
        return isFinite(n) && !isNaN(parseFloat(n))
    }, m.isNaN = function(n) {
        return m.isNumber(n) && n !== +n
    }, m.isBoolean = function(n) {
        return n === !0 || n === !1 || "[object Boolean]" === s.call(n)
    }, m.isNull = function(n) {
        return null === n
    }, m.isUndefined = function(n) {
        return n === void 0
    }, m.has = function(n, t) {
        return null != n && p.call(n, t)
    }, m.noConflict = function() {
        return u._ = i, this
    }, m.identity = function(n) {
        return n
    }, m.constant = function(n) {
        return function() {
            return n
        }
    }, m.noop = function() {}, m.property = w, m.propertyOf = function(n) {
        return null == n ? function() {} : function(t) {
            return n[t]
        }
    }, m.matcher = m.matches = function(n) {
        return n = m.extendOwn({}, n),
            function(t) {
                return m.isMatch(t, n)
            }
    }, m.times = function(n, t, r) {
        var e = Array(Math.max(0, n));
        t = b(t, r, 1);
        for (var u = 0; n > u; u++) e[u] = t(u);
        return e
    }, m.random = function(n, t) {
        return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1))
    }, m.now = Date.now || function() {
        return (new Date).getTime()
    };
    var B = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;"
        },
        T = m.invert(B),
        R = function(n) {
            var t = function(t) {
                    return n[t]
                },
                r = "(?:" + m.keys(n).join("|") + ")",
                e = RegExp(r),
                u = RegExp(r, "g");
            return function(n) {
                return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, t) : n
            }
        };
    m.escape = R(B), m.unescape = R(T), m.result = function(n, t, r) {
        var e = null == n ? void 0 : n[t];
        return e === void 0 && (e = r), m.isFunction(e) ? e.call(n) : e
    };
    var q = 0;
    m.uniqueId = function(n) {
        var t = ++q + "";
        return n ? n + t : t
    }, m.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var K = /(.)^/,
        z = {
            "'": "'",
            "\\": "\\",
            "\r": "r",
            "\n": "n",
            "\u2028": "u2028",
            "\u2029": "u2029"
        },
        D = /\\|'|\r|\n|\u2028|\u2029/g,
        L = function(n) {
            return "\\" + z[n]
        };
    m.template = function(n, t, r) {
        !t && r && (t = r), t = m.defaults({}, t, m.templateSettings);
        var e = RegExp([(t.escape || K).source, (t.interpolate || K).source, (t.evaluate || K).source].join("|") + "|$", "g"),
            u = 0,
            i = "__p+='";
        n.replace(e, function(t, r, e, o, a) {
            return i += n.slice(u, a).replace(D, L), u = a + t.length, r ? i += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'" : e ? i += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : o && (i += "';\n" + o + "\n__p+='"), t
        }), i += "';\n", t.variable || (i = "with(obj||{}){\n" + i + "}\n"), i = "var __t,__p='',__j=Array.prototype.join," + "print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", i)
        } catch (a) {
            throw a.source = i, a
        }
        var c = function(n) {
                return o.call(this, n, m)
            },
            f = t.variable || "obj";
        return c.source = "function(" + f + "){\n" + i + "}", c
    }, m.chain = function(n) {
        var t = m(n);
        return t._chain = !0, t
    };
    var P = function(n, t) {
        return n._chain ? m(t).chain() : t
    };
    m.mixin = function(n) {
        m.each(m.functions(n), function(t) {
            var r = m[t] = n[t];
            m.prototype[t] = function() {
                var n = [this._wrapped];
                return f.apply(n, arguments), P(this, r.apply(m, n))
            }
        })
    }, m.mixin(m), m.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments), "shift" !== n && "splice" !== n || 0 !== r.length || delete r[0], P(this, r)
        }
    }), m.each(["concat", "join", "slice"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            return P(this, t.apply(this._wrapped, arguments))
        }
    }), m.prototype.value = function() {
        return this._wrapped
    }, m.prototype.valueOf = m.prototype.toJSON = m.prototype.value, m.prototype.toString = function() {
        return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return m
    })
}).call(this);
var SelectedTransactionTypeSourceId = '00000000-0000-0000-0000-000000000000';
var AdminSecret = undefined;
var useInternalCaptchaForAccountDetailsPopUp = undefined;
var noFileSelectedText = "No file selected.";
var proofIdSize = true;
var proofResidenceSize = true;
var proofIdMobileSize = true;
var fileTypeValid = false;
var proofResidenceMobileSize = true;
window.promptFICANotification = false;
CASHOUTBETS = [];
CASHOUTBETS_INITIALIZED = false;
CASHOUT_MARGIN = 0.9;
MIN_CASHOUT_LIMIT = 0.2;
MAX_CASHOUT_LIMIT = 0.8;
var constId = {};
constId.emptyGuid = '00000000-0000-0000-0000-000000000000';
constId.feedDataType_LIP = '00000000-0000-0000-da7a-000000580003';
constId.feedDataType_Prematch = '00000000-0000-0000-da7a-000000580001';
constId.feedDataType_LiveOutrights = '00000000-0000-0000-da7a-000000580008';
constId.BrandIdZA = 'BD66EBE1-080B-4455-9094-BF0464D4ADBF';
constId.soccerId = '00000000-0000-0000-DA7A-000000550001';
constId.BetYourWay = '00000000-0000-0000-da7a-000000550072';
constId.FormulaOne = '00000000-0000-0000-da7a-000000550100';
constId.Golf = '00000000-0000-0000-da7a-000000550007';
constId.MotorSport = '00000000-0000-0000-da7a-000000550009';
constId.esportId = '00000000-0000-0000-da7a-000000550064';
constId.Trending = '00000000-0000-0000-da7a-000000550101';
constId.Accumulators = '00000000-0000-0000-da7a-000000550102';
constId.BuildABet = '00000000-0000-0000-da7a-000000710003';
constId.ResultingStatus_NotResulted = 0;
constId.ResultingStatus_Win = 1;
constId.ResultingStatus_Loss = 2;
constId.ResultingStatus_Void = 3;
constId.ResultingStatus_EarlySettlement = 6;
constId.ResultingStatus_ManualResultingRequired = 7;
constId.ResultingStatus_EarlyCashout = 9;
constId.ResultingStatus_WinWithDeadHeatFactor = 10;
constId.LiveOutrightSports = [constId.Golf.toLowerCase(), constId.MotorSport.toLowerCase(), constId.FormulaOne.toLowerCase()];
window.promptForCompleteProfile = false;
constId.OutcomeDisplaySorting_Default = 0;
constId.OutcomeDisplaySorting_Title = 1;
constId.OutcomeDisplaySorting_TitleDesc = 2;
constId.OutcomeDisplaySorting_PriceDecimal = 3;
constId.OutcomeDisplaySorting_PriceDecimalDesc = 4;
constId.OutcomeDisplaySorting_SBV = 5;
constId.OutcomeDisplaySorting_SBVDesc = 6;
constId.OutcomeDisplaySorting_FeedId = 7;
constId.OutcomeDisplaySorting_FeedIdDesc = 8;
var swiftEndVerificationType = {};
swiftEndVerificationType.PHONE_NUMBER = "Phone Number";
swiftEndVerificationType.NATIONAL_IDENTITY_NUMBER = "National Identity Number";
swiftEndVerificationType.BABK_VERIFICATION_NUMBER = "Bank Verification Number";
constId.BrandId_Nigeria = "F8A8D16A-D619-4B49-AA8C-F21211403C92";
var global = {
    setCookie: function(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue.replace(/"/g, "'") + ";" + expires + ";path=/";
    },
    setCookieWithAllSubDomain: function(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue.replace(/"/g, "'") + ";" + expires + ";path=/; hostOnly=false; domain=" + `.${window.location.host.toString()}`;
    },
    getCookie: function(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(";");
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === " ") {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length).replace(/'/g, '"');
            }
        }
        return "";
    },
    eraseCookie: function(name) {
        global.setCookie(name, "", -1);
    },
    isMobile: function() {
        var viewportWidth = $(window).width();
        var isMobileScreen = viewportWidth > 768 ? false : true;
        return isMobileScreen;
    },
    PostAppMessage: function(messageJsonString) {
        if (removeElements) {
            if (this.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(messageJsonString);
            } else {
                window.Data.postData(messageJsonString);
            }
        }
    }
};
var TaxCalculation = {};
TaxCalculation.Winnings = 2;
TaxCalculation.Payout = 3;
var EmailValidator = {
    validateEmail: function() {
        var currentValue = document.querySelector('.email-input').value;
        if (currentValue !== "" && !/(.+)@(.+){2,}\.(.+){3,}/.test(currentValue)) {
            return false;
        } else {
            return true;
        }
    }
}

function syntaxHighlightForJson(json) {
    if (typeof json != 'string') {
        json = JSON.stringify(json, undefined, 2);
    }
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
};
var general = {
    bootstrapColumns: function(colCount) {
        return "col-xs-" + colCount + " col-sm-" + colCount + " col-md-" + colCount + " col-lg-" + colCount + "";
    }
};
$(document).ready(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('#scroll').fadeIn();
        } else {
            $('#scroll').fadeOut();
        }
    });
    $('#scroll').click(function() {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
    checkPageTheme(window.location.pathname.toLocaleLowerCase());
});

function checkPageTheme(currentPage) {
    if (currentPage.indexOf("/event/inplay") > -1 || currentPage.indexOf("/event/inplay/") > -1 || currentPage.indexOf("/event/livesport") > -1 || currentPage.indexOf("/event/livesport") > -1 || currentPage.indexOf("?inplay=true") > -1) {
        setTheme("yellow");
    } else if (currentPage.indexOf("/jackpots/index") > -1 || currentPage.indexOf("/jackpots") > -1) {} else if (currentPage.indexOf("/casino") > -1) {
        setTheme("casino");
    } else if (currentPage.indexOf("/betgames") > -1) {
        setTheme("purple");
    } else if (currentPage.indexOf("/luckynumbers") > -1) {
        setTheme("purple");
    } else if (currentPage.indexOf("/virtuals") > -1 || currentPage.indexOf("betradar") > -1 || currentPage.indexOf("goldenrace") > -1) {
        setTheme("virtualsport");
    }
}

function setTheme(themeColour) {
    var mainPage = $("#my-page");
    var mobileBetslip = $("#betslip-mobile-modal");
    var mobileFooter = $("#mobileBetslipFooter");
    var loginModal = $("#LoginModal");
    var additionalElements = $("#login-controls, #SignUpModal, #miniBetslip");
    mainPage.addClass(themeColour);
    mobileBetslip.addClass(themeColour);
    mobileFooter.addClass(themeColour);
    loginModal.addClass(themeColour);
    additionalElements.addClass(themeColour);
};
var homePage = {
    synapseNavBarEnabled: false,
    initialLoad: true,
    showingMoreBigWinners: false,
    isBigWinnerWidgetShowing: true,
    getEventStreamingLink: function(url, eventTitle, sportTitle, multiMarketUrl, eventId) {
        lipStreaming.initStreamLoad = true;
        lipStreaming.displayStreamer(url, eventTitle, sportTitle, multiMarketUrll, eventId);
    },
    changeTabColours: function(link, colour) {
        if (document.getElementById('webTabs') !== null && typeof document.getElementById('webTabs') !== 'undefined') {
            var nodes = document.getElementById('webTabs').childNodes;
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].nodeName.toLowerCase() === 'li') {
                    nodes[i].style.backgroundColor = "#515151";
                }
            }
        }
        $('#' + link.charAt(0).toUpperCase() + link.slice(1)).css("background-color", colour + "!important");
    },
    ShowAccountOptionsModal: function(accountOptionUrl, accountOption, name, tabName = "") {
        homePage.showOverlay();
        var accountOptions = document.getElementsByClassName('accountOption-sideNav');
        if (accountOptions.length > 0) {
            for (var i = 0; i < accountOptions.length; i++) {
                accountOptions[i].classList.remove('accountOption-active');
            }
        }
        if (document.getElementById(accountOption) != null) {
            document.getElementById(accountOption).classList.add('accountOption-active');
        }
        sessionStorage.setItem('accountOptionsSelected', accountOption.substring(accountOption.indexOf('_') + 1));
        var modalName = getParameterByName('modal');
        modalName = modalName == null ? name : modalName
        pat.get(accountOptionUrl, {
            modal: modalName
        }).done(function(data) {
            $(".accountOptionsBody").html(data);
            $('#accountOptionsModal').modal();
            $('#nav-link-container').css('pointer-events', 'none')
            if (tabName != "") {
                $(tabName).click();
            }
            document.querySelector("html").style.overflow = 'hidden';
            homePage.closeOverlay();
            if (modalName != null) {
                if (window.innerWidth <= 768) {
                    if (sessionStorage.getItem('accountOptionsSelected')) {
                        $('[data-account-option-name="' + sessionStorage.getItem('accountOptionsSelected').toLowerCase() + '"]').prop('selected', true);
                    }
                }
            }
            if (localStorage.getItem("IsPrimaryNumberUpdateAttempt") == 'true' && accountOptionUrl == '/Account/UpdateDetails' && !data.includes('confirmAccountDetailsContainer')) {
                if ($('#otp-popup-content').length > 0) {
                    $('#generic-modal').css("display", "block");
                }
                account.CheckPrimaryNumberCheckbox(primaryNumberElementId);
                $("#generic-modal").show();
            }
        });
        $('#betslip-mobile-modal').modal('hide');
    },
    updateSelect: function(id) {
        $('#' + id).prop('selected', true);
    },
    closeAccountOptionsModal: function() {
        $("#accountOptionsModal").css("display", "none");
        $('#nav-link-container').css('pointer-events', 'initial')
        document.querySelector("html").style.overflow = 'scroll';
        document.querySelector("html").removeAttribute("style");
    },
    expandStreamList: function() {
        if ($('#filterstreaming-selection').hasClass('open')) {
            $('#filterstreaming-list').hide();
            $('#filterstreaming-selection').removeClass('open');
            $('#filterstreaming-selection').attr('aria-expanded', 'false');
        } else {
            $('#filterstreaming-list').show();
            $('#filterstreaming-selection').attr('aria-expanded', 'false');
            $('#filterstreaming-selection').addClass('open');
            $('#filterstreaming-selection').attr('aria-expanded', 'true');
        }
    },
    setSelectedStreamEvent: function(eventTitle, sportTitle) {
        var templateHtml = document.getElementById("filterStreamVideoTemplate") !== null ? document.getElementById("filterStreamVideoTemplate").innerHTML : null;
        var elem = null;
        var imageStyle = "";
        if (!isMobileDevice) {
            imageStyle = 'height:15px; margin-top: 0px; float: left;width: 15px;background-repeat: no-repeat;margin-right:5px; margin-bottom: 5px';
        } else {
            imageStyle = 'height:15px; margin-top: 2px; float: left;width: 15px;background-repeat: no-repeat;margin-right:5px; margin-bottom: 5px';
        }
        if (templateHtml !== null) {
            elem = '<i class="sprite sprite-mSport img-sport img-' +
                sportTitle.toLowerCase() +
                '" style="' +
                imageStyle +
                '"></i>';
            templateHtml = templateHtml.split("%selectedsporttype%").join(elem);
            templateHtml = templateHtml.split("%selectedeventtitle%").join(eventTitle);
            document.getElementById("filterStreamVideo").innerHTML = templateHtml;
        } else {
            templateHtml = document.getElementById('selectedStreamEvent');
            if (templateHtml !== null) {
                elem = '<i class="sprite sprite-mSport img-sport img-' +
                    sportTitle.toLowerCase() +
                    '" style="' +
                    imageStyle +
                    '"></i><div class="titleEllipsis">' + eventTitle + '</div>';
                templateHtml.innerHTML = elem;
            }
        }
    },
    getList: function() {
        try {
            pat.get("/LiveUpdate/GetStreamingMatches").done(function(result) {
                return result;
            });
        } catch (err) {
            console.log(err)
        }
    },
    streamSelectionOptions: function() {
        var templateHtml = document.getElementById("filterStreamVideoTemplate") !== null ? document.getElementById("filterStreamVideoTemplate").innerHTML : null;
        var elem = null;
        var imageStyle = "";
        if (!isMobileDevice) {
            imageStyle = 'height:15px; margin-top: 0px; float: left;width: 15px;background-repeat: no-repeat;margin-right:5px; margin-bottom: 5px';
        } else {
            imageStyle = 'height:15px; margin-top: 2px; float: left;width: 15px;background-repeat: no-repeat;margin-right:5px; margin-bottom: 5px';
        }
        if (templateHtml !== null) {
            var streams = homePage.getList();
            for (x in streams) {
                console.log(streams[x].sportTitle);
            }
            elem = '<i class="sprite sprite-mSport img-sport img-' +
                sportTitle.toLowerCase() +
                '" style="' +
                imageStyle +
                '"></i>';
            templateHtml = templateHtml.split("%streamSelectionOptions%").join(elem);
            document.getElementById("filterStreamVideo").innerHTML = templateHtml;
        } else {
            templateHtml = document.getElementById('selectedStreamEvent');
            if (templateHtml !== null) {
                elem = '<i class="sprite sprite-mSport img-sport img-' +
                    sportTitle.toLowerCase() +
                    '" style="' +
                    imageStyle +
                    '"></i><div class="titleEllipsis">' + eventTitle + '</div>';
                templateHtml.innerHTML = elem;
            }
        }
    },
    applyLiveInPlayColourScheme: function() {
        var parentLocation = window.location.pathname;
        if (parentLocation.toLowerCase() === "/event/inplay" || parentLocation.toLowerCase() === "/event/livesport/" || (parentLocation.toLowerCase() === "/bet/eventmultimarket" && $('#multi-head').hasClass('inPlayBg'))) {
            $('#generateBookingCode, #btnConfirm, #LogoutBtn, #depositBtnInline, #allcordion, #filtermarket-list .btn, #country-title, .mSport.active, #mobileSignUpBtn, #mobileLoginBtn, .fica-btn, #updateLeagueFilterBtn, #depositBtn, #continueBettingBtn, .sr-scoreboard-head, .sr-lmts-collapse-bar, .bet-confirmation-header, #LoginModalPopUp, #LoginModalPopUpLink, #Login, #SignUp, #liveNowHeader, #sb_id.active, #mb_id.active, #placeFreeBet, #events-btn-next, #btnReset, #closeLeagueFilterBtn, #showMoreLeagues, .close-button, .placeAnotherLink.btn, #btn-confirm, .back-to-bets.btn, #ConfirmBetslip.betslip-trapezoid, #showLessLeagues, #expand-Acc, #colapse-Acc, .sr-scoreboard-head, .sr-lmts-collapse-bar, .betslip-trapezoid, #placeCashBet, #betslipBtn, #BetslipBtn, #placeFreeBet, .betConfirmBtns.btn, .mobileMiddleNav, .mobileMiddleNavContainer, #ficaStatusMessage.button, .sr-scoreboard-head-title-wrap, .bet-confirmation-header, #miniBetslip, .mSport:Hover').addClass("liveInPlayClr");
            $('.lmt-container').css({
                'margin-bottom': '5%'
            });
            $('.info-box-betslip').addClass("info-box-betslip-LIP");
            $('.info-box-betslip-color').addClass("info-box-betslip-color-LIP");
        }
    },
    applyColossusColourScheme: function() {
        var parentLocation = window.location.pathname;
        if (parentLocation.toLowerCase() === "/jackpots/index" || parentLocation.toLowerCase() === "/colossus/betslipchoices") {
            $('#LogoutBtn, #depositBtnInline').addClass("jackpotColour");
        }
    },
    ApplyServerColour: function(colourToApply) {
        var hex = '#439539';
        if (location.hash.indexOf('#') > -1 || colourToApply === 'undefined' || colourToApply === null) {
            $(".colour").css({
                "background-color": hex,
                "border-bottom-color": hex + " !important",
                'color': 'black'
            });
            $('.textColour').css({
                "color": hex
            });
        } else {
            if (location.pathname.toLowerCase().indexOf('inplay') > -1 || location.pathname.toLowerCase().indexOf('loyalty') > -1) {
                $('.btnTextColour').css({
                    color: '#262626'
                });
            } else {
                $('.btnTextColour').css({
                    color: '#ffffff'
                });
            }
            $(".colour").css({
                "background-color": colourToApply,
                "border-bottom-color": colourToApply
            });
            $('.textColour').css({
                "color": colourToApply
            });
        }
        homePage.applyLiveInPlayColourScheme();
    },
    TabClick: function(tab) {
        var divId = useSynapseNavBar ? tab : (tab.charAt(0).toUpperCase() + tab.slice(1));
        var barButton = document.getElementById(divId);
        if (barButton !== null && typeof barButton !== 'undefined') {
            if (useSynapseNavBar) {
                barButton.click();
                if ($(barButton).hasClass('active-tab'))
                    $(barButton).removeClass('v-btn--disabled');
            } else {
                document.getElementById('tab-' + divId).click();
            }
        } else if (tab === 'short_term_outrights' && $('#sto_region').length < 1) {
            homePage.showOverlay();
            pat.get("/Event/OutrightsOnly").done(function(data) {
                $('#short_term_outrights').html(data);
                homePage.closeOverlay();
            });
        }
        events.checkLoad();
    },
    getSportFilters: function() {
        if (loadFiltersViaAjax) {
            var sportConfigId = $('p.active').parent().attr('id');
            sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
            if (sportConfigId === null || sportConfigId === undefined) {
                sportConfigId = localStorage.getItem('currentSportId');
            }
            if (sportConfigId === null || sportConfigId === undefined) {
                sportConfigId = "00000000-0000-0000-DA7A-000000550001";
            }
            $.get("/Ajax/GetSportsFilters", {
                feedDataTypeId: constId.feedDataType_Prematch,
                brandId: BrandId,
                sportConfigId: sportConfigId,
                IsLoggedIn: isUserLoggedIn,
                pathName: window.location.pathname
            }).done(function(data) {
                $('#_sportsFiltersContainer').html(data);
                if (typeof(filterOptions) !== 'undefined') {
                    filterOptions.Init(null);
                }
            });
        }
    },
    getWidgetHighlights: function(sportConfigId) {
        if (loadWidgetHighlightsViaAjax) {
            sportConfigId = $('p.active').parent().attr('id');
            sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
            if (sportConfigId === null || sportConfigId === undefined) {
                sportConfigId = localStorage.getItem('currentSportId');
            }
            $.get("/Ajax/GetHighlightsOnWidget", {
                sportConfigId: sportConfigId
            }).done(function(data) {
                $('#Widget-highlights').html(data);
            });
        }
    },
    getTopLeagues: function(sportConfigId) {
        if (localStorage.getItem('Current_location').toLowerCase() == '/event/livesport' || window.location.href.toLowerCase().indexOf('inplay=true') > -1) {
            document.querySelector('#topLeaguesDiv').style.display = "none";
        } else {
            $.get("/Event/GetTopLeaguesAndRegionName", {
                sportConfigId: sportConfigId
            }).done(function(data) {
                $('#topLeaguesDiv').html(data);
                var accountFavoritesStorage = localStorage.getItem('accountFavorites');
                if (accountFavoritesStorage != null && accountFavoritesStorage != '' && accountFavoritesStorage != '[object Object]') {
                    updatefavLeagueItems();
                }
                homePage.initTopLeaguesSlick('#top-leagues-div');
                var topLeaguesStorage = JSON.parse(localStorage.getItem("topLeagues"));
                if (topLeaguesStorage == null || topLeaguesStorage.length === 0) {
                    $('#TopLeagues').css({
                        'height': '0px'
                    });
                } else {
                    $('#TopLeagues').css({
                        'height': '52px'
                    });
                }
                setTimeout(function() {
                    AddSlickWidth($('#top-leagues-div').find('.league-items').length, '#top-leagues-div');
                    toggleTopFavList();
                }, 200);
            });
            if (isFavoritesTabEnabled) {
                $('#topfavCoverId').addClass('hide');
            } else {
                $('#topfavCoverId').removeClass('hide');
            }
            applyFavorites();
            if (window.innerWidth <= 425) {
                $('.top-and-fav-leagues-container').addClass('rowTopFavAccordion');
            }
        }
    },
    initTopLeaguesSlick: function(id) {
        $(id).not('.slick-initialized').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            infinite: false,
            nextArrow: "<span class='material-icons-outlined right'>chevron_right</span>",
            prevArrow: "<span class='material-icons-outlined left'>chevron_left</span>",
            speed: 500,
            responsive: [{
                breakpoint: 800,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 2
                }
            }, {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }]
        });
    },
    toggleAccordionArrow: function(id) {
        var element = $(id);
        if (element.hasClass('fa-angle-down')) {
            element.removeClass('fa-angle-down');
            element.addClass('fa-angle-up');
            $('#top-leagues-div,#fav-leagues-div,#topfavCoverId').removeClass('hide');
            $('#TopLeagues').css({
                'height': '52px'
            });
        } else {
            element.removeClass('fa-angle-up');
            element.addClass('fa-angle-down');
            $('#top-leagues-div,#fav-leagues-div,#topfavCoverId').addClass('hide');
            $('#TopLeagues').css({
                'height': '0px'
            });
        }
    },
    HighlightSubmenuItem: function() {
        if (global.getCookie("submenuRef") !== '' && global.getCookie("submenuRef") !== null && typeof global.getCookie("submenuRef") !== 'undefined') {
            $(".underline").removeClass("underline");
            $("#triangle_" + global.getCookie("submenuRef").substr(1).toLowerCase()).addClass("underline");
        } else if ($(".underline").length === 0) {
            $('span[id^="triangle_"]').first().addClass("underline");
        }
        if (homePage.synapseNavBarEnabled) homePage.HighlightSynapseSubmenuItem();
    },
    HighlightSynapseSubmenuItem: function() {
        if (global.getCookie("submenuRef") !== '' && global.getCookie("submenuRef") !== null && typeof global.getCookie("submenuRef") !== 'undefined') {
            $('button[id^="synapseBar_"]').removeClass("active-tab").removeClass('v-btn--active');
            $("#synapseBar_" + global.getCookie("submenuRef").substr(1).toLowerCase()).addClass("active-tab").addClass("v-btn--active");
        } else if ($(".v-btn--active").length === 0) {
            $('button[id^="synapseBar_"]').removeClass("active-tab").removeClass('v-btn--active');
            $('button[id^="synapseBar_"]:not(.v-btn--disabled):not([data-fdt="liveinplay"])').first().addClass("active-tab").addClass("v-btn--active");
        }
    },
    LoadSynapseSubMenuBar: function(link, targetattribute) {
        homePage.LoadSubMenuBar(link, targetattribute);
        $('button[id^="synapseBar_"]').removeClass("active-tab").removeClass('v-btn--active');
        $("#synapseBar_" + link.toLowerCase().replace('#', '')).addClass("active-tab").addClass("v-btn--active");
        if (link == "#highlights") {
            $('#highlights').find('.league-group-items').removeClass('collapse');
        }
    },
    LoadSubMenuBar: function(link, targetattribute, refererPage = null) {
        if (link.indexOf('#') > -1) {
            global.setCookie("submenuRef", link);
            $('#TopLeagues').show();
            if (link.toLowerCase() === "#outrights" || link.toLowerCase() === "liveoutrights") {
                $('#subsection').children().hide();
                $('#TopLeagues').hide();
                $('.top-Fav-Btns').hide();
                $('#TopLeagues').css('height', '0px');
                $('#TopLeaguesAccordion').attr('style', 'display:none !important');
            }
            if (link.toLowerCase() === "#highlights") {
                $('.filterApplied').addClass("inactive");
                $(".new-filters-container").show();
            } else {
                $('.filterApplied').removeClass("inactive");
            }
        } else {
            global.eraseCookie("submenuRef");
        }
        homePage.HighlightSubmenuItem();
        if (global.getCookie("submenuRef") !== '' && global.getCookie("submenuRef") !== null && typeof global.getCookie("submenuRef") !== 'undefined') {
            $('.nav-middle-tab').hide();
            if (global.getCookie("submenuRef") === '#topgames') {
                $('#topGamesPlaceholder').show();
                $("#subMenuDiv").hide();
            } else {
                $('#topGamesPlaceholder').hide();
                $(global.getCookie("submenuRef")).show();
            }
            $('#subsection > div').removeClass('active');
            $(global.getCookie("submenuRef")).addClass('active');
            var url = link.substr(1).toLowerCase();
            if (useSynapseNavBar === true)
                url = "synapseBar_" + url;
            homePage.TabClick(url);
        } else {
            if (targetattribute === '_self' || targetattribute === '') {
                window.location = link;
            } else {
                window.open(link, targetattribute);
            }
        }
        if (refererPage !== null && refererPage === 'from-golf-live-outrights') {
            localStorage.setItem("from-golf-live-outrights", "true");
        }
    },
    anchorToTop: function() {
        $('body:first').scrollTop(0);
        $("html, body").animate({
            scrollTop: 0
        }, "slow");
    },
    anchorToId: function(id) {
        var d = $(id);
        $('body:first').scrollTop(d.prop("scrollHeight") + 65);
        $("html, body").animate({
            scrollTop: d.prop("scrollHeight") + 65
        }, "fast");
    },
    searchToggle: function(FeedDataTypeId) {
        if (FeedDataTypeId === '') {
            FeedDataTypeId = $("#webTabs").find('.active').data('markettypecategory');
        }
        filters.ShiftFilterToActive(FeedDataTypeId);
    },
    ToggleLiveMiddleNavBar: function() {
        $(".nav-link-item.nav-link-item-live").css({
            'background-color': 'rgba(172, 197, 64, 0.4)'
        });
        $(".topSlit.topSlit-live").css({
            'background-color': 'rgba(172, 197, 64)'
        });
        $(".nav-link-item.nav-link-item-live").addClass('active');
        $(".nav-link-item.nav-link-item-sport").css({
            'background-color': 'rgb(51, 51, 51)'
        });
        $(".topSlit.topSlit-sport").css({
            'background-color': 'rgb(51, 51, 51)'
        });
        $(".nav-link-item.nav-link-item-sport").removeClass('active');
    },
    Highlight: function(action, colour, title) {
        if (title === "esports-inplay") return;
        var lTitle = title.split(' ').join('').toLowerCase();
        if ($("#right").is(":visible")) {
            $('#headerColour').css({
                color: 'white'
            });
        } else {
            $('#headerColour').css({
                color: '#262626'
            });
        }
        if (action === 'over' && $('.nav-link-item-' + lTitle).hasClass("active") !== true) {
            if (typeof colour !== 'undefined' && colour !== null && colour !== '') {
                $('.topSlit-' + lTitle).css("background-color", colour);
                $('.nav-link-item-' + lTitle).css("background-color", homePage.hexToRGB(colour, 0.5));
            } else {
                $('.topSlit-' + lTitle).css("background-color", "#439539");
            }
        } else if (action === 'out' && $('.nav-link-item-' + lTitle).hasClass("active") !== true) {
            $('.topSlit-' + lTitle).css("background-color", "#333333");
            $('.nav-link-item-' + lTitle).css("background-color", "#333333");
        } else if (action === 'clicked') {
            localStorage.setItem('active-nav', lTitle);
            if (location.hash.indexOf('#') > -1) {
                $('.nav-link-item').removeClass("active");
                $('.topSlit').css("background-color", "#333333");
                $('.nav-link-item').css("background-color", "#333333");
                $('.nav-link-item-' + lTitle).addClass("active");
                if (typeof hex !== 'undefined' && hex !== null && hex !== '') {
                    $('.topSlit-' + lTitle).css("background-color", hex);
                    $('.nav-link-item-' + lTitle).css("background-color", homePage.hexToRGB(hex, 0.4));
                } else {
                    var hex = '#439539';
                    $('.topSlit-' + lTitle).css("background-color", "#439539 !important");
                }
                homePage.ApplyServerColour(hex);
                homePage.changeTabColours(lTitle, hex);
                console.log('lTitle', lTitle);
                if (lTitle === 'highlights' || lTitle === 'sports' || lTitle === 'sport' || lTitle === 'matchbetting' || lTitle === 'inplay' || lTitle === 'outrights' || lTitle === 'short_term_outrights' || lTitle === 'topgames' || lTitle === 'esport') {
                    if (lTitle === 'inplay' || lTitle === 'livein-play') {
                        $('#headerColour').css({
                            color: '#262626'
                        });
                    } else if (lTitle !== 'inplay' && lTitle !== 'outrights' && lTitle !== 'short_term_outrights') {
                        lTitle = 'prematchtab';
                        $('.btnTextColour').css({
                            color: 'white'
                        });
                    } else {
                        $('.btnTextColour').css({
                            color: 'white'
                        });
                    }
                    $('#mSportDiv').fadeIn();
                    if (lTitle === 'outrights' || lTitle === 'short_term_outrights') {
                        homePage.toggleShow('', '', true);
                    } else {
                        homePage.toggleShow('.', 'link-' + lTitle, false);
                    }
                } else {
                    if (document.location.href.toLowerCase().indexOf('/event/livesport') === -1) {
                        $('#mSportDiv').fadeOut();
                        $('.mobileEvents').fadeOut();
                    }
                    $('.btnTextColour').css({
                        color: 'white'
                    });
                }
            } else {
                $('.nav-link-item').removeClass("active");
                $('.topSlit').css("background-color", "#333333");
                $('.nav-link-item').css("background-color", "#333333");
                homePage.applyLiveInPlayColourScheme();
                $('.nav-link-item-' + lTitle).addClass("active");
                if (typeof colour !== 'undefined' && colour !== null && colour !== '') {
                    $('.topSlit-' + lTitle).css("background-color", colour);
                    $('.nav-link-item-' + lTitle).css("background-color", homePage.hexToRGB(colour, 0.4));
                } else {
                    $('.nav-link-item-' + lTitle).css("background-color", "#333333");
                    $('.topSlit-' + lTitle).css("background-color", "#439539");
                }
            }
        }
    },
    LoadAjaxContent: function(anchorElement, url) {
        window.AjaxLoading = false;
        var targetElement = document.getElementById(anchorElement.attributes["data-subsection"].nodeValue);
        if (targetElement !== null && window.AjaxLoading === false) {
            window.AjaxLoading = true;
            var subsectionId = '#' + anchorElement.attributes["data-subsection"].nodeValue;
            $(subsectionId).load(url, function() {
                homePage.searchToggle('');
                var subSectionInitScript = $(subsectionId + "-loaded-script");
                if (subSectionInitScript.length > 0) {
                    subSectionInitScript.text();
                }
                window.AjaxLoading = false;
            });
            $('#' + anchorElement.id).unbind("click.ajaxcontent");
        }
    },
    toggleShow: function(toHide, toShow, hideAll) {
        if (hideAll !== null && hideAll === true) {
            $('#subsection').children().hide();
            $('#subsection').find('#outrights').show();
            $('#subsection').find('#outrights').addClass("active");
            $('#subsection').find('#liveoutrights').show();
            $('#subsection').find('#liveoutrights').addClass("active");
        } else if (toHide !== null && hideAll === false) {
            if (toHide !== "" || toHide !== ".") {}
            if (toShow !== "" || toShow !== ".") {
                $('#' + toShow).addClass('active').show();
            }
            if (toHide === 'link-inplay') {
                $('#topGames').hide();
                $('a[href="#outrights"]').each(function(index) {
                    $(this).hide();
                });
            } else {
                $('#topGames').show();
                $('a[href="#outrights"]').each(function(index) {
                    $(this).show();
                });
            }
        } else if (toShow !== null && hideAll === false) {
            $('.toggleLink').show();
            $('#' + toShow).hide();
        }
        events.checkLoad();
    },
    HoverColour: function(divId, action) {
        if (!$("#" + divId).hasClass("active")) {
            if (action === 'over') {
                $("#" + divId).removeClass("mSportColour");
            } else if (action === 'off') {
                $("#" + divId).addClass("mSportColour");
            }
        }
    },
    hexToRGB: function(hex, alpha) {
        var r = parseInt(hex.slice(1, 3), 16),
            g = parseInt(hex.slice(3, 5), 16),
            b = parseInt(hex.slice(5, 7), 16);
        if (alpha) {
            return "rgba(" + r + ", " + g + ", " + b + ", " + alpha + ")";
        } else {
            return "rgb(" + r + ", " + g + ", " + b + ")";
        }
    },
    showPwd: function() {
        if ($('.passwordToggle').attr('psswd-shown') === 'true') {
            $('.passwordToggle').removeAttr('type');
            $('.passwordToggle').attr('type', 'password');
            $('.passwordToggle').removeAttr('psswd-shown');
            $('.passwordToggle').attr('psswd-shown', 'false');
            $('#showPassword').removeClass('glyphicon-eye-close');
            $('#showPassword').addClass('glyphicon-eye-open');
        } else {
            $('.passwordToggle').removeAttr('type');
            $('.passwordToggle').attr('type', 'text');
            $('.passwordToggle').removeAttr('psswd-shown');
            $('.passwordToggle').attr('psswd-shown', 'true');
            $('#showPassword').removeClass('glyphicon-eye-open');
            $('#showPassword').addClass('glyphicon-eye-close');
        }
    },
    createOverlay: function() {
        if (jQuery('.load-overlay').length > 0) {
            var currentBody = jQuery('body');
            var modal = jQuery('<div />');
            modal.addClass('modal');
            modal.attr("id", "modalloading");
            var loading = jQuery('<div />');
            loading.addClass('loading loadingGif');
            loading.attr('align', 'center');
            currentBody.append(loading);
            currentBody.append(modal);
            loading = jQuery('.loading');
            var top = Math.max(jQuery(window).height() / 2 - loading.height() / 2, 0);
            var left = Math.max(jQuery(window).width() / 2 - loading.width() / 2, 0);
            loading.css({
                top: top,
                left: left
            });
        }
    },
    createLoader: function() {
        document.getElementById('subsection').style.display = "none";
        var getHeight = document.getElementById('bettingtabs').parentNode.offsetHeight;
        var iteration = new Array(Math.round(getHeight / 60));
        var struct = document.getElementById('bettingtabs');
        struct.classList.add('row');
        var getEventLoader = document.createElement('div');
        getEventLoader.setAttribute('class', 'eventLoader');
        getEventLoader.setAttribute('style', 'position: absolute; z-index: 1002; background: #fff; height:' + getHeight + 'px; width: 100%; top:0;padding: 25px; display: flex; justify-content: center;');
        struct.appendChild(getEventLoader);
        getEventLoader.innerHTML = '<img src="/Images/CasinoGames/Casino_Loading_Image.gif" alt="Loading Indicator" width="75" height="75">'
    },
    destroyLoader: function() {
        var element = document.querySelector('.eventLoader');
        element.parentNode.removeChild(element);
    },
    showOverlay: function(seconds) {
        if (seconds === null || seconds === undefined)
            seconds = 50000;
        var loading = $(".loading");
        $("#modalloading").show();
        var top = Math.max($(window).height() / 2 - loading.height() / 2, 0);
        var left = Math.max($(window).width() / 2 - loading.width() / 2, 0);
        loading.css({
            top: top,
            left: left
        });
        $("#modalloading").show();
        loading.show();
        return window.setTimeout(homePage.TimeoutElapsed, seconds);
    },
    closeOverlay: function(name) {
        jQuery(".loading").hide();
        jQuery("#modalloading").hide();
        homePage.liveUpdate();
    },
    liveUpdate: function() {
        setTimeout(function() {
            var feedDataTypeId = $("#webTabs").find('.active').data('markettypecategory');
            if (feedDataTypeId !== null && typeof(feedDataTypeId) !== "undefined") {
                if (feedDataTypeId.toLowerCase() === "00000000-0000-0000-da7a-000000580003") {
                    $('.nav-link-item-livein-play').css('background-color', 'rgb(172, 194, 64)');
                    $('#LogoutBtn, #country-title, #Login, #SignUp, .mobileMiddleNav, #events-btn-next, .nav-link-item-livein-play > .topSlit, .mini-betslip-btn-bet').css('background-color', 'rgb(172, 194, 64)');
                    $('.colour').css('background-color', 'rgb(172, 194, 64)');
                    $('.btnTextColour').css('color', '#000');
                    $('.activeTextColour.active').css({
                        color: '#000',
                        'background-color': 'rgb(172, 194, 64)'
                    });
                    $('.mSport').attr("onmouseover", "this.style.background='rgb(172, 194, 64)';").attr("onmouseout", "this.style.background='#FFF';");
                    $('.mSport.active').attr("onmouseout", "");
                }
            }
        }, 400);
    },
    getInboxCount: function() {
        if (homePage.shouldCheckInbox())
            homePage.getInboxCountAjax();
    },
    shouldCheckInbox: function() {
        var sessionItem = sessionStorage.getItem('inbox_next_check');
        var timeNow = Math.round(new Date().getTime());
        var check_after_time = timeNow + 60000;
        if (sessionItem === null || (timeNow >= parseFloat(sessionItem))) {
            sessionStorage.setItem('inbox_next_check', check_after_time);
            return true;
        }
        return false;
    },
    getInboxCountAjax: function() {
        var accountGuid = PlayerAccountID;
        if (accountGuid === constId.emptyGuid || accountGuid === undefined || accountGuid === null || accountGuid === '') {
            homePage.SetMessageCount(0);
            return;
        }
        var brand = Brand;
        pat.get("/Ajax/InboxCount?AccountId=" + accountGuid + "&BrandId=" + brand).done(function(data) {
            homePage.SetMessageCount(data);
        });
    },
    SetMessageCount: function(data) {
        var displayStr = data > 0 ? 'New' : '';
        if (removeElements) {
            var text = '{ "message" : "InboxCount", "data" : { "inboxCount" :' + data + '} }';
            if (global.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(text);
            } else {
                window.Data.postData(text);
            }
        }
        if (document.getElementById('messageCountBadge') !== null) {
            document.getElementById('messageCountBadge').innerHTML = displayStr;
        }
        if (document.getElementById('messageCountBadgeMobile') !== null) {
            document.getElementById('messageCountBadgeMobile').innerHTML = displayStr;
        }
        if (document.getElementById('messageCountBadgeFooter') !== null) {
            document.getElementById('messageCountBadgeFooter').innerHTML = displayStr;
        }
    },
    shouldRefreshInitialBalance: function() {
        if (!initialBalanceTimerEnabled)
            return false;
        var sessionItem = localStorage.getItem('InitialBalance_next_check');
        var timeNow = Math.round(new Date().getTime());
        if (sessionItem === null || (timeNow >= parseFloat(sessionItem))) {
            return true;
        }
        return false;
    },
    setBalanceDisplay: function(initialBalanceState) {
        var balances = initialBalanceState.balance;
        homePage.setInitialSportBonusBalance(initialBalanceState);
        homePage.setInitialCasinoBonusBalance(initialBalanceState);
        homePage.setInitialJackpotBalance(balances);
        homePage.setInitialFreeBetBalance(balances);
        homePage.setInitialCashBalance(balances);
        var localBetslipData = JSON.parse(GetBetslip());
        window.loginObject = {
            isLoggedIn: `${PlayerAccountID}`,
            inboxCount: homePage.getInboxCount(),
            cashBalance: balances.CashBalance,
            freeBetBalance: balances.BonusBalance,
            bonusBalance: balances.PlaythroughBalance,
            sportBonusBalance: balances.SportBonusBalance,
            betCount: localBetslipData == '' ? 0 : localBetslipData.length,
        };
        homePage.sendBalanceWindowEvent(initialBalanceState)
    },
    setInitialSportBonusBalance: function(initialBalanceState) {
        var sportBonusProgressBarPercentage = initialBalanceState.sportBonusPercentageToTarget;
        var balances = initialBalanceState.balance;
        var $sportBonusProgressBars = $('.sports-bonus-bar');
        $sportBonusProgressBars.prop('value', sportBonusProgressBarPercentage);
        $('.sports-bonus').text(`${currency}${ToThousandSeparator(balances.SportBonusBalance)}`);
        $('.sports-bonusOnly').text(`${ToThousandSeparator(balances.SportBonusBalance)}`);
    },
    setInitialCasinoBonusBalance: function(initialBalanceState) {
        var casinoBonusProgressBarPercentage = initialBalanceState.casinoBonusPercentageToTarget;
        var balances = initialBalanceState.balance;
        var $casinoBonusProgressBars = $('.casino.bar');
        $casinoBonusProgressBars.prop('value', casinoBonusProgressBarPercentage);
        $('.mobile-bonus').text(`${currency}${ToThousandSeparator(balances.PlaythroughBalance)}`);
        $('.mobile-bonusOnly').text(`${ToThousandSeparator(balances.PlaythroughBalance)}`);
    },
    setInitialJackpotBalance: function(balances) {
        $('.dailyJackpotTicket').val(balances.DailyJackpotTicketBalance);
        $('.betwayJackpotTicket').val(balances.BetwayJackpotTicketBalance);
        $('.betwayJackpotTicket.dailyJackpotTicket').val(balances.BetwayJackpotTicketBalance + balances.DailyJackpotTicketBalance);
    },
    setInitialFreeBetBalance: function(balances) {
        var pendingFreeBetAmountSum = 0;
        $('.pendingFreeBetAmountShow').show();
        $pendingFreeBetsLockAddAfter = $('.pendingFreeBetsLockAddAfter');
        for (var i = 0; i < $pendingFreeBetsLockAddAfter.length; i++) {
            if ($($pendingFreeBetsLockAddAfter[i]).parent().find('.material-icons-outlined.fb-l').length == 0)
                continue;
            var newLockIconElement = $('<span>', {
                'class': 'material-icons-outlined fb-l',
                'text': 'lock'
            });
            var newLockIconInfoElement = $('<span>', {
                'class': 'material-icons-outlined fb-i',
                'text': 'lock'
            });
            newLockIconElement.insertAfter($pendingFreeBetsLockAddAfter[i]);
            newLockIconInfoElement.insertAfter(newLockIconElement);
        }
        var freeBetBalance = (balances.BonusBalance).toFixed(2);
        $('.freeBetBalanceAmount').text(`${currency}${ToThousandSeparator(freeBetBalance)}`);
        $('.freeBetBalanceAmountOnly').text(`${ToThousandSeparator(freeBetBalance)}`);
        setCookie("CurrentFreeBetAmount", freeBetBalance, 2);
    },
    setInitialCashBalance: function(balances) {
        $('.cashBalanceAmount').text(`${currency}${ToThousandSeparator(balances.CashBalance)}`);
        $('.cashBalanceAmountOnly').text(`${ToThousandSeparator(balances.CashBalance)}`);
    },
    updateBalanceState: function(balanceDetails) {
        var localBalanceDetails = JSON.parse(localStorage.getItem('balanceState'));
        if (localBalanceDetails == undefined || !localBalanceDetails.Success)
            return;
        var hasAnyValueChanged = false;
        if (localBalanceDetails.Data.CashBalance != balanceDetails.CashBalance)
            hasAnyValueChanged = true;
        if (localBalanceDetails.Data.BonusBalance != balanceDetails.BonusBalance)
            hasAnyValueChanged = true;
        if (localBalanceDetails.Data.PlaythroughBalance != balanceDetails.PlaythroughBalance)
            hasAnyValueChanged = true;
        if (localBalanceDetails.Data.SportBonusBalance != balanceDetails.SportBonusBalance)
            hasAnyValueChanged = true;
        if (localBalanceDetails.Data.BetwayJackpotTicketBalance != balanceDetails.BetwayJackpotTicketBalance)
            hasAnyValueChanged = true;
        if (localBalanceDetails.Data.DailyJackpotTicketBalance != balanceDetails.DailyJackpotTicketBalance)
            hasAnyValueChanged = true;
        if (!hasAnyValueChanged)
            return;
        localBalanceDetails.Data.CashBalance = balanceDetails.CashBalance;
        localBalanceDetails.Data.BonusBalance = balanceDetails.BonusBalance;
        localBalanceDetails.Data.PlaythroughBalance = balanceDetails.PlaythroughBalance;
        localBalanceDetails.Data.SportBonusBalance = balanceDetails.SportBonusBalance;
        localBalanceDetails.Data.BetwayJackpotTicketBalance = balanceDetails.BetwayJackpotTicketBalance;
        localBalanceDetails.Data.DailyJackpotTicketBalance = balanceDetails.DailyJackpotTicketBalance;
        homePage.setBalanceDisplay(localBalanceDetails);
        localStorage.setItem('balanceState', JSON.stringify(localBalanceDetails));
    },
    sendBalanceWindowEvent: function(initialBalanceState) {
        var casinoBonusProgressBarPercentage = initialBalanceState.CasinoBonusProgressBarPercentage;
        var sportBonusProgressBarPercentage = initialBalanceState.SportBonusPercentageToTarget;
        var balances = initialBalanceState.balance;
        if (removeElements) {
            var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + (Math.floor(balances.CashBalance * 100) / 100).toFixed(2) +
                ', "freeBetBalance" : ' + (Math.floor(balances.BonusBalance * 100) / 100).toFixed(2) +
                ', "bonusBalance" : ' + (Math.floor(balances.PlaythroughBalance * 100) / 100).toFixed(2) +
                ', "sportBonusBalance" : ' + (Math.floor(balances.SportBonusBalance * 100) / 100).toFixed(2) +
                ', "bonusBalancePercentage" : ' + parseInt(casinoBonusProgressBarPercentage) +
                ', "sportBonusBalancePercentage" : ' + parseInt(sportBonusProgressBarPercentage) +
                ', "sportInactiveBonuses" : ' + (initialBalanceState.sportsBonusesCount > 0 ? (initialBalanceState.sportsBonusesCount - 1) : 0) +
                ', "casinoInactiveBonuses" : ' + 0 +
                ', "currencySymbol" : "' + currency + '" } }';
            if (global.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(text);
            } else {
                window.Data.postData(text);
            }
        }
    },
    isMobileScreen: function() {
        return window.innerWidth < 1025;
    },
    toggleBetTypeLabelText: function(count, isSingleBets, hasFreeBets, isInstantBet, maxPayout) {
        var badgeCountValue = homePage.getBetSlipCountBadgeValue();
        if (homePage.isMobileScreen() && count <= 0 && count !== badgeCountValue)
            count = badgeCountValue;
        if (count <= 0) {
            $("#sigleBetsCount").text("").removeClass("betslipBetsCount");
            $("#multipleBetsCount").text("").removeClass("betslipBetsCount");
        } else {
            if (!(homePage.getIsSingleBets() && homePage.getHasFreeBets())) {
                $(".freeSinglebetsContainer").css({
                    visibility: "hidden",
                    display: 'none'
                });
            } else {
                $(".freeSinglebetsContainer").css({
                    visibility: "visible",
                    display: 'flex'
                });
            }
            if (!(homePage.getIsSingleBets() && homePage.getHasSportBonus())) {
                $(".sportBonusSinglebetsContainer").css({
                    visibility: "hidden",
                    display: 'none'
                });
            } else {
                $(".sportBonusSinglebetsContainer").css({
                    visibility: "visible",
                    display: 'flex'
                });
            }
            if (isSingleBets) {
                $(".stake-return").show();
                $('.stake-input').show();
                $(".sigleBetsCount").text(count);
                $(".multipleBetsCount").text("");
                $(".sigleBetsCount").addClass("betslipBetsCount");
                $(".multipleBetsCount").removeClass("betslipBetsCount");
                $(".h5").css('visibility', 'hidden');
                $("#placeCashBet").text("Bet Now");
                language.translateAtRuntime($("#placeCashBet"), "MyBetsContent", {
                    "data-translate-key": "BetNow"
                });
                $("#divPotentialWager").css('display', 'none');
                $("#divPotentialReturn").css('display', 'none');
                if (hasFreeBets) {
                    $("#placeFreeBet").hide();
                }
                var betslips = $('#betslip-list').find('li.SelectedOutcomeForBetslip');
                for (var k = 0; k < betslips.length; k++) {
                    var outcomeStake = parseFloat($('.stake-return-amount')[k].innerHTML.replace(',', ''));
                    if (outcomeStake > maxPayout) {
                        $('.stake-return-amount')[k].innerHTML = maxPayout.toFixed(2);
                    } else {
                        $('.stake-return-amount')[k].innerHTML = outcomeStake.toFixed(2);
                    }
                }
            } else {
                if ($("#betslip-totalpricedecimal").length) {
                    var potentialReturn = parseFloat($("#potentialWager").val()) * parseFloat($("#betslip-totalpricedecimal")[0].innerHTML);
                    if (potentialReturn > maxPayout) {
                        $("#potentialReturn").val(parseFloat(maxPayout).toFixed(2));
                    } else {
                        $("#potentialReturn").val(potentialReturn.toFixed(2));
                    }
                }
                $(".stake-return").hide();
                $('.stake-input').hide();
                $(".multipleBetsCount").text(count);
                $(".sigleBetsCount").text("");
                $(".h5").css('visibility', 'visible');
                $("#divPotentialWager").css('display', 'block');
                $("#divPotentialReturn").css('display', 'block');
                if (isInstantBet) {
                    var oddsValue = $("#betslip-totalpricedecimal").text();
                }
                if (hasFreeBets) {
                    var placeFreeBetButton = document.getElementById("placeFreeBet");
                    if (placeFreeBetButton === undefined) {
                        var freeBetAmount = $("#freebetBtn").text().replace('Free Bet: ', '');
                        language.translateAtRuntime($("#freebetBtn"), "MyBetsContent", {
                            "data-translate-key": "FreeBet"
                        });
                        var buttonHtml = '<div>' +
                            '<span>' +
                            '<button id="placeFreeBet" value="Use My Free Bet" class="btn btn-lg btn-action theFont" onclick="$(\'#Action\').val(\'Use My Free Bet\');onPlaceFreeBet(event, \'/Bet/ViewBetConfirmationDialog\', \'' + freeBetAmount + '\', $(\'#PlaceBetSlip\').serialize())" name="action">' +
                            'Use My Free Bet' +
                            '</button>' +
                            '</span>' +
                            '</div><br>';
                        $("#divBetslipCenterNotEmpty").append(buttonHtml);
                    } else
                        $("#placeFreeBet").show();
                }
            }
        }
    },
    getIsSingleBets: function() {
        if (document.getElementById('isSingleBetsVar') === null || document.getElementById('isSingleBetsVar') === undefined)
            return $("#initialBetTypeValue").val() === "true" || $("#initialBetTypeValue").val() === "True";
        var isSinglesVar = $("#isSingleBetsVar").val();
        var res = isSinglesVar === "True";
        return res;
    },
    getHasFreeBets: function() {
        var hasFreeBets = $("#hasFreeBetsVar").val() === "True";
        return hasFreeBets;
    },
    getHasSportBonus: function() {
        var hasSportBonus = $("#hasSportBonusVar").val() === "True";
        return hasSportBonus;
    },
    getIsInstantBets: function() {
        var isInstantBets = $("#isInstantBetsVar").val() === "True";
        return isInstantBets;
    },
    getBetSlipCountBadgeValue: function() {
        if (!homePage.isMobileScreen()) return 0;
        return parseFloat($(".betslipCountBadgeCount").length > 1 ? $(".betslipCountBadgeCount").eq(1).text() : $(".betslipCountBadgeCount").text());
    },
    TimeoutElapsed: function() {
        homePage.closeOverlay();
    },
    showStats: function(matchId, isInPlay, showPopup = true) {
        homePage.showOverlay();
        homePage.trackLiveMatch(matchId, isInPlay, showPopup);
        homePage.closeOverlay();
    },
    showCricketStats: function(matchId) {
        homePage.showOverlay();
        $.getScript("https://assets-betway.sportz.io/common/wl-init.js", function() {
            $('#contentStatsContainer').html('<div style="padding-top:30px;" class="si-cwl-container" data-gamecode-req="true"><div class="si-widget" data-wdtype="matchcentre" data-defaulttab="summary" data-gamecode-req="true" data-sport="1" data-leaguecode="icc" data-gamecode="' +
                matchId +
                '"></div></div>');
        });
        homePage.closeOverlay();
    },
    toggleExpandWidget: function(height) {
        if ($('.sr-content').height() !== height) {
            $('.sr-content').animate({
                'height': height
            }, 'slow');
            $('.collapse-bar').removeClass('expandedBar');
            homePage.anchorToTop();
        } else {
            $('.sr-content').css({
                'height': '100%'
            });
            $('.collapse-bar').addClass('expandedBar');
        }
    },
    getAccountNumber: function(event) {
        {
            if ($("#FogotUsernameModal").find("#idNumber").val() == "" || $("#FogotUsernameModal").find("#firstName").val() == "" || $("#FogotUsernameModal").find("#lastName").val() == "") {
                $("#errorForgotUsername").removeAttr("style");
                $("#errorForgotUsername").attr("style", "margin-bottom: 15px");
            } else {
                event.preventDefault();
                homePage.showOverlay();
                $.ajax({
                    type: "POST",
                    url: "/Account/ForgotAccountNumber",
                    data: {
                        idNumber: $("#FogotUsernameModal").find("#idNumber").val(),
                        firstName: $("#FogotUsernameModal").find("#firstName").val(),
                        lastName: $("#FogotUsernameModal").find("#lastName").val()
                    },
                    success: function(response) {
                        if (response.Data.length == 0) {
                            $('#responseFields').removeAttr('style');
                            $("#inputgroup .form-group").hide();
                            $("#submitgroup").hide();
                            $("#linkedNumbers").hide();
                            $("#failGroup").removeAttr("style");
                            homePage.closeOverlay();
                        } else {
                            $("#responseFields").removeAttr("style");
                            $("#linkedNumbers").removeAttr("style");
                            $("#inputgroup .form-group").hide();
                            $("#submitgroup").hide();
                            response.Data.forEach(function(number) {
                                $("#FogotUsernameModal").find("#numbers").append("<div><label>" + number + "</label></div>");
                            })
                            $("#successGroup").removeAttr("style");
                            homePage.closeOverlay();
                        }
                    }
                });
            }
        }
    },
    toggleForgotUsername: function(modal) {
        if (modal === "login") {
            $("#LoginModal").modal('hide');
        }
    },
    showForgotUsername: function() {
        $('#FogotUsernameModal').modal("show");
    },
    dismissForgotUsernameModal: function() {
        $("#FogotUsernameModal").on('hide.bs.modal', function() {
            $("#FogotUsernameModal").find("#idNumber").val("");
            $("#FogotUsernameModal").find("#firstName").val("");
            $("#FogotUsernameModal").find("#lastName").val("");
            homePage.showPrevious();
        });
    },
    setSessionMetaData: function() {
        let sessionMetaData = sessionStorage.getItem('sessionMetaData');
        if (sessionMetaData === null) {
            sessionStorage.setItem('sessionMetaData', '{}');
            sessionMetaData = '{}';
        }
        $('#sessionMetaData').val(sessionMetaData);
        return sessionMetaData;
    },
    showPrevious: function() {
        $("#FogotUsernameModal").find("#numbers").children("div").remove();
        $("#inputgroup .form-group").show();
        $("#submitgroup").removeAttr("style");
        $("#failGroup").hide();
        $("#responseFields").hide();
        $("#successGroup").hide();
        $("#errorForgotUsername").hide();
    },
    onLoginClick: function(e) {
        e.preventDefault();
        homePage.showOverlay();
        if ($("#modal-container-mobile-login").is(":visible")) {
            var data = {
                mobileNumber: $('#modal-container-mobile-login').find('#MobileNumber').val(),
                password: $('#modal-container-mobile-login').find('#Password').val(),
                dialingCode: $('#modal-container-mobile-login').find('#DialingCode').val(),
                sessionMetaData: this.setSessionMetaData()
            };
        } else {
            data = {
                mobileNumber: $('#MobileNumber').val(),
                password: $('#Password').val(),
                dialingCode: $('#NotLoggedInPartial').find('#DialingCode').val(),
                sessionMetaData: this.setSessionMetaData()
            };
        }
        pat.post("/Account/Login", data).done(function(result) {
            if (result.Error === false) {
                appPostMessagesOnLogin(true);
                $('#modal-container-mobile-login').html('');
                $('#inline-login-placeholder').html('');
                SetBetslipOption('WagerAmount', null);
                if (ageVerificationEnabled) {
                    localStorage.setItem("showAgeVerification", true);
                }
                if (result.RedirectUrl !== undefined && result.RedirectUrl) {
                    window.location.href = result.RedirectUrl;
                } else {
                    location.reload();
                }
            } else {
                $('#modal-container-mobile-login').html(result);
                $('#inline-login-placeholder').html(result);
            }
            homePage.closeOverlay();
        });
    },
    LoginModalFormDisplay: function() {
        pat.post("/Account/ViewModalLogin", null, {
            dataType: "html"
        }).done(function(data) {
            $('#modal-container-mobile-login').html(data);
            $('#modal-container-mobile-login').modal();
        });
    },
    handleSportBonusConfig: function(sportbonus) {
        try {
            if (typeof sportbonus !== "undefined") {
                localStorage.setItem("sportsBonusMinOdds", parseFloat(sportbonus.MinOdds).toFixed(2));
                localStorage.setItem("sportsBonusMinSelections", sportbonus.MinSelections);
                localStorage.setItem("sportsBonusIsProtected", sportbonus.IsProtected);
                localStorage.setItem("sportsBonusExpiryDate", sportbonus.ExpiryDate);
                localStorage.setItem("sportsBonusMaxPayoutLimit", parseFloat(sportbonus.MaxPayoutLimit).toFixed(2));
            }
        } catch (e) {
            console.log(e);
        }
    },
    RefreshCashBalance: function(forceRefresh, useLocalStorage) {
        var shouldDoNetworkCall = true;
        var extraGetParameters = '';
        var lastForcedRefresh = localStorage.getItem('lastForcedBalanceRefresh')
        if (isCurrentlyRefreshingBalance && enableStaggeredBalanceRender) {
            console.error('Currently refreshing user balance');
            return;
        }
        if (forceRefresh) {
            shouldDoNetworkCall = true;
            lastForcedRefresh = `${Date.now().toString()}~${PlayerAccountID}`;
            localStorage.setItem('lastForcedBalanceRefresh', lastForcedRefresh)
        }
        if (lastForcedRefresh != undefined && lastForcedRefresh != null) {
            extraGetParameters = `?force=${lastForcedRefresh}`;
        }
        var localBalanceState = localStorage.getItem('balanceState');
        if (useLocalStorage != undefined && useLocalStorage != null && useLocalStorage == true && localBalanceState != undefined && localBalanceState != null && enableStaggeredBalanceRender)
            shouldDoNetworkCall = false;
        if (homePage.shouldRefreshInitialBalance())
            shouldDoNetworkCall = true;
        if (shouldDoNetworkCall == false) {
            try {
                var parsedBalanceState = JSON.parse(localBalanceState);
                if (parsedBalanceState.balance.CashBalance == 0) {
                    shouldDoNetworkCall = true;
                }
            } catch (e) {
                console.error(e);
                shouldDoNetworkCall = true;
            }
        }
        var endpointToGetBalance = `/Account/_GetBalanceForClient${extraGetParameters}`;
        if (shouldDoNetworkCall) {
            pat.get(endpointToGetBalance).done(function(response) {
                var data = response.balance;
                if (response.sportbonus !== null) {
                    homePage.handleSportBonusConfig(response.sportbonus);
                } else {
                    $('.IsProtectedLock').text('');
                    $('.sportsBonusProtectedMode').text('');
                }
                if ($("#cashAmount").is(":visible")) {
                    $('#cashAmount').html(ToThousandSeparator(data.CashBalance));
                    $('.balance-label-amount, .mobile-cash').html(currency + ToThousandSeparator(data.CashBalance));
                } else if ($(".balance-label").length > 0) {
                    $('.balance-label-amount, .mobile-cash').html(currency + ToThousandSeparator(data.CashBalance));
                }
                if ($(".account-balance-field-amount").length > 0) {
                    $(".account-balance-field-amount").html(ToThousandSeparator(data.CashBalance));
                }
                if (enableStaggeredBalanceRender) {
                    try {
                        localStorage.setItem('balanceState', JSON.stringify(response));
                    } catch (e) {
                        console.error(e);
                        localStorage.removeItem('balanceState');
                    }
                    isCurrentlyRefreshingBalance = false;
                    homePage.setBalanceDisplay(response);
                    localStorage.setItem('InitialBalance_next_check', Math.round(new Date().getTime()) + InitialBalanceValidPeriod * 1000);
                } else {
                    homePage.RefreshClientBalances(data);
                }
            });
        } else {
            homePage.setBalanceDisplay(JSON.parse(localBalanceState));
        }
    },
    RefreshClientBalances: async function(balanceDetails) {
        if (removeElements) {
            var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + (Math.floor(balanceDetails.CashBalance * 100) / 100).toFixed(2) +
                ', "freeBetBalance" : ' + (Math.floor(balanceDetails.BonusBalance * 100) / 100).toFixed(2) +
                ', "bonusBalance" : ' + (Math.floor(balanceDetails.PlaythroughBalance * 100) / 100).toFixed(2) +
                ', "sportBonusBalance" : ' + (Math.floor(balanceDetails.SportBonusBalance * 100) / 100).toFixed(2) + ' } }';
            if (global.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(text);
            } else {
                window.Data.postData(text);
            }
        }
        this.updateBalanceValues(balanceDetails.PlaythroughBalance, balanceDetails.BonusBalance, balanceDetails.SportBonusBalance);
    },
    GetAllBalances: async function(cashBalance) {
        var casinoBonus = await pat.get("/Account/_GetPlaythroughBalanceOnly").done(function(data) {
            return ToThousandSeparator(data)
        });
        var freeBet = await pat.get("/Account/_FreeBetBalanceOnly").done(function(data) {
            return ToThousandSeparator(data)
        });
        var sportsBonus = await pat.get("/Account/_GetSportBonusBalanceOnly").done(function(data) {
            return ToThousandSeparator(data)
        });
        if (removeElements) {
            var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + cashBalance +
                ', "freeBetBalance" : ' + freeBet +
                ', "bonusBalance" : ' + casinoBonus +
                ', "sportBonusBalance" : ' + sportsBonus + ' } }';
            if (global.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(text);
            } else {
                window.Data.postData(text);
            }
        }
        this.updateBalanceValues(casinoBonus, freeBet, sportsBonus);
        account.updateBalanceProgress();
    },
    updateBalanceValues: function(casinoBonus, freeBet, sportsBonus) {
        $('.sports-bonus').text(currency + sportsBonus);
        $('#sportBonusAmountVal').text(sportsBonus);
        $('.mobile-bonus').text(currency + casinoBonus);
        $('#bonusAmountVal').text(casinoBonus);
        $('.mobile-freebet').text(currency + freeBet);
    },
    GetCashBalance: function() {
        pat.get("/Account/_GetCashBalanceOnly").done(function(data) {
            return data;
        });
    },
    OpenGenericOverlay: function(message) {
        $('#messageCaption').html(message);
        $("#modal-generic").modal();
    },
    OpenOverlay: function(bannerId) {
        $('#slide_caption').html($("#overlayMessage_" + bannerId).val());
        language.translateAtRuntime($('#slide_caption'), "MainCarouselDialog", {
            "data-translate-key": language.generateKey($("#overlayMessage_" + bannerId).val())
        });
        $("#modal-motd").modal();
    },
    RegistrationInitiatedEvent_EventTracking: function(registrationPOI) {
        dataLayer.push({
            'event': 'RegistrationInitiatedEvent',
            'registrationPOI': registrationPOI
        });
    },
    changeItemPlaceHolder: function(dropdown, element, isMobile) {
        if (Object.keys(dropdown).length !== 0) {
            if (jQuery(dropdown).val() === "South African ID") {
                jQuery(element).attr('placeholder', 'ID Number');
                language.translateAtRuntime(jQuery(element), "SignUpDialog", {
                    "data-translate-key": "IDNumberPlaceholder",
                    "data-translate-type": "placeholder"
                });
                jQuery(element).attr({
                    'type': 'number',
                    'inputmode': 'numeric',
                    'pattern': '[0-9]*'
                });
            } else if (jQuery(dropdown).val() === "National ID Number") {
                jQuery(element).attr('placeholder', 'National ID Number');
                language.translateAtRuntime(jQuery(element), "SignUpDialog", {
                    "data-translate-key": "NationalIDNumberPlaceholder",
                    "data-translate-type": "placeholder"
                });
                jQuery(element).attr({
                    'type': 'number',
                    'inputmode': 'numeric',
                    'pattern': '[0-13]*'
                });
            } else {
                jQuery(element).removeAttr('inputmode');
                jQuery(element).removeAttr('pattern');
                jQuery(element).attr('type', 'text');
                var selectedElement = Array.from(jQuery(dropdown)[0].children).find(function fn(el) {
                    return el.selected;
                });
                var selectedElementAttr = selectedElement.attributes["placeholder-content"];
                var selectItemPlaceHolder = selectedElementAttr === undefined || selectedElementAttr.value === '' ? "Please enter " + selectedElement.text : selectedElementAttr.value;
                $(element).attr("placeholder", selectItemPlaceHolder);
                var regex = selectedElement.attributes["regexpression"];
                language.translateAtRuntime(jQuery(element), "SignUpDialog", {
                    "data-translate-key": selectedElement.text.replace(/\s/g, '') + "Placeholder",
                    "data-translate-type": "placeholder"
                });
                jQuery(element).attr({
                    'type': 'text',
                    'inputmode': 'text',
                    'pattern': regex.value
                });
                if (regex.value === 'disable')
                    $('#IDNumber_tmpl').attr('disabled', 'disabled');
                else
                    $('#IDNumber_tmpl').removeAttr('disabled');
            }
        }
    },
    toggleLoginSignup: function(modal) {
        this.setSessionMetaData();
        if (modal === "login") {
            $("#LoginModal").modal('hide');
            $("#SignUpModal").modal('show');
        } else {
            $("#SignUpModal").modal('hide');
            if (removeElements)
                global.PostAppMessage('{ "message": "login", "data" : { "value": "showLoginPopUp" } }');
            else
                $("#LoginModal").modal('show');
            if ($("#sideMenuPartialLogin").length === 0) {
                sideMenu.getMenuContent('_MenuLogin', 'MyAccount');
            }
            if (modal === "signup") {
                $('.loginModalBtn').addClass('hidden');
                $('.loginModalLink').removeClass('hidden');
            } else if (modal === "betnowlogin") {
                $('.loginModalBtn').removeClass('hidden');
                $('.loginModalLink').addClass('hidden');
                $('#betslip-mobile-modal').modal("hide");
            }
        }
        setTimeout(function() {
            $('body').addClass('modal-open');
        }, 500);
    },
    dismissLoginModal: function() {
        if (window.location.href.indexOf("lobby") > -1) {
            $("#LoginModal").modal('hide');
            var baseUrl = window.location.protocol + "//" + window.location.host;
            var subLobbyUrl = window.location.pathname.split('/')[1] + '/' + window.location.pathname.split('/')[2];
            window.location.href = baseUrl + '/' + subLobbyUrl;
        } else {
            $("#LoginModal").modal('hide');
        }
    },
    GetQrCodeUrl: function() {
        var appUrl = "";
        if (window.location.host == "www.betway.co.za" || window.location.host == "uat.betway.co.za" || window.location.host == "qa.betway.co.za") {
            appUrl = "https://appdownload.betwayafrica.com/?isi=1274057509&ibi=com.betway.sa&link=https://www.betway.co.za/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie('OriginalQueryString') + "&apn=com.betwayafrica.za&afl=https://cdn.betwayafrica.com/app/za/index.html";
        } else if (window.location.host == "www.betway.com.gh" || window.location.host == "uat.betway.com.gh" || window.location.host == "qa.betway.com.gh") {
            appUrl = "https://appdownload.betwayafrica.com/?isi=1361024170&ibi=Betway.Betway.Ghana&efr=1&link=https://www.betway.com.gh/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie('OriginalQueryString') + "&apn=com.betwayafrica.gh&afl=https://cdn.betwayafrica.com/app/gh/index.html";
        } else if (window.location.host == "www.betway.com.ng" || window.location.host == "uat.betway.com.ng" || window.location.host == "qa.betway.com.ng") {
            appUrl = "https://appdownload.betwayafrica.com/?&isi=1325017221&ibi=com.betway.nigera.Betway&efr=1&link=https://www.betway.com.ng/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie("OriginalQueryString") + "&apn=com.betwayafrica.ng&afl=https://cdn.betwayafrica.com/app/ng/index.html";
        } else if (window.location.host == "www.betway.co.ke" || window.location.host == "uat.betway.co.ke" || window.location.host == "qa.betway.co.ke") {
            appUrl = "https://appdownload.betwayafrica.com/?&isi=1324433430&ibi=com.betwa.kenya&link=https://www.betway.co.ke/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie("OriginalQueryString") + "&apn=com.betwayafrica.ke&afl=https://cdn.betwayafrica.com/app/ke/index.html";
        } else if (window.location.host == "www.betway.ug" || window.location.host == "uat.betway.ug" || window.location.host == "qa.betway.ug") {
            appUrl = "https://appdownload.betwayafrica.com/?&isi=1361509142&ibi=theRangers.Betway&efr=1&link=https://www.betway.ug/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie("OriginalQueryString") + "&apn=com.betwayafrica.ug&afl=https://cdn.betwayafrica.com/app/ug/index.html";
        } else if (window.location.host == "www.betway.co.zm" || window.location.host == "uat.betway.co.zm" || window.location.host == "qa.betway.co.zm") {
            appUrl = "https://appdownload.betwayafrica.com/?&isi=1513149768&ibi=com.betway.zm&efr=1&link=https://www.betway.co.zm/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie("OriginalQueryString") + "&apn=betway.zambia&afl=https://cdn.betwayafrica.com/app/zm/index.html";
        } else if (window.location.host == "www.betway.co.tz" || window.location.host == "uat.betway.co.tz" || window.location.host == "qa.betway.co.tz") {
            appUrl = "https://appdownload.betwayafrica.com/?&isi=1587589957&ibi=com.betway.tz&link=https://www.betway.co.tz/?btag%3D" + encodeURI(getCookie("BTAGCOOKIE")) + "%26" + global.getCookie("OriginalQueryString") + "&apn=com.betway.tz&afl=https://cdn.betwayafrica.com/app/tz/index.html";
        }
        return appUrl = appUrl.replace("&&", "&") + appDownloadIsiAndIbi;
    },
    allProducts: function() {
        $('#moreProductModal').removeClass('hidden');
        $('#overlay1').show();
    },
    closeAllProduct: function() {
        $('#moreProductModal').addClass('hidden');
        $('#overlay1').hide();
        $('.nav-link-item-all').css('background-color', 'transparent');
    },
    showBigWinnerDetails: function(element) {
        element.classList.toggle('active');
        var content = element.nextElementSibling;
        if (content.style.display === 'none') {
            content.style.display = 'flex';
            var childArrow = element.querySelector('.glyphicon-menu-down');
            childArrow.classList.replace('glyphicon-menu-down', 'glyphicon-menu-up');
        } else {
            content.style.display = 'none';
            var childArrow = element.querySelector('.glyphicon-menu-up');
            childArrow.classList.replace('glyphicon-menu-up', 'glyphicon-menu-down');
        }
    },
    toggleBigWinnerWidget: function(showBetslipLogicOverwrite) {
        if (bigWinnersEnabled === false)
            return;
        if (showBetslipLogicOverwrite === undefined) {
            showBetslipLogicOverwrite = false;
        }
        var elemenet = document.getElementById('recent-Winners');
        var betslipElement = document.getElementById('betslip');
        if (elemenet.style.display === 'none' && showBetslipLogicOverwrite === false) {
            elemenet.style.display = 'block';
            betslipElement.classList.add('hidden');
            homePage.isBigWinnerWidgetShowing = true;
        } else {
            elemenet.style.display = 'none';
            betslipElement.classList.remove('hidden');
            homePage.isBigWinnerWidgetShowing = false;
        }
    },
    toggleMoreBigWinners: function(element) {
        if (homePage.showingMoreBigWinners) {
            document.getElementsByClassName('extraWinnerTile').forEach(function(element) {
                element.style.display = 'none';
            });
            homePage.showingMoreBigWinners = false;
            element.firstChild.nextElementSibling.textContent = 'Show More';
        } else {
            document.getElementsByClassName('extraWinnerTile').forEach(function(element) {
                element.style.display = 'flex';
            });
            homePage.showingMoreBigWinners = true;
            element.firstChild.nextElementSibling.textContent = 'Show Less';
        }
    },
    GetSportContent: function(sportConfigId) {
        var loc = location.pathname.toLowerCase();
        if (loc.indexOf("/esport") > -1 && loc.indexOf("/esports_") < 0) {
            sportConfigId = constId.esportId;
        }
        pat.get("/KenticoContent/GetSportContent", {
            sportConfig: sportConfigId
        }).done(function(data) {
            $('#dynamicContent').html(data);
        });
    },
    GetDynamicContent: function(alias) {
        pat.get("/KenticoContent/GetDynamicContent", {
            url: alias
        }).done(function(data) {
            $('#dynamicContent').html(data);
        });
    },
    GetInfoIconContent: function(alias) {
        if ($('#renderIDTypeReg').html().indexOf("Kentico") < 0) {
            homePage.showOverlay();
            pat.get("/KenticoContent/GetDynamicContent", {
                url: alias
            }).done(function(data) {
                if (data !== null && data.indexOf("Kentico") > -1) {
                    $('#renderIDTypeReg').html(data);
                };
                homePage.closeOverlay();
            });
        }
        $('#InfoIconRegistration').modal();
    },
    GetLeagueContentByLeagueId: function(leagueIds, feedDataTypeId) {
        pat.post("/KenticoContent/GetLeagueContentByLeagueId", {
            leagueIds: leagueIds,
            feedDataTypeId: feedDataTypeId
        }).done(function(data) {
            $('#dynamicContent').html(data);
        });
    },
    mobileBetSlipButtonClick: function() {
        homePage.showOverlay();
        $("#betslip-container").detach().appendTo("#betslip-modal-htmlContainer");
        $("#back-to-bets-button-group, #betslip-container, #betslip-header").show();
        $("#oddsAndRemoveAll").css("height", "40px");
        $(".betslipTypeSelection").css("padding-top", "10px");
        $("#betslip-header").css("margin-bottom", "-8px");
        var betslipButtonPosition = null;
        var betslipBtn = document.getElementById("BetslipBtn");
        if (screen.width >= 768 && betslipBtn !== null && typeof betslipBtn !== 'undefined' && (betslipBtn.offsetHeight > 0 && betslipBtn.offsetWidth > 0))
            betslipButtonPosition = betslipBtn.getBoundingClientRect();
        else
            betslipButtonPosition = document.getElementById("betslipBtn").getBoundingClientRect();
        if (!removeElements)
            $("#betslip-mobile-modal").css({
                left: betslipButtonPosition.right - parseFloat($("#betslip-mobile-modal").css("width").replace("px", ""))
            });
        $("#betslip-mobile-modal .modal-dialog").css({
            top: betslipButtonPosition.bottom - parseFloat($("#betslip-mobile-modal .modal-dialog").css("margin-top").replace('px', ''))
        });
        $("#betslip-mobile-modal").modal();
        $("#betslip-mobile-modal.modal-dialog").css('z-index', 2);
        $("#mobileBetslipFooter").css('z-index', 1);
        homePage.applyLiveInPlayColourScheme();
        $("html").addClass("modal-open");
        $('.stake-input').attr('onclick', 'this.select();');
        $('.betslip-overlay-container').removeClass("hidden");
        $("#betslip-mobile-modal").on('hidden.bs.modal', function() {
            $(document).removeClass('modal-open');
            $("html").removeClass('modal-open');
            $("#mobileBetslipFooter").css('z-index', 2);
            $("#back-to-bets-button-group").hide();
        });
        homePage.closeOverlay();
        UpdateVisualElementsOnBetslip();
        $('#accountOptionsModal').modal('hide');
    },
    setCountryOfOrigin: function(dropdown) {
        $(dropdown).val("46a8e794-1d98-4d21-824a-5ff3f791e5c5");
    },
    setInitLogin: function(dropdown) {
        console.log('it comes here');
        setCookie("InitLogin", 'true', 0.01);
    },
    logout: function() {
        appPostMessagesOnLogin(false);
        localStorage.removeItem("showAgeVerification");
        localStorage.removeItem("totalSeconds");
        localStorage.removeItem("balanceState");
        localStorage.removeItem("InitialBalance_next_check");
        localStorage.removeItem("accountFavorites");
    },
    getPlayerJourney: function() {
        pat.get("/Account/GetPlayerJourney").done(function(data) {
            if (data.accountId !== constId.emptyGuid)
                localStorage.setItem('PlayerJourney', data);
        });
    },
    setSession: function(key, value, expiryTime) {
        const now = new Date();
        const itemVals = {
            value: value,
            expiry: now.getTime() + expiryTime
        }
        localStorage.setItem(key, JSON.stringify(itemVals));
    },
    retrieveSession: function(key, callBackFunction) {
        const itemStr = localStorage.getItem(key);
        if (!itemStr) {
            return null;
        }
        const item = JSON.parse(itemStr);
        const now = new Date();
        if (now.getTime() > item.expiry) {
            callBackFunction;
        }
    },
    overrideValidatorErrorLabel: function(form, errorElement = 'span', errorClass = 'custom-error-message') {
        $(form).validate({
            errorElement: errorElement,
            errorClass: errorClass
        });
    },
    verifyAccountDetails: function() {
        if (window.promptForCompleteProfile) {
            pat.get("/Account/UpdateProfile").done(function(data) {
                $('#modal-container-profilecompletion-confirmation').modal().show();
                $('#complete-profile-body').html(data);
                $('#modal-container-profilecompletion-confirmation .modal-content').css("overflow", "hidden");
                $('#modal-container-profilecompletion-confirmation .modal-content label').css("font-weight", "normal");
                $('#modal-container-profilecompletion-confirmation .modal-content label').css("font-size", "smaller");
            });
        }
    },
    RefreshBonusBalance: function() {
        pat.get("/Account/_GetPlaythroughBalanceOnly").done(function(data) {
            $('.mobile-bonus').text(currency + ToThousandSeparator(data));
            $('#bonusAmountVal').text(ToThousandSeparator(data));
            if (removeElements) {
                var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + window.loginObject.cashBalance.toFixed(2) +
                    ', "freeBetBalance" : ' + window.loginObject.freeBetBalance.toFixed(2) +
                    ', "bonusBalance" : ' + window.loginObject.bonusBalance.toFixed(2) +
                    ', "sportBonusBalance" : ' + window.loginObject.sportBonusBalance.toFixed(2) + data + ' } }';
                if (global.getCookie('isIosApp') === 'true') {
                    webkit.messageHandlers.PostData.postMessage(text);
                } else {
                    window.Data.postData(text);
                }
            }
            account.updateBalanceProgress();
        });
    },
    RefreshSportBonusBalance: function() {
        pat.get("/Account/_GetSportBonusBalanceOnly").done(function(data) {
            $('.sports-bonus').text(currency + ToThousandSeparator(data));
            $('#sportBonusAmountVal').text(ToThousandSeparator(data));
            if (removeElements) {
                var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + window.loginObject.cashBalance.toFixed(2) +
                    ', "freeBetBalance" : ' + window.loginObject.freeBetBalance.toFixed(2) +
                    ', "bonusBalance" : ' + window.loginObject.bonusBalance.toFixed(2) +
                    ', "sportBonusBalance" : ' + window.loginObject.sportBonusBalance.toFixed(2) + ' } }';
                if (global.getCookie('isIosApp') === 'true') {
                    webkit.messageHandlers.PostData.postMessage(text);
                } else {
                    window.Data.postData(text);
                }
            }
            account.updateBalanceProgress();
        });
    },
    RefreshFreeBetBalance: function() {
        ajax.get("/Account/_FreeBetBalanceOnly?_=" + new Date().getTime(), "", function(result) {
            var element = document.getElementById("accountFreeBetAmount");
            if (element !== null) element.innerText = result;
            if ($("#freeBetAmountVal").is(":visible")) {
                $('#freeBetAmountVal').html(ToThousandSeparator(result));
                $('.balance-label-amount, .mobile-cash').html(currency + ToThousandSeparator(result));
            }
            setCookie("CurrentFreeBetAmount", result, 0.001);
            $('.mobile-freebet').text(currency + ToThousandSeparator(result));
        }, true);
    },
    RefreshAllJackpotFreeTickets: function(useCache = false) {
        pat.get("/Account/GetAllJackpotsFreeTickets", {
            useCache: useCache
        }).done(function(data) {
            if (data !== '' && data !== 'null') {
                var betwayJackpots = document.getElementById("mainNavbarCounter_betwayJackpots");
                var dailyJackpots = document.getElementById("mainNavbarCounter_dailyJackpots");
                tickets = JSON.parse(data);
                if (betwayJackpots) betwayJackpots.innerText = tickets.BetwayJackpotTicketBalance.toLocaleString('en', {
                    minimumIntegerDigits: 2,
                    useGrouping: false
                });
                if (dailyJackpots) dailyJackpots.innerText = tickets.DailyJackpotTicketBalance.toLocaleString('en', {
                    minimumIntegerDigits: 2,
                    useGrouping: false
                });
            }
        });
    },
    ToggleJackpotBalancesModalAccordian: function() {
        if ($("#toggle-jackpotIndevidualTotals").hasClass('fa-angle-down')) {
            $("#toggle-jackpotIndevidualTotals").removeClass('fa-angle-down').addClass('fa-angle-up');
        } else {
            $("#toggle-jackpotIndevidualTotals").removeClass('fa-angle-up').addClass('fa-angle-down');
        }
    },
    logVerticalClick: function(elem) {
        var name = $(elem).data().mainNavName;
        var _vertial = name.toLowerCase();
        if (_vertial === 'livegames' || _vertial === 'luckynumbers' || _vertial === 'virtuals' || _vertial === 'betgames') {
            dataLayer.push({
                'event': 'VerticalClickEvent',
                'VerticalName': _vertial
            });
        }
    },
    trackLiveMatch: function(matchId, isInPlay = false, showPopup = true) {
        let _matchType, _widgetProperty;
        let _widgetContainer = showPopup ? ".sr-widget-1" : "#sr-widget";
        if (isInPlay) {
            _matchType = "match.lmtPlus";
            _widgetProperty = {
                layout: isMobileScreen() ? "topdown" : "double",
                detailedScoreboard: "disable",
                matchId: matchId
            };
        } else {
            _matchType = "headToHead.standalone";
            _widgetProperty = {
                layout: showPopup ? "overlay" : "inline",
                matchId: matchId
            };
        }
        SIR("addWidget", _widgetContainer, _matchType, _widgetProperty);
        if (showPopup) {
            $('#sportRadarMatchTracker').modal();
            if (!isInPlay) {
                $('#sportRadarMatchTracker .sr-widget-1').addClass('overflow-div');
            }
        }
    },
    showNewsBox: function() {
        if (localStorage.getItem('NewsBoxClosed') === null || localStorage.getItem('NewsBoxClosed') !== newsBoxId) {
            $('.news-box-container').show();
        }
    },
    closeNewsBox: function() {
        $('.news-box-container').hide();
        localStorage.setItem('NewsBoxClosed', newsBoxId);
    },
    ShowFullNewsBoxMessage: function(newsBoxId) {
        $('#slide_caption').html($('#NewsBoxFull-' + newsBoxId).html());
        language.translateAtRuntime($('#slide_caption'), "NewsBoxFullMessage", {
            "data-translate-key": language.generateKey($("#NewsBoxFull-" + newsBoxId).html())
        });
        $("#modal-motd").modal();
    },
    IsHorseracing: () => {
        const location = document.location.pathname.toLowerCase() === '/horseracing';
        console.log({
            location
        });
        return location;
    },
    scrollToLastUpcomingEventsPosition: function() {
        var lastEventsScrollPosition = localStorage.getItem('lastEventsScrollPosition');
        if (lastEventsScrollPosition !== null) {
            setTimeout(function() {
                $(document).scrollTop(parseInt(lastEventsScrollPosition));
                localStorage.removeItem('lastEventsScrollPosition');
            }, 1600);
        }
    },
    toggleHideBalances: function(hideBalances) {
        if (hideBalances === "true") {
            $('.btn-show-balances, .hidden-balance, .show-balance-eye').show();
            $('.refresh-balance, .balance-label-amount, .md-refresh-14, .popup-balances, .jackpots-popup, #cashAmount, #freeBetAmountVal, #sportBonusAmountVal, #bonusAmountVal, .hide-balance-eye').hide();
            $('.balances-sidemenu-container').attr("style", "display: none !important");
            localStorage.setItem('hideBalances', true);
        } else {
            localStorage.setItem('hideBalances', false);
            $('.btn-show-balances, .hidden-balance, .show-balance-eye').hide();
            $('.refresh-balance, .balance-label-amount, .md-refresh-14, .balances-sidemenu-container, .popup-balances, .jackpots-popup, .hide-balance-eye').show();
            $('#cashAmount, #freeBetAmountVal, #sportBonusAmountVal, #bonusAmountVal').css('display', 'inline');
        }
    },
    LoadFlagUrls: function(url) {
        try {
            var missingFlagsStr = localStorage.getItem("MissingFlags");
            if (missingFlagsStr === null || missingFlagsStr.length == 0) {
                return url;
            } else {
                var missingFlags = JSON.parse(missingFlagsStr);
                var searchedFlag = missingFlags.flags.filter(x => {
                    return x.url == url
                });
                if (searchedFlag.length > 0) {
                    return searchedFlag[0].defaultUrl;
                } else {
                    return url;
                }
            }
            return url;
        } catch (e) {
            console.log(e);
        }
    },
    UpdateMissingFlagList: function(url, cdnPath) {
        try {
            var missingFlags = {
                expiryDate: new Date(),
                flags: []
            };
            var defaultFlag = {
                url: url,
                defaultUrl: cdnPath + '/Images/Flags/default-circular.svg'
            }
            var flags = localStorage.getItem("MissingFlags");
            if (flags !== 'undefined' && typeof flags !== 'undefined' && flags !== null) {
                missingFlags = JSON.parse(flags);
            }
            if (missingFlags.flags.filter(x => {
                    return x.url == url
                }).length == 0) {
                missingFlags.flags.push(defaultFlag)
            }
            localStorage.setItem("MissingFlags", JSON.stringify(missingFlags));
        } catch (e) {
            console.log(e);
        }
    },
    ReadyToLoadFlags: function() {
        $(".flags-img").each(function() {
            var region = $(this).data("region-flag");
            var url = homePage.LoadFlagUrls(cdnPrefix + '/Images/Flags/' + region + '-circular.svg');
            $(this).attr("src", url);
        });
    },
    bonusSummaryMoreInfo: function(tab) {
        if (accountOptionsPopUpEnabled) {
            $('#balances-Close').click();
            sideMenu.closeMenu();
            $('#SportsBonusQualifyingCriteriaModal').modal('hide');
            homePage.ShowAccountOptionsModal('/BonusSummary', 'accountOption_bonussummary', 'Bonus Summary', tab);
        } else {
            window.location = "/BonusSummary";
        }
    },
    showDeleteInaactiveSportsBonusModal: function(accountId, sportsBonusId) {
        pat.post('/BonusSummary/GetInActiveSportsBonus', {
            accountId: accountId,
            sportsBonusId: sportsBonusId
        }).done(function(data) {
            $("#DeleteInactiveSportsBonusBody").html(data);
            $("#DeleteInactiveSportsBonusModal").show();
            $("#DeleteInactiveSportsBonusModal").css("display", "block");
        });
    },
    closeDeleteInaactiveSportsBonusModal: function() {
        $("#DeleteInactiveSportsBonusModal").css("display", "none");
    },
    closeLockedSportsBonusCardInfoModal: function() {
        $("#LockedSportsBonusCardInfoModal").css("display", "none");
    },
    closeUnlockedSportsBonusCardInfoModal: function() {
        $("#UnlockedSportsBonusCardInfoModal").css("display", "none");
    },
    showSportsBonusCardInfoModal: function(lock) {
        if (lock === 'lock') {
            $("#LockedSportsBonusCardInfoModal").show();
            $("#LockedSportsBonusCardInfoModal").css("display", "block");
        } else if (lock === 'lock_open') {
            $("#UnlockedSportsBonusCardInfoModal").show();
            $("#UnlockedSportsBonusCardInfoModal").css("display", "block");
        }
    },
    processDeleteInactiveSportsBonusModal: function(sportsBonusId, accountId) {
        homePage.showOverlay();
        pat.post('/BonusSummary/RemoveInactiveSportsBonus', {
            sportsBonusId: sportsBonusId,
            accountId: accountId
        }).done(function(data) {
            if (data.Success) {
                if (accountOptionsPopUpEnabled && accountOptionnBonusSummaryEnabled) {
                    homePage.closeOverlay();
                    homePage.ShowAccountOptionsModal('/BonusSummary', 'accountOption_bonussummary', 'Bonus Summary');
                } else {
                    location.reload();
                }
            } else {
                homePage.closeOverlay();
            }
        });
    },
    toggleBonusSummaryTabs: function(id) {
        $('#sportsBonusTab, #playthroughBonusTab, #sportsBonus, #playthroughBonus').removeClass('active in');
        $(id + ', ' + id + 'Tab').addClass('active in');
    },
    getCurrentSportId: function() {
        var result = $('#hfPrintFixtures').val() != null ? localStorage.getItem('currentFixturesSportId') : localStorage.getItem('currentSportId');
        if (result) {
            return result;
        }
        return "";
    },
    getCasinoWidget: function() {
        if (enableCasinoWidget) {
            pat.get("/Widget/GetCasinoWidget").done(function(data) {
                if (isMobile) {
                    $('#mcasinoWidget-container').html(data);
                } else {
                    $('#casinoWidget-container').html(data);
                }
            });
        }
    },
    loadCasinoWidgets: function() {
        if (enableCasinoWidget) {
            $('casino-mini-widget').attr('style', 'display:block');
        }
    }
};

function appPostMessagesOnLogin(_loggedIn, _accId = '') {
    var accID = _accId !== '' ? _accId : global.getCookie('AccountId');
    if (accID !== '')
        global.PostAppMessage('{ "message" : "Login", "data" : { "login" : ' + _loggedIn + ', "PlayerId":"' + global.getCookie('AccountId') + '", "PlayerToken":"' + global.getCookie('Syn') + '"} }');
}

function navResize() {
    if (window.innerWidth > 1440 && window.innerWidth < 1880) {
        $('.nav-link-row').css({
            'width': '100%',
            'margin-left': '0%'
        });
    } else if (window.innerWidth >= 1880) {
        $('.nav-link-row').css({
            'width': '64.9%',
            'margin-left': '16.2%'
        });
    }
}
$(document).ready(homePage.createOverlay);
$(document).ready(homePage.liveUpdate);
window.addEventListener('resize', function(event) {
    navResize();
});
$(document).ready(function() {
    navResize();
    $(document).keypress(function(event) {
        if (event.which == '13') {
            event.preventDefault();
        }
    });
    homePage.applyLiveInPlayColourScheme();
    homePage.applyColossusColourScheme();
    var viewportWidth = $(window).width();
    if (viewportWidth < 425) {
        setTimeout(function() {
            if ($('.nav-link-item.active').length && $('.nav-link-item.active').offset() !== undefined && !isNaN($('.nav-link-item.active').offset().left)) {
                var pos = $(".nav-link-item.active").offset().left - 50;
                $('.nav-link-row').animate({
                    scrollLeft: pos
                }, 1000, 'easeOutQuad');
            }
        }, 200);
    }
    $('.homeCarousel').not('.slick-initialized').slick({
        lazyLoad: 'progressive',
        infinite: true,
        draggable: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        cssEase: 'ease',
        pauseOnHover: true,
        swipe: true,
        variableWidth: false,
        dots: true
    });
    if (!checkForLite()) {
        window.homePage = window.homePage || {};
        if (!window.homePage.bLazy) {
            window.homePage.bLazy = new Blazy({
                container: ".homeCarousel",
                offset: 15000,
            });
        } else {
            window.homePage.bLazy.revalidate();
        }
    }
    var inPlayBg = $('.inPlayBg').css('background');
    if (typeof(inPlayBg) !== "undefined" && inPlayBg !== null && inPlayBg.length > 16 && location.pathname.toLowerCase().indexOf('esport') === -1) {
        var inPlayBgRgb = inPlayBg.substring(0, 17);
        if (inPlayBgRgb === "rgb(166, 187, 66)") {
            homePage.Highlight('clicked', '#ACC540', 'live');
        }
    }
    if (location.pathname.toLowerCase().indexOf('inplay') > -1 || location.pathname.toLowerCase().indexOf('sport') > -1) {
        var sportConfigId = $('p.active').parent().attr('id');
        sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
        homePage.GetSportContent(sportConfigId);
    }
    if (typeof eventDisplay.expandCollapseMenu === 'function')
        eventDisplay.expandCollapseMenu();
    if (typeof closeOverlay === 'function')
        homePage.closeOverlay();
    if (typeof filters !== 'undefined') {
        if (typeof filters.backToBets === 'function')
            filters.backToBets();
    }
    if (location.href.toLowerCase().indexOf("/bet/eventmultimarket") > -1 && window.location.search.includes(constId.feedDataType_LIP)) {
        $('#my-page, #depositBtn, #miniBetslip, #mobileBetslipFooter, #MenuLoginModalPopUp, #multi-header, #mainBody, .market-grouping, #betslip-mobile-modal, #login-controls, #SignUpModal').addClass("yellow");
    }
    if (location.href.toLowerCase().indexOf('inplay=true') > -1 && location.href.toLowerCase().indexOf('sporttype=1') === -1 && location.href.toLowerCase().indexOf('esport') === -1) {
        homePage.ToggleLiveMiddleNavBar();
        $('#my-page, #login-controls, #SignUpModal, #miniBetslip').addClass('yellow');
    }
    var loc = location.href.toLowerCase();
    if ((loc.indexOf("/esport") > -1 && loc.indexOf("/esports_") < 0) || loc.indexOf('sporttype=1') > -1 || (loc === '/bet/eventmultimarket' && $('#multi-head').hasClass('esportsHeader'))) {
        $('#my-page, #depositBtn, #miniBetslip, #mobileBetslipFooter, #MenuLoginModalPopUp, #multi-header, #mainBody, .market-grouping, #betslip-mobile-modal, #login-controls, #SignUpModal').removeClass("yellow").addClass("esports esports-market-grouping");
        homePage.Highlight('clicked', '#843492', 'esports');
    }
    if (loc.indexOf("/livecasino") > -1 || loc.indexOf("/livegames") > -1) {
        $('#my-page').addClass('livecasino');
        $('#mobileBetslipFooter, #login-controls, #SignUpModal, #miniBetslip').addClass('livecasino');
    }
    setTimeout(function() {
        if ($('#sb_id').hasClass('active')) {
            $('#betslip-list').addClass('ms-hide-exclamation').addClass('sb-active');
        } else if ($('#mb_id').hasClass('active')) {
            $('#betslip-list').removeClass('ms-hide-exclamation').removeClass('sb-active');
        }
        if (isLoggedIn)
            appPostMessagesOnLogin(true);
    }, 100);
    if (!checkForLite() && isMobile && !homePage.IsHorseracing()) {
        var initialLogin = getCookie('InitLogin');
        if (initialLogin === 'true') {
            if (typeof GetBetslip() !== 'undefined' && GetBetslip() !== null && GetBetslip() !== '{}') {
                homePage.mobileBetSlipButtonClick();
            }
            setCookie('InitLogin', 'false');
        }
    }
    $('#FirstName_tmpl, #LastName_tmpl').on("keyup", function() {
        var $input = $(this);
        if ($input.val().trim().length < 2) {
            $input.val($input.val().trim());
        }
    });
    homePage.showNewsBox();
    var modalName = getParameterByName('modal');
    if (modalName !== null) {
        if (isLoggedIn === true && accountOptionsPopUpEnabled === true) {
            $('[data-account-option-name="' + modalName + '"]').click();
        }
    }
    if ($("#synapseBar_highlights") && !$("#synapseBar_inplay").hasClass("v-btn--active") && !$("#synapseBar_highlights").hasClass("v-btn--active") && !$("#synapseBar_prematchtab").hasClass("v-btn--active") && !$("#synapseBar_outrights").hasClass("v-btn--active")) {
        if (!$("#synapseBar_highlights").hasClass('v-btn--disabled')) {
            homePage.LoadSynapseSubMenuBar('#highlights', '');
            homePage.toggleShow('.', 'highlights', false);
        }
    }
    if ($("#synapseBar_highlights") && constId.LiveOutrightSports.includes(homePage.getCurrentSportId().toLowerCase())) {
        if ($("#synapseBar_highlights").hasClass("v-btn--active") && $('.league-group-event').count === 0) {
            homePage.LoadSynapseSubMenuBar('#outrights', '');
            homePage.toggleShow('.', 'outrights', false);
        }
    }
    homePage.setSessionMetaData();
    var langParam = getParameterByName('lang');
    if (langParam !== null) {
        language.handleLanguageChange(langParam, true);
    }
    var postRegSetup = null;
    if (postRegSetup !== null) {
        if (postRegSetup !== 'completed') {
            pat.get('/Account/ThankYouPartial').done(function(data) {
                $('#PostReg').html(data);
            });
        }
    }
});
var srliveLoaded = false;
var interval = {};
var handles = {};

function checkLoaded(widgetType, matchId, container, startCollapsed = false, isInPlay = false) {
    homePage.showOverlay();
    if (interval[matchId]) {
        clearInterval(interval[matchId]);
    }
    if (!handles[matchId]) {
        homePage.showOverlay();
        handles[matchId] = SRLive.addWidget({
            name: widgetType,
            config: {
                container: container,
                showTitle: false,
                matchId: matchId,
                showMomentum: false,
                pitchCrowd: true,
                collapse_startCollapsed: startCollapsed,
                sidebarLayout: 'dynamic'
            },
            callback: function() {
                if (startCollapsed) {
                    if (isInPlay) {
                        $('.sr-widget').css({
                            'margin-bottom': '11px'
                        });
                    } else {
                        $('.sr-content').css({
                            'height': '200px',
                            'overflow': 'hidden'
                        });
                        $('.sr-widget').css({
                            'margin-bottom': '12px'
                        });
                    }
                }
                homePage.closeOverlay();
            }
        });
    }
}
SRConfig = {
    on: {
        srlive_initialized: function() {
            srliveLoaded = true;
        }
    }
}

function betradarWidget(d, s, id) {
    var js, h = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) {
        return;
    }
    js = d.createElement(s);
    js.id = id;
    js.async = true;
    js.setAttribute("data-autoInit", true);
    js.src = "https://cs.betradar.com/ls/widgets/?/betwaykenya/en/Africa:Johannesburg/widgetloader/widgets";
    h.parentNode.insertBefore(js, h);
}
if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(search, pos) {
        return this.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
    };
}
if (!Array.prototype.find) {
    Object.defineProperty(Array.prototype, 'find', {
        value: function(predicate) {
            if (this === null) {
                throw new TypeError('"this" is null or not defined');
            }
            var o = Object(this);
            var len = o.length >>> 0;
            if (typeof predicate !== 'function') {
                throw new TypeError('predicate must be a function');
            }
            var thisArg = arguments[1];
            var k = 0;
            while (k < len) {
                var kValue = o[k];
                if (predicate.call(thisArg, kValue, k, o)) {
                    return kValue;
                }
                k++;
            }
            return undefined;
        },
        configurable: true,
        writable: true
    });
}
if (!Array.prototype.includes) {
    Object.defineProperty(Array.prototype, 'includes', {
        value: function(searchElement, fromIndex) {
            if (this === null) {
                throw new TypeError('"this" is null or not defined');
            }
            var o = Object(this);
            var len = o.length >>> 0;
            if (len === 0) {
                return false;
            }
            var n = fromIndex | 0;
            var k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

            function sameValueZero(x, y) {
                return x === y || (typeof x === 'number' && typeof y === 'number' && isNaN(x) && isNaN(y));
            }
            while (k < len) {
                if (sameValueZero(o[k], searchElement)) {
                    return true;
                }
                k++;
            }
            return false;
        }
    });
}
if (!String.prototype.includes) {
    String.prototype.includes = function(search, start) {
        'use strict';
        if (typeof start !== 'number') {
            start = 0;
        }
        if (start + search.length > this.length) {
            return false;
        } else {
            return this.indexOf(search, start) !== -1;
        }
    };
}
if (!Array.prototype.findIndex) {
    Object.defineProperty(Array.prototype, 'findIndex', {
        value: function(predicate) {
            if (this === null) {
                throw new TypeError('"this" is null or not defined');
            }
            var o = Object(this);
            var len = o.length >>> 0;
            if (typeof predicate !== 'function') {
                throw new TypeError('predicate must be a function');
            }
            var thisArg = arguments[1];
            var k = 0;
            while (k < len) {
                var kValue = o[k];
                if (predicate.call(thisArg, kValue, k, o)) {
                    return k;
                }
                k++;
            }
            return -1;
        },
        configurable: true,
        writable: true
    });
}
jQuery.validator.addMethod("ValidSaIdNumber", function(value, element) {
    return this.optional(element) || ValidateIdNumber(value);
}, 'Please enter a valid SA ID Number.');
jQuery.validator.addMethod("ValidIdentityType", function(value, element) {
    return this.optional(element) || ValidIdentityType(element, value);
}, 'This field is in incorrect format.');

function ToThousandSeparator(val, decimalPoints = 2) {
    try {
        if (isThousandSeperatorEnabled) {
            return (Math.floor(val * 100) / 100).toLocaleString('en', {
                minimumFractionDigits: decimalPoints,
                maximumFractionDigits: decimalPoints
            });
        } else {
            return (Math.floor(val * 100) / 100).toFixed(2);
        }
    } catch (error) {
        console.log(error);
        return val;
    }
}

function ValidateMultiCheckBox(elementIds, newSelection) {
    for (index in elementIds) {
        if (elementIds[index] !== newSelection) {
            var element = document.getElementById(elementIds[index]);
            if (element.checked) {
                element.checked = false;
            }
        }
    }
}

function InitializeUserBalance() {
    PlayerAccountID = getCookie('AccountId');
    var isClientLoggedIn = getCookie('IsLoggedIn');
    var lemony = getCookie('Lemony');
    if (isClientLoggedIn.toLocaleLowerCase() === 'true' || (PlayerAccountID != '' && PlayerAccountID != null && PlayerAccountID != constId.emptyGuid) || (lemony != null && lemony != '')) {
        try {
            homePage.RefreshCashBalance(false, true);
            accNo = lemony.split('|')[1]
            $('#currentAccount_Number').text(` : ${accNo}`);
        } catch (e) {
            console.error(e);
        }
    }
    if (window.loginObject == null) {
        var playerId = constId.emptyGuid;
        if (PlayerAccountID != null && PlayerAccountID != undefined && PlayerAccountID != '') {
            playerId = PlayerAccountID;
        }
        window.loginObject = {
            isLoggedIn: `${playerId}`,
            inboxCount: 0,
            cashBalance: 0,
            freeBetBalance: 0,
            bonusBalance: 0,
            sportBonusBalance: 0,
            betCount: 0
        };
        var localBalanceState = JSON.parse(localStorage.getItem('balanceState'));
        if (localBalanceState != null) {
            window.loginObject.cashBalance = localBalanceState.balance.CashBalance;
            window.loginObject.freeBetBalance = localBalanceState.balance.BonusBalance;
            window.loginObject.bonusBalance = localBalanceState.balance.PlaythroughBalance;
            window.loginObject.sportBonusBalance = localBalanceState.balance.SportBonusBalance;
        }
    }
}

function InitializeNotificationPanel() {
    if (isNotificationPanelEnabled && IsUserLoggedInCookieCheck()) {
        pat.get("/Widget/GetNotificationPanel?val=true").done(function(response) {
            $('#notifications-panel-placeholder').html(response);
        });
    }
}

function InitializeSwiftEndVerificationModal() {
    if (!swiftEndEnabled)
        return;
    pat.get("/Account/GetSwiftEndSessionModal?val=true").done(function(response) {
        $('#SwiftEndAccountVerificationModal_PlaceHolder').html(response);
        $('#btnVerifyNin').off('click').on('click', account.verifyNIN);
        $('#btnVerifyBvn').off('click').on('click', account.verifyBVN);
    });
}

function IsUserLoggedInCookieCheck() {
    PlayerAccountID = getCookie('AccountId');
    var isClientLoggedIn = getCookie('IsLoggedIn');
    var lemony = getCookie('Lemony');
    return isClientLoggedIn.toLocaleLowerCase() === 'true' || (PlayerAccountID != '' && PlayerAccountID != null && PlayerAccountID != constId.emptyGuid) || (lemony != null && lemony != '');
}

function IsUserLoggedInCookieCheck() {
    PlayerAccountID = getCookie('AccountId');
    var isClientLoggedIn = getCookie('IsLoggedIn');
    var lemony = getCookie('Lemony');
    return isClientLoggedIn.toLocaleLowerCase() === 'true' || (PlayerAccountID != '' && PlayerAccountID != null && PlayerAccountID != constId.emptyGuid) || (lemony != null && lemony != '');
}
window.launchNotificationPanel = function() {
    OpenOsirisNotificationPanel();
}
window.launchSportsBonus = function() {
    homePage.bonusSummaryMoreInfo('#sportsBonusTab > a');
};
window.launchCasinoBonus = function() {
    homePage.bonusSummaryMoreInfo('#playthroughBonusTab > a');
};
window.launchManagePassword = function() {
    $('[data-account-option-name="managepassword"]').click();
};
window.launchInboxMessage = function() {
    $('[data-account-option-name="messages"]').click();
};
window.launchPromoVoucher = function() {
    $('[data-account-option-name="vouchers"]').click();
};
window.launchFreeBets = function() {
    $('[data-account-option-name="freebets"]').click();
};
window.launchTransactionSummary = function() {
    $('[data-account-option-name="transactionsummary"]').click();
};
window.launchUpdateDetails = function() {
    $('[data-account-option-name="updatedetails"]').click();
};
window.launchDocumentUpload = function() {
    $('[data-account-option-name="documentupload"]').click();
}
window.launchResponsibleGaming = function() {
    $('[data-account-option-name="responsiblegaming"]').click();
}
window.launchDeposits = function() {
    $('#depositBtnInline').click();
}
window.launchChat = function() {
    window.location = $('#betway-chat').attr('href');
}
window.launchWithdrawFunds = function() {
    window.location = "/Account/WithdrawFunds";
};
var timeout;
var eventsWithFiltersLoaded = false;
var eventDisplay = {
    isMultiMixMarket: false,
    outcomeButtonClick: function(btn, outcomeId, eventId, actionSelection, outcomeTitle, outcomePriceDecimal, isInstantBet) {
        var event = $(btn).closest("#" + eventId)[0];
        var FeedDataTypeId = event.getAttribute('data-markettypecategory');
        var marketId = event.getAttribute('data-market');
        if (marketId === null)
            marketId = btn.getAttribute('data-market');
        var eventTitle = event.getAttribute('data-eventtitle');
        var sportTitle = event.getAttribute('data-sporttitle');
        var startDateTime = event.getAttribute('data-eventdate');
        var marketTitle = event.getAttribute('data-markettitle');
        if (marketTitle === null)
            marketTitle = btn.getAttribute('data-markettitle');
        var outcomeIdAndPriceDecimal = outcomeId + "|" + outcomePriceDecimal;
        var outcomesbv = document.getElementById(outcomeId).getAttribute('data-lip-sbv');
        var eventContainers = $("div[id=" + eventId + "]");
        $('#betslip-single-multi-error').text("");
        eventDisplay.AddToSessionBetslip(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, actionSelection, eventContainers, '', isInstantBet, outcomesbv);
        gax.AddToBetslip_EventTracking(outcomeTitle, sportTitle, eventTitle, outcomePriceDecimal, '', '', eventId);
    },
    onFilterDropdownClick: function(id, event) {
        $('.dropdown-submenu a').off('click');
        $('.dropdown-submenu a').on('click', function(event) {
            $('.dropdown-submenu a').each(function(e) {
                $(this).next('ul').hide();
            });
            $(this).next('ul').show();
            event.stopPropagation();
            event.preventDefault();
        });
        if ($('#filterleagues-section').hasClass('open')) {
            $('#' + id).hide();
            $('#filterleagues-section').removeClass('open');
            $('#filterleagues-button').attr('aria-expanded', 'false');
        } else {
            $('#filterleagues-section').addClass('open');
            $('#' + id).show();
            $('#filtermarket-list').hide();
            $('#filtermarket-button').parent().removeClass('open');
            $('#filtermarket-button').attr('aria-expanded', 'false');
            $('#filterleagues-button').attr('aria-expanded', 'true');
        }
        homePage.applyLiveInPlayColourScheme();
    },
    closeLeagueFilterList: function() {
        $('#filterLeagues-list').hide();
        $('#filterleagues-section').removeClass('open');
    },
    expandCollapseMenu: function(event) {
        $('.submenu .list-group.checked-list-box .league-item').off('click');
        $('.submenu .list-group.checked-list-box .league-item').on('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
        });
        $('#filterLeagues-list li').off('click');
        $('#filterLeagues-list li').on('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
        });
    },
    setCheckedState: function(item) {
        var settings = {
            on: {
                icon: 'glyphicon glyphicon-check'
            },
            off: {
                icon: 'glyphicon glyphicon-unchecked'
            }
        };
        var isChecked = $(item).children('input').is(':checked');
        var style = 'isChecked';
        $(item).data('state', (isChecked) ? "on" : "off");
        $(item).find('.state-icon').removeClass().addClass('state-icon ' + settings[$(item).data('state')].icon);
        if (isChecked) {
            $(item).addClass(style);
        } else {
            $(item).removeClass(style);
        }
    },
    updateDisplay: function() {
        $('li.league-item').each(function() {
            eventDisplay.setCheckedState(this);
        });
    },
    setLeagueValues: function(item) {
        var $widget = $(item),
            $checkbox = $(item).children('input');
        $widget.css('cursor', 'pointer');
        $widget.on('click', function() {
            $checkbox.prop('checked', !$checkbox.is(':checked'));
            $checkbox.triggerHandler('change');
            eventDisplay.updateDisplay();
        });
        $checkbox.on('change', function() {
            eventDisplay.updateDisplay();
        });
    },
    closeSubmenu: function(id, fl) {
        var parentLocation = window.location.pathname;
        var subListUL = $('[id="' + id + '"]');
        var linkAchor = $("[id='leagueLink-" + id + "']");
        $('.leagueLink').css({
            'background-color': 'transparent',
            'color': 'black'
        });
        if ($(subListUL).css('display') === 'block') {
            $(subListUL).fadeOut('fast');
            $(linkAchor).removeClass('liveInPlayClr');
            $(linkAchor).removeClass("active");
        } else {
            $(".leagueLink").removeClass('active');
            $(linkAchor).addClass("active");
            $(".list-group").hide();
            $(".leagueLink").removeClass('liveInPlayClr');
            $('.checked-list-box').hide();
            $(linkAchor).css({
                'background-color': '#439539',
                'color': 'white'
            });
            $(subListUL).fadeIn('fast');
            if (parentLocation.toLowerCase() === "/event/inplay" || parentLocation.toLowerCase() === "/event/livesport" || (parentLocation.toLowerCase() === "/bet/eventmultimarket" && $('#multi-head').hasClass('inPlayBg'))) {
                $(linkAchor).addClass('liveInPlayClr');
            } else {
                $(linkAchor).removeClass('liveInPlayClr');
            }
        }
    },
    AddToSessionBetslip: function(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, actionSelection, selectionParentContainers, couponTypeId, isInstantBet, specialBetValue) {
        var isRemove = false;
        $(selectionParentContainers).each(function() {
            var isRemoveLocal = eventDisplay.addRemoveSelectedClass(this, FeedDataTypeId, outcomeId);
            if (isRemove === false)
                isRemove = isRemove || isRemoveLocal;
        });
        var element = $('*[data-lip-value="' + outcomeId + '"]');
        if (element !== null && element.data('lip-pricedecimal') !== undefined && element.data('lip-pricedecimal') !== null) {
            outcomePriceDecimal = $(".outcome-pricedecimal[data-lip-value='" + outcomeId + "']").text();
        }
        if (typeof eval(actionSelection) === "function") {
            eval(actionSelection)(outcomeId, eventId, isRemove, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, isInstantBet, specialBetValue);
        }
    },
    addRemoveSelectedClass: function(selectionParentContainer, FeedDataTypeId, outcomeId) {
        var setInPlay = FeedDataTypeId === constId.feedDataType_LIP;
        var isRemove = false;
        var allSelections = selectionParentContainer.querySelectorAll(".isSelected");
        if (setInPlay) {
            allSelections = selectionParentContainer.querySelectorAll(".isSelectedInPlay");
        }
        for (var i = 0; i < allSelections.length; i++) {
            var e = allSelections[i];
            if (e.id === outcomeId) {
                isRemove = true;
                e.className = setInPlay === true ? e.className.replace(/(?:^|\s)isSelectedInPlay(?!\S)/g, '') : e.className.replace(/(?:^|\s)isSelected(?!\S)/g, '');
            }
        }
        if (!isRemove) {
            var _isSingleBets = homePage.getIsSingleBets();
            var eventSelection = selectionParentContainer.getElementsByTagName('*');
            for (var k = 0; k < eventSelection.length; k++) {
                var ev = eventSelection[k];
                if (ev.id === outcomeId) {
                    if (setInPlay === true && !ev.className.match(/(?:^|\s)isSelectedInPlay(?!\S)/)) {
                        ev.className += " isSelectedInPlay";
                    } else if (setInPlay !== true && !ev.className.match(/(?:^|\s)isSelected(?!\S)/)) {
                        if ($(ev).is("div") && !_isSingleBets && (eventDisplay.isMultiMixMarket === undefined || eventDisplay.isMultiMixMarket === false)) {
                            $(ev).parent().parent().parent().find(".isSelected").removeClass("isSelected");
                        }
                        ev.className += " isSelected";
                    }
                } else {
                    if (setInPlay === true) {
                        if (!_isSingleBets) {
                            ev.className = ev.className.replace(/(?:^|\s)isSelectedInPlay(?!\S)/g, '');
                            if ($(ev).is("select")) {
                                $(ev).val("EMPTY");
                            }
                        }
                    } else {
                        if (!_isSingleBets) {
                            if (eventDisplay.isMultiMixMarket !== 'undefined' && eventDisplay.isMultiMixMarket !== false) {
                                $('#' + outcomeId).parent().parent().parent().parent().find('.btn-bettingmatch').removeClass('isSelected');
                                $('#' + outcomeId).addClass('isSelected');
                                break;
                            } else {
                                ev.className = ev.className.toString().replace(/(?:^|\s)isSelected(?!\S)/g, '');
                            }
                            if ($(ev).is("select")) {
                                $(ev).val("EMPTY");
                            }
                        }
                    }
                }
            }
        }
        return isRemove;
    },
    addActive: function(elem) {
        elem.classList.add('active', 'mSportColour');
        $(elem).find('p').attr('style', 'overflow: hidden;');
    },
    filterSports: function(sportConfigId, FeedDataTypeId, event, isOperaMini, isEsport, promotionsUrl, isStaggeredLoad) {
        if (localStorage.getItem("from-golf-live-outrights") !== null) {
            sportConfigId = constId.soccerId;
            localStorage.removeItem('from-golf-live-outrights');
        }
        if (promotionsUrl && promotionsUrl.length > 0) {
            window.location = promotionsUrl;
            return;
        }
        localStorage.setItem('currentSportId', sportConfigId);
        if (isEsport == true)
            global.setCookieWithAllSubDomain(`selectedSport~${FeedDataTypeId.toString()}~esport`, sportConfigId, 31);
        else
            global.setCookieWithAllSubDomain(`selectedSport~${FeedDataTypeId.toString()}~sport`, sportConfigId, 31);
        $('.top-Fav-Btns').hide();
        $('#TopLeagues').css('height', '0px');
        $('#TopLeaguesAccordion').attr('style', 'display:none !important');
        if (FeedDataTypeId.toUpperCase() === constId.feedDataType_LIP.toUpperCase() && sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550064') {
            window.location = "/esports/live";
            return;
        }
        if (sportsFilterOptionsEnabled === "True" && typeof(filterOptions) !== "undefined" && typeof(filterOptions.InitFilterObject) != "undefined") {
            filterOptions.InitFilterObject(sportConfigId, FeedDataTypeId);
        }
        $('.new-filters-container').hide();
        homePage.createLoader();
        location.hash = '';
        global.eraseCookie("submenuRef");
        global.eraseCookie("selectedSportPageNo");
        $('.mSport').each(function() {
            $(this).removeClass('active mSportColour');
            $(this).find('p').attr('style', 'overflow: hidden; color: #333 !important');
        })
        $(this).addClass('active')
        if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550031') {
            window.location = "/Casino";
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550032') {
            window.location = "/Jackpots/Index";
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550064') {
            window.location = "/Esports";
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550069') {
            window.location = "/virtualsport";
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550070') {
            window.location = "/betgames";
        } else if ((typeof isEsport != 'undefined' && isEsport) || (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550064')) {
            var useNewFilters = (sportsFilterOptionsEnabled === "True" && typeof(filterOptions) !== "undefined");
            this.getSportEvents(sportConfigId, FeedDataTypeId, useNewFilters, isEsport);
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550072') {
            if (homePage.synapseNavBarEnabled) {
                if ($('#synapseNaveBarContainer').find('.betMyWayTab').length === 0) {
                    $(".mobileEvents").empty().append(`
                        <div class="mobileMiddleNav colour">
                            <div>
                                <div class="mobileMiddleNavContainer">
                                    <span class='mobileMiddleNavItem btnTextColour clickable theFont betMyWayTab'
                                            onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550072', '00000000-0000-0000-da7a-000000580001',event, false, false);'>
                                        <span id='triangle_betyourway' class='triangle-down'></span>BetMyWay</span>
                                </div>
                            </div>
                        </div>`);
                    language.translateAtRuntime($("#betMyWaySpan"), "SportContent", {
                        "data-translate-key": "BetMyWay"
                    });
                }
            } else {
                if ($('#mobileMiddleNavContainer').find('.betMyWayTab').length === 0) {
                    $(".mobileMiddleNavContainer").empty().append("<span class='mobileMiddleNavItem btnTextColour clickable theFont betMyWayTab' onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550072', '00000000-0000-0000-da7a-000000580001',event, false, false);'><span id='triangle_betyourway' class='triangle-down'></span id='betMyWaySpan'>BetMyWay</span>");
                    language.translateAtRuntime($("#betMyWaySpan"), "SportContent", {
                        "data-translate-key": "BetMyWay"
                    });
                }
            }
            pat.post("/BetYourWay/Index").done(function(result) {
                if (document.getElementById('IndexPartialContainer') === null) {
                    location.reload();
                } else {
                    $("#subsection").html(result).show();
                    $(".eventLoader").hide();
                    $("#bettingtabs").removeClass('row');
                }
                $('#mobileFilter, .new-filters-container').hide();
                events.setActiveSport(sportConfigId);
                homePage.closeOverlay();
                SetOutcomeButtons();
            }).fail(function() {
                homePage.closeOverlay();
            });
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550101') {
            if (homePage.synapseNavBarEnabled) {
                if ($('#synapseNaveBarContainer').find('.trendingTab').length === 0) {
                    $(".mobileEvents").empty().append(`
                        <div class="mobileMiddleNav colour">
                            <div>
                                <div class="mobileMiddleNavContainer">
                                    <span class='mobileMiddleNavItem btnTextColour clickable theFont trendingTab'
                                            onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550101', '00000000-0000-0000-da7a-000000580001',event, false, false);'>
                                        <span id='triangle_trending' class='triangle-down'></span>Trending</span>
                                </div>
                            </div>
                        </div>`);
                    language.translateAtRuntime($("#trendingSpan"), "SportContent", {
                        "data-translate-key": "Trending"
                    });
                }
            } else {
                if ($('#mobileMiddleNavContainer').find('.trendingTab').length === 0) {
                    $(".mobileMiddleNavContainer").empty().append("<span class='mobileMiddleNavItem btnTextColour clickable theFont trendingTab' onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550101', '00000000-0000-0000-da7a-000000580001',event, false, false);'><span id='triangle_trending' class='triangle-down'></span id='trendingSpan'>Trending</span>");
                    language.translateAtRuntime($("#trendingSpan"), "SportContent", {
                        "data-translate-key": "Trending"
                    });
                }
            }
            pat.get("/TrendingBets/Index").done(function(result) {
                if (document.getElementById('IndexPartialContainer') === null) {
                    location.reload();
                } else {
                    $("#subsection").html(result).show();
                    $('.mobileEvents').removeClass('hidden');
                    $("#subsection").removeClass('hidden');
                    $(".eventLoader").hide();
                    $("#bettingtabs").removeClass('row');
                }
                $('#mobileFilter, .new-filters-container').hide();
                events.setActiveSport(sportConfigId);
                homePage.closeOverlay();
                SetOutcomeButtons();
            }).fail(function() {
                homePage.closeOverlay();
            });
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550102') {
            $('#TopLeagues').hide();
            if (homePage.synapseNavBarEnabled) {
                if ($('#synapseNaveBarContainer').find('.couponsTab').length === 0) {
                    $(".mobileEvents").empty().append(`
                        <div class="mobileMiddleNav colour">
                            <div>
                                <div class="mobileMiddleNavContainer">
                                    <span class='mobileMiddleNavItem btnTextColour clickable theFont couponsTab'
                                            onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550102', '00000000-0000-0000-da7a-000000580001',event, false, false);'>
                                        <span id='triangle_coupons' class='triangle-down'></span>Coupons</span>
                                </div>
                            </div>
                        </div>`);
                    language.translateAtRuntime($("#couponsSpan"), "SportContent", {
                        "data-translate-key": "Coupons"
                    });
                }
            } else {
                if ($('#mobileMiddleNavContainer').find('.couponsTab').length === 0) {
                    $(".mobileMiddleNavContainer").empty().append("<span class='mobileMiddleNavItem btnTextColour clickable theFont couponsTab' onclick='eventDisplay.filterSports('00000000-0000-0000-da7a-000000550102', '00000000-0000-0000-da7a-000000580001',event, false, false);'><span id='triangle_coupons' class='triangle-down'></span id='couponSpan'>Coupons</span>");
                    language.translateAtRuntime($("#couponsSpan"), "SportContent", {
                        "data-translate-key": "Coupons"
                    });
                }
            }
            pat.get("/Coupons/Index").done(function(result) {
                if (document.getElementById('IndexPartialContainer') === null) {
                    location.reload();
                } else {
                    $("#subsection").html(result).show();
                    $(".eventLoader").hide();
                    $("#bettingtabs").removeClass('row');
                }
                $('#mobileFilter, .new-filters-container').hide();
                events.setActiveSport(sportConfigId);
                homePage.closeOverlay();
                SetOutcomeButtons();
            }).fail(function() {
                homePage.closeOverlay();
            });
        } else if (sportConfigId.toUpperCase() === '00000000-0000-0000-DA7A-000000550033') {
            var _eventsBySportIdUrl = "/Event/GetEventsBySportId";
            var _eventsBySportIdArgs = {
                sportConfigId: sportConfigId,
                FeedDataTypeId: FeedDataTypeId
            };
            if (loadEventsForSportsViaAjax) {
                _eventsBySportIdUrl = "/Ajax/GetEventsBySportId";
                _eventsBySportIdArgs = {
                    sportConfigId: sportConfigId,
                    FeedDataTypeId: FeedDataTypeId,
                    brandId: Brand,
                    accountGuid: PlayerAccountID,
                    isLoggedIn: isLoggedIn,
                    isMobileDevice: isMobile
                };
            }
            pat.get(_eventsBySportIdUrl, _eventsBySportIdArgs).done(function(result) {
                $(".mSport").css("background-color", "#e8e8e8");
                if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                    location.reload();
                } else if (document.getElementById('IndexPartialContainer') === null) {
                    location.reload();
                } else {
                    $("#IndexPartialContainer").html(result);
                }
                events.setActiveSport(sportConfigId);
                $('#submenu_International > li').first().attr('data-checked', "True").addClass("isChecked").find("span").removeClass("glyphicon-unchecked").addClass("glyphicon-check");
                homePage.closeOverlay();
                SetOutcomeButtons();
                homePage.getSportFilters();
            }).fail(function() {
                homePage.closeOverlay();
                if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                    location.reload();
                }
            });
        } else {
            if (FeedDataTypeId.toUpperCase() === '00000000-0000-0000-DA7A-000000580001') {
                var useNewFilters = (sportsFilterOptionsEnabled === "True" && typeof(filterOptions) !== "undefined");
                pat.get("/Event/OutrightsOnly", {
                    sportConfigId: sportConfigId
                }).done(function(hasEvent) {
                    if ($('#triangle_topgames').hasClass('triangle-down') && (sportConfigId === '00000000-0000-0000-da7a-000000550001' || hasEvent === 'False')) {
                        $(".mSport").css("background-color", "#e8e8e8");
                        event.setActiveSport(sportConfigId);
                        gotoSport();
                        $('#mobileFilter, .new-filters-container').hide();
                        SetOutcomeButtons();
                        if (sportsFilterOptionsEnabled === "True" && typeof(filterOptions) !== "undefined") {
                            filterOptions.clearFilters();
                        }
                        if (loadWidgetHighlightsViaAjax) {
                            homePage.getWidgetHighlights(sportConfigId);
                        }
                    } else {
                        eventDisplay.getSportEvents(sportConfigId, FeedDataTypeId, useNewFilters);
                    }
                });
            } else {
                eventDisplay.getSportEvents(sportConfigId, FeedDataTypeId, useNewFilters);
            }
        }
        if (sportConfigId !== constId.FormulaOne && sportConfigId !== constId.Golf && (typeof(isStaggeredLoad) === "undefined" || (typeof(isStaggeredLoad) !== "undefined" && !isStaggeredLoad))) {
            homePage.GetSportContent(sportConfigId);
        }
        homePage.applyLiveInPlayColourScheme();
        if (sportsFilterOptionsEnabled === "True" && typeof(filterOptions) !== "undefined") {
            filterOptions.updateSportTileFilters(sportConfigId, FeedDataTypeId);
        }
    },
    getSportEvents: function(sportConfigId, FeedDataTypeId, useNewFilters, isEsport = false) {
        var url = isEsport ? "/ESports/GetEventsBySportId" : (loadEventsForSportsViaAjax && FeedDataTypeId != constId.feedDataType_LIP) ? "/Ajax/GetEventsBySportId" : "/Event/GetEventsBySportId";
        if ((sportConfigId === constId.FormulaOne || sportConfigId === constId.Golf) && (FeedDataTypeId === constId.feedDataType_LIP || FeedDataTypeId === constId.feedDataType_LiveOutrights)) {
            FeedDataTypeId = constId.feedDataType_LiveOutrights;
        } else if (FeedDataTypeId != constId.feedDataType_Prematch) {
            FeedDataTypeId = constId.feedDataType_LIP;
        }
        var _eventsBySportIdArgs = {
            sportConfigId: sportConfigId,
            FeedDataTypeId: FeedDataTypeId
        };
        if (!isEsport && loadEventsForSportsViaAjax) {
            _eventsBySportIdArgs = {
                sportConfigId: sportConfigId,
                FeedDataTypeId: FeedDataTypeId,
                brandId: Brand,
                accountGuid: PlayerAccountID,
                isLoggedIn: isLoggedIn,
                isMobileDevice: isMobile
            };
        }
        pat.get(url, _eventsBySportIdArgs).done(function(result) {
            if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                location.reload();
            } else if (document.getElementById('IndexPartialContainer') === null) {
                location.reload();
            } else {
                if (result.indexOf("liveoutrights-auto") > 0 || result.indexOf("outrights-auto") > 0) {
                    result = result.replace("-auto", "");
                    window.location = result;
                } else {
                    $("#IndexPartialContainer").html(result);
                    eventDisplay.expandCollapseMenu();
                    homePage.getSportFilters();
                    populateSportSlider();
                    homePage.closeOverlay();
                    SetOutcomeButtons();
                    homePage.HighlightSubmenuItem();
                    if ((sportConfigId.toUpperCase() === "00000000-0000-0000-DA7A-000000550100" || sportConfigId.toUpperCase() === "00000000-0000-0000-DA7A-000000550007") && (FeedDataTypeId === constId.feedDataType_LIP || FeedDataTypeId === constId.feedDataType_LiveOutrights)) {
                        $("#triangle_outrights").addClass("liveInPlayClr");
                    } else {
                        $("#triangle_outrights").removeClass("liveInPlayClr");
                    }
                }
            }
            SetOutcomeButtons();
        }).fail(function() {
            homePage.closeOverlay();
            if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                location.reload();
            }
        });
    },
    onOutcomeDropDownFocus: function(sel) {
        var select = $(sel);
        var outcomeId = select.val();
        $('#selectedOutcomeValue').val(outcomeId);
    },
    updatePotentialReturnConfirmation: function(isSingle, potentialReturnAmount, maxPayout) {
        $('#sb_id, #mb_id').css({
            "background-color": "white",
            "color": "black"
        }).removeClass('active');
        var parentLocation = window.location.pathname;
        if (parentLocation.toLowerCase() === "/event/inplay" || parentLocation.toLowerCase() === "/event/livesport/" || (parentLocation.toLowerCase() === "/bet/eventmultimarket" && $('#multi-head').hasClass('inPlayBg'))) {
            $('#sb_id.active, #mb_id.active').css({
                "background-color": "#acc240",
                "color": "black"
            });
        } else {
            $('#sb_id.active, #mb_id.active').css({
                "background-color": "#439539",
                "color": "white"
            });
        }
        if (isSingle) {
            $('#sb_id').css({
                "background-color": "#439539",
                "color": "white"
            }).addClass('active');
            var returns = $('#betslip-list').find('.stake-return-amount');
            var singleBetsPotentialReturn = 0;
            var freeBetId = $('.chk-free-bet:checkbox:checked[id^="usefreebet"]').attr('id');
            var freeBetIndex = -1;
            if (typeof freeBetId !== "undefined") {
                freeBetIndex = parseInt(freeBetId.replace("usefreebet", ""));
            }
            if (!$.isNumeric(freeBetIndex)) {
                freeBetIndex = -1;
            }
            var potentialSingleFreeBetReturn = parseFloat($('#potentialSingleFreeBetReturn').text());
            for (var j = 0; j < returns.length; j++) {
                var stake = $(returns[j]);
                if (j !== freeBetIndex) {
                    singleBetsPotentialReturn += parseFloat(stake.text());
                }
            }
            if (!$.isNumeric(potentialSingleFreeBetReturn)) {
                $("#potentialSingleFreeBetReturn").val(potentialSingleFreeBetReturn.toFixed(2));
                $("#potentialSingleFreeBetReturn").text(potentialSingleFreeBetReturn.toFixed(2));
            }
            $("#PotentialReturnAmount").val(singleBetsPotentialReturn.toFixed(2));
            $("#potentialReturnConfirm").val(singleBetsPotentialReturn.toFixed(2));
            $("#PotentialReturnAmount").text(singleBetsPotentialReturn.toFixed(2));
            $("#potentialReturnConfirm").text(singleBetsPotentialReturn.toFixed(2));
            $("#potentialSingleReturnConfirm").val(singleBetsPotentialReturn.toFixed(2));
            $("#potentialSingleReturnConfirm").text(singleBetsPotentialReturn.toFixed(2));
            $('#mb_id').removeClass('active');
            homePage.applyLiveInPlayColourScheme();
        } else {
            $('#mb_id').css({
                "background-color": "#439539",
                "color": "white"
            }).addClass('active');
            var totalPriceDecimal = $('#betslip-list').find('#betslip-totalpricedecimal').text();
            var potentialWager = parseFloat($('#potentialWager').val());
            var potentialReturn = 0;
            if (potentialReturnAmount > 0) {
                potentialReturn = potentialReturnAmount;
            } else {
                potentialReturn = (totalPriceDecimal * potentialWager);
            }
            if (potentialReturn > maxPayout) {
                potentialReturn = maxPayout;
            }
            $("#PotentialReturnAmount").val(potentialReturn.toFixed(2));
            $("#potentialReturn").val(potentialReturn.toFixed(2));
            $("#PotentialReturnAmount").text(potentialReturn.toFixed(2));
            $("#potentialReturn").text(potentialReturn.toFixed(2));
            $("#potentialReturnConfirm").val(potentialReturn.toFixed(2));
            $("#potentialReturnConfirm").text(potentialReturn.toFixed(2));
            $('#sb_id').removeClass('active');
            homePage.applyLiveInPlayColourScheme();
        }
    },
    scrollBind: function() {
        try {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                var heightTollerance = 2;
                var scrollHeight = Math.trunc($(this).scrollTop() + $(this).height());
                var shouldLoad = false;
                if (isMobileDevice == false && (scrollHeight < $(document).height() + heightTollerance && scrollHeight > $(document).height() - heightTollerance)) {
                    shouldLoad = true;
                } else if (isMobileDevice && ($(this).scrollTop() > ($("#subsection")[0].scrollHeight / 2))) {
                    shouldLoad = true;
                }
                if (shouldLoad) {
                    $(window).unbind('scroll');
                    $("#loader").fadeIn(300);
                    eventDisplay.onEventsClick(true);
                }
            }, 50);
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => scrollBind()", details: ' + e);
        }
    },
    onEventsClick: function(isNext, pageNumValue) {
        var feedDataTypeId = $('#bettingtabs,#webTabs').find('li.active').data('markettypecategory');
        var selectedFeedDataTypeId = feedDataTypeId === constId.emptyGuid ? constId.feedDataType_Prematch : feedDataTypeId;
        var pageNumPlaceHolder = $("#events-page-number");
        var pageNum = parseInt((isNaN(pageNumPlaceHolder.val()))) ? 0 : parseInt(pageNumPlaceHolder.val());
        var currentSportId = $(".mSport .active").parent().attr("id").replace("Sport_", "");
        if (isNext !== null) {
            if (isNext) {
                pageNum += 1;
            } else {
                pageNum -= 1;
            }
        } else {
            pageNum = parseInt(pageNumValue);
        }
        var eventIds = null;
        if (refreshLIPEnabled) {
            eventIds = $('*[data-event-id][data-markettypecategory="00000000-0000-0000-da7a-000000580003"]').map(function() {
                return $(this).data("event-id");
            }).get();
        }
        pat.post("/Event/GetEventSet", {
            FeedDataTypeId: selectedFeedDataTypeId,
            pageNumber: pageNum,
            eventIds: eventIds,
            sportConfigId: currentSportId
        }).done(function(data) {
            global.setCookie("selectedSportPageNo", pageNum.toString());
            if (!events.shouldShowMoreEvents(true)) {
                $('#fixturesToReplace').append(data);
                $(window).unbind('scroll');
                $("#loaderText").html("End of results");
                $("#loader").fadeOut(2000);
                $("#loadMore").hide();
                localStorage.setItem("lastEventIsLazyLoaded", true);
                eventDisplay.addOrAppendEventToLeagueGroup();
                return;
            }
            if ($(data).find('*[data-event-display-has-more-markettypecategory*="' + selectedFeedDataTypeId + '"]').length === 0) {
                if ($(data).find('*[data-event-id]').length > 0) {
                    $('#fixturesToReplace').append(data);
                    eventDisplay.addOrAppendEventToLeagueGroup();
                    if ($(data).find('*[data-event-has-more*="False"]').length > 0) {
                        $("#loaderText").html("End of results");
                        $("#loader").fadeOut(2000);
                        $("#loadMore").hide();
                        eventDisplay.addOrAppendEventToLeagueGroup();
                        return;
                    }
                } else {
                    $(window).unbind('scroll');
                    $("#loaderText").html("End of results");
                    $("#loader").fadeOut(2000);
                    $("#loadMore").hide();
                    eventDisplay.addOrAppendEventToLeagueGroup()
                    return;
                }
            } else {
                $('#fixturesToReplace').append(data);
                eventDisplay.addOrAppendEventToLeagueGroup()
            }
            if ($(data).find('#event-session-expire-redirect').length > 0) {
                window.location = "/";
            }
            pageNumPlaceHolder.val(pageNum);
            $("#loader").hide();
            $("#loadMore").show();
        });
    },
    ApplyLazyLoad: function() {
        try {
            global.eraseCookie("selectedSportPageNo");
            $(window).bind("scroll", eventDisplay.scrollBind);
        } catch (e) {
            console.log('An unexpected error occurred in "eventDisplay => ApplyLazyLoad()", details: ' + e);
        }
    },
    filterEventSportPaging: function() {
        var isBack = global.getCookie("isBackButtonClicked");
        if (isBack !== undefined && isBack === "true") {
            var selectedPageNoCookie = global.getCookie('selectedSportPageNo');
            if (selectedPageNoCookie !== undefined && selectedPageNoCookie !== "") {
                eventDisplay.onEventsClick(null, selectedPageNoCookie);
                global.eraseCookie("isBackButtonClicked");
            }
        }
    },
    createIsBackCookie: function(isBack) {
        if (isBack === undefined || isBack === "") {
            isBack = 'true';
        }
        global.setCookie("isBackButtonClicked", isBack);
    },
    isDeviceOperaMini: function() {
        if (document.getElementById("isOperaMini"))
            return $('#isOperaMini').val() === "true";
        return false;
    },
    inplayMiddleNav: function() {
        $(".mobileMiddleNav").css("background-color", "#acc540");
        $(".mobileMiddleNavItem").css("color", "#262626");
        $(".mobileMiddleNavItem a").css("color", "#262626");
    },
    actionBetslip: function(outcomeId, eventId, isRemove, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, isInstantBet, outcomesbv) {
        if (outcomeId !== '' && outcomeId !== "EMPTY") {
            homePage.showOverlay();
            var successCallBack = function(data) {
                $("#potentialWager").val(parseFloat($("#DefaultBetAmount").val()).toFixed(2)).focusout();
                if (data.error !== null && data.error !== undefined) {
                    homePage.closeOverlay();
                    var container = $('#selectionError');
                    container.html(data.error);
                    $('.modal-message').html(data.error);
                    $('#modal-container-event-started').modal();
                    if (data.status === 'started') {
                        $('.error-message').hide();
                    }
                    return;
                } else {
                    if (window.innerWidth >= 1024) {
                        betslipNS.AddBetItemClientSide(data);
                    }
                }
                var selectedCount = data.Outcomes.length;
                homePage.toggleBetTypeLabelText(selectedCount, data.IsSingleBets, homePage.getHasFreeBets(), homePage.getIsInstantBets(), $("#MaximumPayout").val());
                if ($('#mobileBetslipCount').length > 0) {
                    $("#mobileBetslipCount").text(selectedCount);
                } else if ($('#betslipCountBadge').length > 0) {
                    $(".betslipCountBadgeCount").text(selectedCount);
                }
                homePage.closeOverlay();
            }
            var potentialWager = $("#potentialWager").val();
            if (isRemove) {
                if (outcomeId) {
                    pat.post("/Bet/RemoveOutcomeJSON", {
                        outcomeId: outcomeId,
                        potentialWager: potentialWager
                    }).done(function(data) {
                        successCallBack(data);
                    });
                }
            } else {
                var outcomeDetail = outcomeTitle + " (" + outcomePriceDecimal + ")";
                pat.post("/Bet/SelectOutcomeJSON", {
                    outcomeId: outcomeId,
                    eventId: eventId,
                    marketId: marketId,
                    eventTitle: eventTitle,
                    sportTitle: sportTitle,
                    startDateTime: startDateTime,
                    outcomeTitle: outcomeTitle,
                    outcomeDetail: outcomeDetail,
                    marketTitle: marketTitle,
                    outcomeIdAndPriceDecimal: outcomeIdAndPriceDecimal,
                    priceDecimal: outcomePriceDecimal,
                    FeedDataTypeId: FeedDataTypeId,
                    specialBetValue: outcomesbv,
                    select: true
                }).done(function(data) {
                    successCallBack(data);
                });
            }
        }
    },
    showOutrightLeagues: function(regionId) {
        pat.get("/Bet/ShortTermOutrightsLeagues", {
            regionId: regionId
        }).done(function(data) {
            $('#short_term_outrights').html(data);
            homePage.closeOverlay();
        });
    },
    addOrAppendEventToLeagueGroup: function() {
        if (displayEventsByRegionAndLeagueGrouping) {
            var duplicateGroupsToRemove = [];
            var getGroups = document.querySelectorAll('.league-group');
            if (getGroups.length > 0) {
                for (var i = 0; i < getGroups.length; i++) {
                    if (document.querySelectorAll(`.league-group[group-id='${getGroups[i].getAttribute('group-id')}']`).length > 1) {
                        var duplicateGroups = document.querySelectorAll(`.league-group[group-id='${getGroups[i].getAttribute('group-id')}']`);
                        for (var j = 0; j < duplicateGroups[1].children[1].children.length; j++) {
                            if (!duplicateGroups[1].id.includes("_duplicate")) {
                                var cloneNode = duplicateGroups[1].children[1].children[j].cloneNode(true);
                                duplicateGroups[0].children[1].appendChild(cloneNode);
                            }
                        }
                        if (!duplicateGroups[1].id.includes('_duplicate')) {
                            duplicateGroups[1].id = duplicateGroups[1].id + "_duplicate";
                            duplicateGroupsToRemove.push(duplicateGroups[1].id);
                        }
                    }
                }
                if (duplicateGroupsToRemove.length > 0) {
                    for (var i = 0; i < duplicateGroupsToRemove.length; i++) {
                        if (document.getElementById(duplicateGroupsToRemove[i]) != null && document.getElementById(duplicateGroupsToRemove[i]) != undefined) {
                            document.getElementById(duplicateGroupsToRemove[i]).remove();
                        }
                    }
                }
            }
        }
    },
    toggleLeagueGroup: function(header) {
        $(header.parentNode.parentNode.children[1]).toggle();
    },
    toggleExpandArrow: function(header) {
        var div = header.querySelector('.eventsByLeagueArrows');
        if (div.innerHTML.includes("expand_more")) {
            div.innerHTML = "expand_less";
        } else {
            div.innerHTML = "expand_more";
        }
    },
    renderMoreBets: function(_eventId, _feedDataType, fullUrl) {
        if (loadEventMultiMarketViaAjax) {
            this.getAjaxEventMultiMarket(_eventId, _feedDataType);
            window.history.pushState(null, null, '/more-bets');
            window.history.replaceState(null, null, fullUrl);
        } else {
            window.location = fullUrl;
        }
    },
    getAjaxEventMultiMarket: function(eventId, feedDataTypeId) {
        homePage.showOverlay();
        pat.get("/Ajax/GetEventMultiMarket", {
            'eventId': eventId,
            'FeedDataTypeId': feedDataTypeId,
            brandId: BrandId,
            isOperaMini: isOperaMini,
            language: currentLanguage
        }).done(function(data) {
            homePage.closeOverlay();
            if (data === "LiveSport") {
                window.location = '/Event/LiveSport';
                return;
            } else if (data === "Home") {
                history.back();
                return;
            }
            $('#eventAndLeagueModal').modal('hide');
            $("#main").html(data);
            setTimeout(scrollTo(0, 0), 400);
            $('.panel-collapse.collapse').show();
            marketGrouping.resetGroups();
        });
    },
    handleBackButton: function() {
        localStorage.setItem('fromBack', 'yes');
        history.back();
    }
};;
var events = {
    setActiveSport: function(sportId) {
        $('#sporttype ul li').removeClass('active');
        $("#Sport_" + sportId).addClass('active');
    },
    filterSportsSearch: function(SportConfigId, FeedDataTypeId, e, isOperaMini) {
        e.preventDefault();
        homePage.showOverlay();
        pat.post("/Home/GetEventsBySportIdSearch", {
            sportConfigId: SportConfigId
        }).done(function(result) {
            if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                location.reload();
            } else {
                eventDisplay.expandCollapseMenu();
                filters.bindLeagues();
                event.setActiveSport(SportConfigId);
                homePage.closeOverlay();
            }
        }).fail(function() {
            homePage.closeOverlay();
            if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                location.reload();
            }
        });
    },
    filterLeaguesByLeagueId: function(leagueId, isMultiMarket, overrideFeedDataTypeId) {
        try {
            homePage.showOverlay();
            var selectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
            var listElement = $('*[data-filtermarket-list-markettypecategory*="' + selectedFeedDataTypeId + '"]');
            var selectedMarketId = listElement.find('li.isActive').attr('id');
            if (selectedFeedDataTypeId === null || selectedFeedDataTypeId.length <= 0) {
                selectedFeedDataTypeId = '00000000-0000-0000-da7a-000000580001';
            }
            var filterData = {
                couponTypeId: selectedMarketId,
                FeedDataTypeId: selectedFeedDataTypeId
            };
            filterData.leagueId = leagueId;
            if (overrideFeedDataTypeId !== null) {
                filterData.FeedDataTypeId = overrideFeedDataTypeId;
            }
            pat.post("/Event/FilterEventsByLeagueId", filterData).done(function(data) {
                var element = $('*[data-matchbetting-events-markettypecategory*="' + selectedFeedDataTypeId + '"]');
                if (!isMultiMarket) {
                    element.html('');
                    element.html(data);
                } else {
                    if (filterData.FeedDataTypeId === '00000000-0000-0000-da7a-000000580003') {
                        window.location.href = "/Event/LiveSport";
                    } else {
                        window.location.href = "/";
                    }
                }
                homePage.closeOverlay();
            });
        } catch (err) {
            console.log(err.message);
        }
    },
    changeSportAndfilterLeaguesByLeagueId: function(sportConfigId, leagueId, isMultiMarket, overrideFeedDataTypeId) {
        try {
            homePage.showOverlay();
            var selectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
            var listElement = $('*[data-filtermarket-list-markettypecategory*="' + selectedFeedDataTypeId + '"]');
            var selectedMarketId = listElement.find('li.isActive').attr('id');
            if (typeof(selectedFeedDataTypeId) === 'undefined' || selectedFeedDataTypeId === null || selectedFeedDataTypeId.length <= 0) {
                selectedFeedDataTypeId = '00000000-0000-0000-da7a-000000580001';
            }
            var filterData = {
                CouponTypeId: selectedMarketId,
                FeedDataTypeId: selectedFeedDataTypeId,
                sportConfigId: sportConfigId
            };
            filterData.leagueId = leagueId;
            if (overrideFeedDataTypeId !== null) {
                filterData.FeedDataTypeId = overrideFeedDataTypeId;
            }
            pat.post("/Event/FilterEventsForSportByLeagueId", filterData).done(function(data) {
                var element = $('*[data-matchbetting-events-markettypecategory*="' + selectedFeedDataTypeId + '"]');
                if (!isMultiMarket) {
                    element.html('');
                    element.html(data);
                } else {
                    if (filterData.FeedDataTypeId === '00000000-0000-0000-da7a-000000580003') {
                        window.location.href = "/Event/LiveSport";
                    } else {
                        window.location.href = "/";
                    }
                }
                homePage.closeOverlay();
            });
        } catch (err) {
            console.log(err.message);
        } finally {
            homePage.closeOverlay();
        }
    },
    showMobileFiltersOnly: function() {
        if (!$('#mobileFilter').is(":visible")) {
            $("#mobileFilter").fadeIn('slow');
        }
    },
    hideMobileFiltersonly: function() {
        if ($('#mobileFilter').is(":visible")) {
            $("#mobileFilter").fadeOut('slow');
        }
    },
    showHideTopGames: function(sportConfigId) {
        pat.post("/Event/GetTopEventsSports").done(function(data) {
            var parsed = JSON.parse(data.replace(/&quot;/g, '"'));
            var arr = [];
            for (var x in data) {
                arr.push(parsed[x]);
            }
            if (arr.indexOf(sportConfigId) === -1) {
                $('#topGames').hide();
            } else {
                $('#topGames').show();
            }
        });
    },
    getTopEvents: function(sportConfigId) {
        if (sportConfigId === undefined) {
            pat.post("/Event/GetTopEvents").done(function(data) {
                $("#topGamesPlaceholder").html('');
                $("#topGamesPlaceholder").html(data);
                $('#mobileFilter').children('#filters').hide();
                $('#mobileFilter').children('#filters2').hide();
                $('.btn-countriesAndMarkets').hide();
                $('.mobileSearch').hide();
                $('#mobileFilter').hide();
                homePage.closeOverlay();
            });
        } else {
            pat.post("/Event/GetTopEventsBySportConfigId", {
                sportConfigId: sportConfigId
            }).done(function(data) {
                $("#topGamesPlaceholder").html('');
                $("#topGamesPlaceholder").html(data);
                $('#mobileFilter').children('#filters').hide();
                $('#mobileFilter').children('#filters2').hide();
                $('.btn-countriesAndMarkets').hide();
                $('.mobileSearch').hide();
                $('#mobileFilter').hide();
                homePage.closeOverlay();
            });
        }
    },
    onTopEventsNextClick: function() {
        var pageNumPlaceHolder = $('*[data-events-page-number-markettypecategory]*');
        var pageNum = parseInt((isNaN(pageNumPlaceHolder.val()))) ? 0 : parseInt(pageNumPlaceHolder.val());
        pageNum += 1;
        var selectectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
        pat.post("/Event/GetTopEventsSet", {
            pageNumber: pageNum
        }).done(function(data) {
            $("#events-btn-next").before(data);
            pageNumPlaceHolder.val(pageNum);
            if ($(data).find('*[data-event-display-has-more-markettypecategory*="' + selectectedFeedDataTypeId + '"]').length === 0) {
                $('*[data-events-btn-next-markettypecategory*="' + selectectedFeedDataTypeId + '"]').hide();
            }
            homePage.closeOverlay();
        });
    },
    getOutrightsByLeagueId: function(leagueId) {
        homePage.showOverlay();
        pat.get("/Bet/Outrights", {
            leagueId: leagueId
        }).done(function(data) {
            $('#Tournaments_' + leagueId).html(data);
            $(".TO-" + leagueId).addClass("active");
            $(".H-" + leagueId + ",.LO-" + leagueId).removeClass("active");
            homePage.closeOverlay();
            SetOutcomeButtons();
        });
    },
    getLiveOutrightsByLeagueId: function(leagueId) {
        homePage.showOverlay();
        pat.get("/Bet/LiveOutrights", {
            leagueId: leagueId
        }).done(function(data) {
            $('#Tournaments_' + leagueId).html(data);
            $(".LO-" + leagueId).addClass("active");
            $(".H-" + leagueId + ",.TO-" + leagueId).removeClass("active");
            homePage.closeOverlay();
            SetOutcomeButtons();
        });
    },
    getHead2Heads: function(leagueId) {
        homePage.showOverlay();
        pat.get("/Bet/Head2Heads", {
            leagueId: leagueId
        }).done(function(data) {
            $('#Tournaments_' + leagueId).html(data);
            $(".H-" + leagueId).addClass("active");
            $(".TO-" + leagueId + ",.LO-" + leagueId).removeClass("active");
            homePage.closeOverlay();
            SetOutcomeButtons();
        });
    },
    toggleAccordionArrow: function(id) {
        var element = $('.' + id);
        if (element.hasClass('fa-angle-down')) {
            element.removeClass('fa-angle-down');
            element.addClass('fa-angle-up');
        } else {
            element.removeClass('fa-angle-up');
            element.addClass('fa-angle-down');
        }
    },
    expandDefault: function(id) {
        var elem = document.getElementById("TO-" + id) || document.getElementById("H-" + id) || document.getElementById("LO-" + id);
        if (elem === null)
            return;
        if (elem.parentNode.parentNode.getAttribute("aria-expanded") === "true")
            return;
        elem.click();
    },
    getMultiMarketContainerByCouponTypeId: function(couponTypeId) {
        var marketDiv = document.querySelectorAll('[data-markettype="' + couponTypeId + '"]')[0];
        if (marketDiv !== null) {
            var marketContainer = {
                marketId: marketDiv.getAttribute('data-market'),
                FeedDataTypeId: marketDiv.getAttribute('data-markettypecategory'),
                marketTitle: marketDiv.getAttribute('data-marketTitle')
            };
            return marketContainer;
        }
        return null;
    },
    getMultiMarketContainerByClosestDataTag: function(element) {
        var marketDiv = $(element).closest('[data-markettype]')[0];
        if (marketDiv !== null) {
            var marketContainer = {
                marketId: marketDiv.getAttribute('data-market'),
                FeedDataTypeId: marketDiv.getAttribute('data-markettypecategory'),
                marketTitle: marketDiv.getAttribute('data-marketTitle')
            };
            return marketContainer;
        }
        return null;
    },
    outcomeButtonMultiMarketClick: function(outcomeId, eventId, actionSelection, couponTypeID, outcomeTitle, marketTitle, outcomePriceDecimal, FeedDataTypeId) {
        var event = document.getElementById(eventId);
        var eventTitle = event.getAttribute('data-eventtitle');
        var sportTitle = event.getAttribute('data-sporttitle');
        var startDateTime = event.getAttribute('data-eventdate');
        var outcomesbv = document.getElementById(outcomeId).getAttribute('data-lip-sbv');
        var marketId;
        var multiMarketContainer = events.getMultiMarketContainerByCouponTypeId(couponTypeID);
        if (multiMarketContainer !== null) {
            marketId = multiMarketContainer.marketId;
            FeedDataTypeId = multiMarketContainer.FeedDataTypeId;
        }
        if (sportTitle === "" || sportTitle === null) {
            sportTitle = "Soccer"
        }
        var outcomeIdAndPriceDecimal = outcomeId + "|" + outcomePriceDecimal;
        var outcomesContainer = document.getElementById("MultiMarket");
        eventDisplay.AddToSessionBetslip(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, actionSelection, outcomesContainer, couponTypeID, homePage.getIsInstantBets(), outcomesbv)
        homePage.applyLiveInPlayColourScheme();
    },
    outcomeButtonOutrightsClick: function(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId) {
        var eventRow = document.getElementById(eventId);
        eventDisplay.AddToSessionBetslip(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, outcomePriceDecimal, FeedDataTypeId, 'eventDisplay.actionBetslip', eventRow, '', homePage.getIsInstantBets(), '')
    },
    onOutcomeDropDownSelect: function(sel, eventId, actionSelection, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, outcomeDetail, marketTitle, outcomeIdAndPriceDecimal, priceDecimal, FeedDataTypeId, isInstantBet) {
        var select = $(sel)
        var outcomeId = select.val();
        priceDecimal = document.getElementById(outcomeId).getAttribute('data-lip-pricedecimal');
        outcomeTitle = document.getElementById(outcomeId).getAttribute('data-outcomeTitle');
        var outcomesbv = document.getElementById(outcomeId).getAttribute('data-lip-sbv');
        var event = document.getElementById(eventId);
        var setInPlay = FeedDataTypeId === constId.feedDataType_LIP;
        var allSelections = event.querySelectorAll(".isSelected");
        if (setInPlay === true) {
            allSelections = event.querySelectorAll(".isSelectedInPlay");
        }
        FeedDataTypeId = event.getAttribute('data-markettypecategory');
        marketId = event.getAttribute('data-market');
        eventTitle = event.getAttribute('data-eventtitle');
        sportTitle = event.getAttribute('data-sporttitle');
        startDateTime = event.getAttribute('data-eventdate');
        marketTitle = event.getAttribute('data-markettitle');
        outcomeIdAndPriceDecimal = outcomeId + "|" + priceDecimal;
        for (var i = 0; i < allSelections.length; i++) {
            var e = allSelections[i];
            if (e.id !== outcomeId) {
                if (setInPlay === true) {
                    e.className = e.className.replace(/(?:^|\s)isSelectedInPlay(?!\S)/g, '');
                } else {
                    e.className = e.className.replace(/(?:^|\s)isSelected(?!\S)/g, '');
                }
                break;
            }
        }
        if (select.val() !== "EMPTY") {
            select.addClass("isSelected");
            actionSelection(outcomeId, eventId, false, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, priceDecimal, FeedDataTypeId, isInstantBet, outcomesbv);
            if (setInPlay === true) {
                select.addClass("isSelectedInPlay");
            } else {
                select.addClass("isSelected");
            }
            $('#selectedOutcomeValue').val(outcomeId);
        } else {
            var optionString = '#' + $('#selectedOutcomeValue').val();
            actionSelection($('#selectedOutcomeValue').val(), eventId, true);
            if (setInPlay === true) {
                select.removeClass("isSelectedInPlay");
                if ($('#selectedOutcomeValue').val() !== '') {
                    $(optionString).removeClass("isSelectedInPlay");
                }
            } else {
                select.removeClass("isSelected");
                if ($('#selectedOutcomeValue').val() !== '') {
                    $(optionString).removeClass("isSelected");
                }
            }
            return;
        }
    },
    onOutcomeDropDownSelectMultiMarket: function(sel, eventId, actionSelection, marketId, outcomeDetail, priceDecimal, setInPlay, FeedDataTypeId) {
        var select = $(sel);
        if (select.val() === "EMPTY") {
            eventDisplay.actionBetslip($('#selectedOutcomeValue').val(), eventId, true);
            return;
        }
        var outcomeId = select.val();
        priceDecimal = document.getElementById(outcomeId).getAttribute('data-lip-pricedecimal');
        var outcomeTitle = document.getElementById(outcomeId).getAttribute('data-outcomeTitle');
        var event = document.getElementById(eventId)
        var eventTitle = event.getAttribute('data-eventtitle');
        var sportTitle = event.getAttribute('data-sporttitle');
        var startDateTime = event.getAttribute('data-eventdate');
        var outcomesbv = document.getElementById(outcomeId).getAttribute('data-lip-sbv');
        var outcomeIdAndPriceDecimal = outcomeId + "|" + priceDecimal;
        var marketInfo = event.getMultiMarketContainerByClosestDataTag(select);
        marketId = marketInfo.marketId;
        FeedDataTypeId = marketInfo.FeedDataTypeId;
        var marketTitle = marketInfo.marketTitle;
        select.val(outcomeId);
        var outcomesContainer = document.getElementById(marketId);
        eventDisplay.AddToSessionBetslip(outcomeId, eventId, marketId, eventTitle, sportTitle, startDateTime, outcomeTitle, marketTitle, outcomeIdAndPriceDecimal, priceDecimal, FeedDataTypeId, 'eventDisplay.actionBetslip', outcomesContainer, '', homePage.getIsInstantBets(), outcomesbv);
        event.UpdateMultiMarketOutcomeControl(outcomesContainer, setInPlay, true, outcomeId);
    },
    UpdateMultiMarketOutcomeControl: function(outcomesContainerElement, isLiveInPlay, isDropdown, selectedOutcomeId) {
        var activeClass = "isSelected";
        if (isLiveInPlay) {
            activeClass = "isSelectedInPlay";
        }
        var allSelections = document.querySelectorAll('.' + activeClass);
        var isSingleBets = homePage.getIsSingleBets();
        var sel = $("#" + outcomesContainerElement.id).find("select")[0];
        if (!isSingleBets) {
            for (var i = 0; i < allSelections.length; i++) {
                $(allSelections[i]).removeClass(activeClass);
                if (isDropdown && allSelections[i].tagName === "OPTION") {
                    $(allSelections[i]).addClass("inner");
                }
                if (allSelections[i].tagName === "SELECT") {
                    $(allSelections[i]).val("EMPTY");
                }
            }
            if (isDropdown) {
                sel.options[0].className = "inner";
                $('#' + selectedOutcomeId).addClass(activeClass);
                $(sel).addClass(activeClass);
                $(sel).val(selectedOutcomeId);
            }
        } else {
            if (($('#' + selectedOutcomeId).parent().find("option." + activeClass).length > 0) && !$('#' + selectedOutcomeId).parent().hasClass(activeClass)) {
                $('#' + selectedOutcomeId).parent().addClass(activeClass);
                $('#' + selectedOutcomeId).parent().val($('#' + selectedOutcomeId).parent().find("option." + activeClass)[0].id);
            } else if ($('#' + selectedOutcomeId).parent().find("option." + activeClass).length <= 0) {
                $('#' + selectedOutcomeId).parent().removeClass(activeClass);
                $('#' + selectedOutcomeId).parent().val("EMPTY");
            } else if (!$('#' + selectedOutcomeId).hasClass(activeClass)) {
                $('#' + selectedOutcomeId).parent().val($('#' + selectedOutcomeId).parent().find("option." + activeClass)[0].id);
            }
            if (isDropdown) {
                sel = $('#' + outcomesContainerElement.id + ' > select').first();
                sel.options[0].className = "inner";
                $('#' + selectedOutcomeId).addClass(activeClass);
                $(sel).addClass(activeClass);
                $(sel).val(selectedOutcomeId);
            }
        }
    },
    MultiMarketPartial: function(eventId, FeedDataTypeId, marketTypeId, action) {
        homePage.showOverlay();
        jQuery.ajax({
            type: "POST",
            url: "/Event/GetEventMultiMarket",
            data: {
                eventId: eventId,
                FeedDataTypeId: FeedDataTypeId,
                marketTypeId: marketTypeId
            },
            async: true,
            success: function(data) {
                homePage.closeOverlay();
                action(data);
            },
            error: function(data) {
                homePage.closeOverlay();
            }
        });
    },
    openAccordions: function() {
        $('#expand-Acc').css('display', 'block').attr('onclick', 'events.closeAccordions()').attr('value', 'Collapse').text('Collapse');
        $(".accordionArrows").removeClass("fa-angle-down").addClass("fa-angle-up");
        $(".acc-header123").addClass("in");
    },
    closeAccordions: function() {
        $('#expand-Acc').css('display', 'block').attr('onclick', 'events.openAccordions()').attr('value', 'Expand').text('Expand');;
        $(".accordionArrows").removeClass("fa-angle-up").addClass("fa-angle-down");
        $(".acc-header123").removeClass("in").css("height", "auto");
    },
    MultiMarketDropDown: function(caller, eventId, FeedDataTypeId, marketTypeId) {
        var callback = function(html) {
            var parent = $("#dll-" + eventId);
            parent.html(html);
            parent.addClass("loaded");
            showItem(parent);
        };

        function showItem(itm) {
            itm.fadeIn('fast');
            itm.removeClass("hide");
            itm.addClass("show");
            $(caller).text($(caller).text().replace("+", "-"));
        }

        function hideItem(itm) {
            itm.fadeOut('fast');
            itm.removeClass("show");
            itm.addClass("hide");
            $(caller).text($(caller).text().replace("-", "+"));
        }
        var parent = $("#dll-" + eventId);
        if (parent.hasClass("loaded")) {
            if (parent.hasClass("show")) {
                hideItem(parent);
            } else {
                showItem(parent);
            }
        } else {
            event.MultiMarketPartial(eventId, FeedDataTypeId, marketTypeId, callback);
        }
    },
    initAccordionEvent: function() {
        var stop = false;
        $("#accordion > h4").click(function(event) {
            if (stop) {
                event.stopImmediatePropagation();
                event.preventDefault();
                stop = false;
            }
        });
    },
    showTip: function() {
        var isVisible = $('.tooltip').is(':visible');
        if (isVisible) {
            $('.tooltip').hide();
        } else {
            $('.tooltip').show();
        }
    },
    disableToggle: function(id) {
        var first = $('#a-' + id).attr('href');
        var second = $('#a-' + id).attr('onclick');
        $('#a-' + id).removeAttr('href');
        $('#a-' + id).removeAttr('onclick');
        setTimeout(function() {
            $('#a-' + id).attr('href', first);
            $('#a-' + id).attr('onclick', second);
        }, 100);
    },
    addAllRecommendationToBetslip: function() {
        homePage.showOverlay();
        pat.post("/BetYourWay/JsonRet").done(function(result) {
            var eves = JSON.parse(result).BetRecommendations;
            var betslip = JSON.parse(GetBetslip());
            var outcomes = _.pluck(betslip, 'OutcomeId');
            for (k = 0; k < eves.length; k++) {
                if (_.contains(outcomes, eves[k].OutcomeId)) {
                    continue;
                } else {
                    SendToBetslip(eves[k].OutcomeId, eves[k].OutcomeTitle, eves[k].PriceDecimal, eves[k].SportTitle, eves[k].MarketTitle, eves[k].SpecialBetValue, eves[k].EventTitle, new Date(eves[k].StartDateTimeSAST.match(/\d+/)[0] * 1), eves[k].EventId, false, eves[k].FeedDataTypeId, eves[k].AllowEarlyCashout, eves[k].AllowStretch, eves[k].LeagueFriendlyName);
                }
            }
            SetOutcomeButtons();
            homePage.closeOverlay();
        }).fail(function() {
            homePage.closeOverlay();
        });
    },
    checkLoad: function() {
        if ((typeof($("#matchbetting").attr("class")) != "undefined" && $("#matchbetting").attr("class").indexOf('active') !== -1) || (typeof($("#inplay").attr("class")) != "undefined" && $("#inplay").attr("class").indexOf('active') !== -1)) {
            var shouldShowLoad = true;
            if (typeof(sportFilters) !== "undefined" && sportFilters != null) {
                if ($('li.league-item.isChecked').length > 0) {
                    shouldShowLoad = false;
                }
                if (sportFilters.couponTypeId !== "") {
                    shouldShowLoad = false;
                }
                if (sportFilters.OddsRange.From != 1 || sportFilters.OddsRange.To != 9999) {
                    shouldShowLoad = false;
                }
                if (sportFilters.DateRange.PredeterminedTime !== "None") {
                    shouldShowLoad = false;
                }
                if (sportFilters.DateRange.From != null || sportFilters.DateRange.To != null) {
                    shouldShowLoad = false;
                }
                if ($('#boltSpan > .filterApplied').length > 0) {
                    shouldShowLoad = false;
                }
            } else {
                if ($('li.league-item.isChecked').length > 0) {
                    shouldShowLoad = false;
                }
                if ($(".fltrText") != null && $(".fltrText").text() !== "") {
                    shouldShowLoad = false;
                }
            }
            shouldShowLoad = events.shouldShowMoreEvents(shouldShowLoad);
            if (shouldShowLoad) {
                $("#loadMore").show();
                var feedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
                var selectedFeedDataTypeId = feedDataTypeId === constId.emptyGuid ? constId.feedDataType_Prematch : feedDataTypeId;
                var pageNumPlaceHolder = $('*[data-events-page-number-markettypecategory*="' + selectedFeedDataTypeId + '"]');
                pageNumPlaceHolder.val(1);
                var countVis = 0
                $('.row .eventRow').each(function() {
                    if ($(this).is(":visible")) {
                        countVis++;
                    }
                });
                if (countVis >= 100) {
                    pageNumPlaceHolder.val(5);
                }
                $("#loadMoreButton").off();
                $("#loadMoreButton").click(function() {
                    $("#loadMore").hide();
                    $("#loader").show();
                    eventDisplay.onEventsClick(true);
                });
            } else {
                $("#loadMore").hide();
            }
        } else {
            $("#loadMore").hide();
        }
    },
    shouldShowMoreEvents: function(shouldShowLoad) {
        if ($("#event-display-has-more") == null || typeof($("#event-display-has-more")) == "undefined" || typeof($("#event-display-has-more").attr("data-event-display-has-more-markettypecategory")) == "undefined" || $("#matchbetting").find("#event-display-has-more").attr("data-event-display-has-more-markettypecategory") === "00000000-0000-0000-0000-000000000000") {
            shouldShowLoad = false;
        }
        var hasMore = $("#event-display-has-more-events").attr("data-event-has-more");
        var upcomingHasMore = $("#event-display-has-more").length > 0 && $("#event-display-has-more").attr("data-event-has-more") === "True";
        if ((typeof(hasMore) != 'undefined' && hasMore == 'False') && (typeof(upcomingHasMore) === 'undefined' || !upcomingHasMore)) {
            shouldShowLoad = false;
        }
        if ($('li.league-item.isChecked').length < 1 && hasMore === "True") {
            shouldShowLoad = true;
        }
        return shouldShowLoad;
    },
    addAllTrendingBetsToBetslip: function() {
        homePage.showOverlay();
        pat.post("/TrendingBets/JsonRet").done(function(result) {
            var eves = JSON.parse(result).TrendingBets;
            var betslip = JSON.parse(GetBetslip());
            var outcomes = _.pluck(betslip, 'OutcomeId');
            for (k = 0; k < eves.length; k++) {
                if (_.contains(outcomes, eves[k].OutcomeId)) {
                    continue;
                } else {
                    SendToBetslip(eves[k].OutcomeId, eves[k].OutcomeTitle, eves[k].PriceDecimal, eves[k].SportTitle, eves[k].MarketTitle, eves[k].SpecialBetValue, eves[k].EventTitle, new Date(eves[k].StartDateTimeSAST.match(/\d+/)[0] * 1), eves[k].EventId, false, eves[k].FeedDataTypeId, eves[k].AllowEarlyCashout, eves[k].AllowStretch, eves[k].LeagueFriendlyName, eves[k].IsBoosted);
                }
            }
            SetOutcomeButtons();
            homePage.closeOverlay();
        }).fail(function() {
            homePage.closeOverlay();
        });
    },
    showBetBoosterWidget: function(homeTeam, awayTeam, startDate, sportTitle, originHome, originAway, originLeague, rootElement, isMoreBets, feedDataTypeId) {
        if (isMoreBets) {
            ToggleHighlightMoreBetsBetBoosterIcon();
        }
        if (activeBetBoosterWidget) {
            if (isMoreBets && global.getCookie("Stats") != "Yes-Please") {
                $('.lmt-container-new, .lmt-container-old').addClass('hidden');
            }
            if (rootElement == currentActiveBetBoosterEvent) {
                document.getElementsByTagName('betboostercontainer')[0].remove();
                currentActiveBetBoosterEvent = undefined;
                isActiveBetBoosterWidgetInitialized = false;
                return;
            } else {
                activeBetBoosterWidget.remove();
                currentActiveBetBoosterEvent = undefined;
                isActiveBetBoosterWidgetInitialized = false;
            }
        }
        var betBoosterParent = document.createElement('BetBoosterContainer');
        var loader = document.createElement('div');
        loader.setAttribute('class', 'betboosterloader row justify-content-center align-items-center');
        loader.setAttribute('id', 'betbooster-loader');
        isMoreBets ? document.getElementById('sr-widget').parentElement.after(betBoosterParent) : document.getElementById(rootElement).after(betBoosterParent);
        betBoosterParent.appendChild(loader);
        activeBetBoosterWidget = betBoosterParent;
        if (feedDataTypeId == undefined) {
            feedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
            if (feedDataTypeId == undefined || feedDataTypeId === null || feedDataTypeId.length <= 0) {
                feedDataTypeId = '00000000-0000-0000-da7a-000000580001';
            }
        }
        $.when(GetBetBoosterMarketInfo(rootElement, sportTitle, betBoosterParent.firstChild, homeTeam, awayTeam, feedDataTypeId)).then(function(x) {
            betBoosterParent.innerHTML = `<betbooster-widget id='BetBoosterWidget-Betway' style='display: none;'betmarkets='${x}' layout='1' className='col-xs-12' home='${homeTeam}' away='${awayTeam}' date='${startDate}'
                                               sport='${sportTitle}' apiKey='${betboosterAPIKey}' lang='en' originhome='${originHome}' originaway='${originAway}' originleauge='${originLeague} ' />`
            document.getElementById('BetBoosterWidget-Betway').style.display = '';
        }).catch((function(error) {
            console.error(error);
            showBetBoosterWidget();
        }));
        currentActiveBetBoosterEvent = rootElement;
        gax.LightbulbClickEvent(sportTitle, originLeague);
    },
    SetBetBoosterDataForMoreBets: function(homeTeam, awayTeam, startDate, sportTitle, originHome, originAway, originLeague, rootElement) {
        localStorage.setItem('BetBooster-MoreBets', JSON.stringify({
            homeTeam,
            awayTeam,
            startDate,
            sportTitle,
            originHome,
            originAway,
            originLeague,
            rootElement
        }));
        localStorage.setItem('lastEventsScrollPosition', $(document).scrollTop());
    },
    ShowBetboosterWidgetMoreBets: function(eventId, feedDataTypeId) {
        var objData;
        try {
            objData = JSON.parse(localStorage.getItem('BetBooster-MoreBets'));
            if (objData == undefined || objData.rootElement != eventId && activeBetBoosterWidget == null) {
                isRetrievingEvent = true;
                pat.get("/Event/GetEventById", {
                    eventId: eventId
                }, {
                    dataType: "json"
                }).done(function(jsonData) {
                    if (jsonData) {
                        console.error(jsonData);
                        if (jsonData.Success) {
                            console.error(jsonData.result);
                            objData = {
                                homeTeam: jsonData.result.HomeTeam == null ? jsonData.result.HomeTeamFriendlyName : jsonData.result.HomeTeam,
                                awayTeam: jsonData.result.AwayTeam == null ? jsonData.result.AwayTeamFriendlyName : jsonData.result.AwayTeam,
                                startDate: new Date(jsonData.result.StartDateTime),
                                sportTitle: jsonData.result.SportTitle,
                                originHome: jsonData.result.HomeTeam == null ? jsonData.result.HomeTeamFriendlyName : jsonData.result.HomeTeam,
                                originAway: jsonData.result.AwayTeam == null ? jsonData.result.AwayTeamFriendlyName : jsonData.result.AwayTeam,
                                originLeague: jsonData.result.League,
                                rootElement: eventId
                            };
                        }
                        if (objData != undefined) {
                            objData.startDate = `${objData.startDate.toLocaleDateString("en-UK")} ${objData.startDate.toLocaleTimeString("en-UK",{hour:'2-digit',minute:'2-digit'})}`;
                            isRetrievingEvent = false;
                            events.SetBetBoosterDataForMoreBets(objData.homeTeam, objData.awayTeam, objData.startDate, objData.sportTitle, objData.originHome, objData.originAway, objData.originLeague, objData.rootElement)
                            events.showBetBoosterWidget(objData.homeTeam, objData.awayTeam, objData.startDate, objData.sportTitle, objData.originHome, objData.originAway, objData.originLeague, objData.rootElement, true, feedDataTypeId);
                        }
                    }
                });
            } else {
                isRetrievingEvent = false;
                events.showBetBoosterWidget(objData.homeTeam, objData.awayTeam, objData.startDate, objData.sportTitle, objData.originHome, objData.originAway, objData.originLeague, objData.rootElement, true, feedDataTypeId);
            }
        } catch (e) {
            isRetrievingEvent = false;
            console.error(e);
        }
    }
};
var selectedBetsOutcomeIds = [];
var mappedMarketIndexByOutcomeId = [];
var mappedMarketOutcomeIdIndex = [];
var marketDataKeyDict = [];
var currentActiveBetBoosterEvent;
var isActiveBetBoosterWidgetInitialized;
var betBoosterWidgetRenderingTips;
var persistentOddsForOutcomes = [];
var isBetBoosterMarketSyncRequired;
var activeBetBoosterWidget = null;
var betBoosterMarketSyncPollFunction = setInterval(BetboosterMarketSyncPoller, betBoosterQueuePollTimer);
var isSerilizationRunning;
var isRetrievingEvent;

function replacer(i, val) {
    if (i === null) {
        return "";
    } else {
        return val;
    }
}

function BetBoosterObj(id, name, marketLines, bets) {
    this.id = id;
    this.name = name;
    this.bets = bets || [];
    this.marketLines = marketLines;
}

function BetInfoObj(name, outcomeId, odds, isSelected, shortTitle, displayOdds, displayOutcomeName) {
    this.name = name;
    this.outcomeId = outcomeId;
    this.odds = odds;
    this.isSelected = isSelected;
    this.shortTitle = shortTitle;
    this.displayOdds = displayOdds;
    this.displayOutcomeName = displayOutcomeName;
}

function ToggleHighlightMoreBetsBetBoosterIcon() {
    var notHighlightedElements = document.getElementsByClassName('mg-betooster-toggle toggle-clicked');
    if (notHighlightedElements.length > 0) {
        notHighlightedElements[0].children[0].classList.remove('icon-clicked')
        notHighlightedElements[0].classList.remove('toggle-clicked')
    } else {
        var highlightedElements = document.getElementsByClassName('mg-betooster-toggle');
        highlightedElements[0].children[0].classList.add('icon-clicked')
        highlightedElements[0].classList.add('toggle-clicked');
    }
}

function GetBetBoosterMarketInfo(eventId, sportTitle, widgetElement, homeTeamName, awayTeamName, feedDataTypeId) {
    return new Promise(function(resolve, reject) {
        try {
            marketDataKeyDict = [];
            mappedMarketIndexByOutcomeId = [];
            mappedMarketOutcomeIdIndex = [];
            persistentOddsForOutcomes = [];
            selectedBetsOutcomeIds = [];
            pat.get("/Event/GetBetBoosterAvailableMarkets", {
                eventId: eventId,
                sportTitle: sportTitle,
                feedId: feedDataTypeId
            }).done(function(data) {
                var betslip = JSON.parse(GetBetslip());
                if (betslip && betslip.length > 0) {
                    betslip.forEach(x => selectedBetsOutcomeIds.push(x.OutcomeId));
                }
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    if (!item.ShortTitle) {
                        item.ShortTitle = item.OutcomeTitle;
                    }
                    var marketKey = null;
                    var outcomeIndex = 1;
                    var displayOutcomeName = item.OutcomeTitle;
                    var displayOdds = (global.getCookie('oddsFormat') === 'fraction') ? oddsFormatter.convertFromDecimalToFraction(item.PriceDecimal) : item.PriceDecimal.toFixed(2);
                    var odds = item.PriceDecimal;
                    if (item.IsHidden || !item.IsBettingAllowed) {
                        displayOutcomeName = 'Suspended';
                        persistentOddsForOutcomes[item.OutcomeId] = odds;
                        odds = 0;
                        displayOdds = '';
                    }
                    var isOutcomeSelected = !(selectedBetsOutcomeIds[item.OutcomeId] == null);
                    var outcomeObj = new BetInfoObj(item.OutcomeTitle, item.OutcomeId, odds, isOutcomeSelected, item.ShortTitle, displayOdds, displayOutcomeName);
                    if (item.MarketLines) {
                        marketKey = item.MarketLines + item.MarketTitle;
                        if (marketDataKeyDict[marketKey] == null) {
                            marketDataKeyDict[marketKey] = new BetBoosterObj(item.MarketId, item.MarketTitle, item.MarketLines, [outcomeObj]);
                        } else {
                            outcomeIndex = marketDataKeyDict[marketKey].bets.push(outcomeObj);
                        }
                    } else {
                        marketKey = item.MarketId;
                        if (marketDataKeyDict[marketKey] == null) {
                            marketDataKeyDict[marketKey] = new BetBoosterObj(item.MarketId, item.MarketTitle, null, [outcomeObj]);
                        } else {
                            outcomeIndex = marketDataKeyDict[marketKey].bets.push(outcomeObj);
                        }
                    }
                    mappedMarketIndexByOutcomeId[item.OutcomeId] = marketKey;
                    mappedMarketOutcomeIdIndex[item.OutcomeId] = outcomeIndex - 1;
                }
                return resolve(JSON.stringify(Object.values(marketDataKeyDict)).replaceAll("'", "&#39;"));
            });
        } catch (e) {
            reject(e);
        }
    })
}

function betBoosterWidgetLoaded(responseCode) {
    console.log('Betbooster widget loaded with code: ' + responseCode);
    if (responseCode == 0) {
        activeBetBoosterWidget.children[0].classList.add('hidden');
        var errorMessageParent = document.createElement('div');
        errorMessageParent.innerHTML = '<div class="alert alert-info" role="alert" style="color: #31708f !important"><i class="fa fa-info-circle fa-2x" aria-hidden="true"></i><span style="display:flex; align-items:center; padding: 0px 10px 0px 10px;">No Tips available at this time, please check again later.</span> </div>';
        activeBetBoosterWidget.appendChild(errorMessageParent);
        betBoosterWidgetRenderingTips = false;
    } else {
        betBoosterWidgetRenderingTips = true;
    }
    isActiveBetBoosterWidgetInitialized = true;
}

function betBoosterWidgetReloaded(responseCode) {
    console.log('Betbooster widget re-loaded with code: ' + responseCode);
    if (responseCode == 0 && isActiveBetBoosterWidgetInitialized && activeBetBoosterWidget.childElementCount == 1) {
        activeBetBoosterWidget.children[0].classList.add('hidden');
        var errorMessageParent = document.createElement('div');
        errorMessageParent.innerHTML = '<div class="alert alert-info" role="alert" style="color: #31708f !important"><i class="fa fa-info-circle fa-2x" aria-hidden="true"></i><span style="display:flex; align-items:center; padding: 0px 10px 0px 10px;">No Tips available at this time, please check again later.</span> </div>';
        activeBetBoosterWidget.appendChild(errorMessageParent);
        betBoosterWidgetRenderingTips = false;
    } else if (responseCode > 0 && isActiveBetBoosterWidgetInitialized && activeBetBoosterWidget.childElementCount == 2) {
        activeBetBoosterWidget.children[0].classList.remove('hidden');
        activeBetBoosterWidget.children[1].remove();
        betBoosterWidgetRenderingTips = true;
    }
}

function outcomeAddedToBetslip_BetBooster(outcomeId) {
    if (document.contains(document.getElementById('BetBoosterWidget-Betway'))) {
        if (selectedBetsOutcomeIds[outcomeId]) {
            var i = selectedBetsOutcomeIds.findIndex(value => outcomeId);
            selectedBetsOutcomeIds.splice(i, 1);
        } else {
            selectedBetsOutcomeIds.push(outcomeId);
        }
        if (activeBetBoosterWidget && mappedMarketIndexByOutcomeId[outcomeId]) {
            var mId = mappedMarketIndexByOutcomeId[outcomeId];
            var oIndex = mappedMarketOutcomeIdIndex[outcomeId];
            marketDataKeyDict[mId].bets[oIndex].isSelected = !marketDataKeyDict[mId].bets[oIndex].isSelected;
            isBetBoosterMarketSyncRequired = true;
        }
    }
}

function outcomeOddsUpdated_BetBooster(outcomeId, newOdds) {
    if (activeBetBoosterWidget && mappedMarketIndexByOutcomeId[outcomeId]) {
        if (!persistentOddsForOutcomes[outcomeId]) {
            var mId = mappedMarketIndexByOutcomeId[outcomeId];
            var oIndex = mappedMarketOutcomeIdIndex[outcomeId];
            marketDataKeyDict[mId].bets[oIndex].odds = Number(newOdds);
            marketDataKeyDict[mId].bets[oIndex].displayOdds = (global.getCookie('oddsFormat') === 'fraction') ? oddsFormatter.convertFromDecimalToFraction(newOdds) : Number(newOdds).toFixed(2);
            isBetBoosterMarketSyncRequired = true;
        } else {
            persistentOddsForOutcomes[outcomeId] = newOdds;
        }
    }
}

function BetboosterMarketSyncPoller() {
    if (isActiveBetBoosterWidgetInitialized && isBetBoosterMarketSyncRequired && betBoosterWidgetRenderingTips && !isSerilizationRunning && document.getElementsByClassName('first').length > 0) {
        var startTime = Date.now();
        isSerilizationRunning = true;
        document.getElementById('BetBoosterWidget-Betway').setAttribute('betmarkets', JSON.stringify(Object.values(marketDataKeyDict), replacer).replaceAll("'", "&#39;"));
        if (Date.now() - startTime > betBoosterQueuePollTimer_MaxSerilizationTime) {
            betBoosterQueuePollTimer += betBoosterQueuePollTimer_IncrementalAdjustment;
            betBoosterQueuePollTimer_MaxSerilizationTime += betBoosterQueuePollTimer_IncrementalAdjustment;
            clearInterval(betBoosterMarketSyncPollFunction);
            betBoosterMarketSyncPollFunction = setInterval(BetboosterMarketSyncPoller, betBoosterQueuePollTimer);
        }
        isSerilizationRunning = false;
        isBetBoosterMarketSyncRequired = false;
    }
}

function ToggleDisableOutcome_betbooster(outcomeId, isActive, isHidden) {
    if (activeBetBoosterWidget && mappedMarketIndexByOutcomeId[outcomeId]) {
        var mId = mappedMarketIndexByOutcomeId[outcomeId];
        var oIndex = mappedMarketOutcomeIdIndex[outcomeId];
        if (isActive && !isHidden) {
            marketDataKeyDict[mId].bets[oIndex].displayOutcomeName = marketDataKeyDict[mId].bets[oIndex].name;
            if (persistentOddsForOutcomes[outcomeId]) {
                marketDataKeyDict[mId].bets[oIndex].displayOdds = (global.getCookie('oddsFormat') === 'fraction') ? oddsFormatter.convertFromDecimalToFraction(persistentOddsForOutcomes[outcomeId]) : Number(persistentOddsForOutcomes[outcomeId]).toFixed(2);
                marketDataKeyDict[mId].bets[oIndex].odds = persistentOddsForOutcomes[outcomeId];
                delete(persistentOddsForOutcomes[outcomeId]);
            }
        } else {
            marketDataKeyDict[mId].bets[oIndex].displayOutcomeName = "Suspended";
            persistentOddsForOutcomes[outcomeId] = marketDataKeyDict[mId].bets[oIndex].odds;
            marketDataKeyDict[mId].bets[oIndex].displayOdds = "";
            marketDataKeyDict[mId].bets[oIndex].odds = 0;
        }
        isBetBoosterMarketSyncRequired = true;
    }
}

function addToBetslip_BetBooster(outcomeId) {
    if (!persistentOddsForOutcomes[outcomeId]) {
        addToBetslip(outcomeId);
    }
}

function outRightFistItemExpand() {
    $($('.sto-container')[0]).find('.panel-collapse').addClass('in').attr('aria-expanded', true);
    $($('.sto-container')[0]).find('a').addClass('fi-opened').attr('aria-expanded', true);
}
$(document).ready(function() {
    events.initAccordionEvent();
    if ($('.fi-opened').length === 0) {
        setTimeout(function() {
            $('[id^=TL-]:visible').first().click();
        }, 100);
        setTimeout(function() {
            outRightFistItemExpand();
        }, 200);
    }
    events.checkLoad();
    homePage.HighlightSubmenuItem();
    if (typeof($("#matchbetting").attr("class")) !== "undefined" && $("#matchbetting").attr("class").indexOf('active') !== -1) {
        events.checkLoad();
    }
    if (typeof($("#inplay").attr("class")) !== "undefined" && $("#inplay").attr("class").indexOf('active') !== -1)
        events.checkLoad();
});;
var freezeScrolling = {
    _freezeMethod: function(event) {
        var closestElementNotOn = $(event.target).closest($(freezeScrolling._elementNotOn));
        if (closestElementNotOn.length > 0) {
            return;
        }
        event.preventDefault();
    },
    _elementNotOn: null,
    enableFreeze: function(elementNotOn, bool) {
        if (!elementNotOn) {
            return;
        }
        $("html, body").off("touchmove", freezeScrolling._freezeMethod)
        if (bool == true) {
            freezeScrolling._elementNotOn = elementNotOn;
            $("html, body").on("touchmove", freezeScrolling._freezeMethod)
            return;
        }
        freezeScrolling._elementNotOn = null;
    }
};
var sideMenu = {
    openMenu: function(partialView, textId) {
        sideMenu.getMenuControls();
        sideMenu.getMenuOptions(partialView, textId);
        sideMenu.getMenuBottomNav();
        if (textId == "MenuLogin" && removeElements)
            global.PostAppMessage('{ "message": "login", "data" : { "value": "showLoginPopUp" } }');
        else
            sideMenu.showMenu();
    },
    openMenuUpdate: function() {
        sideMenu.getInfoContent('_InfoMenu');
        if (window.loginObject.isLoggedIn === constId.emptyGuid) {
            sideMenu.getSignInOptions('_MenuOptions');
            $('#collapseInfo').addClass('in');
            $('#info-panel-toggle').removeClass('collapsed');
        } else {
            sideMenu.getAccountContent('_MyAccount');
        }
        sideMenu.showMenu();
    },
    getMenuControls: function() {
        pat.get("/SideMenu/GetSideMenuControls").done(function(result) {
            $('#sideMenuControls').html(result);
        });
    },
    generateShareLink: function(url, description, targetContainer, renderOption) {
        pat.get("/SideMenu/RenderShareButton?url=" + url + "&description=" + description + "&renderOption=" + renderOption).done(function(result) {
            $(targetContainer).html(result);
        });
    },
    getMenuContent: function(partialView, textId) {
        homePage.showOverlay();
        pat.get("/SideMenu/GetSideMenuContent", {
            renderPartial: partialView
        }).done(function(result) {
            $('#desktopLogin').html(result);
            $(".btnMenuBtn").removeClass("active");
            $(".btnMenu" + textId).addClass("active");
            if (removeElements) {
                global.PostAppMessage('{ "message": "login", "data" : { "value": "showLoginPopUp" } }');
            } else {
                $("#LoginModal").modal();
            }
            homePage.closeOverlay();
        });
    },
    getMenuContentWithSuccessfulRedirect: function(partialView, textId, redirectUrl) {
        homePage.showOverlay();
        pat.get("/SideMenu/GetSideMenuContentWithRedirect", {
            renderPartial: partialView,
            redirectToUrl: redirectUrl
        }).done(function(result) {
            $('#desktopLogin').html(result);
            $(".btnMenuBtn").removeClass("active");
            $(".btnMenu" + textId).addClass("active");
            $("#LoginModal").modal();
            homePage.closeOverlay();
        });
    },
    getMenuOptions: function(partialView, textId) {
        pat.get("/SideMenu/GetSideMenuContent", {
            renderPartial: partialView
        }).done(function(result) {
            $('#sideMenuContent').html(result);
            $(".btnMenuBtn").removeClass("active");
            var buttonToMakeActive = textId === "Info" ? "btnMenuInfo" : "btnMenuMyAccount";
            $("." + buttonToMakeActive).addClass("active");
        });
    },
    getSignInOptions: function(partialView) {
        pat.get("/SideMenu/GetSignInOptions", {
            renderPartial: partialView
        }).done(function(result) {
            $('#login-controls').html(result);
        });
    },
    updateMenuLink: function(linkId, location) {
        $('#' + linkId).attr('onclick', 'location.href="' + location + '"');
    },
    getAccountContent: function(partialView) {
        var loggedIn = window.loginObject.isLoggedIn !== constId.emptyGuid;
        if (loggedIn) {
            $('.account-menu-panel').removeClass('hidden');
        } else {
            $('.account-menu-panel').addClass('hidden');
            $('#collapseInfo').addClass('in');
            $('#info-panel-toggle').removeClass('collapsed');
        }
        var depositModalCheck = document.getElementById('depositingModal');
        var documentUploadCheck = document.getElementById('show-ficastatus-popup') && document.getElementById('bypass-ficastatus-popup') == null;
        var documentUploadWithdrawalCheck = document.getElementById('show-ficastatus-popup');
        if (depositModalCheck) {
            $('#accountOptions').find('#depositfunds').attr('onclick', 'gax.BankingDepositEntryPoint_EventTracking("HamburgerMenu DepositButton");' + ((swiftEndEnabled && !swiftEndVerified && !securityFlagForSwiftendEnabled) ? 'account.showSwiftEndPopup()' : 'depositModal()'))
            $('#accountOptions').find('#depositfunds').removeAttr('href')
            if (accountOptionsPopUpEnabled) {
                $('#accountOptionsSideNavMenu').find('#depositfunds').attr('onclick', 'gax.BankingDepositEntryPoint_EventTracking("HamburgerMenu DepositButton");' + ((swiftEndEnabled && !swiftEndVerified && !securityFlagForSwiftendEnabled) ? 'account.showSwiftEndPopup()' : 'depositModal()'))
                $('#accountOptionsSideNavMenu').find('#depositfunds').removeAttr('href')
            }
        }
        if (isFreePlayWebsite) {
            $('#accountOptions').find('#depositfunds, #withdrawfunds').attr('onclick', 'sideMenu.showFreeplayModal()');
            $('#accountOptions').find('#depositfunds, #withdrawfunds').removeAttr('href');
        }
        if (documentUploadCheck) {
            $('#accountOptions').find('#depositfunds').attr('onclick', "fica.showFicaModalContainer()");
            $('#accountOptions').find('#depositfunds').removeAttr('href');
        }
        if (documentUploadWithdrawalCheck) {
            $('#accountOptions').find('#withdrawfunds').attr('onclick', "fica.showFicaModalContainer()");
            $('#accountOptions').find('#withdrawfunds').removeAttr('href');
        }
    },
    getInfoContent: function(partialView) {
        pat.get("/SideMenu/GetInfoContent", {
            renderPartial: partialView
        }).done(function(result) {
            $('.info-menu-content').html(result);
        });
    },
    getMenuBottomNav: function() {
        pat.get("/SideMenu/GetSideMenuBottomNav").done(function(result) {
            $('#sideMenuBottomNav').html(result);
        });
    },
    showMenu: function() {
        $('#vsmNavigationBar, #vsmStickyOverlayContainer').hide();
        freezeScrolling.enableFreeze($("#menu-ccordion"), true);
        $("html, body").removeClass("full-height-no-vertical-scroll").addClass("full-height-no-vertical-scroll");
        $("#my-menu-overlay, #my-menu").addClass("show-menu");
    },
    closeMenu: function() {
        $("#my-menu-overlay, #my-menu").removeClass("show-menu");
        $("html, body").removeClass("full-height-no-vertical-scroll");
        freezeScrolling.enableFreeze($("#menu-ccordion"), false);
        $('#vsmNavigationBar, #vsmStickyOverlayContainer').fadeIn();
    },
    showFreeplayModal: function() {
        $('#freeplayModal').modal("show");
        sideMenu.closeMenu();
    }
};
var ImageLoader = {
    loadImages: function() {
        var images = [];
        for (var i = 0; i < document.images.length; i++) {
            if (document.images[i].className.indexOf('cross-link-tile') >= 0) {
                images.push(document.images[i]);
            }
        };
        var imgs = images,
            len = imgs.length,
            counter = 0;
        for (var i = 0; i < images.length; i++) {
            if (images[i].complete)
                incrementCounter();
            else
                images[i].addEventListener('load', incrementCounter, false);
        }

        function incrementCounter() {
            counter++;
            if (counter === len) {
                for (var i = 0; i < images.length; i++) {
                    images[i].classList.remove('hidden');
                }
                console.log('All images loaded!');
            }
        }
    }
};
const url = window.location.href.split('/');
const baseUrl = url[0] + '//' + url[2];
var LockingController = {
    switchOption: function(option) {
        if (option === 'Yes') {
            document.querySelector('.content-lock-device').classList.remove("content-lock-device-no-display");
        } else {
            document.querySelector('.content-lock-device').classList.add("content-lock-device-no-display");
        }
        document.querySelector('.yes-or-no-span').innerHTML = option;
    },
    saveLockingReason: function(reason) {
        document.querySelector('.reason-locking-value').innerHTML = reason;
    },
    navigate: function() {
        window.location.href = `${baseUrl}/Home/Index`;
    }
};;
var widgetContainer = {
    renderSearchPartial: function(title, headerStyling) {
        homePage.showOverlay();
        pat.post("/Widget/renderSearchPartial").done(function(data) {
            $('.widget-flyout-header-div').css({
                'background-color': '#585858',
                'color': 'white',
                'margin-bottom': '0px'
            });
            $('.widget-flyout-header').text(title).css({
                'color': 'white'
            });
            language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                "data-translate-key": language.generateKey(title)
            });
            $('.widgetModalContent').css({
                'background-color': '#ffffff',
                'padding-left': '0%',
                'padding-right': '0%'
            }).html(data);
            $('#widgetModal').show();
            homePage.closeOverlay();
            showRecentSearches(true);
        });
        $('html').addClass('modal-open');
    },
    toggleMobileModal: function(dateNow) {
        if ($('.mobileWidgetDiv').is(':visible')) {
            $('.mobileWidgetDiv').fadeOut("slow");
            $('#widgetModal').fadeOut("slow");
            $('.mobileWidgetBtn').text('Search');
            language.translateAtRuntime($('.mobileWidgetBtn'), "SearchEventsWidget", {
                "data-translate-key": "WidgetSearchButton"
            });
            $('.mobileWidgetBtnIcon').removeClass('glyphicon-remove').addClass('glyphicon-plus');
            widgetContainer.allowScroll();
            showRecentSearches(true);
            document.querySelector("html").style.overflow = 'scroll';
        } else {
            $('.mobileWidgetDiv').fadeIn("fast");
            $('.mobileWidgetBtn').text('Close ');
            language.translateAtRuntime($('.mobileWidgetBtn'), "SearchEventsWidget", {
                "data-translate-key": "WidgetCloseButton"
            });
            $('.mobileWidgetBtnIcon').removeClass('glyphicon-plus').addClass('glyphicon-remove');
            $(".mobileWidgetDiv").css({
                'background-color': 'white',
                'width': '100%'
            });
            $("#widgetModal").css('height', 'calc(100% - 50px)');
            widgetContainer.renderSearchPartial('Search', '{\'background-color\':\'gray\',\'color\':\'white\'}')
            $("html").removeClass("modal-open");
            document.querySelector("html").style.overflow = 'hidden';
        }
    },
    allowScroll: function() {
        $("html").removeClass("modal-open");
    },
    getModalEvents: function(widgetType, title, groupedView, queryDate, headerStyling, sportConfigId) {
        homePage.showOverlay();
        var themeStyles = JSON.parse(headerStyling);
        sportConfigId = $('p.active').parent().attr('id');
        sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
        if (sportConfigId === null || sportConfigId === undefined) {
            sportConfigId = localStorage.getItem('currentSportId');
        }
        $('.widget-flyout-header').text(title);
        language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
            "data-translate-key": language.generateKey(title)
        });
        $('.widget-flyout-header').css({
            "color": themeStyles.color
        });
        $('.widget-flyout-header-div').css(themeStyles);
        $('.widgetModalContent').css({
            'padding-left': '5%',
            'background-color': 'white'
        }).html("Loading Content...");
        language.translateAtRuntime($('.widgetModalContent'), "SearchEventsWidget", {
            "data-translate-key": "LoadingContent"
        });
        pat.post("/Widget/getFlyoutEvents", {
            widgetType: widgetType,
            groupedLayout: groupedView,
            QueryDate: queryDate,
            HeaderStyling: headerStyling,
            sportConfigId: sportConfigId
        }).done(function(data) {
            language.removeTranslateAttributes($('.widgetModalContent'));
            $('.widgetModalContent').css({
                'background-color': 'white',
                'padding-left': '5%',
                'padding-right': '5%',
                'padding-bottom': '50px'
            }).html(data);
            widgetType === 2 ? $('#widgetCloseIcon').attr('src', '/Images/Shared/menu/Exit_IconDG.PNG') : $('#widgetCloseIcon').attr('src', '/Images/Shared/menu/CloseIcon.svg');
            $('#widgetModal').show();
            homePage.closeOverlay();
        });
        $('html').removeClass('modal-open');
    },
    closeWidgetFlyout: function() {
        $('.widget-flyout-div').hide();
        $('.widget-flyout').hide();
        $('#angle-Highlights').removeClass('.fa-angle-left').addClass('.fa-angle-right');
        $('#overlay1').fadeOut("fast");
        $("html").removeClass('modal-open');
        widgetContainer.refreshAngles();
        isSearchWidgetOpen = false;
    },
    goToEntity: function(event, eventId, FeedDataTypeId) {
        event.preventDefault();
        window.location.href = "/Bet/EventMultiMarket?eventId=" + eventId + "&FeedDataTypeId=" + FeedDataTypeId;
    },
    goToEntityFriendlyUrl: function(event, url) {
        event.preventDefault();
        window.location.href = url;
    },
    refreshAngles: function() {
        $('.widgetArrow').removeClass('fa-angle-left').removeClass('fa-angle-right').addClass('fa-angle-right');
    },
    openWidgetFlyout: function(isPredictiveSearch) {
        $('.widget-flyout').show().animate({
            width: '452px'
        }).css({
            display: 'flex',
            top: '164px'
        });
        $('.widget-flyout-div').fadeIn("slow");
        if (!isPredictiveSearch) $('#overlay1').fadeOut("fast");
    },
    openRecentSearchResults: function(data, isModal) {
        if (enableRecentSearchTerm) {
            if (isModal) {
                $('.ModalSearchResults').show();
                $('.ModalSearchResults').css({
                    'background-color': 'white',
                    'padding-left': '5%',
                    'padding-right': '5%',
                    'color': 'black',
                    'margin-top': '68px'
                }).html(data);
                $('.widget-flyout-header').text('Previous Searches');
                language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                    "data-translate-key": language.generateKey('PreviousSearchesTitle')
                });
                $('#widgetModal').show();
                homePage.closeOverlay();
            } else {
                $("html").addClass('modal-open');
                $('.widget-flyout').show().animate({
                    width: '452px'
                }).css({
                    display: 'flex',
                    top: '164px'
                });
                $('.widget-flyout-div').fadeIn("slow");
                $('.widget-flyout-content').html(data);
                $('.widget-flyout-header').text('Previous Searches');
                language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                    "data-translate-key": language.generateKey('PreviousSearchesTitle')
                });
            }
        }
    },
    getFlyoutEvents: function(widgetType, id, title, groupedView, queryDate, headerStyling, sportConfigId) {
        if ($('#' + id).hasClass('fa-angle-right')) {
            homePage.showOverlay();
            sportConfigId = $('p.active').parent().attr('id');
            sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
            if (sportConfigId === null || sportConfigId === undefined) {
                sportConfigId = localStorage.getItem('currentSportId');
            }
            pat.post("/Widget/getFlyoutEvents", {
                widgetType: widgetType,
                groupedLayout: groupedView,
                QueryDate: queryDate,
                HeaderStyling: headerStyling,
                sportConfigId: sportConfigId
            }).done(function(data) {
                widgetContainer.openWidgetFlyout();
                widgetContainer.refreshAngles();
                $('#' + id).removeClass('fa-angle-right').addClass('fa-angle-left');
                $('.widget-flyout-header').text(title);
                language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                    "data-translate-key": language.generateKey(title)
                });
                $('.widget-flyout-content').html(data);
                $("html").addClass('modal-open');
                widgetType === 2 ? $('#widgetCloseIcon').attr('src', '/Images/Shared/menu/Exit_IconDG.PNG') : $('#widgetCloseIcon').attr('src', '/Images/Shared/menu/CloseIcon.svg');
                homePage.closeOverlay();
            });
        } else {
            widgetContainer.closeWidgetFlyout();
        }
        if (title === "Highlights") {
            $('.widget-flyout-header-div').removeClass("topLiveWidgetColour");
        } else {
            $('.widget-flyout-header-div').addClass("topLiveWidgetColour");
        }
    },
    widgetSearchTextChange: function(title, keyword) {
        console.log("Predictive OnChange event fired");
        if (keyword.length < 3 || !predictiveTextSearchEnabled) return;
        console.log("Predictive Search Timeout:" + predictiveTextSearchDelay);
        if (!predictiveTextSearchInProgress) {
            setTimeout(function() {
                console.log("Predicting Search after Timeout:" + predictiveTextSearchDelay);
                predictiveTextSearchInProgress = true;
                console.log("predictiveTextSearchInProgress = " + predictiveTextSearchInProgress);
                widgetContainer.widgetSearch(title, keyword, true);
            }, 1000);
            predictiveTextSearchInProgress = false;
        }
    },
    widgetSearch: function(title, keyword, isPredictive = false) {
        if (window.innerWidth < 765) {
            this.widgetModalSearch(title, keyword, isPredictive);
        } else {
            if (keyword.length < 3) return;
            if (isPredictive === null) isPredictive = false;
            var originalKeyword = keyword;
            if (!isPredictive) {
                keyword = language.translateWidgetSearchTerm(keyword);
            }
            keyword = keyword.toLowerCase().trim();
            isSearchWidgetOpen = false;
            var intervalId = !isPredictive ? homePage.showOverlay(120000) : 0;
            var startTime = new Date();
            console.log("Searching for predictive text: " + startTime);
            if (!isPredictive) homePage.showOverlay();
            pat.get("/Widget/DoSearch", {
                'keyword': keyword,
                isPredictiveSearch: isPredictive
            }).done(function(data) {
                var seconds = widgetContainer.widgetModalGetTimeElapsedInSeconds(startTime);
                console.log("Time it took for results: " + seconds + " seconds");
                predictiveTextSearchInProgress = false;
                console.log("predictiveTextSearchInProgress = " + predictiveTextSearchInProgress);
                widgetContainer.openWidgetFlyout(isPredictive);
                $('.widget-flyout-header').text(title);
                language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                    "data-translate-key": language.generateKey(title)
                });
                $('.widget-flyout-content').html(data);
                $("html").animate({
                    scrollTop: "0"
                });
                console.log("Canceling Timeout:" + intervalId);
                if (!isPredictive) clearTimeout(intervalId);
                if (!isPredictive) homePage.closeOverlay();
                if (!isPredictive) saveUserRecentSearchTerm(false, originalKeyword);
                isSearchWidgetOpen = true;
                homePage.closeOverlay();
            });
            if (!isPredictive) gax.SearchEvents_EventTracking(keyword);
            $("html").addClass('modal-open');
        }
    },
    widgetModalGetTimeElapsedInSeconds: function(startTime) {
        endTime = new Date();
        var timeDiff = endTime - startTime;
        timeDiff /= 1000;
        var seconds = Math.round(timeDiff);
        return seconds;
    },
    widgetModalSearch: function(title, keyword, isPredictive) {
        if (keyword.length < 3) return;
        if (isPredictive === null) isPredictive = false;
        var originalKeyword = keyword;
        keyword = keyword.toLowerCase().trim();
        $('.widget-flyout-header').text(title);
        language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
            "data-translate-key": language.generateKey(title)
        });
        $('.modalSearch').show();
        $('.ModalSearchResults').hide();
        language.translateAtRuntime($('.modalSearch'), "SearchEventsWidget", {
            "data-translate-key": "SearchingText"
        });
        $('.ModalSearchResults').attr({
            'data-translate-set': '',
            'data-translate-key': ''
        })
        if (!isPredictive) {
            homePage.showOverlay();
        }
        pat.get("/Widget/DoSearch", {
            'keyword': keyword,
            isPredictiveSearch: isPredictive
        }).done(function(data) {
            $('.ModalSearchResults').css({
                'background-color': 'white',
                'padding-left': '5%',
                'padding-right': '5%',
                'color': 'black',
                'margin-top': '68px'
            }).html(data);
            $('.widget-flyout-header').text(title);
            language.translateAtRuntime($('.widget-flyout-header'), "SearchEventsWidget", {
                "data-translate-key": language.generateKey(title)
            });
            if (data.includes("NoMatchesFound")) language.translateAtRuntime($('.ModalSearchResults'), "SearchEventsWidget", {
                "data-translate-key": "NoMatchesText"
            });
            predictiveTextSearchInProgress = false;
            $('.modalSearch').hide();
            $('.ModalSearchResults').show();
            homePage.closeOverlay();
            if (!isPredictive) saveUserRecentSearchTerm(true, originalKeyword);
        });
        if (!isPredictive) gax.SearchEvents_EventTracking(keyword);
    },
    replaceFlyoutContentByDate: function(widgetType, groupedView, queryDate, sportConfigId) {
        sportConfigId = $('p.active').parent().attr('id');
        sportConfigId = sportConfigId !== null && sportConfigId !== undefined ? sportConfigId.substring(sportConfigId.indexOf("_") + 1) : null;
        if (sportConfigId === null || sportConfigId === undefined) {
            sportConfigId = localStorage.getItem('currentSportId');
        }
        pat.post("/Widget/getFlyoutEvents", {
            widgetType: widgetType,
            groupedLayout: groupedView,
            QueryDate: queryDate,
            sportConfigId: sportConfigId
        }).done(function(data) {
            ($('.widgetModalContent') !== null && typeof $('.widgetModalContent') !== 'undefined' && $('.widgetModalContent').is(':visible')) ? $('.widgetModalContent').html(data): $('.widget-flyout-content').html(data);
        });
    },
    typingDelay: function(fn, ms) {
        let timer = 0
        return function(...args) {
            clearTimeout(timer)
            timer = setTimeout(fn.bind(this, ...args), ms || 0)
        }
    }
}
$("#keywordSearch").on("keyup", widgetContainer.typingDelay(function(event) {
    if (event.keyCode !== 13) {
        widgetContainer.widgetSearchTextChange('Search', $("#keywordSearch").val(), true);
    }
}, 150));
$("#modalKeywordSearch").on("keyup", widgetContainer.typingDelay(function(event) {
    if (event.keyCode !== 13) {
        widgetContainer.widgetSearchTextChange('Search', $("#modalKeywordSearch").val(), true);
    }
}, 150));;
var pat = {};
(function() {
    function ajax(urlParam, dataParam, otherParams, action, isAsync) {
        if (typeof isAsync === 'undefined') isAsync = true;
        var contentType = "application/x-www-form-urlencoded";
        var dataType = null;
        if (typeof dataParam === 'undefined') {
            dataParam = null;
        }
        if (typeof otherParams !== 'undefined') {
            if (typeof otherParams.contentType !== 'undefined') {
                contentType = otherParams.contentType;
            }
            if (typeof otherParams.dataType !== 'undefined') {
                dataType = otherParams.dataType;
            }
        }
        return $.ajax({
            url: urlParam,
            type: action,
            dataType: dataType,
            contentType: contentType,
            data: dataParam,
            async: isAsync,
            cache: true,
            complete: function(xhr, textStatus) {},
            success: function(data, textStatus, xhr) {},
            error: function(xhr, textStatus, errorThrown) {
                console.log('Error: ', errorThrown);
            }
        });
    }
    pat.get = function(urlParam, dataParam, otherParams) {
        return $.when(ajax(urlParam, dataParam, otherParams, "GET"));
    }
    pat.post = function(urlParam, dataParam, otherParams) {
        return $.when(ajax(urlParam, dataParam, otherParams, "POST"));
    }
    pat.getSync = function(urlParam, dataParam, otherParams) {
        return $.when(ajax(urlParam, dataParam, otherParams, "GET", false));
    }
    pat.postSync = function(urlParam, dataParam, otherParams) {
        return $.when(ajax(urlParam, dataParam, otherParams, "POST", false));
    }
}());;
var messages = {
    getInboxCountOpera: function() {
        var accountGuid = PlayerAccountID;
        var brand = Brand;
        pat.get("/Account/InboxCount?AccountId=" + accountGuid + "&BrandId=" + brand).done(function(data) {
            if (document.getElementById('operaButton') !== null) {
                document.getElementById('operaButton').style.backgroundColor = 'red';
            }
        });
    },
    openMessageModal: function() {
        if (typeof document.getElementById('myModal') === 'undefined' || document.getElementById('myModal') === null) {
            $('#askLoginModal').modal('show');
            $("#askLoginModal").on('hidden.bs.modal', function() {
                $("html").removeClass('modal-open');
            });
            $('.modal-backdrop').css('z-index', '-1');
            $("html").addClass("modal-open");
            homePage.closeOverlay();
        } else {
            pat.get("/Account/InboxMessages").done(function(data) {
                if (typeof document.getElementById('myModal') !== 'undefined' && document.getElementById('myModal') !== null) {
                    document.getElementById('myModal').innerHTML = data;
                    language.translateSection("myModal");
                    $('#myModal').on('hidden.bs.modal', function() {
                        $('html').removeClass('modal-open');
                    });
                    $('.modal-backdrop').css('z-index', '1040');
                    $("html").addClass("modal-open");
                }
                homePage.closeOverlay();
            });
        }
    },
    refreshInboxMessages: function() {
        pat.get("/Account/UpdateMessages").done(function(data) {
            if (document.getElementById('message-container') !== null) {
                document.getElementById('message-container').innerHTML = data;
            }
        });
    },
    refreshInboxMessagesModal: function() {
        pat.get("/Account/InboxMessages").done(function(data) {
            if ($(".modal-body") !== null) {
                document.getElementById("myModal").innerHTML = data;
            }
        });
    },
    readMessage: function(guid, msgId, divId, isOperaMini, isFeaturePhone, isRead) {
        if (isRead) {
            homePage.closeOverlay();
            return;
        }
        pat.post("/Account/UpdateMessage", {
            accountId: guid,
            ReadMessage: msgId
        }).done(function(data) {
            if (!isOperaMini && !isFeaturePhone) {
                var doc = document.getElementById('head-' + divId);
                var labelNode = null;
                for (var i = 0; i < doc.childNodes.length; i++) {
                    if (typeof doc.childNodes[i].nextElementSibling !== 'undefined' && doc.childNodes[i].nextElementSibling !== null && doc.childNodes[i].nextElementSibling.className.toLowerCase().indexOf("label-warning") >= 0) {
                        labelNode = doc.childNodes[i].nextElementSibling;
                        labelNode.className = 'label label-success';
                        labelNode.innerHTML = 'Read';
                        break;
                    }
                }
            }
            homePage.getInboxCountAjax();
        });
        homePage.closeOverlay();
    },
    deleteMessage: function(guid, msgId, divId, isOperaMini, isFeaturePhone) {
        pat.post("/Account/DeleteMessage", {
            accountId: guid,
            ReadMessage: msgId
        }).done(function(data) {
            if (isOperaMini || isFeaturePhone) {
                location.reload();
            } else {
                var doc = document.getElementById('head-' + divId);
                var labelNode = null;
                for (var i = 0; i < doc.childNodes.length; i++) {
                    if (typeof doc.childNodes[i].nextElementSibling !== 'undefined' && doc.childNodes[i].nextElementSibling !== null && doc.childNodes[i].nextElementSibling.className.toLowerCase().indexOf("label") >= 0) {
                        labelNode = doc.childNodes[i].nextElementSibling;
                        labelNode.className = 'label label-danger';
                        labelNode.innerHTML = 'Deleted';
                        $('#confirm-' + divId).modal('hide');
                        break;
                    }
                }
            }
            if (!isOperaMini && !isFeaturePhone) {
                homePage.getInboxCount();
            }
        });
        if (!isOperaMini && !isFeaturePhone) {
            homePage.closeOverlay();
        }
    },
    loadInboxPage: function(direction) {
        pat.post("/Account/LoadInboxPage", {
            direction: direction
        }).done(function(data) {
            messages.refreshInboxMessages();
            homePage.closeOverlay();
        });
    },
    loadInboxPageModal: function(direction) {
        pat.post("/Account/LoadInboxPage", {
            direction: direction
        }).done(function(data) {
            messages.refreshInboxMessagesModal();
            homePage.closeOverlay();
        });
    },
    confirmDelete: function(e, divId) {
        e.stopPropagation();
        $('#confirm-' + divId).modal('show');
        $('.modal-backdrop').css('z-index', '1040');
    }
};
var filters = {
    ShiftFilterToActive: function(FeedDataTypeId) {
        if (FeedDataTypeId === constId.emptyGuid) {
            FeedDataTypeId = constId.feedDataType_Prematch;
        }
        var toSwitchMarketType = $('#mobileFilter').children('#filters').data('markettypecategory');
        if ($('#mobileFilter').children('[data-markettypecategory="' + FeedDataTypeId + '"]').length === 0) {
            if ($('#mobileFilter').children('#filters').length > 0) {
                $('#mobileFilter').children('#filters').hide();
                $('#mobileFilter').children('#filters2').hide();
                $('#mobileFilter').children('#filters').attr('id', 'filters_' + toSwitchMarketType);
                $('#mobileFilter').children('#filters2').attr('id', 'filters2_' + toSwitchMarketType);
            }
            $('#mobileFilter').append($('#filters'));
            $('#mobileFilter').append($('#filters2'));
        } else {
            $('#mobileFilter').children('#filters').hide();
            $('#mobileFilter').children('#filters2').hide();
            $('#mobileFilter').children('#filters').attr('id', 'filters_' + toSwitchMarketType);
            $('#mobileFilter').children('#filters2').attr('id', 'filters2_' + toSwitchMarketType);
            $('#mobileFilter').children('#filters_' + FeedDataTypeId).attr('id', 'filters');
            $('#mobileFilter').children('#filters2_' + FeedDataTypeId).attr('id', 'filters2');
            $('#mobileFilter').children('#filters').show();
            $('#mobileFilter').children('#filters2').show();
        }
        if (FeedDataTypeId === constId.feedDataType_LIP) {
            $('.mobileSearch').css('display', 'none');
        } else if (global.getCookie("submenuRef").toLowerCase().indexOf('outrights') > -1 || FeedDataTypeId === '00000000-0000-0000-da7a-000000580005' || FeedDataTypeId === '00000000-0000-0000-da7a-000000580008' || FeedDataTypeId === '00000000-0000-0000-da7a-000000580006' || FeedDataTypeId === '00000000-0000-0000-da7a-000000580007' || FeedDataTypeId === '00000000-0000-0000-0000-000000000000') {
            $('#mobileFilter, .new-filters-container').css('display', 'none');
            $('.mobileSearch').css('display', 'none');
            $('.btn-countriesAndMarkets').css('display', 'none');
        } else {
            $('.mobileSearch').fadeIn();
            $('#mobileFilter').css({
                'display': 'block',
                'max-height': '48px'
            });
            $(".new-filters-container").show();
            $('.btn-countriesAndMarkets').fadeIn();
        }
        $('#filtersDiv').remove();
    },
    getMore: function(isOperaMini, more, FeedDataTypeId) {
        homePage.showOverlay();
        var moreOrLess = more;
        filters.filterLeagues('more', true, isOperaMini, moreOrLess, FeedDataTypeId);
        var selectedLeagues = [],
            counter = 0;
        $('li.league-item.isChecked').each(function(idx, li) {
            selectedLeagues.push($(li).attr('id'));
            counter++;
        });
        if (selectedLeagues.length === 10 || selectedLeagues.length > 10) {
            $('.league-item[data-checked~="False"]').addClass('unclickable');
        } else {
            $('.league-item[data-checked~="False"]').removeClass('unclickable');
        }
        homePage.applyLiveInPlayColourScheme();
    },
    resetLeagues: function(FeedDataTypeId) {
        homePage.showOverlay();
        var listElement = $('*[data-filterleagues-list-markettypecategory*="' + FeedDataTypeId + '"]');
        listElement.find('li.league-item').removeClass('isChecked');
        listElement.find('li.league-item').children('input').prop('checked', false);
        listElement.find('li.league-item').children('span').removeClass('glyphicon-check');
        listElement.find('li.league-item').children('span').addClass('glyphicon-unchecked');
        pat.post("/Event/ClearLeagueFilter", {
            FeedDataTypeId: FeedDataTypeId
        }).done(function(data) {
            filters.filterLeagues();
            homePage.closeOverlay();
        });
        $('.selectedLeagueCount').text('0');
        $.cookie('FilterCount', 0);
        $('.league-item:not(.isChecked)').removeClass('unclickable');
        $('#filterLeagues-list').toggle();
        $('.checked-list-box').css('display', 'none');
        $('.leagueLink').css('background-color', 'transparent');
        $('.leagueLink').css('color', 'black');
        homePage.applyLiveInPlayColourScheme();
        $('*[id^="submenu_"]').hide();
    },
    bindLeagues: function() {
        $('li.league-item').each(function() {
            eventDisplay.setLeagueValues(this)
        });
    },
    addSelectedLeagues: function(id) {
        var selectedLeagues = [],
            counter = 0;
        $('li.league-item.isChecked').each(function(idx, li) {
            selectedLeagues.push($(li).attr('id'));
            counter++;
        });
        if ($('#' + id).hasClass('isChecked')) {
            $('#' + id).removeClass('isChecked');
            var result = selectedLeagues.filter(function(elem) {
                return elem !== id;
            });
            $(".selectedLeagueCount").html('').append(selectedLeagues.length);
            $.cookie("FilterCount", selectedLeagues.length);
            selectedLeagues = result;
        } else {
            selectedLeagues.push(id);
            $(".selectedLeagueCount").html('').append(selectedLeagues.length);
            $.cookie("FilterCount", selectedLeagues.length);
        }
        $(".selectedLeagueCount").html('').append(selectedLeagues.length);
        $.cookie("FilterCount", selectedLeagues.length);
        if (selectedLeagues.length === 10) {
            $('.league-item[data-checked~="False"]').addClass('unclickable');
            $('.league-item.isChecked').removeClass('unclickable');
            $('#' + id).removeClass('unclickable');
        }
    },
    backToBets: function() {
        if (location.hash) {
            if (location.hash === "#inplay") {
                $('a[href="' + location.hash + '"]').tab('show').css("background-color", "transparent !important");
            } else {
                $('a[href="' + location.hash + '"]').tab('show');
            }
        }
        $(document.body).on("click", "a[data-toggle=tab]", function(event) {
            location.hash = this.getAttribute("href");
            if (location.hash === "#inplay") {
                $('a[href="' + location.hash + '"]').tab('show').css("background-color", "transparent !important");
            } else {
                $('a[href="#inplay"]').css("background-color", "transparent !important");
            }
        });
    },
    anchorFilterToTop: function(id) {
        var pos = $('#mobileFilter').offset().top - $('.navbar-fixed-top').height() - 5;
        $('body').scrollTop(pos);
        if ($('#filtermarket-button').parent().hasClass('open')) {
            $('#' + id).hide();
            $('#filtermarket-button').parent().removeClass('open');
            $('#filtermarket-button').attr('aria-expanded', 'false');
        } else {
            $('#' + id).show();
            $('#filterLeagues-list').hide();
            $('#filterleagues-section').removeClass('open');
            $('#filterleagues-button').attr('aria-expanded', 'false');
            $('#filtermarket-button').parent().addClass('open');
            $('#filtermarket-button').attr('aria-expanded', 'true');
        }
    },
    setActiveMarket: function(e, marketId, feedDataTypeId) {
        homePage.showOverlay();
        if (feedDataTypeId === "00000000-0000-0000-da7a-000000580001") {
            homePage.LoadSubMenuBar('#prematchtab', '');
        }
        e.preventDefault();
        var listElement = $('*[data-filtermarket-list-markettypecategory*="' + feedDataTypeId + '"]');
        listElement.find('li').removeClass('isActive');
        listElement.find(marketId).addClass('isActive');
        var buttonElement = $('*[data-filtermarket-button-markettypecategory*="' + feedDataTypeId + '"]');
        buttonElement.html('<span class="fltrText">' + $(marketId).text() + '</span><span class="glyphicon glyphicon-menu-down fade-a-bit"></span>');
        filters.filterLeagues();
    },
    filterLeaguesByRegionId: function(regionId, isMultiMarket, overrideFeedDataTypeId) {
        try {
            homePage.showOverlay();
            var selectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
            var listElement = $('*[data-filtermarket-list-markettypecategory*="' + selectedFeedDataTypeId + '"]');
            var selectedMarketId = listElement.find('li.isActive').attr('id');
            if (selectedFeedDataTypeId === null || selectedFeedDataTypeId.length <= 0) {
                selectedFeedDataTypeId = '00000000-0000-0000-da7a-000000580001';
            }
            var filterData = {
                couponTypeId: selectedMarketId,
                FeedDataTypeId: selectedFeedDataTypeId
            };
            filterData.regionId = regionId;
            if (overrideFeedDataTypeId !== null) {
                filterData.FeedDataTypeId = overrideFeedDataTypeId;
            }
            pat.post("/Event/FilterEventsByRegionId", filterData).done(function(data) {
                var element = $('*[data-matchbetting-events-markettypecategory*="' + selectedFeedDataTypeId + '"]');
                if (!isMultiMarket) {
                    element.html('');
                    element.html(data);
                } else {
                    if (filterData.FeedDataTypeId === '00000000-0000-0000-da7a-000000580003') {
                        window.location.href = "/Event/LiveSport";
                    } else {
                        window.location.href = "/";
                    }
                }
                homePage.closeOverlay();
            });
        } catch (err) {
            console.log(err.message);
        }
    },
    filterLeaguesByLeagueId: function(leagueId, isMultiMarket, overrideFeedDataTypeId) {
        try {
            homePage.showOverlay();
            var selectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory');
            var listElement = $('*[data-filtermarket-list-markettypecategory*="' + selectedFeedDataTypeId + '"]');
            var selectedMarketId = listElement.find('li.isActive').attr('id');
            if (selectedFeedDataTypeId === null || selectedFeedDataTypeId.length <= 0) {
                selectedFeedDataTypeId = '00000000-0000-0000-da7a-000000580001';
            }
            var filterData = {
                couponTypeId: selectedMarketId,
                FeedDataTypeId: selectedFeedDataTypeId
            };
            filterData.leagueId = leagueId;
            if (overrideFeedDataTypeId !== null) {
                filterData.FeedDataTypeId = overrideFeedDataTypeId;
            }
            pat.post("/Event/FilterEventsByLeagueId", filterData).done(function(data) {
                var element = $('*[data-matchbetting-events-markettypecategory*="' + selectedFeedDataTypeId + '"]');
                if (!isMultiMarket) {
                    element.html('');
                    element.html(data);
                } else {
                    if (filterData.FeedDataTypeId === '00000000-0000-0000-da7a-000000580003') {
                        window.location.href = "/Event/LiveSport";
                    } else {
                        window.location.href = "/";
                    }
                }
                homePage.closeOverlay();
            });
        } catch (err) {
            console.log(err.message);
        }
    },
    updateCount: function() {
        var leagueFilterCount = $('li.league-item.isChecked').length;
        $(".selectedLeagueCount").html('').append(leagueFilterCount);
        $.cookie("FilterCount", leagueFilterCount);
    },
    filterLeagues: function(marketDropdown, flag, isOperaMini, more, marketTypeCategoryId) {
        homePage.showOverlay();
        var selectedLeagues = [],
            counter = 0;
        $('li.league-item.isChecked').each(function(idx, li) {
            selectedLeagues.push($(li).attr('id'));
            counter++;
        });
        var selectedFeedDataTypeId = $('#bettingtabs').find('li.active').data('markettypecategory') === constId.emptyGuid ? constId.feedDataType_Prematch : $('#bettingtabs').find('li.active').data('markettypecategory');
        var listElement = $('*[data-filtermarket-list-markettypecategory*="' + selectedFeedDataTypeId + '"]');
        var selectedMarketId = listElement.find('li.isActive').attr('id');
        var filterData = {
            couponTypeId: selectedMarketId,
            FeedDataTypeId: selectedFeedDataTypeId
        };
        if (selectedLeagues.length > 0) {
            filterData.leagueIds = selectedLeagues;
        }
        homePage.GetLeagueContentByLeagueId(filterData.leagueIds, filterData.FeedDataTypeId);
        pat.post("/Event/FilterEvents", filterData).done(function(data) {
            var element = $('*[data-matchbetting-events-markettypecategory*="' + selectedFeedDataTypeId + '"]');
            element.html(data);
            SetOutcomeButtons();
            homePage.closeOverlay();
            if (marketDropdown !== 'more') {
                if (marketDropdown === null) {
                    $('#filterLeagues-list').hide();
                    $('#filtermarket-list').hide();
                    if ($('#filterLeagues-list').parent().hasClass('open')) {
                        $('#filterLeagues-list').parent().removeClass('open')
                    }
                } else {
                    $('#filtermarket-list').hide();
                    $('#filterLeagues-list').hide();
                    if ($('#filterleagues-section').hasClass('open') || $('#filtermarket-button').parent().hasClass('open')) {
                        $('#filterleagues-section').removeClass('open');
                        $('#filtermarket-button').parent().removeClass('open');
                    }
                }
            }
            homePage.anchorToId('mSportDiv');
            if (constId.feedDataType_Prematch === selectedFeedDataTypeId) {
                homePage.synapseNavBarEnabled ? $('#synapseBar_prematchtab').click() : $('#tab_UC').click();
            }
        });
        if (flag === true) {
            pat.post("/Home/GetMore", {
                isOperaMini: isOperaMini,
                moreEvents: more,
                FeedDataTypeId: selectedFeedDataTypeId
            }).done(function(data1) {
                var result = data1;
                if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                    if ($('#filtersDiv').length > 0) {
                        $("#filtersDiv").html(result);
                    } else {
                        $("#filtersDiv2").html(result);
                    }
                } else {
                    if ($('#filtersDiv').length > 0) {
                        $("#filtersDiv").hide().html(result).fadeIn('slow');
                    } else if ($('#filtersDiv2').length > 0) {
                        $("#filtersDiv2").hide().html(result).fadeIn('slow');
                    } else if ($('#mobileFilter').length > 0) {
                        $("#mobileFilter").hide().html(result).fadeIn('slow');
                    }
                    $("#searchFormSearch").remove();
                }
                if (more === true) {
                    $("#moreLeagueBtn").addClass('hidden');
                    $("#lessLeagueBtn").removeClass('hidden');
                    if ($.cookie('FilterCount') === '10') {
                        $('.league-item[data-checked~="False"]').addClass('unclickable');
                    }
                    $("#filterleagues-section").addClass('open');
                    $("#filterleagues-list.dropdown-menu").css('display', 'block');
                } else if (more === false) {
                    $("#moreLeagueBtn").removeClass('hidden');
                    $("#lessLeagueBtn").addClass('hidden');
                    if ($.cookie('FilterCount') === '10') {
                        $('.league-item[data-checked~="False"]').addClass('unclickable');
                    }
                    $("#filterleagues-section").addClass('open');
                    $("#filterleagues-list.dropdown-menu").css('display', 'block');
                } else {
                    if ($.cookie('FilterCount') === '10') {
                        $('.league-item[data-checked~="False"]').addClass('unclickable');
                    }
                    $("#filterleagues-section").removeClass('open');
                    $("#filterleagues-list.dropdown-menu").css('display', 'none');
                }
                eventDisplay.expandCollapseMenu();
                filters.bindLeagues();
                SetOutcomeButtons();
                homePage.closeOverlay();
                homePage.anchorToId('mSportDiv');
            }).fail(function() {
                homePage.closeOverlay();
                if (typeof isOperaMini !== 'undefined' && isOperaMini === true) {
                    location.reload();
                }
                SetOutcomeButtons();
                homePage.closeOverlay();
            });
        }
        homePage.applyLiveInPlayColourScheme();
        var containerUL = $('#leagueLink-' + marketDropdown);
        if (containerUL.hasClass('active') && $('#' + marketDropdown + ' li.isChecked').index() === -1) {
            eventDisplay.closeSubmenu(marketDropdown, this);
        }
    },
}
$(document).ready(function() {
    if (!(window.location.href.indexOf("inplay=true") > -1)) {
        setTimeout(function() {
            if (parseInt($('.selectedLeagueCount').text()) > 0) {
                homePage.synapseNavBarEnabled ? $('#synapseBar_prematchtab').click() : $('#tab_UC').click();
            }
        }, 100);
    }
});;

function browserStorage(disallowCookieStore) {
    var cookieName = "LDS";
    var storageAvailable = function(type) {
        try {
            var storage = window[type],
                x = "__storage_test__";
            storage.setItem(x, x);
            storage.removeItem(x);
            return true
        } catch (e) {
            return false
        }
    };
    var localStorageStore = {
        storeItem: function(name, value) {
            localStorage.setItem(name, value)
        },
        getItem: function(name) {
            return localStorage.getItem(name)
        },
        removeItem: function(name) {
            localStorage.removeItem(name)
        },
        removeAllItems: function() {
            for (var i = 0; i < localStorage.length; i++) {
                localStorage.removeItem(localStorage.key(i))
            }
        }
    };
    var cookieStorageHelper = function(name, value) {
        var dataToStore = {};
        var cookieStore = ReadCookie(name);
        if (!cookieStore) {
            dataToStore[name] = value
        } else {
            cookieStore[name] = value
        }
        return JSON.stringify(dataToStore)
    };
    var cookieStore = {
        storeItem: function(name, value) {
            try {
                CreateCookie(cookieName, cookieStorageHelper(name, value), 365)
            } catch (e) {
                console.log(e)
            }
        },
        getItem: function(name) {
            var dataValue = "";
            try {
                var cookieStore = ReadCookie(name);
                if (cookieStore) {
                    var jsonCookieStore = JSON.parse(cookieStore);
                    if (jsonCookieStore.hasOwnProperty(name)) {
                        dataValue = jsonCookieStore[name];
                        if (!dataValue) {
                            dataValue = ""
                        }
                    }
                }
            } catch (e) {
                console.log(e)
            }
            return dataValue
        },
        removeItem: function(name) {
            try {
                var cookieStore = ReadCookie(name);
                if (cookieStore) {
                    var jsonCookieStore = JSON.parse(cookieStore);
                    if (jsonCookieStore.hasOwnProperty(name)) {
                        var dataValue = jsonCookieStore[name];
                        if (dataValue) {
                            jsonCookieStore[name] = ""
                        }
                    }
                }
                CreateCookie(cookieName, JSON.stringify(cookieStore), 365)
            } catch (e) {
                console.log(e)
            }
        },
        removeAllItems: function() {
            EraseCookie(cookieName)
        }
    };
    return {
        storeItem: function(name, value) {
            if (storageAvailable("localStorage")) {
                localStorageStore.storeItem(name, value)
            } else {
                if (!disallowCookieStore) {
                    cookieStore.storeItem(name, value)
                }
            }
        },
        getItem: function(name) {
            if (storageAvailable("localStorage")) {
                return localStorageStore.getItem(name)
            } else {
                if (!disallowCookieStore) {
                    return cookieStore.getItem(name)
                }
            }
        },
        removeItem: function(name) {
            if (storageAvailable("localStorage")) {
                localStorageStore.removeItem(name)
            } else {
                if (!disallowCookieStore) {
                    cookieStore.removeItem(name)
                }
            }
        },
        removeAllItems: function() {
            if (storageAvailable("localStorage")) {
                localStorageStore.removeAllItems()
            } else {
                if (!disallowCookieStore) {
                    cookieStore.removeAllItems()
                }
            }
        }
    }
}
if (window.XDomainRequest) {
    jQuery.ajaxTransport(function(e) {
        if (e.crossDomain && e.async) {
            if (e.timeout) {
                e.xdrTimeout = e.timeout;
                delete e.timeout
            }
            var t;
            return {
                send: function(n, r) {
                    function i(e, n, i, s) {
                        t.onload = t.onerror = t.ontimeout = jQuery.noop;
                        t = undefined;
                        r(e, n, i, s)
                    }
                    t = new XDomainRequest;
                    t.onload = function() {
                        i(200, "OK", {
                            text: t.responseText
                        }, "Content-Type: " + t.contentType)
                    };
                    t.onerror = function() {
                        i(404, "Not Found")
                    };
                    t.onprogress = jQuery.noop;
                    t.ontimeout = function() {
                        i(0, "timeout")
                    };
                    t.timeout = e.xdrTimeout || Number.MAX_VALUE;
                    t.open(e.type, e.url);
                    t.send(e.hasContent && e.data || null)
                },
                abort: function() {
                    if (t) {
                        t.onerror = jQuery.noop;
                        t.abort()
                    }
                }
            }
        }
    })
}
jQuery.support.cors = true;
(function() {
    var o = this;
    if (o.$JSTools) return false;
    String.prototype.reverse = function() {
        return this.split("").reverse().join("")
    };
    o.$JSTools = {
        sortObjectsByProperty: function(r, o, t, e) {
            if (r.length <= 1 || !o) return r;
            for (var r = r.slice(0), l = o.isArray ? o.slice(0) : [o], o = l[0], n = [], a = [], s = !1, i = "Number" === e ? function(r, o) {
                    return r - o
                } : void 0, h = 0; h < r.length; h++) n.push($JSTools.drillDownToProperty(r[h], o));
            n = n.sort(i);
            for (var h = 0; h < n.length; h++) {
                s = !1;
                for (var f = 0; f < r.length; f++) s || "!%^&&^%!" === r[f] || $JSTools.drillDownToProperty(r[f], o) !== n[h] || (a[h] = r[f], r[f] = "!%^&&^%!", s = !0)
            }
            if (l[1]) {
                var u = $JSTools.groupSortedObjectsByProperty(a, o),
                    P = [];
                l.shift();
                for (var h = 0; h < u.length; h++) P = P.concat($JSTools.sortObjectsByProperty(u[h], l, t));
                a = P
            }
            return t ? a.reverse() : a
        },
        drillDownToProperty: function(r, o) {
            aPath = o.split(".");
            for (var t = 0; t < aPath.length; t++) {
                if (t === aPath.length - 1) return r[aPath[t]];
                r[aPath[t]] && (r = r[aPath[t]])
            }
        },
        groupSortedObjectsByProperty: function(r, o) {
            if (0 === r.length || !o) return r;
            for (var t = [
                    [r[0]]
                ], e = 0, l = 0; l < r.length; l++) r[l + 1] && ($JSTools.drillDownToProperty(r[l + 1], o) !== $JSTools.drillDownToProperty(r[l], o) && (e++, t[e] = []), t[e].push(r[l + 1]));
            return t
        },
        encodeEntities: function(value) {
            value = value || "";
            return value.replace(/&/g, '&amp;').replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, function(value) {
                var hi = value.charCodeAt(0);
                var low = value.charCodeAt(1);
                return '&#' + (((hi - 0xD800) * 0x400) + (low - 0xDC00) + 0x10000) + ';';
            }).replace(/([^\#-~| |!])/g, function(value) {
                return '&#' + value.charCodeAt(0) + ';';
            }).replace(/</g, '&lt;').replace(/>/g, '&gt;')
        }
    }
}).call(this);
(function(e) {
    function n(e) {
        return u.raw ? e : encodeURIComponent(e)
    }

    function r(e) {
        return u.raw ? e : decodeURIComponent(e)
    }

    function i(e) {
        return n(u.json ? JSON.stringify(e) : String(e))
    }

    function s(e) {
        if (e.indexOf('"') === 0) {
            e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\")
        }
        try {
            e = decodeURIComponent(e.replace(t, " "));
            return u.json ? JSON.parse(e) : e
        } catch (n) {}
    }

    function o(t, n) {
        var r = u.raw ? t : s(t);
        return e.isFunction(n) ? n(r) : r
    }
    var t = /\+/g;
    var u = e.cookie = function(t, s, a) {
        if (arguments.length > 1 && !e.isFunction(s)) {
            a = e.extend({}, u.defaults, a);
            if (typeof a.expires === "number") {
                var f = a.expires,
                    l = a.expires = new Date;
                l.setTime(+l + f * 864e5)
            }
            return document.cookie = [n(t), "=", i(s), a.expires ? "; expires=" + a.expires.toUTCString() : "", a.path ? "; path=" + a.path : "", a.domain ? "; domain=" + a.domain : "", a.secure ? "; secure" : ""].join("")
        }
        var c = t ? undefined : {};
        var h = document.cookie ? document.cookie.split("; ") : [];
        for (var p = 0, d = h.length; p < d; p++) {
            var v = h[p].split("=");
            var m = r(v.shift());
            var g = v.join("=");
            if (t && t === m) {
                c = o(g, s);
                break
            }
            if (!t && (g = o(g)) !== undefined) {
                c[m] = g
            }
        }
        return c
    };
    u.defaults = {};
    e.removeCookie = function(t, n) {
        if (e.cookie(t) === undefined) {
            return false
        }
        e.cookie(t, "", e.extend({}, n, {
            expires: -1
        }));
        return !e.cookie(t)
    }
})($)

function ElizaBot(e) {
    function o() {
        a.quit = !1, a.mem = [], a.lastchoice = [];
        for (var e = 0; e < h.length; e++) {
            a.lastchoice[e] = [];
            for (var o = h[e][2], t = 0; t < o.length; t++) a.lastchoice[e][t] = -1
        }
    }

    function t() {
        var e = {};
        if ("object" === typeof y)
            for (var o in y) e[o] = "(" + o + "|" + y[o].join("|") + ")";
        "undefined" === typeof h.length && (h = [
            ["###", 0, [
                ["###", []]
            ]]
        ]);
        for (var t = /@(\S+)/, n = /(\S)\s*\*\s*(\S)/, r = /^\s*\*\s*(\S)/, l = /(\S)\s*\*\s*$/, d = /^\s*\*\s*$/, m = /\s+/g, g = 0; g < h.length; g++) {
            var c = h[g][2];
            h[g][3] = g;
            for (var o = 0; o < c.length; o++) {
                var f = c[o];
                if ("$" === f[0].charAt(0)) {
                    for (var w = 1;
                        " " === f[0].charAt[w];) w++;
                    f[0] = f[0].substring(w), f[2] = !0
                } else f[2] = !1;
                for (var b = t.exec(f[0]); b;) {
                    var p = e[b[1]] ? e[b[1]] : b[1];
                    f[0] = f[0].substring(0, b.index) + p + f[0].substring(b.index + b[0].length), b = t.exec(f[0])
                }
                if (d.test(f[0])) f[0] = "\\s*(.*)\\s*";
                else {
                    if (b = n.exec(f[0])) {
                        for (var v = "", W = f[0]; b;) v += W.substring(0, b.index + 1), ")" !== b[1] && (v += "\\b"), v += "\\s*(.*)\\s*", "(" !== b[2] && "\\" !== b[2] && (v += "\\b"), v += b[2], W = W.substring(b.index + b[0].length), b = n.exec(W);
                        f[0] = v + W
                    }
                    if (b = r.exec(f[0])) {
                        var v = "\\s*(.*)\\s*";
                        ")" !== b[1] && "\\" !== b[1] && (v += "\\b"), f[0] = v + f[0].substring(b.index - 1 + b[0].length)
                    }
                    if (b = l.exec(f[0])) {
                        var v = f[0].substring(0, b.index + 1);
                        "(" !== b[1] && (v += "\\b"), f[0] = v + "\\s*(.*)\\s*"
                    }
                }
                f[0] = f[0].replace(m, "\\s+"), m.lastIndex = 0
            }
        }
        if (h.sort(a._sortKeywords), a.pres = {}, a.posts = {}, s.length) {
            for (var k = new Array, o = 0; o < s.length; o += 2) k.push(s[o]), a.pres[s[o]] = s[o + 1];
            a.preExp = new RegExp("\\b(" + k.join("|") + ")\\b")
        } else a.preExp = /####/, a.pres["####"] = "####";
        if (i.length) {
            for (var k = new Array, o = 0; o < i.length; o += 2) k.push(i[o]), a.posts[i[o]] = i[o + 1];
            a.postExp = new RegExp("\\b(" + k.join("|") + ")\\b")
        } else a.postExp = /####/, a.posts["####"] = "####";
        "undefined" === typeof u.length && (u = []), a._dataParsed = !0
    }
    var a = this,
        n = ["How do you do.  Please tell me your problem.", "Please tell me what's been bothering you.", "Is something troubling you ?"],
        r = ["Goodbye.  It was nice talking to you.", "Goodbye.  This was really a nice talk.", "Goodbye.  I'm looking forward to our next session.", "This was a good session, wasn't it -- but time is over now.   Goodbye.", "Maybe we could discuss this moreover in our next session ?   Goodbye."],
        u = ["bye", "goodbye", "done", "exit", "quit"],
        s = ["dont", "don't", "cant", "can't", "wont", "won't", "recollect", "remember", "recall", "remember", "dreamt", "dreamed", "dreams", "dream", "maybe", "perhaps", "certainly", "yes", "machine", "computer", "machines", "computer", "computers", "computer", "were", "was", "you're", "you are", "i'm", "i am", "same", "alike", "identical", "alike", "equivalent", "alike"],
        i = ["am", "are", "your", "my", "me", "you", "myself", "yourself", "yourself", "myself", "i", "you", "you", "I", "my", "your", "i'm", "you are"],
        y = {
            be: ["am", "is", "are", "was"],
            belief: ["feel", "think", "believe", "wish"],
            cannot: ["can't"],
            desire: ["want", "need"],
            everyone: ["everybody", "nobody", "noone"],
            family: ["mother", "mom", "father", "dad", "sister", "brother", "wife", "children", "child"],
            happy: ["elated", "glad", "better"],
            sad: ["unhappy", "depressed", "sick"]
        },
        h = [
            ["xnone", 0, [
                ["*", ["I'm not sure I understand you fully.", "Please go on.", "What does that suggest to you ?", "Do you feel strongly about discussing such things ?", "That is interesting.  Please continue.", "Tell me more about that.", "Does talking about this bother you ?"]]
            ]],
            ["sorry", 0, [
                ["*", ["Please don't apologise.", "Apologies are not necessary.", "I've told you that apologies are not required.", "It did not bother me.  Please continue."]]
            ]],
            ["apologise", 0, [
                ["*", ["goto sorry"]]
            ]],
            ["remember", 5, [
                ["* i remember *", ["Do you often think of (2) ?", "Does thinking of (2) bring anything else to mind ?", "What else do you recollect ?", "Why do you remember (2) just now ?", "What in the present situation reminds you of (2) ?", "What is the connection between me and (2) ?", "What else does (2) remind you of ?"]],
                ["* do you remember *", ["Did you think I would forget (2) ?", "Why do you think I should recall (2) now ?", "What about (2) ?", "goto what", "You mentioned (2) ?"]],
                ["* you remember *", ["How could I forget (2) ?", "What about (2) should I remember ?", "goto you"]]
            ]],
            ["forget", 5, [
                ["* i forget *", ["Can you think of why you might forget (2) ?", "Why can't you remember (2) ?", "How often do you think of (2) ?", "Does it bother you to forget that ?", "Could it be a mental block ?", "Are you generally forgetful ?", "Do you think you are suppressing (2) ?"]],
                ["* did you forget *", ["Why do you ask ?", "Are you sure you told me ?", "Would it bother you if I forgot (2) ?", "Why should I recall (2) just now ?", "goto what", "Tell me more about (2)."]]
            ]],
            ["if", 3, [
                ["* if *", ["Do you think it's likely that (2) ?", "Do you wish that (2) ?", "What do you know about (2) ?", "Really, if (2) ?", "What would you do if (2) ?", "But what are the chances that (2) ?", "What does this speculation lead to ?"]]
            ]],
            ["dreamed", 4, [
                ["* i dreamed *", ["Really, (2) ?", "Have you ever fantasized (2) while you were awake ?", "Have you ever dreamed (2) before ?", "goto dream"]]
            ]],
            ["dream", 3, [
                ["*", ["What does that dream suggest to you ?", "Do you dream often ?", "What persons appear in your dreams ?", "Do you believe that dreams have something to do with your problem ?"]]
            ]],
            ["perhaps", 0, [
                ["*", ["You don't seem quite certain.", "Why the uncertain tone ?", "Can't you be more positive ?", "You aren't sure ?", "Don't you know ?", "How likely, would you estimate ?"]]
            ]],
            ["name", 15, [
                ["*", ["I am not interested in names.", "I've told you before, I don't care about names -- please continue."]]
            ]],
            ["deutsch", 0, [
                ["*", ["goto xforeign", "I told you before, I don't understand German."]]
            ]],
            ["francais", 0, [
                ["*", ["goto xforeign", "I told you before, I don't understand French."]]
            ]],
            ["italiano", 0, [
                ["*", ["goto xforeign", "I told you before, I don't understand Italian."]]
            ]],
            ["espanol", 0, [
                ["*", ["goto xforeign", "I told you before, I don't understand Spanish."]]
            ]],
            ["xforeign", 0, [
                ["*", ["I speak only English."]]
            ]],
            ["hello", 0, [
                ["*", ["How do you do.  Please state your problem.", "Hi.  What seems to be your problem ?"]]
            ]],
            ["computer", 50, [
                ["*", ["Do computers worry you ?", "Why do you mention computers ?", "What do you think machines have to do with your problem ?", "Don't you think computers can help people ?", "What about machines worries you ?", "What do you think about machines ?", "You don't think I am a computer program, do you ?"]]
            ]],
            ["am", 0, [
                ["* am i *", ["Do you believe you are (2) ?", "Would you want to be (2) ?", "Do you wish I would tell you you are (2) ?", "What would it mean if you were (2) ?", "goto what"]],
                ["* i am *", ["goto i"]],
                ["*", ["Why do you say 'am' ?", "I don't understand that."]]
            ]],
            ["are", 0, [
                ["* are you *", ["Why are you interested in whether I am (2) or not ?", "Would you prefer if I weren't (2) ?", "Perhaps I am (2) in your fantasies.", "Do you sometimes think I am (2) ?", "goto what", "Would it matter to you ?", "What if I were (2) ?"]],
                ["* you are *", ["goto you"]],
                ["* are *", ["Did you think they might not be (2) ?", "Would you like it if they were not (2) ?", "What if they were not (2) ?", "Are they always (2) ?", "Possibly they are (2).", "Are you positive they are (2) ?"]]
            ]],
            ["your", 0, [
                ["* your *", ["Why are you concerned over my (2) ?", "What about your own (2) ?", "Are you worried about someone else's (2) ?", "Really, my (2) ?", "What makes you think of my (2) ?", "Do you want my (2) ?"]]
            ]],
            ["was", 2, [
                ["* was i *", ["What if you were (2) ?", "Do you think you were (2) ?", "Were you (2) ?", "What would it mean if you were (2) ?", "What does ' (2) ' suggest to you ?", "goto what"]],
                ["* i was *", ["Were you really ?", "Why do you tell me you were (2) now ?", "Perhaps I already know you were (2)."]],
                ["* was you *", ["Would you like to believe I was (2) ?", "What suggests that I was (2) ?", "What do you think ?", "Perhaps I was (2).", "What if I had been (2) ?"]]
            ]],
            ["i", 0, [
                ["* i @desire *", ["What would it mean to you if you got (3) ?", "Why do you want (3) ?", "Suppose you got (3) soon.", "What if you never got (3) ?", "What would getting (3) mean to you ?", "What does wanting (3) have to do with this discussion ?"]],
                ["* i am* @sad *", ["I am sorry to hear that you are (3).", "Do you think coming here will help you not to be (3) ?", "I'm sure it's not pleasant to be (3).", "Can you explain what made you (3) ?"]],
                ["* i am* @happy *", ["How have I helped you to be (3) ?", "Has your treatment made you (3) ?", "What makes you (3) just now ?", "Can you explain why you are suddenly (3) ?"]],
                ["* i was *", ["goto was"]],
                ["* i @belief i *", ["Do you really think so ?", "But you are not sure you (3).", "Do you really doubt you (3) ?"]],
                ["* i* @belief *you *", ["goto you"]],
                ["* i am *", ["Is it because you are (2) that you came to me ?", "How long have you been (2) ?", "Do you believe it is normal to be (2) ?", "Do you enjoy being (2) ?", "Do you know anyone else who is (2) ?"]],
                ["* i @cannot *", ["How do you know that you can't (3) ?", "Have you tried ?", "Perhaps you could (3) now.", "Do you really want to be able to (3) ?", "What if you could (3) ?"]],
                ["* i don't *", ["Don't you really (2) ?", "Why don't you (2) ?", "Do you wish to be able to (2) ?", "Does that trouble you ?"]],
                ["* i feel *", ["Tell me more about such feelings.", "Do you often feel (2) ?", "Do you enjoy feeling (2) ?", "Of what does feeling (2) remind you ?"]],
                ["* i * you *", ["Perhaps in your fantasies we (2) each other.", "Do you wish to (2) me ?", "You seem to need to (2) me.", "Do you (2) anyone else ?"]],
                ["*", ["You say (1) ?", "Can you elaborate on that ?", "Do you say (1) for some special reason ?", "That's quite interesting."]]
            ]],
            ["you", 0, [
                ["* you remind me of *", ["goto alike"]],
                ["* you are *", ["What makes you think I am (2) ?", "Does it please you to believe I am (2) ?", "Do you sometimes wish you were (2) ?", "Perhaps you would like to be (2)."]],
                ["* you* me *", ["Why do you think I (2) you ?", "You like to think I (2) you -- don't you ?", "What makes you think I (2) you ?", "Really, I (2) you ?", "Do you wish to believe I (2) you ?", "Suppose I did (2) you -- what would that mean ?", "Does someone else believe I (2) you ?"]],
                ["* you *", ["We were discussing you -- not me.", "Oh, I (2) ?", "You're not really talking about me -- are you ?", "What are your feelings now ?"]]
            ]],
            ["yes", 0, [
                ["*", ["You seem to be quite positive.", "You are sure.", "I see.", "I understand."]]
            ]],
            ["no", 0, [
                ["* no one *", ["Are you sure, no one (2) ?", "Surely someone (2) .", "Can you think of anyone at all ?", "Are you thinking of a very special person ?", "Who, may I ask ?", "You have a particular person in mind, don't you ?", "Who do you think you are talking about ?"]],
                ["*", ["Are you saying no just to be negative?", "You are being a bit negative.", "Why not ?", "Why 'no' ?"]]
            ]],
            ["my", 2, [
                ["$ * my *", ["Does that have anything to do with the fact that your (2) ?", "Lets discuss further why your (2).", "Earlier you said your (2).", "But your (2)."]],
                ["* my* @family *", ["Tell me more about your family.", "Who else in your family (4) ?", "Your (3) ?", "What else comes to your mind when you think of your (3) ?"]],
                ["* my *", ["Your (2) ?", "Why do you say your (2) ?", "Does that suggest anything else which belongs to you ?", "Is it important to you that your (2) ?"]]
            ]],
            ["can", 0, [
                ["* can you *", ["You believe I can (2) don't you ?", "goto what", "You want me to be able to (2).", "Perhaps you would like to be able to (2) yourself."]],
                ["* can i *", ["Whether or not you can (2) depends on you more than on me.", "Do you want to be able to (2) ?", "Perhaps you don't want to (2).", "goto what"]]
            ]],
            ["what", 0, [
                ["*", ["Why do you ask ?", "Does that question interest you ?", "What is it you really want to know ?", "Are such questions much on your mind ?", "What answer would please you most ?", "What do you think ?", "What comes to mind when you ask that ?", "Have you asked such questions before ?", "Have you asked anyone else ?"]]
            ]],
            ["who", 0, [
                ["who *", ["goto what"]]
            ]],
            ["when", 0, [
                ["when *", ["goto what"]]
            ]],
            ["where", 0, [
                ["where *", ["goto what"]]
            ]],
            ["how", 0, [
                ["how *", ["goto what"]]
            ]],
            ["because", 0, [
                ["*", ["Is that the real reason ?", "Don't any other reasons come to mind ?", "Does that reason seem to explain anything else ?", "What other reasons might there be ?"]]
            ]],
            ["why", 0, [
                ["* why don't you *", ["Do you believe I don't (2) ?", "Perhaps I will (2) in good time.", "Should you (2) yourself ?", "You want me to (2) ?", "goto what"]],
                ["* why can't i *", ["Do you think you should be able to (2) ?", "Do you want to be able to (2) ?", "Do you believe this will help you to (2) ?", "Have you any idea why you can't (2) ?", "goto what"]],
                ["*", ["goto what"]]
            ]],
            ["everyone", 2, [
                ["* @everyone *", ["Really, (2) ?", "Surely not (2).", "Can you think of anyone in particular ?", "Who, for example?", "Are you thinking of a very special person ?", "Who, may I ask ?", "Someone special perhaps ?", "You have a particular person in mind, don't you ?", "Who do you think you're talking about ?"]]
            ]],
            ["everybody", 2, [
                ["*", ["goto everyone"]]
            ]],
            ["nobody", 2, [
                ["*", ["goto everyone"]]
            ]],
            ["noone", 2, [
                ["*", ["goto everyone"]]
            ]],
            ["always", 1, [
                ["*", ["Can you think of a specific example ?", "When ?", "What incident are you thinking of ?", "Really, always ?"]]
            ]],
            ["alike", 10, [
                ["*", ["In what way ?", "What resemblence do you see ?", "What does that similarity suggest to you ?", "What other connections do you see ?", "What do you suppose that resemblence means ?", "What is the connection, do you suppose ?", "Could there really be some connection ?", "How ?"]]
            ]],
            ["like", 10, [
                ["* @be *like *", ["goto alike"]]
            ]],
            ["different", 0, [
                ["*", ["How is it different ?", "What differences do you see ?", "What does that difference suggest to you ?", "What other distinctions do you see ?", "What do you suppose that disparity means ?", "Could there be some connection, do you suppose ?", "How ?"]]
            ]]
        ],
        l = [/ old old/g, " old", /\bthey were( not)? me\b/g, "it was$1 me", /\bthey are( not)? me\b/g, "it is$1 me", /Are they( always)? me\b/, "it is$1 me", /\bthat your( own)? (\w+)( now)? \?/, "that you have your$1 $2 ?", /\bI to have (\w+)/, "I have $1", /Earlier you said your( own)? (\w+)( now)?\./, "Earlier you talked about your $2."];
    a.noRandom = e ? !0 : !1, a.capitalizeFirstLetter = !0, a.debug = !1, a.memSize = 20, a.version = "1.1 (original)", a._dataParsed || t(), o(), a._dataParsed = !1, a._sortKeywords = function(e, o) {
        return e[1] > o[1] ? -1 : e[1] < o[1] ? 1 : e[3] > o[3] ? 1 : e[3] < o[3] ? -1 : 0
    }, a.transform = function(e) {
        var o = "";
        a.quit = !1, e = e.toLowerCase(), e = e.replace(/@#\$%\^&\*\(\)_\+=~`\{\[\}\]\|:;<>\/\\\t/g, " "), e = e.replace(/\s+-+\s+/g, "."), e = e.replace(/\s*[,\.\?!;]+\s*/g, "."), e = e.replace(/\s*\bbut\b\s*/g, "."), e = e.replace(/\s{2,}/g, " ");
        for (var t = e.split("."), n = 0; n < t.length; n++) {
            var r = t[n];
            if ("" !== r) {
                for (var s = 0; s < u.length; s++)
                    if (u[s] === r) return a.quit = !0, a.getFinal();
                var i = a.preExp.exec(r);
                if (i) {
                    for (var y = "", l = r; i;) y += l.substring(0, i.index) + a.pres[i[1]], l = l.substring(i.index + i[0].length), i = a.preExp.exec(l);
                    r = y + l
                }
                a.sentence = r;
                for (var d = 0; d < h.length; d++)
                    if (r.search(new RegExp("\\b" + h[d][0] + "\\b", "i")) >= 0 && (o = a._execRule(d)), "" !== o) return o
            }
        }
        if (o = a._memGet(), "" === o) {
            a.sentence = " ";
            var d = a._getRuleIndexByKey("xnone");
            d >= 0 && (o = a._execRule(d))
        }
        return "" !== o ? o : "I am at a loss for words."
    }, a._execRule = function(e) {
        for (var o = h[e], t = o[2], n = /\(([0-9]+)\)/, r = 0; r < t.length; r++) {
            var u = a.sentence.match(t[r][0]);
            if (null !== u) {
                var s = t[r][1],
                    i = t[r][2],
                    y = a.noRandom ? 0 : Math.floor(Math.random() * s.length);
                a.noRandom && a.lastchoice[e][r] > y || a.lastchoice[e][r] === y ? (y = ++a.lastchoice[e][r], y >= s.length && (y = 0, a.lastchoice[e][r] = -1)) : a.lastchoice[e][r] = y;
                var l = s[y];
                if (a.debug && alert("match:\nkey: " + h[e][0] + "\nrank: " + h[e][1] + "\ndecomp: " + t[r][0] + "\nreasmb: " + l + "\nmemflag: " + i), 0 === l.search("^goto ", "i") && (ki = a._getRuleIndexByKey(l.substring(5)), ki >= 0)) return a._execRule(ki);
                var d = n.exec(l);
                if (d) {
                    for (var m = "", g = l; d;) {
                        var c = u[parseInt(d[1])],
                            f = a.postExp.exec(c);
                        if (f) {
                            for (var w = "", b = c; f;) w += b.substring(0, f.index) + a.posts[f[1]], b = b.substring(f.index + f[0].length), f = a.postExp.exec(b);
                            c = w + b
                        }
                        m += g.substring(0, d.index) + c, g = g.substring(d.index + d[0].length), d = n.exec(g)
                    }
                    l = m + g
                }
                if (l = a._postTransform(l), !i) return l;
                a._memSave(l)
            }
        }
        return ""
    }, a._postTransform = function(e) {
        if (e = e.replace(/\s{2,}/g, " "), e = e.replace(/\s+\./g, "."), l.length)
            for (var o = 0; o < l.length; o += 2) e = e.replace(l[o], l[o + 1]), l[o].lastIndex = 0;
        if (a.capitalizeFirstLetter) {
            var t = /^([a-z])/,
                n = t.exec(e);
            n && (e = n[0].toUpperCase() + e.substring(1))
        }
        return e
    }, a._getRuleIndexByKey = function(e) {
        for (var o = 0; o < h.length; o++)
            if (h[o][0] === e) return o;
        return -1
    }, a._memSave = function(e) {
        a.mem.push(e), a.mem.length > a.memSize && a.mem.shift()
    }, a._memGet = function() {
        if (a.mem.length) {
            if (a.noRandom) return a.mem.shift();
            for (var e = Math.floor(Math.random() * a.mem.length), o = a.mem[e], t = e + 1; t < a.mem.length; t++) a.mem[t - 1] = a.mem[t];
            return a.mem.length--, o
        }
        return ""
    }, a.getFinal = function() {
        return r ? r[Math.floor(Math.random() * r.length)] : ""
    }, a.getInitial = function() {
        return n ? n[Math.floor(Math.random() * n.length)] : ""
    }
}

function Transport_REST_ELIZA(a) {
    "use strict";

    function b(a) {
        var b = a.promise();
        return {
            done: b.done,
            fail: b.fail
        }
    }

    function c(a) {
        var b = {},
            c = !1;
        switch (a.type) {
            case "Text":
                a.type = "MessageReceived";
                break;
            case "ParticipantJoined":
                a.type = "AgentConnected";
                break;
            case "ParticipantLeft":
                a.type = "AgentDisconnected";
                break;
            case "ParticipantRejoined":
                a.type = "ParticipantRejoined";
                break;
            case "TypingStarted":
                a.type = "AgentTyping", c = !0;
                break;
            case "TypingStopped":
                a.type = "AgentTyping", c = !1;
                break;
            case "TranscriptSaveDone":
                a.type = "TranscriptSaveDone";
                break;
            case "Notice":
                a.type = "Notice"
        }
        if (a.from && a.from.type) switch (a.from.type) {
            case "Customer":
                a.from.type = "Client";
                break;
            case "Agent":
                a.from.type = "Agent";
                break;
            case "External":
                a.from.type = "External"
        }
        return b.type = a.type, b.index = a.index, b.timestamp = (new Date).getTime(), b.isTyping = "AgentTyping" === a.type ? c : void 0, b.content = a.text ? {
            text: a.text,
            type: "text"
        } : void 0, b.party = {
            id: a.from ? parseInt(a.from.participantId) : "",
            type: a.from ? a.from.type : "",
            name: a.from ? a.from.nickname : ""
        }, b
    }

    function d(a) {
        $.each(a.messages, function() {
            var a = c(this);
            h[a.type] && h[a.type](a)
        })
    }

    function e(a, b, c) {
        setTimeout(function() {
            d(a), c && c()
        }, b || 1e3)
    }
    var f = this,
        g = $.Deferred,
        h = {},
        i = 0;
    this.bWaitingForTokens = !1;
    var j = null,
        k = !1;
    this.updateOptions = function() {}, this.setFormData = function() {}, this.restore = function() {}, this.startSession = function() {
        return $.Deferred(function(a) {
            ElizaBot ? (j = new ElizaBot(!0), a.done(function() {
                e({
                    statusCode: 0,
                    messages: [{
                        index: ++i,
                        type: "ParticipantJoined",
                        from: {
                            id: "1",
                            type: "Customer",
                            nickname: "b",
                            participantId: "1"
                        }
                    }]
                }, 1e3), e({
                    statusCode: 0,
                    messages: [{
                        index: ++i,
                        type: "ParticipantJoined",
                        from: {
                            id: "2",
                            type: "External",
                            nickname: "system",
                            participantId: "2"
                        }
                    }]
                }, 2e3), e({
                    statusCode: 0,
                    messages: [{
                        index: ++i,
                        type: "Text",
                        from: {
                            id: "2",
                            type: "External",
                            nickname: "system",
                            participantId: "2"
                        },
                        text: "agent will be with you shortly ..."
                    }]
                }, 3e3), e({
                    statusCode: 0,
                    messages: [{
                        index: ++i,
                        type: "ParticipantJoined",
                        from: {
                            id: "3",
                            type: "Agent",
                            nickname: "Eliza",
                            participantId: "3"
                        }
                    }]
                }, 5e3, function() {
                    k = !0, f.elizaRespond(!1, "Hello! My name is Eliza. How can you help yourself?")
                })
            }), setTimeout(a.resolve, 1e3)) : setTimeout(a.fail, 1e3)
        })
    }, this.sendMessage = function(a) {
        e({
            statusCode: 0,
            messages: [{
                index: ++i,
                type: "Text",
                from: {
                    id: "1",
                    type: "Customer",
                    nickname: "You",
                    participantId: "1"
                },
                text: a.message
            }]
        }, 10), f.elizaRespond(a.message)
    }, this.elizaRespond = function(a, b) {
        if (k) {
            var b = b || j.transform(a);
            e({
                statusCode: 0,
                messages: [{
                    index: ++i,
                    type: "TypingStarted",
                    from: {
                        id: "3",
                        type: "Agent",
                        nickname: "Eliza",
                        participantId: "3"
                    }
                }]
            }), e({
                statusCode: 0,
                messages: [{
                    index: ++i,
                    type: "Text",
                    from: {
                        id: "3",
                        type: "Agent",
                        nickname: "Eliza",
                        participantId: "3"
                    },
                    text: b
                }, {
                    index: ++i,
                    type: "TypingStopped",
                    from: {
                        id: "3",
                        type: "Agent",
                        nickname: "Eliza",
                        participantId: "3"
                    }
                }]
            }, 3e3, function() {
                b.toLowerCase().match("goodbye") && e({
                    statusCode: 0,
                    messages: [{
                        index: ++i,
                        type: "ParticipantLeft",
                        from: {
                            id: "3",
                            type: "Agent",
                            nickname: "Eliza",
                            participantId: "3"
                        }
                    }, {
                        index: ++i,
                        type: "ParticipantLeft",
                        from: {
                            id: "1",
                            type: "Customer",
                            nickname: "You",
                            participantId: "1"
                        }
                    }]
                })
            })
        }
    }, this.leaveSession = function(a) {
        h.SessionEnded()
    }, this.stopPoll = function() {}, this.sendTyping = function(a) {}, this.setUserData = function(a) {
        return b(new g)
    }, this.getUserData = function(a) {
        return b(new g)
    }, this.deleteUserData = function(a) {
        return b(new g)
    }, this.onAgentConnected = function(a) {
        h.AgentConnected = a
    }, this.onAgentTyping = function(a) {
        h.AgentTyping = a
    }, this.onAgentDisconnected = function(a) {
        h.AgentDisconnected = a
    }, this.onMessageReceived = function(a) {
        h.MessageReceived = a
    }, this.onSessionEnded = function(a) {
        h.SessionEnded = a
    }, this.onError = function(a) {
        h.Error = a
    }, this.onRestore = function(a) {
        h.Restore = a
    }
}

function Transport_REST_WebAPI(a) {
    "use strict";

    function b() {
        k && "/" !== k[k.length - 1] && (k += "/")
    }

    function c(a) {
        var b = a.promise();
        return {
            done: b.done,
            fail: b.fail
        }
    }

    function d(a) {
        return setTimeout(a, 0)
    }

    function e(a) {
        var b = {},
            c = !1,
            d = !1;
        switch (a.type) {
            case "Message":
                a.type = "MessageReceived";
                break;
            case "ParticipantJoined":
                a.type = "AgentConnected";
                break;
            case "ParticipantLeft":
                a.type = "AgentDisconnected";
                break;
            case "ParticipantRejoined":
                a.type = "ParticipantRejoined";
                break;
            case "TypingStarted":
                a.type = "AgentTyping", c = !0;
                break;
            case "TypingStopped":
                a.type = "AgentTyping", c = !1;
                break;
            case "TranscriptSaveDone":
                a.type = "TranscriptSaveDone";
                break;
            case "Notice":
                a.type = "MessageReceived", d = !0
        }
        if (a.from && a.from.type) switch (a.from.type) {
            case "Client":
                a.from.type = "Client";
                break;
            case "Agent":
                a.from.type = "Agent";
                break;
            case "External":
                a.from.type = "External"
        }
        return b.type = a.type, b.index = a.index, b.timestamp = (new Date).getTime(), b.isTyping = "AgentTyping" === a.type ? c : void 0, b.content = a.text ? {
            text: a.text,
            type: d ? "notice" : "text"
        } : void 0, b.party = {
            id: a.from ? parseInt(a.from.participantId) : "",
            type: a.from ? a.from.type : "",
            name: a.from ? a.from.nickname : ""
        }, a.index >= 0 && a.index >= q && (q = a.index + 1), b
    }

    function f() {
        localStorage.removeItem("genesys_webchat_session_id"), localStorage.removeItem("genesys_webchat_session_keys")
    }

    function g(a) {
        $.each(a.messages, function() {
            var a = e(this);
            t[a.type] && t[a.type](a)
        }), a.chatEnded === !0 && (i.stopPoll(), f(), t.SessionEnded(a))
    }

    function h(a, b, d) {
        var e = new j;
        return $.ajax({
            url: k + $JSTools.encodeEntities(m) + (a || ""),
            type: b,
            crossDomain: !0,
            data: JSON.stringify(d, void 0, 2),
            headers: {
                "Content-Type": "application/json"
            },
            xhrFields: {
                withCredentials: !0
            },
            success: function(a) {
                a.id && (a.sessionId = a.id), a.alias && (p = a.alias), localStorage.setItem("genesys_webchat_session_keys", JSON.stringify({
                    secureKey: o,
                    alias: p,
                    userId: n
                })), e.resolve(a || {})
            },
            error: function(a) {
                e.reject(a || {})
            },
            beforeSend: function(a) {}
        }), c(e)
    }
    if (console.log("A"), !a || a && !a.id) return !1;
    var i = this,
        j = $.Deferred,
        k = a.dataURL.replace(/\/$/, ""),
        l = a.id || "Environment",
        m = "",
        n = "",
        o = "",
        p = "",
        q = 1,
        r = 1,
        s = ((new Date).getTimezoneOffset(), new j),
        t = {},
        u = !1,
        v = !1,
        w = 3e3;
    b(), console.log("B"), this.restore = function() {
        var b = localStorage.getItem("genesys_webchat_session_id"),
            c = JSON.parse(localStorage.getItem("genesys_webchat_session_keys"));
        b && c && (m = b, f(), o = c.secureKey, p = c.alias, n = c.userId, this.getTranscript().done(function(b) {
            a.onRestore && a.onRestore()
        }).fail(function(a) {
            m = ""
        }))
    }, this.init = function() {
        return d(s.resolve), c(s)
    }, this.poll = function(a, b, c) {
        v || (v = !0, this.getTranscript().done(function(a) {
            g(a), v = !1
        }))
    }, this.startPoll = function() {
        this.stopPoll(), u = setInterval(function() {
            i.poll()
        }, w), this.poll()
    }, this.stopPoll = function() {
        clearInterval(u)
    }, this.setFormData = function(b) {
        a.formData = b
    }, this.updateOptions = function(c) {
        for (var d in c) a[d] = c[d];
        return b(), this
    }, this.reset = function() {
        m = "", n = "", o = "", p = "", q = 1, r = 1
    }, this.startSession = function(b) {
        var c = {
            tenantName: l,
            nickname: a.formData.nickname || a.formData.firstname || "Anonymous",
            firstName: a.formData.firstname || "John",
            lastName: a.formData.lastname || "Doe",
            emailAddress: a.formData.email || "",
            subject: a.formData.subject || "No Subject",
            text: "",
            userData: a.userData || {}
        };
        return a.endpoint && (c.endpoint = a.endpoint), m ? this.getTranscript().done(function(a) {
            0 === a.statusCode && (i.startPoll(), localStorage.setItem("genesys_webchat_session_id", m))
        }) : h("", "POST", c).done(function(a) {
            0 === a.statusCode && (m = a.chatId, o = a.secureKey, p = a.alias, n = a.userId, localStorage.setItem("genesys_webchat_session_id", m), localStorage.setItem("genesys_webchat_session_keys", JSON.stringify({
                secureKey: o,
                alias: p,
                userId: n
            })), i.startPoll())
        })
    }, this.sendMessage = function(a) {
        return h("", "POST", {
            tenantName: l,
            operationName: "SendMessage",
            text: a.message,
            userId: n,
            secureKey: o,
            alias: p
        })
    }, this.getTranscript = function(a) {
        return h("/messages", "POST", {
            tenantName: l,
            secureKey: o,
            alias: p,
            userId: n,
            transcriptPosition: q
        })
    }, this.getChat = function(a) {
        return h("", "GET", {
            tenantName: l,
            secureKey: o,
            alias: p,
            userId: n
        })
    }, this.leaveSession = function(a) {
        return this.stopPoll(), h("", "POST", {
            tenantName: l,
            operationName: "Complete",
            alias: p,
            secureKey: o,
            userId: n
        })
    }, this.sendTyping = function(a) {
        var a = a || {};
        return a.isTyping ? h("", "POST", {
            tenantName: l,
            operationName: "SendStartTypingNotification",
            alias: p,
            secureKey: o,
            userId: n
        }) : h("", "POST", {
            tenantName: l,
            operationName: "SendStopTypingNotification",
            alias: p,
            secureKey: o,
            userId: n
        })
    }, this.setUserData = function(a) {
        return c(new j)
    }, this.getUserData = function(a) {
        return c(new j)
    }, this.deleteUserData = function(a) {
        return c(new j)
    }, this.onAgentConnected = function(a) {
        t.AgentConnected = a
    }, this.onAgentTyping = function(a) {
        t.AgentTyping = a
    }, this.onAgentDisconnected = function(a) {
        t.AgentDisconnected = a
    }, this.onMessageReceived = function(a) {
        t.MessageReceived = a
    }, this.onSessionEnded = function(a) {
        t.SessionEnded = a
    }, this.onError = function(a) {
        t.Error = a
    }
}

function Transport_REST_HTCC(a) {
    "use strict";

    function b() {
        h && "/" !== h[h.length - 1] && (h += "/")
    }

    function c(a) {
        var b = {},
            c = !1;
        switch (a.type) {
            case "Text":
                a.type = "MessageReceived";
                break;
            case "ParticipantJoined":
                a.type = "AgentConnected";
                break;
            case "ParticipantLeft":
                a.type = "AgentDisconnected";
                break;
            case "ParticipantRejoined":
                a.type = "ParticipantRejoined";
                break;
            case "TypingStarted":
                a.type = "AgentTyping", c = !0;
                break;
            case "TypingStopped":
                a.type = "AgentTyping", c = !1;
                break;
            case "TranscriptSaveDone":
                a.type = "TranscriptSaveDone";
                break;
            case "Notice":
                a.type = "Notice"
        }
        if (a.from && a.from.type) switch (a.from.type) {
            case "Customer":
                a.from.type = "Client";
                break;
            case "Agent":
                a.from.type = "Agent";
                break;
            case "External":
                a.from.type = "External"
        }
        return b.type = a.type, b.index = a.index, b.timestamp = (new Date).getTime(), b.isTyping = "AgentTyping" === a.type ? c : void 0, b.content = a.text ? {
            text: a.text,
            type: "text"
        } : void 0, b.party = {
            id: a.from ? parseInt(a.from.participantId) : "",
            type: a.from ? a.from.type : "",
            name: a.from ? a.from.nickname : ""
        }, b
    }

    function d(a) {
        var b = $JSTools.sortObjectsByProperty(a.messages, "index", !1, "Number");
        $.each(b, function() {
            var a = c(this);
            k[a.type] && k[a.type](a)
        })
    }

    function e(a, b, c) {
        var d = new g;
        return $.ajax({
            url: h + $JSTools.encodeEntities(j) + (a || ""),
            type: b,
            crossDomain: !0,
            data: "POST" === b ? JSON.stringify(c, void 0, 2) : c,
            headers: {
                "Content-Type": "application/json"
            },
            xhrFields: {
                withCredentials: !0
            },
            success: function(a, b, c) {
                a.id && (a.sessionId = a.id), c.getResponseHeader("X-CSRF-HEADER") && c.getResponseHeader("X-CSRF-TOKEN") && (p.CSRFHeaderName = c.getResponseHeader("X-CSRF-HEADER"), p.CSRFToken = c.getResponseHeader("X-CSRF-TOKEN")), d.resolve(a || {})
            },
            error: function(a) {
                d.reject(a || {})
            },
            beforeSend: function(a) {
                p.CSRFHeaderName && p.CSRFToken && a.setRequestHeader(p.CSRFHeaderName, p.CSRFToken), q ? a.setRequestHeader("apikey", q) : i && a.setRequestHeader("ContactCenterId", i)
            }
        }), d.promise()
    }
    if (!a) return !1;
    var f = this,
        g = $.Deferred,
        h = a.dataURL.replace(/\/$/, ""),
        i = a.id,
        j = "",
        k = ((new Date).getTimezoneOffset(), new g, {}),
        l = !1,
        m = 3e3,
        n = !0,
        o = !1,
        p = {},
        q = (document.createElement("a"), a.apikey || !1);
    this.bWaitingForTokens = !0, b(), this.restore = function() {
        $.cookie("genesys_webchat_session_id") && (j = $.cookie("genesys_webchat_session_id"), $.removeCookie("genesys_webchat_session_id", {
            path: "/"
        }), this.getTranscript().done(function(b) {
            n = !0, a.onRestore && a.onRestore()
        }).fail(function(a) {
            j = ""
        }))
    }, this.poll = function(a, b, c) {
        l || (l = !0, this.getTranscript(n ? {
            index: 0
        } : {}).done(function(a) {
            d(a), l = !1
        }), n = !1)
    }, this.startPoll = function() {
        this.stopPoll();
        var a = this;
        a.poll(), window.poll_int = setInterval(function() {
            a.poll()
        }, m)
    }, this.stopPoll = function() {
        clearInterval(window.poll_int)
    }, this.setFormData = function(b) {
        a.formData = b
    }, this.updateOptions = function(c) {
        for (var d in c) a[d] = c[d];
        return b(), this
    }, this.startSession = function() {
        if (o) return (new g).promise();
        o = !0;
        var b = {
            operationName: "RequestChat",
            nickname: a.formData.nickname || a.formData.firstname || a.UserNameDefault || "Anonymous",
            subject: a.formData.subject || "No Subject",
            userData: a.userData || {}
        };
        return a.formData && (b.userData.FirstName = a.formData.firstname || void 0, b.userData.LastName = a.formData.lastname || void 0, b.userData.EmailAddress = a.formData.email || void 0), a.endpoint && (b.endpoint = a.endpoint), j ? this.getTranscript().done(function(a) {
            f.startPoll(), $.cookie("genesys_webchat_session_id", j, {
                path: "/"
            })
        }).always(function() {
            o = !1
        }) : e("", "POST", b).done(function(a) {
            a.id && (j = a.id, $.cookie("genesys_webchat_session_id", j, {
                path: "/"
            })), f.startPoll()
        }).always(function() {
            o = !1
        })
    }, this.sendMessage = function(a) {
        return e("", "POST", {
            operationName: "SendMessage",
            text: a.message
        }).done(function() {
            f.poll()
        })
    }, this.getTranscript = function(a) {
        return e("/messages", "GET", a)
    }, this.getChat = function(a) {
        return e("", "GET", {})
    }, this.leaveSession = function(a) {
        return this.stopPoll(), e("", "POST", {
            operationName: "Complete"
        }).done(function() {
            $.removeCookie("genesys_webchat_session_id", {
                path: "/"
            }), k.SessionEnded()
        }).fail(function() {
            k.SessionEnded()
        })
    }, this.sendTyping = function(a) {
        var a = a || {};
        return a.isTyping ? e("", "POST", {
            operationName: "SendStartTypingNotification"
        }) : e("", "POST", {
            operationName: "SendStopTypingNotification"
        })
    }, this.setUserData = function(a) {
        return (new g).promise()
    }, this.getUserData = function(a) {
        return (new g).promise()
    }, this.deleteUserData = function(a) {
        return (new g).promise()
    }, this.onAgentConnected = function(a) {
        k.AgentConnected = a
    }, this.onAgentTyping = function(a) {
        k.AgentTyping = a
    }, this.onAgentDisconnected = function(a) {
        k.AgentDisconnected = a
    }, this.onMessageReceived = function(a) {
        k.MessageReceived = a
    }, this.onSessionEnded = function(a) {
        k.SessionEnded = a
    }, this.onError = function(a) {
        k.Error = a
    }, this.onRestore = function(a) {
        k.Restore = a
    }
}

function Transport_REST_GMS(a) {
    "use strict";

    function b() {
        k && "/" !== k[k.length - 1] && (k += "/")
    }

    function c(a) {
        var b = a.promise();
        return {
            done: b.done,
            fail: b.fail
        }
    }

    function d(a) {
        return setTimeout(a, 0)
    }

    function e(a) {
        var b = {},
            c = !1,
            d = !1;
        switch (a.type) {
            case "Message":
                a.type = "MessageReceived";
                break;
            case "ParticipantJoined":
                a.type = "AgentConnected";
                break;
            case "ParticipantLeft":
                a.type = "AgentDisconnected";
                break;
            case "ParticipantRejoined":
                a.type = "ParticipantRejoined";
                break;
            case "TypingStarted":
                a.type = "AgentTyping", c = !0;
                break;
            case "TypingStopped":
                a.type = "AgentTyping", c = !1;
                break;
            case "TranscriptSaveDone":
                a.type = "TranscriptSaveDone";
                break;
            case "Notice":
                a.type = "MessageReceived", d = !0
        }
        return b.type = a.type, b.index = a.index, b.timestamp = a.utcTime, b.isTyping = "AgentTyping" === a.type ? c : void 0, b.content = a.text ? {
            text: a.text,
            type: d ? "notice" : "text"
        } : void 0, b.party = {
            id: a.from ? parseInt(a.from.participantId) : "",
            type: a.from ? a.from.type : "",
            name: a.from ? a.from.nickname : ""
        }, a.index >= 0 && a.index >= p && (p = a.index + 1), b
    }

    function f() {
        localStorage.removeItem("genesys_webchat_session_id"), localStorage.removeItem("genesys_webchat_session_keys")
    }

    function g(a) {
        $.each(a.messages, function() {
            var a = e(this);
            r[a.type] && r[a.type](a)
        }), a.chatEnded === !0 && (i.stopPoll(), f(), r.SessionEnded(a))
    }

    function h(a, b, d) {
        var e = new j;
        return $.ajax({
            url: k + $JSTools.encodeEntities(l) + (a || ""),
            type: b,
            crossDomain: !0,
            data: d,
            timeout: 3e3,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            xhrFields: {
                withCredentials: !1
            },
            success: function(a) {
                a.id && (a.sessionId = a.id), a.alias && (o = a.alias), localStorage.setItem("genesys_webchat_session_keys", JSON.stringify({
                    secureKey: n,
                    alias: o,
                    userId: m
                })), e.resolve(a || {})
            },
            error: function(a) {
                e.reject(a || {})
            },
            beforeSend: function(a) {
                v && a.setRequestHeader("apikey", v)
            }
        }), c(e)
    }
    if (!a) return !1;
    var i = this,
        j = $.Deferred,
        k = a.dataURL.replace(/\/$/, ""),
        l = "",
        m = "",
        n = "",
        o = "",
        p = 1,
        q = ((new Date).getTimezoneOffset(), new j),
        r = {},
        s = !1,
        t = !1,
        u = 3e3,
        v = a.apikey || !1;
    b(), this.restore = function() {
        var b = localStorage.getItem("genesys_webchat_session_id"),
            c = JSON.parse(localStorage.getItem("genesys_webchat_session_keys"));
        b && c && (l = b, f(), n = c.secureKey, o = c.alias, m = c.userId, this.getTranscript().done(function(b) {
            b && b.chatEnded === !1 && a.onRestore && a.onRestore()
        }).fail(function(a) {
            l = ""
        }))
    }, this.init = function() {
        return d(q.resolve), c(q)
    }, this.poll = function(a, b, c) {
        t || (t = !0, this.getTranscript().done(function(a) {
            g(a), t = !1
        }))
    }, this.startPoll = function() {
        this.stopPoll(), s = setInterval(function() {
            i.poll()
        }, u), this.poll()
    }, this.stopPoll = function() {
        clearInterval(s)
    }, this.setFormData = function(b) {
        a.formData = b
    }, this.updateOptions = function(c) {
        for (var d in c) a[d] = c[d];
        return b(), this
    }, this.startSession = function(b) {
        var c = {
            nickname: a.formData.nickname || a.formData.firstname || "Anonymous",
            firstName: a.formData.firstname || "John",
            lastName: a.formData.lastname || "Doe",
            emailAddress: a.formData.email || "",
            subject: a.formData.subject || "No Subject",
            text: "",
            userData: a.userData || {}
        };
        return a.endpoint && (c.endpoint = a.endpoint), l ? this.getTranscript().done(function(a) {
            0 === a.statusCode && (i.startPoll(), localStorage.setItem("genesys_webchat_session_id", l))
        }) : h("", "POST", c).done(function(a) {
            0 === a.statusCode && (l = a.chatId, n = a.secureKey, o = a.alias, m = a.userId, localStorage.setItem("genesys_webchat_session_id", l), localStorage.setItem("genesys_webchat_session_keys", JSON.stringify({
                secureKey: n,
                alias: o,
                userId: m
            })), i.startPoll())
        })
    }, this.sendMessage = function(a) {
        return h("/send", "POST", {
            message: a.message,
            messageType: a.messageType || "text",
            userId: m,
            secureKey: n,
            alias: o
        })
    }, this.getTranscript = function(a) {
        return h("/refresh", "POST", {
            userId: m,
            secureKey: n,
            alias: o,
            transcriptPosition: p,
            message: i.getCurrentTextEntered()
        })
    }, this.getChat = function(a) {
        return h("", "GET", {
            secureKey: n,
            alias: o,
            userId: m
        })
    }, this.leaveSession = function(a) {
        return this.stopPoll(), h("/disconnect", "POST", {
            alias: o,
            secureKey: n,
            userId: m
        }).done(function(a) {
            0 === a.statusCode && (f(), r.SessionEnded(a))
        })
    }, this.sendTyping = function(a) {
        var a = a || {};
        return a.isTyping ? h("/startTyping", "POST", {
            alias: o,
            secureKey: n,
            userId: m,
            message: a.message || ""
        }) : h("/stopTyping", "POST", {
            alias: o,
            secureKey: n,
            userId: m,
            message: a.message || ""
        })
    }, this.setUserData = function(a) {
        return c(new j)
    }, this.getUserData = function(a) {
        return c(new j)
    }, this.deleteUserData = function(a) {
        return c(new j)
    }, this.onAgentConnected = function(a) {
        r.AgentConnected = a
    }, this.onAgentTyping = function(a) {
        r.AgentTyping = a
    }, this.onAgentDisconnected = function(a) {
        r.AgentDisconnected = a
    }, this.onMessageReceived = function(a) {
        r.MessageReceived = a
    }, this.onSessionEnded = function(a) {
        r.SessionEnded = a
    }, this.onError = function(a) {
        r.Error = a
    }, this.getCurrentTextEntered = function() {
        return ""
    }
}

function GenesysWebChat(a) {
    function b() {
        q.updateI18nMessages();
        var b = s;
        for (var c in b) b[c] = $(b[c], r);
        b.Input.keypress(function(a) {
            if (13 === a.which && !a.ctrlKey) return f(), a.preventDefault(), a.stopPropagation(), !0;
            if (B) {
                var b = E;
                b.Interval ? b.Timer = 0 : (B && B.sendTyping({
                    isTyping: !0
                }), b.Interval = setInterval(function() {
                    b.Timer += b.TimeInterval, b.Timer >= b.Timeout && (clearInterval(b.Interval), b.Interval = !1, b.Timer = 0, B && B.sendTyping({
                        isTyping: !1
                    }))
                }, b.TimeInterval))
            }
        }).addClass("disabled").attr("disabled", !0), b.Submit.click(function(a) {
            a.preventDefault(), q.startSession()
        }), b.Send.click(function(a) {
            a.preventDefault(), f()
        }), b.Close.click(function(a) {
            a.preventDefault(), q.close()
        }), b.Minimize.click(function(a) {
            a.preventDefault(), z ? q.maximize() : q.minimize()
        }), b.End.click(function(a) {
            a.preventDefault(), q.endSession()
        }), b.ChatEnd.find("button.end-confirm").click(function(a) {
            q.hideConfirmEnd(), q.endSession()
        }), b.ChatEnd.find("button.end-cancel").click(function(a) {
            b.Smokescreen.hide(), q.hideConfirmEnd()
        }), b.ChatFailed.find("button.failed-close").click(function(a) {
            q.hideChatFailed(), q.endSession()
        }), b.ChatFailed.find("button.failed-retry").click(function(a) {
            b.Smokescreen.hide(), q.hideChatFailed(), q.startSession()
        }), b.CoBrowse.click(function() {
            q.startCoBrowse()
        }), s.Title.text(a.title || ""), n = setInterval(function() {
            d()
        }, 500), e(), C.restore(), "slave" !== a.mode && $(window.document.body).append(r)
    }

    function c(a) {
        for (var b = 0; b < I.length; b++)
            if ((a + "").match(I[b])) return !1;
        return !0
    }

    function d() {
        return null !== n ? a.i18n_URL && !u ? t = !1 : (t = !0, clearInterval(n), n = null, !0) : t = !1
    }

    function e() {
        D && (C && C.stopPoll(), C = new D({
            id: a.id,
            apikey: a.apikey,
            tenantName: a.tenantName,
            dataURL: a.dataURL,
            userData: a.userData,
            CSRFURL: a.CSRFURL,
            UserNameDefault: H.UserNameDefault,
            onRestore: function() {
                q.onRestore(), "overlay" !== a.mode && "slave" !== a.mode || (q.startSession(!0), q.open())
            }
        }))
    }

    function f(a) {
        B && (a || s.Input.val()) && B.sendMessage({
            message: a || s.Input.val(),
            type: "text"
        }), a || s.Input.val("")
    }

    function g(b) {
        var d = !1,
            e = "",
            f = (b.sType || "").toLowerCase();
        return c(b.sText) && (d = s.LastMessage, A && "system" !== f && d && b.sName === d.data("name") && (d.hasClass("them") && m(f) || d.hasClass("you") && "customer" === f) && b.iTimestamp && d.data("time") && b.iTimestamp - d.data("time") <= J ? (d.find(".message").append("<p>" + b.sText + "</p>"), i()) : (d = a.templateMessage ? $(a.templateMessage) : $("<div><span class='avatar'></span><span class='name'></span><span class='message'></span></div>"), "injected" === f ? d.addClass("injected") : "system" === f ? (H[b.sText] ? (e = b.sText, b.sText = H[b.sText]) : b.sText = b.sText, H[b.sName] && (e = b.sName, b.sName = H[b.sName]), d.addClass("system"), d.attr({
            "data-message": e,
            "data-message-type": "transcript"
        }), d.addClass("i18n")) : (m(f) ? d.addClass("them").addClass(f) : d.addClass("you"), a.avatars && (m(f) && a.avatars.agent ? d.find(".avatar").addClass(a.avatars.agent) : "client" === f && a.avatars.customer && d.find(".avatar").addClass(a.avatars.customer))), d.find(".name").text(b.sName), b.bHTML ? d.find(".message").html(b.sText) : d.find(".message").text(b.sText), s.Transcript.find(".NewTextBubble").removeClass("NewTextBubble"), d.addClass("NewTextBubble"), s.Transcript.append(d), s.LastMessage = d, b.bNoAnimation ? i() : (d.find(".avatar").hide().fadeIn(), d.find("> p").hide().fadeIn(), i())), z && r.addClass("NewMessage"), b.iTimestamp && (d.find(".time").text(new Date(b.iTimestamp).toLocaleTimeString().split(":").slice(0, 2).join(":")), d.data("time", b.iTimestamp)), d.data("name", b.sName), q.onMessageAdded({
            name: b.sName,
            text: b.sText,
            type: f,
            timestamp: b.iTimestamp
        })), d
    }

    function h(a) {
        a.sText.toLowerCase().match("http://") || a.sText.toLowerCase().match("https://") || (a.sText = "http://" + a.sText), a.sText = "<a href='" + a.sText + "' target='_BLANK'>" + a.sText + "</a>", a.bHTML = !0;
        var b = g(a);
        return b.addClass("notice"), b
    }

    function i() {
        p || (p = !0, s.Transcript.animate({
            scrollTop: s.Transcript[0].scrollHeight
        }, "500", "swing", function() {
            p = !1, s.Transcript[0].scrollTop < s.Transcript[0].scrollHeight && (s.Transcript[0].scrollTop = s.Transcript[0].scrollHeight)
        }))
    }

    function j(a) {
        var a = a || "";
        switch (a.toLowerCase()) {
            case "pre":
                return Transport_REST_WebAPI;
            case "vcc":
                return Transport_REST_HTCC;
            case "pod":
                return Transport_REST_HTCC;
            case "apg":
                return Transport_REST_HTCC;
            case "htcc":
                return Transport_REST_HTCC;
            case "gms":
                return Transport_REST_GMS;
            case "eliza":
                return Transport_REST_ELIZA
        }
    }

    function k() {
        r.find(".i18n").each(function() {
            var a = $(this);
            switch (a.data("message-type")) {
                case "transcript":
                    a.find(".message").html(H[a.data("message")]);
                    break;
                case "placeholder":
                    a.attr("placeholder", H[a.data("message")]);
                    break;
                default:
                    a.text(H[a.data("message")])
            }
        })
    }

    function l(a) {
        return F[a] ? !1 : (F[a] = !0, !0)
    }

    function m(a) {
        return a = a.toLowerCase(), "agent" === a || "supervisor" === a
    }
    var n, o, p, q = this,
        a = a || {},
        r = $(a.template),
        s = {
            Title: ".title",
            Transcript: ".transcript",
            Input: ".input",
            InputContainer: ".input-container",
            IsTyping: a.templateMessage || ".isTyping",
            Form: ".form",
            Submit: ".submit",
            Close: ".close",
            Minimize: ".minimize",
            Send: ".send",
            PopUpWindow: "",
            End: ".end",
            CoBrowse: ".start-cobrowse",
            LastMessage: "",
            ChatEnd: ".confirmation.chat-end",
            ChatFailed: ".confirmation.chat-failed",
            Smokescreen: ".smokescreen"
        },
        t = !1,
        u = !1,
        v = !1,
        w = !1,
        x = !1,
        y = !1,
        z = !1,
        A = !0,
        B = null,
        C = null,
        D = j(a.transport),
        E = {
            Timer: 0,
            Timeout: 2e3,
            TimeInterval: 100,
            Interval: !1
        },
        F = {},
        G = null,
        H = {
            ChatStarted: "Chat Started",
            ChatEnded: "Chat Ended",
            ChatFailed: "Failed to Start Chat Session",
            UserNameDefault: "Anonymous",
            AgentNameDefault: "Agent",
            AgentConnected: "<%Agent%> Connected",
            AgentDisconnected: "<%Agent%> Disconnected",
            AgentTyping: "...",
            AgentPending: "An Agent will be with you shortly",
            AgentUnavailable: "Sorry. There are no agents available. Please try later",
            ChatTitle: "Chat Support",
            ChatEnd: "X",
            ChatClose: "X",
            ChatFormFirstName: "First Name",
            ChatFormLastName: "Last Name",
            ChatFormNickname: "Nickname",
            ChatFormEmail: "Email",
            ChatFormSubject: "Subject",
            ChatFormSubmit: "Start Chat",
            ChatInputPlaceholder: "Type your message here and hit return",
            ChatInputSend: "SEND",
            CoBrowseStart: "Start Cobrowse",
            ChatEndQuestion: "Are you sure you want to end this chat session?",
            ChatEndCancel: "Cancel",
            ChatEndConfirm: "End chat",
            ActionsDownload: "Download transcript",
            ActionsEmail: "Email transcript",
            ActionsPrint: "Print transcript",
            ActionsCoBrowse: "Co-Browse",
            ActionsVideo: "Invite to Video Chat",
            "agent will be with you shortly ...": "An Agent will be with you shortly...",
            system: "system"
        },
        I = a.prefilters || [/\{start\:[0-9]{9}\}/],
        J = a.iMessageGroupingThreshold || 1e5;
    this.startSession = function(b) {
        return q.updateI18nMessages(), q.hideCoBrowse(), this.checkForm() ? (this.clear(), this.hideForm(), b || e(), C.updateOptions(a), C.setFormData && C.setFormData(a.formData), r.addClass("starting-session"), o = setInterval(function() {
            t && (clearInterval(o), x = !1, C.startSession().done(function() {
                if (B = C, a.formData = !1, B.setFormData(a.formData), x) return x = !1, q.reset(), q.endSession(), q.onCancelled(), !1;
                var b = s;
                B.getCurrentTextEntered = function() {
                    return s.Input.val()
                }, B.onMessageReceived(function(a) {
                    if (l(a.index)) {
                        var c = a.party.type;
                        "system" === a.party.name && "External" === a.party.type && (c = "system"), "notice" === a.content.type ? h({
                            sName: a.party.name,
                            sText: a.content.text,
                            sType: c,
                            iTimestamp: a.timestamp
                        }) : g({
                            sName: a.party.name,
                            sText: a.content.text,
                            sType: c,
                            iTimestamp: a.timestamp
                        })
                    }
                    m(a.party.type) && b.IsTyping.hide()
                }), B.onAgentConnected(function(a) {
                    l(a.index) && (m(a.party.type) ? (v = !0, q.onAgentConnected(), y || q.showCoBrowse(), g({
                        sName: a.party.name,
                        sText: H.AgentConnected.replace("<%Agent%>", a.party.name || H.AgentNameDefault),
                        sType: "system",
                        iTimestamp: a.timestamp
                    })) : "Client" === a.party.type && g({
                        sName: a.party.name,
                        sText: "ChatStarted",
                        sType: "system",
                        iTimestamp: a.timestamp
                    }))
                }), B.onAgentDisconnected(function(a) {
                    l(a.index) && (m(a.party.type) ? g({
                        sName: a.party.name,
                        sText: H.AgentDisconnected.replace("<%Agent%>", a.party.name || H.AgentNameDefault),
                        sType: "system",
                        iTimestamp: a.timestamp
                    }) : "Client" === a.party.type && q.endSession(), q.hideCoBrowse(), v = !1, q.onAgentDisconnected()), b.IsTyping.hide()
                }), B.onAgentTyping(function(c) {
                    l(c.index) && m(c.party.type) && (c.isTyping ? (b.IsTyping.addClass("them"), H.AgentTyping = H.AgentTyping.replace("<%Agent%>", c.party.name || H.AgentNameDefault), b.IsTyping.text(H.AgentTyping), b.Transcript.append(b.IsTyping), a.avatars && a.avatars.agent && b.IsTyping.find(".avatar").addClass(a.avatars.agent), b.IsTyping.find(".avatar").hide().fadeIn(), b.IsTyping.find("> p").hide().fadeIn(), i(), b.IsTyping.show(), i()) : b.IsTyping.hide())
                }), B.onSessionEnded(function(a) {
                    var c = !1;
                    a && a.messages && a.messages[0] && a.messages[0].utcTime && (c = a.messages[0].utcTime), g({
                        sName: "",
                        sText: "ChatEnded",
                        sType: "system",
                        iTimestamp: c
                    }), b.Input.addClass("disabled").attr("disabled", !0), b.IsTyping.hide(), b.End.hide(), b.Close.show(), B = null, v = !1, q.hideCoBrowse(), G && G.exitSession(), q.onSessionEnded()
                }), b.Input.removeClass("disabled").attr("disabled", !1), b.Close.hide(), b.End.show(), q.onStart(), r.removeClass("starting-session")
            }).fail(function() {
                q.onStartFailed(), r.removeClass("starting-session")
            }))
        }, 500), this) : this
    }, this.endSession = function() {
        return B && (B.leaveSession(), B = null, C = null, F = {}), s.Input.empty(), s.IsTyping.hide(), s.End.hide(), s.Close.show(), this.onEnd(), this
    }, this.checkForm = function() {
        var b = s.Form,
            c = !0,
            d = ["firstname", "lastname", "nickname", "subject", "email"],
            e = {
                firstname: !1,
                lastname: !1,
                nickname: !1,
                subject: !1,
                email: !1
            },
            f = [];
        return b.find("input").removeClass("error"), a.formData && a.formData !== {} || (a.formData = {}, $(d).each(function() {
            var d = b.find("input[name=" + this + "]");
            e[this] && "" === d.val() && (f.push(d), c = !1), a.formData[this] = d.val()
        }), $(f).each(function() {
            this.addClass("error")
        })), c
    }, this.showForm = function() {
        return s.Form.show(), s.Transcript.hide(), s.InputContainer.hide(), s.Close.show(), this
    }, this.hideForm = function() {
        return s.Form.hide(), s.Transcript.show(), s.InputContainer.show(), this
    }, this.showCoBrowse = function() {
        G && s.CoBrowse.show()
    }, this.hideCoBrowse = function() {
        s.CoBrowse.hide()
    }, this.showConfirmEnd = function() {
        s.ChatEnd.show(), s.Smokescreen.show()
    }, this.hideConfirmEnd = function() {
        s.ChatEnd.hide(), s.Smokescreen.hide()
    }, this.showChatFailed = function() {
        s.ChatFailed.show(), s.Smokescreen.show()
    }, this.hideChatFailed = function() {
        s.ChatFailed.hide(), s.Smokescreen.hide()
    }, this.open = function() {
        return r.show(), this.onOpen(), this
    }, this.close = function() {
        return B && this.endSession(), this.hideConfirmEnd(), this.hideChatFailed(), x = !0, this.clear(), r.hide(), this.showForm(), w = !1, this.maximize(), this.onClose(), this
    }, this.minimize = function() {
        r.removeClass("NewMessage").addClass("Minimized"), z = !0
    }, this.maximize = function() {
        r.removeClass("NewMessage").removeClass("Minimized"), z = !1
    }, this.clear = function() {
        var a = s;
        return a.Input.val(""), a.Form.find("input").val(""), a.Transcript.empty(), a.IsTyping.hide(), this
    }, this.reset = function() {
        this.clear(), this.showForm(), v = !1, w = !1
    }, this.openInNewWindow = function() {
        if (a.popupChatWindowHREF) {
            var b = s,
                c = a.popupChatWindowOptions || "width=420, height=" + screen.height + ", top=0, left=" + (screen.width - 420),
                d = a.popupChatWindowHREF + "?options=" + encodeURIComponent(JSON.stringify(a));
            b.PopUpWindow = window.open(d, "popupChatWindow", c), b.PopUpWindow.focus(), $(b.PopUpWindow).load(function() {
                q.onOpenNewWindow()
            }), $(b.PopUpWindow).unload(function() {
                q.onCloseNewWindow()
            })
        }
    }, this.suspend = function() {
        w || (w = !0, C.stopPoll(), this.onSuspend())
    }, this.resume = function() {
        w && (w = !1, C.startPoll(), this.onResume())
    }, this.updateI18nMessages = function(b) {
        "object" === typeof b && (a.i18n_messages = b), a.i18n_messages ? ($.extend(H, a.i18n_lang && a.i18n_messages[a.i18n_lang] ? a.i18n_messages[a.i18n_lang] : a.i18n_messages), q.onUpdateI18nMessages($.extend({}, H)), k(), u = !0) : a.i18n_URL && $.getJSON(a.i18n_URL, function(b) {
            b && ($.extend(H, a.i18n_lang && b[a.i18n_lang] ? b[a.i18n_lang] : b), q.onUpdateI18nMessages($.extend({}, H)), k(), u = !0)
        })
    }, this.sendFilteredMessage = function(a, b) {
        "string" === typeof a && b instanceof RegExp && (q.addPrefilter(b), f(a))
    }, this.addPrefilter = function(a) {
        if (a) {
            a.length || (a = [a]);
            for (var b = 0; b < a.length; b++) I.push(a[b])
        }
    }, this.clearPrefilters = function() {
        I = []
    }, this.registerCoBrowse = function(a) {
        G = a;
        var b = function(a) {
                a && a.agents && a.agents.length > 0 && (y = !0, q.hideCoBrowse())
            },
            c = function(a) {
                a && a.token && (q.sendFilteredMessage("{start:" + a.token + "}", /\{start\:[0-9]{9}\}/), y = !0, q.hideCoBrowse())
            },
            d = function() {
                y = !1, v && q.showCoBrowse()
            };
        return G.onInitialized.add ? (G.onInitialized.add(b), G.onSessionStarted.add(c), G.onSessionEnded.add(d)) : (G.onInitialized = b, G.onSessionStarted = c, G.onSessionEnded = d), G.markServiceElement(r[0]), G
    }, this.isReady = function() {
        return t
    }, this.isAgentConnected = function() {
        return v
    }, this.destroy = function() {
        r.remove()
    }, this.getTemplate = function() {
        return r
    }, this.injectMessage = function(a, b, c) {
        var a = (a + "").toLowerCase() || "text";
        switch (a) {
            case "text":
                if ("object" === typeof c && c[0] && c[0].outerHTML) sText = c[0].outerHTML;
                else {
                    if ("string" !== typeof c) return !1;
                    sText = c
                }
                break;
            case "html":
                sText = c;
                break;
            default:
                return !1
        }
        return g({
            sName: b,
            sText: sText,
            sType: "injected"
        })
    }, this.startCoBrowse = function() {
        return G ? (G.startSession(), q.hideCoBrowse(), !0) : !1
    }, this.endCoBrowse = function() {
        return G ? (G.exitSession(), !0) : !1
    }, this.onOpen = this.onClose = this.onReady = this.onStart = this.onStartFailed = this.onCancelled = this.onEnd = this.onSuspend = this.onResume = this.onRestore = this.onOpenNewWindow = this.onCloseNewWindow = this.onAgentConnected = this.onAgentDisconnected = this.onUpdateI18nMessages = this.onMessageAdded = this.onSessionEnded = function() {}, b()
}
window.GenesysWebChat = GenesysWebChat;

function _liveChat(brand, country, mobileNumber, currentLanguage, accountId) {
    var chatBox = document.getElementById('chat_iframe');
    if (chatBox !== undefined && chatBox !== null) {
        $(chatBox).css('display', 'block');
        return;
    }
    window.chatVisible = false;
    var brandCode = '';
    switch (brand) {
        case 'KE':
            country = "kenya", brandCode = "K", currentLanguage = "en";
            break;
        case 'UG':
            country = "uganda", brandCode = "U", currentLanguage = "en";
            break;
        case 'GH':
            country = "ghana", brandCode = "G", currentLanguage = "en";
            break;
        case 'ZA':
            country = "southafrica", brandCode = "SA", currentLanguage = "en";
            break;
        case 'NG':
            country = "nigeria", brandCode = "N", currentLanguage = "en";
            break;
        case 'ZM':
            country = "zambia", brandCode = "Z", currentLanguage = "en";
            break;
        case 'CM':
            country = "cameroon", brandCode = "BCM";
            break;
        case 'TZ':
            country = "tanzania", brandCode = "BTZ";
            break;
    }
    var accountNumber = "";
    var skill = "betway" + country;
    var casinoId = 0;
    var skillLanguage = currentLanguage;
    casinoId = casinoId;
    mobileNumber = (mobileNumber === '' || mobileNumber === undefined) ? '' : mobileNumber;
    accountId = (accountId === '' || accountId === undefined || accountId === constId.emptyGuid) ? '' : accountId;
    var iframeSource = "https://chat.betwayafrica.com/" +
        "?skill=" + skill +
        "&casinoid=" + casinoId +
        "&referringurl=" +
        "&brandcode=" + brandCode +
        "&accountreference=UNKNOWN" +
        "&accountNumber=" + mobileNumber +
        "&ismobile=UNKNOWN" +
        "&languagecode=" + skillLanguage +
        "&isvip=false" +
        "&email=" +
        "&dentifier=UNKNOWN" +
        "&ipaddress=UNKNOWN" +
        "&countrycode=" + brand +
        "&accountid=" + accountId +
        "&primarycontact=phone" +
        "&name=" + name +
        "&phone=" + mobileNumber +
        "&primarycolor=28a745" +
        "&econdarycolor=333333" +
        "&inclient=false"
    var iframe = document.createElement('iframe');
    iframe.setAttribute('src', iframeSource);
    iframe.setAttribute('id', 'chat_iframe');
    iframe.setAttribute('class', 'chat-iframe');
    document.body.appendChild(iframe);
    window.addEventListener('message', function(e) {
        var command = e.data;
        if (command === 'close') {
            toggleChat();
        } else if (command === 'minimize') {
            hideChat();
        }
    });

    function toggleChat() {
        if (!window.chatVisible) {
            document.body.appendChild(iframe);
        } else {
            var chat_iframe = document.getElementById('chat_iframe');
            document.body.removeChild(chat_iframe);
        }
        window.chatVisible = !window.chatVisible;
    }

    function hideChat() {
        var chatBox = document.getElementById('chat_iframe');
        if (chatBox !== undefined) {
            $(chatBox).css('display', 'none');
            return;
        }
    }
}
window.casinoChatIsActive = false;
window.allowChatSend = false;
var x = screen.width,
    y = screen.height;
var isMobileDevice = x <= 425;;
$(document).ready(function() {
    $(window).resize(function() {
        resizeSlick();
    });
    setTimeout(function() {
        $('.sportsList').not('.slick-initialized').slick({
            dots: false,
            infinite: false,
            speed: 300,
            arrows: true,
            responsive: [{
                breakpoint: 6000,
                settings: {
                    slidesToShow: 25,
                    slidesToScroll: 25,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 4100,
                settings: {
                    slidesToShow: 20,
                    slidesToScroll: 20,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 3000,
                settings: {
                    slidesToShow: 18,
                    slidesToScroll: 18,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 2560,
                settings: {
                    slidesToShow: 16,
                    slidesToScroll: 16,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 2100,
                settings: {
                    slidesToShow: 14,
                    slidesToScroll: 14,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 1920,
                settings: {
                    slidesToShow: 11,
                    slidesToScroll: 11,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 1440,
                settings: {
                    slidesToShow: 10,
                    slidesToScroll: 10,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 8,
                    slidesToScroll: 8,
                    infinite: false,
                    arrows: true,
                    dots: false
                }
            }, {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 6
                }
            }, {
                breakpoint: 600,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 5,
                    arrows: false
                }
            }, {
                breakpoint: 425,
                settings: "unslick"
            }]
        });
    }, 1);
});
$(document).ready(function() {
    $('#sporttype').fadeIn(8000);
    window.setTimeout("gotoSport()", 20);
});

function gotoSport() {
    var element = $(".mSport.active");
    if (element !== null && element.length > 0) {
        var currentIndex = $(".mSport.active").attr('data-slick-index');
        $('.sportsList').slick("slickGoTo", currentIndex);
        if (window.innerWidth < 425) {
            scrollToActiveSportTile();
        }
        if (!isMobileScreen()) {
            setTimeout(function() {
                var pos = $(".mSport.active").offset().left - 50;
                console.log('scrolling', pos);
                $('.sportsList').animate({
                    scrollLeft: pos
                }, 1000, 'easeOutQuad');
            }, 200);
        }
    }
}

function scrollToActiveSportTile() {
    var active = $(".mSport.active");
    var left = active.position().left;
    var currScroll = $(".sportsList").scrollLeft();
    var contWidth = $('.sportsList').width() / 2;
    var activeOuterWidth = active.outerWidth() / 2;
    left = left + currScroll - contWidth + activeOuterWidth;
    $('.sportsList').animate({
        scrollLeft: left
    }, 100);
}

function resizeSlick() {
    var viewportWidth = $(window).width();
    if (viewportWidth > 425) {
        populateSportSlider();
    } else {
        gotoSport();
    }
}

function populateSportSlider() {
    $('.sportsList').not('.slick-initialized').slick({
        dots: false,
        infinite: false,
        speed: 300,
        arrows: true,
        responsive: [{
            breakpoint: 6000,
            settings: {
                slidesToShow: 25,
                slidesToScroll: 25,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 4100,
            settings: {
                slidesToShow: 20,
                slidesToScroll: 20,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 3000,
            settings: {
                slidesToShow: 18,
                slidesToScroll: 18,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 2560,
            settings: {
                slidesToShow: 16,
                slidesToScroll: 16,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 2100,
            settings: {
                slidesToShow: 14,
                slidesToScroll: 14,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 1920,
            settings: {
                slidesToShow: 12,
                slidesToScroll: 12,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 1440,
            settings: {
                slidesToShow: 11,
                slidesToScroll: 11,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 1200,
            settings: {
                slidesToShow: 8,
                slidesToScroll: 8,
                infinite: false,
                arrows: true,
                dots: false
            }
        }, {
            breakpoint: 1024,
            settings: {
                slidesToShow: 6,
                slidesToScroll: 6
            }
        }, {
            breakpoint: 600,
            settings: {
                slidesToShow: 6,
                slidesToScroll: 5,
                arrows: false,
            }
        }, {
            breakpoint: 425,
            settings: "unslick"
        }]
    });
    gotoSport();
}

function HighlightExactMatches() {
    if ($("#searchTerm")[0] === null || $("#searchTerm")[0].innerText === null)
        return;
    var searchedval = $("#searchTerm")[0].innerText;
    for (var i = 0; i < $(".outcome-title").length; i++) {
        var currentOutcomeTitle = ($(".outcome-title")[i].childNodes[0].innerText);
        if (currentOutcomeTitle.toLowerCase() === searchedval.toLowerCase()) {
            $(".outcome-title")[i].childNodes[0].innerHTML = "<b>" + currentOutcomeTitle + "</b>";
        }
    }
};
var fasearch = false;
var currentTabId = '00000000-0000-0000-0000-000000000000';
var timeout;
var searchTimeout;
$(document).ready(function() {
    $(window).unbind("scroll", marketGrouping.scrollBind);
    localStorage.removeItem("00000000-0000-0000-da7a-000000710001accordPageNum");
});
var marketGrouping = {
    expandGroups: function(id) {
        if ($('#selectButton').hasClass('open')) {
            $('#' + id).hide();
            $('#selectButton').removeClass('open').attr('aria-expanded', 'false');
        } else {
            $('#' + id).show();
            $('#selectButton').addClass('open').attr('aria-expanded', 'true');
        }
    },
    expandGroups1: function(id) {
        if ($('#selectButton1').hasClass('open')) {
            $('#' + id).hide();
            $('#selectButton1').removeClass('open').attr('aria-expanded', 'false');
        } else {
            $('#' + id).show();
            $('#selectButton1').addClass('open').attr('aria-expanded', 'true');
        }
    },
    toggleMultimarketAccordion: function(id, market) {
        if (id === 'anchor') {
            if ($('#accordion.widget-angle').hasClass('fa-angle-up')) {
                $('#accordion.fa').removeClass('fa-angle-up').addClass('fa-angle-down');
            } else {
                $('#accordion.fa').removeClass('fa-angle-down').addClass('fa-angle-up');
            }
        }
        if (market === 'outrights') {
            var spans = $(".accordionArrows");
            if ($("#" + id).prev().find(spans).hasClass('fa-angle-down')) {
                $("#" + id).prev().find(spans).removeClass('fa-angle-down').addClass('fa-angle-up');
                $("#" + id).addClass('in');
            } else {
                $("#" + id).prev().find(spans).removeClass('fa-angle-up').addClass('fa-angle-down');
                $("#" + id).removeClass('in');
            }
        } else {
            if (currentTabId === '00000000-0000-0000-da7a-000000710003') {
                $('#_AllOutcomes .search-link').each(function() {
                    $(this).find(".acc-header123").removeClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-up').addClass('fa-angle-down');
                });
            }
            if ($("#" + id).hasClass('fa-angle-up')) {
                $("#" + id).removeClass('fa-angle-up').addClass('fa-angle-down');
            } else {
                $("#" + id).removeClass('fa-angle-down').addClass('fa-angle-up');
            }
        }
        setTimeout(function() {
            var hasOpen = false;
            $('.acc-header123').each(function(i, obj) {
                if (obj.className.indexOf('collapsing') > -1 || obj.className.indexOf('in') > -1) {
                    hasOpen = true;
                }
            });
            if (hasOpen) {
                $('#expand-Acc').css('display', 'block').attr('onclick', 'events.closeAccordions()').attr('value', 'Collapse').text('Collapse');
            } else {
                $('#expand-Acc').css('display', 'block').attr('onclick', 'events.openAccordions()').attr('value', 'Expand').text('Expand');
            }
        }, 500);
    },
    bindListeners: function() {
        $(".mg-tab, .button").click(function() {
            $(".mg-tab span,.mg-tab select").removeClass("selected");
            $(this).children("span, select").addClass("selected");
            var btnId = $(this).attr("id");
            if (btnId === "selectButton") {
                btnId = $("#extra-groups .selected").attr("id");
            }
        });
    },
    FilterTabs: function(Id, outcomeGroupModelsCount) {
        currentTabId = Id;
        if (typeof buildABet != 'undefined' && buildABet.inBuildABetTab()) {
            buildABet.setBuildABetActive(false);
            if (Id !== '00000000-0000-0000-da7a-000000710003') SetOutcomeButtons();
        }
        var loadedAllMarkets = localStorage.getItem("loadedAllMarkets");
        $('.search-link').show();
        $("#multimarketTabPages #_AllOutcomes .accordionArrows").removeClass('fa-angle-up').addClass('fa-angle-down');
        var currentTab = '#multimarketTabPages #_AllOutcomes .acc-header123';
        $(currentTab).removeClass("in");
        $("#empty-group").hide();
        $('#empty-favorite-group').hide();
        var visibleCounter = 0;
        var tabCounter = 0;
        if (Id !== "00000000-0000-0000-da7a-000000710001" && Id !== "00000000-0000-0000-da7a-000000710002" && Id !== "00000000-0000-0000-da7a-000000710003" && Id !== "00000000-0000-0000-da7a-000000710099") {
            $("#loadMore").hide();
            $('#_AllOutcomes .search-link').each(function() {
                if ($(this).attr("data-marketgroups").indexOf(Id) === -1) {
                    $(this).hide();
                } else {
                    tabCounter++;
                    visibleCounter++;
                    if (tabCounter <= 5) {
                        $(this).find(".acc-header123").addClass('in');
                        $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                    }
                }
            });
            if (visibleCounter === 0) {
                $("#empty-group").show();
                $("#empty-group .alert-box").show();
            }
            return true;
        }
        if (Id === "00000000-0000-0000-da7a-000000710002") {
            tabCounter = 0;
            var popularMarketsLength = typeof outcomeGroupModelsCount == "undefined" || isNaN(outcomeGroupModelsCount) ? 10 : parseInt(outcomeGroupModelsCount);
            $('#_AllOutcomes .search-link').each(function() {
                tabCounter++;
                visibleCounter++;
                if (tabCounter <= 5) {
                    $(this).find(".acc-header123").addClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                }
                if (tabCounter > popularMarketsLength) {
                    $(this).hide();
                }
            });
            $(window).unbind('scroll');
            $("#loadMore").hide();
            return true;
        }
        if (Id === "00000000-0000-0000-da7a-000000710001" && (typeof(loadedAllMarkets) == "undefined" || loadedAllMarkets == null || loadedAllMarkets == "false")) {
            tabCounter = 0;
            $('#_AllOutcomes .search-link').each(function() {
                tabCounter++;
                visibleCounter++;
                if (tabCounter <= 5) {
                    $(this).find(".acc-header123").addClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                }
                var currentPage = parseInt(localStorage.getItem(Id + 'accordPageNum'));
                if (isNaN(currentPage) || typeof(currentPage) == 'undefined' || currentPage == null) {
                    currentPage = 1;
                }
                var pageSize = localStorage.getItem('accordMaxPageSize');
                if ((typeof(pageSize) == 'undefined' || pageSize == null) || isNaN(parseInt(pageSize)) || parseInt(pageSize) <= 0) {
                    pageSize = 20;
                } else {
                    pageSize = parseInt(pageSize);
                }
                if (currentPage = 1) {
                    pageSize = 30;
                }
                if (tabCounter > (currentPage * pageSize)) {
                    $(this).hide();
                }
            });
            $(window).unbind('scroll');
            var isLastLazyLoaded = localStorage.getItem("lastIsLazyLoaded");
            if (isLastLazyLoaded == null || typeof(isLastLazyLoaded) == "undefined") {
                $("#loadMore").show();
            } else if (isLastLazyLoaded == "true") {
                $("#loadMore").hide();
            }
            return true;
        }
        if (Id === "00000000-0000-0000-da7a-000000710099") {
            tabCounter = 0;
            applyFavorites();
            $("#loadMore").hide();
            $('#_AllOutcomes .search-link').hide();
            $('#_AllOutcomes .search-link[data-is-markettype-favorite="true"]').each(function() {
                tabCounter++;
                visibleCounter++;
                $(this).show();
                if (tabCounter <= 5) {
                    $(this).find(".acc-header123").addClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                }
                var pageSize = localStorage.getItem('accordMaxPageSize');
                if ((typeof(pageSize) == 'undefined' || pageSize == null) || isNaN(parseInt(pageSize)) || parseInt(pageSize) <= 0) {
                    pageSize = 20;
                } else {
                    pageSize = parseInt(pageSize);
                }
                if (visibleCounter == 0) {
                    $('#empty-favorite-group').hide();
                }
            });
            $(window).unbind('scroll');
            this.showOnlyFavorites();
            return true;
        }
        if (Id === '00000000-0000-0000-da7a-000000710003' && typeof buildABet != 'undefined') {
            tabCounter = 0;
            buildABet.setBuildABetActive(true);
            buildABet.applyAvailableSelections();
            $('#_AllOutcomes .search-link').each(function() {
                tabCounter++;
                if (tabCounter > 1) {
                    $(this).find(".acc-header123").removeClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-up').addClass('fa-angle-down');
                } else {
                    $(this).find(".acc-header123").addClass('in');
                    $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                }
            });
            $("#loadMore").hide();
            return true;
        }
        $('#_AllOutcomes .search-link').each(function() {
            tabCounter++;
            visibleCounter++;
            if (tabCounter <= 5) {
                $(this).find(".acc-header123").addClass('in');
                $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
            } else {
                return true;
            }
        });
    },
    addToCurrentMarketTypeDictionary: function(_eventId, _data) {
        var currentEventId = localStorage.getItem("_eventId");
        if (typeof(currentEventId) != 'undefined' && currentEventId != _eventId) {
            marketGrouping.listCurrentMarketTypes = [];
            localStorage.removeItem("_multiMarketTypesData");
        }
        $(_data).each(function() {
            var marketTypeId = $(this).attr("data-markettype");
            var marketTitle = $(this).attr("data-marketTitle");
            var marketSortIndex = $(this).attr("data-market-sortindex");
            if ((marketTitle != null && typeof(marketTitle) != "undefined") && (marketTypeId != null && typeof(marketTypeId) != "undefined")) {
                marketGrouping.listCurrentMarketTypes.push({
                    marketTypeId: marketTypeId,
                    marketSortIndex: marketSortIndex,
                    marketTitle: marketTitle
                });
            }
        });
    },
    retrieveEventMarketGroupsForUpdate: function(pageNum) {
        try {
            var _eventId = $('#multimarketTabPages').parent().attr('id');
            var _FeedDataTypeId = $("#" + _eventId).attr('data-markettypecategory');
            return pat.get("/Bet/EventMultiMarket", {
                'eventId': _eventId,
                'FeedDataTypeId': _FeedDataTypeId,
                'isPopular': false,
                'pageNum': pageNum,
                'isFullView': false
            }).done(function(data) {
                if (data == null || $("div", data).length <= 20) {
                    $(window).unbind('scroll');
                    $("#loaderText").html("End of results");
                    $("#loader").fadeOut(850);
                    $("#loadMore").hide();
                    localStorage.setItem("lastIsLazyLoaded", true);
                    return;
                }
                $("#_AllOutcomes .container-panel").append(data);
                marketGrouping.addToCurrentMarketTypeDictionary(_eventId, $(data, '#_AllOutcomes .search-link'));
                marketGrouping.invokePageUpdate();
                $("#loader").hide();
                $("#loadMore").show();
            });
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => retrieveEventMarketGroupsForUpdate()", details: ' + e);
            $("#loader").hide();
            $("#loadMore").show();
        }
    },
    invokePageUpdate: function() {
        try {
            var _id = localStorage.getItem("accordionTabID");
            if (typeof(_id) == "undefined" || _id == null) return;
            var tabCounter = 0;
            var visibleCounter = 0;
            var pageSize = localStorage.getItem('accordMaxPageSize');
            if ((typeof(pageSize) == 'undefined' || pageSize == null) || isNaN(parseInt(pageSize)) || parseInt(pageSize) <= 0) {
                pageSize = 20;
            } else {
                pageSize = parseInt(pageSize);
            }
            var _pageNum = 0;
            var currentPage;
            currentPage = parseInt(localStorage.getItem(_id + 'accordPageNum'));
            if (typeof(currentPage) != 'undefined' && currentPage >= 1) {
                _pageNum = currentPage + 1;
                localStorage.setItem(_id + 'accordPageNum', _pageNum);
            } else {
                _pageNum = 1;
                localStorage.setItem(_id + 'accordPageNum', _pageNum);
            }
            var pageStart = 0;
            var pageEnd = (pageSize * _pageNum);
            if (_id === "00000000-0000-0000-da7a-000000710001") {
                var txt = $('#mtSearch').val();
                $('#_AllOutcomes .search-link').each(function() {
                    tabCounter++;
                    if (txt != "" && typeof(txt) != 'undefined') {
                        if ($(this).attr("data-marketTitle").toUpperCase().indexOf(txt.toUpperCase()) != -1) {
                            $(this).show();
                            if ($('#mtSearch').val()) {
                                $("#searchclear").show();
                            } else {
                                $("#searchclear").hide();
                            }
                        } else {
                            $(this).hide();
                        }
                    } else {
                        if (tabCounter > pageStart && tabCounter <= pageEnd) {
                            visibleCounter++;
                            $(this).show();
                            if (tabCounter <= 15 && _pageNum <= 1) {
                                $(this).find(".acc-header123").addClass('in');
                                $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                            }
                        } else {
                            $(this).hide();
                        }
                    }
                });
            } else if (_id == "00000000-0000-0000-da7a-000000710099") {
                marketGrouping.showOnlyFavorites();
            } else if (_id !== "00000000-0000-0000-da7a-000000710001" && _id !== "00000000-0000-0000-da7a-000000710002") {
                $('#_AllOutcomes .search-link').each(function() {
                    if ($(this).attr("data-marketgroups").indexOf(_id) === -1) {
                        $(this).hide();
                    } else {
                        tabCounter++;
                        if (tabCounter > pageStart && tabCounter <= pageEnd) {
                            visibleCounter++;
                            $(this).show();
                            if (tabCounter <= 5) {
                                $(this).find(".acc-header123").addClass('in');
                                $(this).find(".accordionArrows").removeClass('fa-angle-down').addClass('fa-angle-up');
                            }
                        } else {
                            $(this).hide();
                        }
                    }
                });
                if (visibleCounter === 0) {
                    $("#empty-group").show();
                    $("#empty-group .alert-box").show();
                }
            }
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => invokePageUpdate()", details: ' + e);
        }
    },
    scrollBind: function() {
        try {
            clearTimeout(timeout);
            timeout = setTimeout(function() {
                var heightTollerance = 2;
                var scrollHeight = Math.trunc($(this).scrollTop() + $(this).height());
                var shouldLoad = false;
                var buildABetActive = typeof buildABet !== 'undefined' && buildABet.isBuildABetActive();
                if (isMobileDevice == false && (scrollHeight < $(document).height() + heightTollerance && scrollHeight > $(document).height() - heightTollerance) && !buildABetActive) {
                    shouldLoad = true;
                } else if (isMobileDevice && ($(this).scrollTop() > ($("#groupViewContainer")[0].scrollHeight / 2)) && !buildABetActive) {
                    shouldLoad = true;
                }
                if (shouldLoad) {
                    $(window).unbind('scroll');
                    $("#loadMore").hide();
                    $("#loader").fadeIn(300);
                    var _id = localStorage.getItem("accordionTabID");
                    if (typeof(_id) == "undefined" || _id == null) return;
                    var currentPage = 1;
                    currentPage = parseInt(localStorage.getItem(_id + 'accordPageNum'));
                    if (typeof(currentPage) != 'undefined' && currentPage > 1) {
                        marketGrouping.retrieveEventMarketGroupsForUpdate(currentPage);
                    } else {
                        marketGrouping.invokePageUpdate();
                        $("#loadMore").show();
                        $("#loader").hide();
                    }
                }
            }, 50);
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => scrollBind()", details: ' + e);
        }
    },
    ApplyLazyLoad: function() {
        try {
            var _id = localStorage.getItem("accordionTabID");
            if (typeof(_id) == "undefined" || _id == null) return;
            $(window).bind("scroll", marketGrouping.scrollBind);
            var currentPage = parseInt(localStorage.getItem(_id + 'accordPageNum'));
            if (isNaN(currentPage) || typeof(currentPage) == 'undefined' || currentPage == null) {
                marketGrouping.invokePageUpdate();
            }
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => ApplyLazyLoad()", details: ' + e);
        }
    },
    listAllMarketTypes: [],
    listCurrentMarketTypes: [],
    searchMarkets: function(searchTxt) {
        var matchCountCurr = 0;
        var matchCountAll = 0;
        try {
            $(window).unbind('scroll');
            marketGrouping.listCurrentMarketTypes.forEach(function(marketType) {
                if (marketType.marketTitle.toUpperCase().indexOf(searchTxt.toUpperCase()) != -1) {
                    matchCountCurr++;
                }
            });
            marketGrouping.listAllMarketTypes.forEach(function(marketType) {
                if (marketType.MarketTitle.toUpperCase().indexOf(searchTxt.toUpperCase()) != -1) {
                    matchCountAll++;
                }
            });
            if (matchCountCurr != matchCountAll && matchCountAll > 0) {
                var _eventId = $('#multimarketTabPages').parent().attr('id');
                var _FeedDataTypeId = $("#" + _eventId).attr('data-markettypecategory');
                pat.get("/Bet/EventMultiMarket", {
                    'eventId': _eventId,
                    'FeedDataTypeId': _FeedDataTypeId,
                    'isPopular': false,
                    'searchCriteria': $('#mtSearch').val().toLowerCase(),
                    'isFullView': false
                }).done(function(data) {
                    $("#_AllOutcomes .container-panel").html(data);
                    marketGrouping.FilterTabs("00000000-0000-0000-da7a-000000710001");
                    if (fasearch) {
                        $("#mtSearch").focus();
                    }
                    $('.search-link').each(function() {
                        if ($(this).attr("data-marketTitle").toUpperCase().indexOf(searchTxt.toUpperCase()) != -1) {
                            $(this).show();
                        } else {
                            $(this).hide();
                        }
                    });
                    homePage.closeOverlay();
                });
                console.log("Match not found, making svr request. Current = " + matchCountCurr + " All = " + matchCountAll);
            } else {
                $("#_AllOutcomes .container-panel").html(localStorage.getItem("_multiMarketTypesData"));
                marketGrouping.FilterTabs("00000000-0000-0000-da7a-000000710001");
                var isLastLazyLoaded = localStorage.getItem("lastIsLazyLoaded");
                if (isLastLazyLoaded == null || typeof(isLastLazyLoaded) == "undefined") {
                    $("#loadMore").show();
                } else if (isLastLazyLoaded == "true") {
                    $("#loadMore").hide();
                }
                console.log("Match found, just filter page. Current = " + matchCountCurr + " All = " + matchCountAll);
                homePage.closeOverlay();
            }
        } catch (e) {
            console.log('An unexpected error occurred in "marketGrouping => searchMarkets()", details: ' + e);
        }
    },
    resetGroups: function() {
        buttonGroupsCount = 15;
        var btnelements = $('.mg-tabs').find('.button');
        var dropelements = $('.mg-tabs').find('li');
        var allElements = [];
        var hasBuildABet = false;
        btnelements.each(function() {
            if ($(this).attr('id') == constId.BuildABet)
                hasBuildABet = true;
            if (this.id !== 'selectButton') {
                var bInstance = {
                    id: $(this).attr('id'),
                    title: $(this).children().first().text(),
                    isSelected: $(this).children().first().hasClass('selected'),
                    className: $(this).attr('class')
                };
                allElements.push(bInstance);
            }
        });
        if (screen.width <= 768 && isMobileMultiMarketLayout) {
            buttonGroupsCount = hasBuildABet ? 1 : 0;
        }
        dropelements.each(function() {
            var bInstance = {
                id: $(this).attr('id'),
                title: $(this).text(),
                isSelected: $(this).hasClass('selected')
            };
            allElements.push(bInstance);
        });
        var buttonsContainer = document.getElementsByClassName('mg-tabs')[0];
        var addDropDown = allElements.length > buttonGroupsCount;
        $(buttonsContainer).empty();
        for (var i = 0; i < buttonGroupsCount; i++) {
            if (i === allElements.length) {
                return;
            }
            var buttonElement = allElements[i];
            if (buttonElement.id !== '') {
                var spandiv = document.createElement('div');
                spandiv.id = buttonElement.id;
                spandiv.className = buttonElement.className;
                if (!buttonElement.className) spandiv.className = 'mg-tab tab-' + (i + 1).toString() + " button";
                spandiv.setAttribute('onClick', "switchTab('" + buttonElement.id + "');marketGrouping.closeDd();");
                var span = document.createElement('span');
                span.textContent = buttonElement.title;
                language.translateAtRuntime(span, "ContentHeaders", {
                    "data-translate-key": language.generateKey(buttonElement.title)
                });
                if (buttonElement.isSelected)
                    $(span).addClass('selected');
                spandiv.appendChild(span);
                buttonsContainer.appendChild(spandiv);
            }
        }
        if (addDropDown) {
            var selectdiv = document.createElement('div');
            selectdiv.className = 'mg-tab mg-dropdown';
            selectdiv.id = 'selectButton';
            selectdiv.setAttribute('type', 'button');
            selectdiv.setAttribute('aria-expanded', 'true');
            selectdiv.setAttribute('onclick', "marketGrouping.expandGroups('extra-groups');");
            var selectDivSpan = document.createElement('span');
            selectDivSpan.textContent = "More...";
            selectdiv.appendChild(selectDivSpan);
            var select = document.createElement('ul');
            select.setAttribute('role', 'menu');
            select.setAttribute('id', 'extra-groups');
            select.setAttribute('aria-labelledby', "selectButton");
            select.className = 'dropdown-menu';
            for (var k = buttonGroupsCount; k < allElements.length; k++) {
                var liGroupItem = allElements[k];
                if (liGroupItem.id !== '' && liGroupItem.id !== 'selectButton') {
                    var liOption = document.createElement('li');
                    liOption.id = liGroupItem.id;
                    liOption.textContent = liGroupItem.title;
                    if (liGroupItem.isSelected) {
                        $(selectdiv).find('span').first().addClass('selected');
                        $(liOption).addClass('selected');
                        $(selectdiv).find('span').first().text(liGroupItem.title);
                    }
                    liOption.setAttribute('onclick', "switchTab('" + liGroupItem.id + "', true); marketGrouping.expandGroups('extra-groups'); ");
                    select.appendChild(liOption);
                }
            }
            selectdiv.appendChild(select);
            buttonsContainer.appendChild(selectdiv);
        }
    },
    closeDd: function() {
        $('#extra-groups').hide();
        $('#selectButton').removeClass('open');
        $('#selectButton').attr('aria-expanded', 'false');
    },
    SetRegionFilterAndReload: function(regionId, isMultiMarket) {
        filterLeaguesByRegionId(regionId, isMultiMarket, '@Model.breadCrumbFeedDataTypeId');
    },
    PinLiveStreamVideo: function(url, isMobile) {
        $.session.set("url", url);
        $.session.set("isMobile", isMobile);
    },
    handleSBVgrouping: function() {
        var marketTypeIds = [];
        $('[data-groupsbv="True"]').each(function() {
            marketTypeIds.push($(this).data().markettype);
        });
        marketTypeIds.forEach(item => {
            var marketTypeGroup = $('[data-markettype="' + item + '"]');
            if (marketTypeGroup.length > 1) {
                var outcomes = "";
                for (var x = 1; x < marketTypeGroup.length; x++) {
                    outcomes += $($(marketTypeGroup)[x]).find('.panel-body').html();
                    $($(marketTypeGroup)[x]).remove();
                }
                $($(marketTypeGroup)[0]).find('.panel-body').append(outcomes);
            }
        });
    },
    showOnlyFavorites: function() {
        if (isAccountFavoriteEnabled) {
            var allMarketGroupingParents = document.querySelectorAll('div[data-markettype-favorite-parent]');
            var accountFavoritesStorage = localStorage.getItem('accountFavorites');
            var showCount = 0;
            if (accountFavoritesStorage != null && accountFavoritesStorage != '') {
                if (allMarketGroupingParents.length > 0) {
                    for (var i = 0; i < allMarketGroupingParents.length; i++) {
                        if (allMarketGroupingParents[i].getAttribute('data-is-markettype-favorite') == "true") {
                            allMarketGroupingParents[i].style.display = '';
                            showCount++;
                        } else {
                            allMarketGroupingParents[i].style.display = 'none';
                        }
                    }
                }
            }
            if (showCount == 0) {
                $('#empty-favorite-group').show();
            } else {
                $('#empty-favorite-group').hide();
            }
        }
    },
    removeDuplicateMarkets: function() {
        var marketIds = [];
        $('#_AllOutcomes div .row.search-link').each(function() {
            marketIds.push($(this).data().market);
        });
        for (var i = 0; i < marketIds.length; i++) {
            var market = $('.row[data-market="' + marketIds[i] + '"]');
            if (market.length > 1) {
                market[1].remove();
            }
        }
    }
};
$(document).ready(function() {
    var counter = 0;
    $('#_AllOutcomes .acc-header123').each(function(i) {
        counter++;
        if (counter <= 5) {
            $(this).addClass('in');
        }
    });
    var toggleCounter = 0;
    $('#_AllOutcomes .accordionArrows').each(function(i) {
        toggleCounter++;
        if (toggleCounter <= 5) {
            $(this).removeClass('fa fa-angle-down');
            $(this).addClass('fa fa-angle-up');
        }
    });
    window.addEventListener("resize", marketGrouping.resetGroups);
    marketGrouping.resetGroups();
    marketGrouping.bindListeners();
    if ($("#multi-head").hasClass('inPlayBg')) {
        $(".event-heading").css('line-height', '27px');
    }
    if ((document.location.pathname.indexOf("/bet/eventmultimarket") && $('#multi-head').hasClass('inPlayBg')) === true) {
        $("#mainBody").addClass("yellow");
    } else {
        $("#mainBody").removeClass("yellow");
    }
});;
var fica = {
    toggleFICAUploadActive: function(fileTypeValid, fileSizeValid) {
        var filesSelected = false;
        var proofId = document.getElementById("proofIdFile").innerHTML;
        var proofIdMobile = document.getElementById("proofIdFileMobile").innerHTML;
        (proofId !== "" && proofId !== noFileSelectedText) ? filesSelected = true: "";
        (proofIdMobile !== "" && proofIdMobile !== noFileSelectedText) ? filesSelected = true: "";
        (filesSelected && proofIdMobileSize && fileTypeValid && fileSizeValid) ? (document.getElementById("fica-submission-button-mobile").disabled = false, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button-mobile").disabled = true, document.getElementById("fileuploads").className = "fica-subheading-disabled");
        (filesSelected && proofIdSize && fileTypeValid && fileSizeValid) ? (document.getElementById("fica-submission-button").disabled = false, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button").disabled = true, document.getElementById("fileuploads").className = "fica-subheading-disabled");
    },
    toggleDocumentUploadActive: function(fileTypeValid, fileSizeValid, btnSubmitElement, fileNameDiv) {
        var documentUpload = document.getElementById(fileNameDiv).innerHTML;
        var filesSelected = documentUpload !== "" && documentUpload !== noFileSelectedText;
        document.getElementById(btnSubmitElement).disabled = !(filesSelected && fileTypeValid && fileSizeValid);
    },
    setDisplay: function(elementId, text) {
        var filename = text.split("\\");
        text.length === 0 ? document.getElementById(elementId).innerHTML = noFileSelectedText : ((filename.length > 0 && filename.constructor === Array) ? (text = filename[filename.length - 1], document.getElementById(elementId).innerHTML = text) : "");
        fica.toggleFICAUploadActive();
    },
    closeOverlay: function() {
        jQuery(".loading").hide();
        jQuery("#modalloading").hide();
    },
    showFICAPopup: function() {
        fica.BindFileUploads();
        $("#fica-popup-modal").modal({
            backdrop: "static",
            keyboard: false
        });
    },
    VerifyFicaDetails: function() {
        pat.get("/Account/VerifyFicaDetails").done(function(data) {
            window.promptFICANotification = (data.toLowerCase() === 'true');
        });
    },
    showFICAStatusConfirmation: function() {
        if (window.promptFICANotification && !checkForLite()) {
            $('#modal-container-ficastatus-confirmation').modal().show();
        }
    },
    FicaUploadFormDisplay: function(isOperaMini) {
        if (!checkForLite()) {
            pat.post("/Account/SubmitFICADetails", null, {
                dataType: "html"
            }).done(function(data) {
                if (typeof isOperaMini !== 'undefined' && isOperaMini.toLowerCase() === 'true') {
                    $('#OperaminiModalHolderContent').html(data);
                    $('#OperaminiModalHolderContent').find('#fica-modal,#fica-popup-modal').attr('id', '').removeClass('modal');
                    $('html,body').removeClass('modal-open');
                    $('#main').css('margin-top', '0px');
                    $('#OperaminiModalHolder').show();
                    $('#ficaModal').hide();
                } else if (docUploadEnabled === 'True') {
                    location.href = '/DocumentUpload';
                } else {
                    $('#modal-container-ficastatus-upload').html(data).modal();
                }
            });
        } else {
            if (docUploadEnabled) {
                location.href = '/DocumentUpload';
            } else {
                ajax.post("/Account/SubmitFICADetails", null, ficaUploadFormDisplayCallBack)
            }
        }
    },
    DelayFicaNotification: function(isOperaMini) {
        if (typeof isOperaMini !== 'undefined' && isOperaMini.toLowerCase() === 'true') {
            window.location.href = '/';
        } else {
            pat.post("/Account/DelayFICANotification", null, {
                dataType: "html"
            }).done(function(data) {
                window.promptFICANotification = false;
            });
        }
    },
    ficaButtonBack: function() {
        $('#OperaminiModalHolder').hide();
        $('#ficaModal').show();
    },
    submitFicaDetailsAsync: function(isMobile, isOperaMini, event) {
        if (isOperaMini.toLowerCase() === "false") {
            var dataString = null;
            var divToUse;
            isMobile === "true" ? divToUse = $("#ficaProofMobile") : divToUse = $("#ficaProof");
            var action = divToUse.attr("action");
            homePage.showOverlay();
            var contentType = "";
            var processData = "";
            divToUse.attr("enctype") === "multipart/form-data" ? (dataString = new FormData(divToUse.get(0)), contentType = false, processData = false) : "";
            $.ajax({
                type: "POST",
                url: action,
                data: dataString,
                dataType: "html",
                contentType: contentType,
                processData: processData,
                success: function(result) {
                    isOperaMini.toLowerCase() === "true" ? window.location.href = "/Account/MyAccount" : ($(".modal-backdrop.fade.in").remove(), $("#fica-modal-upload-items").html(result), $("#fica-modal-upload-items").hide(), $("#modal-container-ficauploadresult").show(), fica.closeOverlay());
                },
                error: function(jqXhr, textStatus, errorThrown) {
                    $('#subsection').innerHTML = errorThrown;
                    $('#subsection').show();
                    homePage.closeOverlay();
                }
            });
        }
    },
    submitFicaDetailsKICAsync: function(isMobile, isOperaMini, formId) {
        var dataString = null;
        var divToUse;
        isMobile === "true" ? divToUse = $("#ficaProofMobile") : divToUse = $("#ficaProof");
        var action = "/account/SubmitFICADetailsKIC";
        homePage.showOverlay();
        var contentType = "";
        var processData = "";
        dataString = new FormData(divToUse.get(0)), contentType = false, processData = false;
        $.ajax({
            type: "POST",
            url: action,
            data: dataString,
            dataType: "html",
            contentType: contentType,
            processData: processData,
            success: function(data) {
                homePage.closeOverlay();
                if (isOperaMini.toLowerCase() === "true") {
                    window.location.reload();
                } else {
                    $('#confirmModalContent').html(data);
                    $('#confirmModal').modal('show');
                    $('#confirmModal').on('hidden.bs.modal', function(e) {
                        window.location.reload();
                    });
                }
            },
            error: function(jqXhr, textStatus, errorThrown) {
                $('#subsection').innerHTML = errorThrown;
                $('#subsection').show();
                homePage.closeOverlay();
            }
        });
    },
    showFicaComplete: function() {
        if (!checkForLite()) {
            $('#modal-container-ficauploadresult').modal();
            $('#modal-container-ficauploadresult').show();
            $('#modal-container-ficastatus-upload').hide();
        }
    },
    clearFICAValidationError: function(elementId) {
        if (elementId !== null) {
            var elemRemove = document.getElementById(elementId);
            if (elemRemove !== null) {
                elemRemove.remove();
            }
            var count = document.querySelectorAll("#fica-errors ul li").length;
            if (count === 0) {
                var elem = document.querySelector('#fica-errors div');
                elem.parentNode.removeChild(elem);
                document.querySelector("#fica-errors div").append("validation-summary-valid");
                var ficaErrors = document.querySelector("#fica-errors div");
                ficaErrors.classList.remove("validation-summary-errors");
                ficaErrors.classList.add("validation-summary-valid");
            }
        } else {
            document.querySelectorAll("#fica-errors ul>li").forEach(li => li.remove());
            var elemRem = document.querySelector("#fica-errors div");
            elemRem.classList.remove("validation-summary-errors");
            document.querySelector("#fica-errors div").classList.add("validation-summary-valid");
        }
    },
    setFICAValidationError: function(errorString, elementId) {
        var ficaErrorsDiv = document.querySelector("#fica-errors div");
        ficaErrorsDiv.classList.remove("validation-summary-valid");
        ficaErrorsDiv.classList.add("validation-summary-errors");
        let elemAdd = document.createElement('li');
        elemAdd.setAttribute("id", elementId);
        elemAdd.innerHTML = errorString;
        document.querySelector("#fica-errors ul").appendChild(elemAdd);
    },
    BindFileUploads: function() {
        var proofIdElement = document.getElementById("proofId");
        var proofIdMobileElement = document.getElementById("proofIdMobile");
        proofIdElement.addEventListener('change', function() {
            fica.validateUpload('proofId', this);
        });
        proofIdMobileElement.addEventListener('change', function() {
            fica.validateUpload('proofIdMobile', this);
        });
    },
    validateUpload: function(inputId, inutBox) {
        fica.validateDocument(inputId, inutBox, "proof-of-id-error", "The ID proof document is too large.", false);
    },
    validateDocument: function(inputId, inutBox, elementError, fileSizeErrorMsg, documentUploadEnabled, btnSubmitElement, fileNameDiv) {
        var fileTypeValid = true;
        var fileSizeValid = true;
        fica.clearFICAValidationError(elementError);
        fica.clearFICAValidationError("file-type-error");
        if (inutBox.files !== null && inutBox.files.length > 0) {
            let actualsize = inutBox.files[0].size / 1024;
            let minFileSize = minDocumentUploadFileSize == null || minDocumentUploadFileSize == undefined ? 0 : minDocumentUploadFileSize;
            if (!this.between(actualsize, minFileSize, 4096)) {
                fileSizeValid = false;
                fica.setFICAValidationError(fileSizeErrorMsg, elementError);
                if (!checkForLite()) {
                    language.translateAtRuntime($(elementError), "SubmitFICADetailsDialog", {
                        "data-translate-key": "IDProofdocumentTooLarge"
                    });
                }
            }
            var acceptedTypesArray = inutBox.getAttribute('accept').toLowerCase().split(",");
            var fileExtension = "." + inutBox.files[0].name.toLowerCase().split(".").pop();
            if (acceptedTypesArray !== null && !acceptedTypesArray.includes(fileExtension)) {
                fileTypeValid = false;
                fica.setFICAValidationError("The selected document format/file-type is not supported. Please see below for acceptable file types", "file-type-error");
                if (!checkForLite()) {
                    language.translateAtRuntime($("#file-type-error"), "SubmitFICADetailsDialog", {
                        "data-translate-key": "SelectedFormatNotSupported"
                    });
                }
            }
        }
        if (documentUploadEnabled)
            fica.toggleDocumentUploadActive(fileTypeValid, fileSizeValid, btnSubmitElement, fileNameDiv);
        else
            fica.toggleFICAUploadActive(fileTypeValid, fileSizeValid);
    },
    submitDocumentUploadDetailsAsync: function(formId, divToReplace = "uploadSection") {
        var form = document.getElementById(formId);
        var otpInput = document.getElementById("DocumentUploadLoggedOutModel_OTPVerificationCode");
        var cloneOtp = null;
        if (otpInput != undefined && otpInput != null) {
            cloneOtp = otpInput.cloneNode(true);
            form.appendChild(cloneOtp);
        }
        var mobileNumberInput = document.getElementById("DocumentUploadLoggedOutModel_MobileNumber");
        var cloneMobileNumber = null;
        if (mobileNumberInput != undefined && mobileNumberInput != null) {
            cloneMobileNumber = mobileNumberInput.cloneNode(true);
            form.appendChild(cloneMobileNumber);
        }
        if (form.getAttribute("enctype") === "multipart/form-data") {
            var xhr = new XMLHttpRequest();
            xhr.open(form.method, form.action, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText !== null && xhr.responseText.trim() !== "") {
                        if (!checkForLite()) {
                            homePage.closeOverlay();
                        }
                        document.getElementById(divToReplace).innerHTML = xhr.responseText;
                        if (xhr.responseText.includes("documentForceReload")) {
                            if (xhr.responseText.includes("documentFinChatResponseText") || xhr.responseText.includes("documentResponseText")) {
                                setTimeout(function() {
                                    fica.SwitchToViewStatusOnUploadSuccess();
                                }, 4000);
                            } else {
                                location.reload();
                            }
                        }
                    }
                }
            };
            xhr.send(new FormData(form));
        }
        if (mobileNumberInput != undefined && mobileNumberInput != null) {
            cloneMobileNumber.remove();
        }
        if (otpInput != undefined && otpInput != null) {
            cloneOtp.remove();
        }
    },
    SwitchToViewStatusOnUploadSuccess: function() {
        if (document.getElementById("uploadSectionTab").classList.contains("active")) {
            document.getElementById("statusSectionTab").classList.add("active");
            document.getElementById("uploadSectionTab").classList.remove("active");
            document.getElementById("uploadSection").classList.remove("active");
            document.getElementById("statusSection").classList.add("active");
            document.getElementById("statusSection").classList.add("in");
            document.getElementById("uploadSection").classList.remove("in");
            fica.getDocumentsInfoForAccount(1);
        } else {
            document.getElementById("uploadSectionTab").classList.add("active");
            document.getElementById("statusSectionTab").classList.remove("active");
            document.getElementById("uploadSection").classList.add("active");
            document.getElementById("statusSection").classList.add("hidden");
            document.getElementById("statusSection").classList.remove("in");
            document.getElementById("uploadSection").classList.add("in");
            document.getElementsByClassName('documentStatus')[0].style.display = 'none';
            if (document.getElementById("documentResponseText") !== null) {
                document.getElementById("documentResponseText").classList.add("hidden");
            }
        }
    },
    reloadUploadSection: function() {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        $.get("/DocumentUpload/GetUploadSectionView", function(data) {
            if (!checkForLite()) {
                homePage.closeOverlay();
            } else {
                fica.toggleSectionTabs(false);
            }
            document.getElementById("uploadSection").innerHTML = data;
        });
    },
    BindFileUpload: function(element, fileSizeErrorMsg, btnSubmitElement, fileNameDiv) {
        if (element !== null && typeof element !== "undefined") {
            fica.setFileNameDisplay(fileNameDiv, element.value);
            fica.validateDocument(element.id, element, "proof-of-document-error", fileSizeErrorMsg, true, btnSubmitElement, fileNameDiv);
        }
    },
    setFileNameDisplay: function(elementId, text) {
        var filename = text.split("\\");
        if (text.length === 0) {
            document.getElementById(elementId).innerHTML = noFileSelectedText;
        } else if (filename.length > 0 && filename.constructor === Array) {
            text = filename[filename.length - 1];
            document.getElementById(elementId).innerHTML = text;
        }
        if (document.getElementById("documentResponseText") !== null) {
            document.getElementById("documentResponseText").classList.add("hidden");
        }
    },
    getDocumentsInfoForAccount: function(pageNo = 1) {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        ajax.get("/DocumentUpload/GetDocumentsInfoForAccount", {
            pageNo: pageNo
        }, function(result) {
            if (!checkForLite()) {
                homePage.closeOverlay();
            } else {
                fica.toggleSectionTabs(false);
            }
            document.getElementById("statusSection").innerHTML = result;
            var currentPage = document.getElementById("CurrentPage") !== null ? parseInt(document.getElementById("CurrentPage").value) : null;
            var pageSize = document.getElementById("PageSize") !== null ? parseInt(document.getElementById("PageSize").value) : 0;
            var recordTotal = document.getElementById("RecordTotal") !== null ? parseInt(document.getElementById("RecordTotal").value) : 0;
            if (recordTotal > pageSize) {
                document.getElementById("showMoreDiv").classList.remove("hidden");
            } else {
                document.getElementById("showMoreDiv").classList.add("hidden");
            }
            if (currentPage !== null) {
                document.getElementById("showPrevious").disabled = currentPage == 1;
                account.isShowMoreVisible(currentPage, pageSize, recordTotal);
            }
        }, true);
    },
    toggleSectionTabs: function(isUploadTab) {
        if (isUploadTab) {
            document.getElementById('btnStatusToggle').classList.remove("active");
            document.getElementById('btnUploadToggle').classList.add("active");
            document.getElementById('uploadSection').classList.remove("hidden");
            document.getElementById('statusSection').classList.add("hidden");
        } else {
            document.getElementById('btnUploadToggle').classList.remove("active");
            document.getElementById('btnStatusToggle').classList.add("active");
            document.getElementById('uploadSection').classList.add("hidden");
            document.getElementById('statusSection').classList.remove("hidden");
        }
    },
    viewDocumentFile: function(documentId) {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        ajax.get("/DocumentUpload/GetDocumentFile", {
            documentId: documentId
        }, function(result) {
            if (!checkForLite()) {
                $('#document-file-modal').html(result);
                $('#document-file-modal').modal();
                homePage.closeOverlay();
            }
        }, true);
    },
    getNextPage: function() {
        var current = parseInt(document.getElementById('CurrentPage').value);
        current++;
        document.getElementById('CurrentPage').value = current;
        this.getDocumentsInfoForAccount(current);
    },
    getPreviousPage: function() {
        var current = parseInt(document.getElementById('CurrentPage').value);
        current--;
        document.getElementById('CurrentPage').value = current < 1 ? 1 : current;
        this.getDocumentsInfoForAccount(current);
    },
    showFicaModalContainer: function() {
        $('#modal-container-ficastatus-confirmation').modal().show();
        sideMenu.closeMenu();
    },
    between: function(value, min, max) {
        return value >= min && value <= max;
    }
};

function ficaUploadFormDisplayCallBack(result) {
    document.getElementById("ficaStatusDiv").outerHTML = result;
    fica.BindFileUploads();
}

function requestOTP(isResend = false) {
    homePage.showOverlay();
    var mobileNumber = $("#DocumentUploadLoggedOutModel_MobileNumber").val();
    var isOTPSuccessful = false;
    if (isResend) {
        isOTPSuccessful = true;
    }
    while (mobileNumber.charAt(0) === '0') {
        mobileNumber = mobileNumber.substr(1);
    }
    var numberStartsWithBrandDialingCode = mobileNumber.startsWith(BrandDialingCode);
    var isNumberCorrectLength = false;
    var mobileNumberRequiredLength = 9;
    if (Brand == "F8A8D16A-D619-4B49-AA8C-F21211403C92") {
        mobileNumberRequiredLength = 10;
    }
    if (numberStartsWithBrandDialingCode) {
        isNumberCorrectLength = false;
    } else {
        isNumberCorrectLength = mobileNumber.length === mobileNumberRequiredLength;
        mobileNumber = BrandDialingCode + mobileNumber;
    }
    if (!isNumberCorrectLength) {
        errorMessage = "Please Enter a Valid Mobile Number";
        $("#docUploadErrors").text(errorMessage);
        homePage.closeOverlay();
        return;
    } else {
        $("#docUploadErrors").text("");
    }
    pat.post('/DocumentUpload/_RequestLoggedOutDocumentUpload', {
        mobileNumber: mobileNumber,
        isOTPSuccessful: isOTPSuccessful
    }).done(function(data) {
        $("#myOTP").html(data);
        if (data.includes("successfulOtp")) {
            document.getElementById("btnRequestOtp").style.display = 'none';
        }
        homePage.closeOverlay();
    });
};
var oddsFormatter = {
    convertToDecimal: function() {
        $('.outcome-pricedecimal, .betslipPriceDecimal, #betslip-totalpricedecimal, .outcome-decimal, .outcome-pd, .priceDecimal').each(function(index) {
            $(this).text($(this).data('pd')).text($(this).data('lip-pricedecimal'));
        });
        $('.ddlPd').each(function(index) {
            var unchangedPart = $(this).text().replace($(this).text().split(':').pop(), '');
            var convertPart = parseFloat($(this).data('lip-pricedecimal')).toFixed(2);
            $(this).text(unchangedPart + convertPart);
        });
        if (buildABet && buildABetEnabled) buildABet.changeOddsFormat('');
    },
    convertToFraction: function() {
        $('.outcome-pricedecimal, .betslipPriceDecimal, #betslip-totalpricedecimal, .outcome-decimal, .outcome-pd, .priceDecimal').each(function(index) {
            $(this).text(oddsFormatter.convertFromDecimalToFraction($(this).text()));
        });
        $('.ddlPd').each(function(index) {
            var unchangedPart = $(this).text().replace($(this).text().split(':').pop(), '');
            var convertPart = oddsFormatter.convertFromDecimalToFraction($(this).text().split(':').pop());
            $(this).text(unchangedPart + convertPart);
        });
        if (buildABet && buildABetEnabled) buildABet.changeOddsFormat('fraction');
    },
    convertFromDecimalToFraction: function(priceDecimal) {
        priceDecimal = typeof priceDecimal === 'number' ? priceDecimal.toFixed(2) : priceDecimal;
        if (priceDecimal !== undefined && priceDecimal.indexOf('/') < 0 && priceDecimal !== '' && priceDecimal !== 'NaN') {
            var ret = "";
            priceDecimal = parseFloat(priceDecimal - 1).toFixed(2);
            var len = priceDecimal.toString().length - 2;
            var denominator = Math.pow(10, len);
            var numerator = priceDecimal * denominator;
            var divisor = oddsFormatter.gcd(numerator, denominator);
            numerator /= divisor;
            denominator /= divisor;
            if (Math.floor(numerator).toString().length > 1 && Math.floor(denominator).toString().length > 2) {
                ret = Math.floor(numerator / 10) + '/' + Math.floor(denominator / 10);
            } else {
                ret = numerator < 0 ? '0/1' : Math.floor(numerator) + '/' + Math.floor(denominator);
            }
            return ret;
        }
        return priceDecimal;
    },
    gcd: function(a, b) {
        if (b < 0.0000001) return a;
        else return oddsFormatter.gcd(b, Math.floor(a % b));
    }
};
$(document).ready(function() {
    var sel = document.getElementById('oddsFormat');
    if (sel !== undefined && sel !== null) {
        sel.addEventListener("change", function() {
            setTimeout(function() {
                if (sel.value === 'fraction') {
                    oddsFormatter.convertToFraction();
                    global.setCookie("oddsFormat", 'fraction');
                } else {
                    oddsFormatter.convertToDecimal();
                    global.setCookie("oddsFormat", 'decimal');
                }
            }, 100);
        });
    }
    if (global.getCookie("oddsFormat") === 'fraction') {
        setTimeout(function() {
            $('#oddsFormat').val('fraction');
            oddsFormatter.convertToFraction();
        }, 100);
    }
});;
var livechat = {
    maximiseChat: function(screenHeight) {
        $('#liveChatModal').show().animate({
            height: screenHeight
        }, 'slow');
    },
    closeChat: function() {
        $('#liveChatModal').animate({
            height: 0
        }, 'slow', function() {
            $('#liveChatModal').hide();
        });
    },
    minimiseChat: function() {
        $('#liveChatModal').animate({
            height: 65
        }, 'slow');
    },
    performAction: function() {
        $('#liveChatModal').height() < 75 ? (screen.width <= 425 ? livechat.maximiseChat("99%") : livechat.maximiseChat("400px")) : livechat.minimiseChat();
    }
};

function load_css_async(filename) {
    var cb = function() {
        var l = document.createElement('link');
        l.rel = 'stylesheet';
        l.href = filename;
        var h = document.getElementsByTagName('head')[0];
        h.parentNode.insertBefore(l, h);
    };
    var raf = requestAnimationFrame || mozRequestAnimationFrame || webkitRequestAnimationFrame || msRequestAnimationFrame;
    if (raf) raf(cb);
    else window.addEventListener('load', cb);
}
(function(w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
    });
    var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-NDNGV7K');
var gax = {};
var showConsoleLogs = false;
var casinoCategory = "All";
var holdBankingTitle = "";
var registrationPOIString = "";
gax.SetRegistration_EventTracking_QueryString = function() {
    if (useGoogleAnalytics) {
        registrationPOIString = "Query String";
    }
};
gax.SetRegistration_EventTracking_Header = function() {
    if (useGoogleAnalytics) {
        registrationPOIString = "Header";
    }
};
gax.RegistrationInitiatedEvent_EventTracking = function() {
    if (useGoogleAnalytics) {
        if (registrationPOIString === "") {
            registrationPOIString = "Other";
        }
        dataLayer.push({
            'event': 'RegistrationInitiatedEvent',
            'registrationPOI': registrationPOIString
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.SuccessfulRegistration_EventTracking = function(offer, promotions) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'RegistrationCompleteEvent',
            'registrationPOI': registrationPOIString,
            'offer': offer,
            'promotions': promotions
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.SearchEvents_EventTracking = function(keyword) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'SearchEventsEvent',
            'SearchEventsText': keyword.toLowerCase()
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.SearchedEventSelection_EventTracking = function(date, league, fixture) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'SearchedEventSelectionEvent',
            'SearchedEventSelectionDateTime': date,
            'SearchedEventSelectionLeague': league,
            'SearchedEventSelectionFixture': fixture
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingGeneric_EventTracking = function(title, eventTitle, methodTitle) {
    if (useGoogleAnalytics) {
        let proceedMethodTemp = methodTitle;
        if (proceedMethodTemp == null) proceedMethodTemp = ''
        proceedMethodTemp = proceedMethodTemp.replace('Credit-Debit Card', 'Peach Payments')
        dataLayer.push({
            'section': title,
            'event': eventTitle,
            'method': proceedMethodTemp
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingVoucherProceed_EventTracking = function(proceedMethod) {
    if (useGoogleAnalytics) {
        localStorage.setItem('LastProceedMethod', proceedMethod);
        if (showConsoleLogs) {
            console.log('LastProceedMethod set', proceedMethod);
        }
        dataLayer.push({
            'event': 'BankingVoucherRedeemClicked',
            'method': proceedMethod
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositResultPageNoMethodSpecified_EventTracking = function(result) {
    if (useGoogleAnalytics) {
        if ($('.newDepositModal').length == 0) {
            let lastProceedMethod = localStorage.getItem('LastProceedMethod');
            if (!lastProceedMethod) lastProceedMethod = '';
            gax.BankingDepositResultPage_EventTracking(lastProceedMethod, result);
        } else {
            console.log('BankingDepositResultPageNoMethodSpecified_EventTracking: This method is obsolete and no longer used');
        }
    }
};
gax.BankingDepositResultPageNoMethodSpecifiedNew_EventTracking = function(result) {
    if (useGoogleAnalytics) {
        let lastProceedMethod = localStorage.getItem('LastProceedMethod');
        if (!lastProceedMethod) lastProceedMethod = '';
        gax.BankingDepositResultPage_EventTracking(lastProceedMethod, result);
    }
};
gax.BankingDepositResultPage_EventTracking = function(method, result) {
    if (useGoogleAnalytics) {
        let bankingDepositVersion = global.getCookie('BankingDepositVersion');
        if ((bankingDepositVersion != null && bankingDepositVersion != undefined && (bankingDepositVersion == '' || bankingDepositVersion == 'Old')) || bankingDepositVersion == null || bankingDepositVersion == undefined) {
            var referrer = (document.referrer != null ? document.referrer : '');
            var disallowRedirect = localStorage.getItem('disallowRedirectForGa');
            if (disallowRedirect == null) disallowRedirect = '0';
            if (method != null && method != '') {
                dataLayer.push({
                    'event': 'BankingDepositResultPage',
                    'method': method,
                    'result': result,
                    'referrer': referrer
                });
            }
            localStorage.setItem('LastProceedMethod', null);
            if (showConsoleLogs) {
                console.log(dataLayer);
            }
            if (disallowRedirect == '1') {
                object.addEventListener("beforeunload", function() {
                    return false
                });
            }
        } else {
            gax.BankingResultLog_EventTracking('deposits', result)
        }
    }
};
gax.BankingResultLog_EventTracking = function(typeLoaded, type) {
    if (useGoogleAnalytics) {
        let lastProceedMethod = localStorage.getItem('LastProceedMethod')
        if (!lastProceedMethod) lastProceedMethod = ''
        let dateTime = new Date()
        let dateTimeGet = new Date(localStorage.getItem(typeLoaded + 'Opened-Method-' + lastProceedMethod))
        let dateTimeOpened = new Date(localStorage.getItem(typeLoaded + 'Opened'))
        dataLayer.push({
            version: 'MoneyUI',
            event: 'DepositResult',
            method: lastProceedMethod,
            fromSource: 'Vuvu',
            type: type,
            timeTakenFromMethodOpen: (dateTime.getTime() - dateTimeGet.getTime()) / 1000,
            timeTakenFromMainLoad: (dateTime.getTime() - dateTimeOpened.getTime()) / 1000,
        })
        if (showConsoleLogs) {
            console.log(dataLayer)
        }
    }
}
gax.BankingDepositProceed_EventTracking = function(proceedAmount, proceedMethod) {
    if (useGoogleAnalytics) {
        let proceedMethodTemp = proceedMethod;
        if (proceedMethodTemp == null) proceedMethodTemp = ''
        proceedMethodTemp = proceedMethodTemp.replace('Credit-Debit Card', 'Peach Payments')
        localStorage.setItem('LastProceedMethod', proceedMethodTemp);
        if (showConsoleLogs) {
            console.log('LastProceedMethod set', proceedMethodTemp);
        }
        dataLayer.push({
            'event': 'BankingDepositProceedClicked',
            'amount': proceedAmount,
            'method': proceedMethodTemp
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositAmount_EventTracking = function(amount, method) {
    if (useGoogleAnalytics) {
        let proceedMethodTemp = method;
        if (proceedMethodTemp == null) proceedMethodTemp = ''
        proceedMethodTemp = proceedMethodTemp.replace('Credit-Debit Card', 'Peach Payments')
        dataLayer.push({
            'event': 'BankingDepositAmountSelected',
            'amount': amount,
            'method': proceedMethodTemp
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositInfo_EventTracking = function(infoClicked) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingDepositInfo',
            'clicked': infoClicked
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositInfo_EventTrackingLong = function(infoClicked, method) {
    if (useGoogleAnalytics) {
        let proceedMethodTemp = method;
        if (proceedMethodTemp == null) proceedMethodTemp = ''
        proceedMethodTemp = proceedMethodTemp.replace('Credit-Debit Card', 'Peach Payments')
        dataLayer.push({
            'event': 'BankingDepositInfo',
            'clicked': infoClicked,
            'method': proceedMethodTemp
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositEntryPoint_EventTracking = function(fromElement) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingDepositEntryPoint',
            'From': fromElement
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.ReverseWithdrawal_EventTracking = function(area, step, action, extraTitle = '', paymentMethod = '', amount = '') {
    if (useGoogleAnalytics) {
        let areaText = area == '' ? document.location.href.toString().indexOf('WithdrawFunds') != -1 ? 'Withdrawals' : 'Deposits' : area;
        areaText = document.location.href.toString().indexOf('ReverseWithdrawalTransactions') != -1 ? 'My Pending Withdrawals' : areaText;
        dataLayer.push({
            'event': 'ReverseWithdrawal',
            'area': areaText,
            'step': step,
            'action': action,
            'extraTitle': extraTitle,
            'paymentMethod': paymentMethod,
            'amount': amount
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingModal_EventTracking = function(eventTitle) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingModalDepositEvent',
            'DepositModal': eventTitle
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingModalTitle_EventTracking = function(bankingTitle) {
    if (useGoogleAnalytics) {
        let proceedMethodTemp = bankingTitle;
        if (proceedMethodTemp == null) proceedMethodTemp = ''
        proceedMethodTemp = proceedMethodTemp.replace('Credit-Debit Card', 'Peach Payments')
        holdBankingTitle = proceedMethodTemp;
        dataLayer.push({
            'event': 'BankingOptionEvent',
            'BankingMethod': proceedMethodTemp
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingTitle_EventTracking = function(bankingTitle) {
    if (useGoogleAnalytics) {
        holdBankingTitle = bankingTitle;
        dataLayer.push({
            'event': 'BankingOptionEvent',
            'BankingMethod': bankingTitle
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingPresetDepositAmount_EventTracking = function(presetDepositAmount) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingPresetDepositAmountEvent',
            'BankingMethod': holdBankingTitle,
            'BankingPresetDepositAmount': presetDepositAmount
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingConfirm_EventTracking = function(chosenDepositAmount) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingProceedDepositEvent',
            'BankingMethod': holdBankingTitle,
            'BankingDepositAmount': chosenDepositAmount
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositSuccess_EventTracking = function(chosenDepositAmount) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'BankingDepositSuccessEvent',
            'DepositID': chosenDepositAmount
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.BankingDepositErrorEvent_EventTracking = function(errorMsg, chosenDepositAmm) {
    if (useGoogleAnalytics) {
        if (chosenDepositAmm === "") {
            chosenDepositAmm = 0;
        }
        dataLayer.push({
            'event': 'BankingDepositErrorEvent',
            'BankingMethod': holdBankingTitle,
            'BankingDepositAmount': chosenDepositAmm,
            'BankingErrorMsg': errorMsg
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.SetCasinoCategory = function(category) {
    if (useGoogleAnalytics) {
        casinoCategory = category;
    }
};
gax.CasinoGameLaunch_EventTracking = function(gameName) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'CasinoGameLaunchEvent',
            'CasinoGameName': gameName,
            'CasinoGameCategory': casinoCategory
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
var betPOICount = 0;
var betPOI = [];
var singleOrMultiBetType = "MultiBet";
gax.SetBetPOI = function(POI, outcomeId) {
    console.log('useGoogleAnalytics', useGoogleAnalytics);
    if (typeof betPOI === "undefined") {
        betPOI = new Array();
    }
    if (typeof betPOICount === "undefined") {
        betPOICount = -1;
    }
    betPOICount++;
    if (useGoogleAnalytics) {
        var removed = false;
        betPOI.forEach(function(betPOIItem, index) {
            if (typeof betPOIItem !== 'undefined' && betPOIItem !== null && betPOIItem.outcome === outcomeId) {
                betPOI.pop(index);
                removed = true;
            }
        });
        if (!removed) {
            betPOI.push({
                'poi': POI,
                'outcome': outcomeId
            });
        }
        betPOICount = betPOI.length - 1;
        gax.SetGAData('GABetPOI', betPOI.poi);
        gax.SetGAData('GABetOutcome', betPOI.outcome);
    }
    console.log('betPOI', betPOI);
};
gax.SetSingleOrMultiBet = function(singleOrMulti_In) {
    if (useGoogleAnalytics) {
        if (singleOrMulti_In === 'SingleBet') {
            gax.SetGAData('GASingleBet', true);
        } else {
            gax.SetGAData('GASingleBet', false);
        }
        singleOrMultiBetType = singleOrMulti_In;
    }
};
gax.RemoveBetSlipPOI = function(posInArr) {
    if (useGoogleAnalytics) {
        var betPOIHold = new Array();
        var newCount = 0;
        var count = 0;
        if (typeof betPOI === 'undefined') {
            betPOI = new Array();
        }
        betPOI.forEach(function(betPOIItem) {
            if (count !== posInArr) {
                betPOIHold[newCount] = betPOI[count];
                newCount++;
            }
            count++;
        });
        betPOI = betPOIHold;
        gax.SetGAData('GABetPOI', betPOI);
        if (betPOICount > 0) {
            betPOICount--;
            gax.SetGAData('GABetPOICount', betPOICount);
        }
    }
};
gax.ResetBetSlipPOICount = function() {
    if (useGoogleAnalytics) {
        betPOICount = 0;
        confirmBetPOICount = 0;
        betPOI = [];
        gax.SetGAData('GABetPOICount', betPOICount);
    }
};
gax.AddToBetslip_EventTracking = function(outcome, type, fixture, odds, marketTitle, sport, eventId) {
    var splitEventId = "";
    if (eventId !== null && eventId.length > 0) {
        splitEventId = eventId.split(',');
    }
    if (typeof betPOI === "undefined") {
        betPOI = new Array();
    }
    if (typeof betPOICount === "undefined") {
        betPOICount = -1;
    }
    if (useGoogleAnalytics) {
        var betBoiItem = [];
        try {
            betBoiItem = (betPOI.length < 1 || betPOICount === -1) ? new Array() : betPOI[betPOICount].poi;
        } catch (e) {
            betBoiItem = new Array();
        }
        dataLayer.push({
            'event': 'AddToBetslipEvent',
            'BetOutcome': outcome,
            'BetType': type,
            'BetFixture': fixture,
            'BetOdds': odds,
            'BetPOI': betBoiItem,
            'BetLeague': marketTitle,
            'BetSport': sport,
            'eventId': splitEventId
        });
        console.log('dataLayer', dataLayer);
        betPOICount++;
        gax.SetGAData('GABetPOICount', betPOICount);
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
var confirmBetPOICount = 0;
gax.reconWithBetslip = function() {
    var betslip = JSON.parse(GetBetslip());
    var removeList = [];
    if (typeof betPOI === "undefined") {
        betPOI = new Array();
    }
    betPOI.forEach(function(betPOIItem, index) {
        var found = false;
        for (var i = 0; i <= betslip.length - 1; i++) {
            if (!found && betslip[i].OutcomeId === betPOIItem.outcome) {
                found = true;
            }
        }
        if (!found) {
            removeList.push(betPOIItem.outcome);
        }
    });
    for (var i = betPOI.length - 1; i >= 0; i--) {
        if (removeList.includes(betPOI[i].outcome)) {
            betPOI.splice(i, 1);
        }
    }
    gax.SetGAData('GABetPOI', betPOI);
};
gax.ConfirmBet = function(betslipId, eventId) {
    var splitEventId = "";
    if (eventId !== null && eventId.length > 0) {
        splitEventId = eventId.split(',');
    }
    if (useGoogleAnalytics) {
        var betPOISet = "";
        gax.reconWithBetslip();
        if (singleOrMultiBetType === "MultiBet") {
            var hasSportPgPOI = false;
            var hasSearchBarPOI = false;
            betPOI.forEach(function(betPOIItem) {
                if (betPOIItem === "Sport Page") {
                    hasSportPgPOI = true;
                }
                if (betPOIItem === "Search") {
                    hasSearchBarPOI = true;
                }
            });
            if (hasSportPgPOI && hasSearchBarPOI) {
                betPOISet = 'Multi Bet POI from both Sport Page and Search';
            } else {
                betPOISet = betPOI[confirmBetPOICount];
            }
        } else {
            betPOISet = betPOI[confirmBetPOICount];
            confirmBetPOICount++;
        }
        dataLayer.push({
            'event': 'CompleteBetslipTransactionEvent',
            'betslipID': betslipId,
            'BetPOI': betPOISet,
            'eventId': splitEventId
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
gax.SetBetslipOptionsGA = function(betslipOptions) {
    var name = "betslipStorageOptionsGA";
    if (lsTest() === true) {
        localStorage.setItem(name, JSON.stringify(betslipOptions));
    } else {
        setCookie(name, JSON.stringify(betslipOptions), 0.01);
    }
};
gax.GetBetslipOptionsGA = function() {
    var name = "betslipStorageOptionsGA";
    if (lsTest() === true) {
        if (localStorage.getItem(name) === null)
            return "";
        return localStorage.getItem(name);
    } else {
        return getCookie(name);
    }
};
gax.SetGAData = function(name, value) {
    var optionString = gax.GetBetslipOptionsGA();
    var options = new Object();
    if (optionString !== "") {
        options = JSON.parse(optionString);
    }
    options[name] = value;
    gax.SetBetslipOptionsGA(options);
};
gax.GetGAData = function(name) {
    var optionString = gax.GetBetslipOptionsGA();
    var options = new Object();
    if (optionString !== "") {
        options = JSON.parse(optionString);
    }
    return options[name];
};
gax.GetGASavedLocalData = function() {
    if (gax.GetGAData('GABetPOICount') !== null) {
        betPOICount = gax.GetGAData('GABetPOICount');
    }
    if (gax.GetGAData('GABetPOI') !== null) {
        betPOI = gax.GetGAData('GABetPOI');
    }
    if (gax.GetGAData('GASingleBet') === true) {
        singleOrMultiBetType = 'SingleBet';
    }
};
gax.ToggleLIPStreaming = function(state) {
    if (useGoogleAnalytics) {
        if (state === 'open') {
            console.log('open');
            dataLayer.push({
                'event': 'viewLiveStreamEvent'
            });
        } else if (state === 'close') {
            console.log('close');
            dataLayer.push({
                'event': 'closeLiveStreamEvent'
            });
        }
    }
};
gax.LightbulbClickEvent = function(sport, league) {
    if (useGoogleAnalytics) {
        dataLayer.push({
            'event': 'LightbulbClickEvent',
            'sport': sport,
            'league': league
        });
        if (showConsoleLogs) {
            console.log(dataLayer);
        }
    }
};
(function() {
    function n(n) {
        function t(t, r, e, u, i, o) {
            for (; i >= 0 && o > i; i += n) {
                var a = u ? u[i] : i;
                e = r(e, t[a], a, t)
            }
            return e
        }
        return function(r, e, u, i) {
            e = b(e, i, 4);
            var o = !k(r) && m.keys(r),
                a = (o || r).length,
                c = n > 0 ? 0 : a - 1;
            return arguments.length < 3 && (u = r[o ? o[c] : c], c += n), t(r, e, u, o, c, a)
        }
    }

    function t(n) {
        return function(t, r, e) {
            r = x(r, e);
            for (var u = O(t), i = n > 0 ? 0 : u - 1; i >= 0 && u > i; i += n)
                if (r(t[i], i, t)) return i;
            return -1
        }
    }

    function r(n, t, r) {
        return function(e, u, i) {
            var o = 0,
                a = O(e);
            if ("number" == typeof i) n > 0 ? o = i >= 0 ? i : Math.max(i + a, o) : a = i >= 0 ? Math.min(i + 1, a) : i + a + 1;
            else if (r && i && a) return i = r(e, u), e[i] === u ? i : -1;
            if (u !== u) return i = t(l.call(e, o, a), m.isNaN), i >= 0 ? i + o : -1;
            for (i = n > 0 ? o : a - 1; i >= 0 && a > i; i += n)
                if (e[i] === u) return i;
            return -1
        }
    }

    function e(n, t) {
        var r = I.length,
            e = n.constructor,
            u = m.isFunction(e) && e.prototype || a,
            i = "constructor";
        for (m.has(n, i) && !m.contains(t, i) && t.push(i); r--;) i = I[r], i in n && n[i] !== u[i] && !m.contains(t, i) && t.push(i)
    }
    var u = this,
        i = u._,
        o = Array.prototype,
        a = Object.prototype,
        c = Function.prototype,
        f = o.push,
        l = o.slice,
        s = a.toString,
        p = a.hasOwnProperty,
        h = Array.isArray,
        v = Object.keys,
        g = c.bind,
        y = Object.create,
        d = function() {},
        m = function(n) {
            return n instanceof m ? n : this instanceof m ? void(this._wrapped = n) : new m(n)
        };
    "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = m), exports._ = m) : u._ = m, m.VERSION = "1.8.3";
    var b = function(n, t, r) {
            if (t === void 0) return n;
            switch (null == r ? 3 : r) {
                case 1:
                    return function(r) {
                        return n.call(t, r)
                    };
                case 2:
                    return function(r, e) {
                        return n.call(t, r, e)
                    };
                case 3:
                    return function(r, e, u) {
                        return n.call(t, r, e, u)
                    };
                case 4:
                    return function(r, e, u, i) {
                        return n.call(t, r, e, u, i)
                    }
            }
            return function() {
                return n.apply(t, arguments)
            }
        },
        x = function(n, t, r) {
            return null == n ? m.identity : m.isFunction(n) ? b(n, t, r) : m.isObject(n) ? m.matcher(n) : m.property(n)
        };
    m.iteratee = function(n, t) {
        return x(n, t, 1 / 0)
    };
    var _ = function(n, t) {
            return function(r) {
                var e = arguments.length;
                if (2 > e || null == r) return r;
                for (var u = 1; e > u; u++)
                    for (var i = arguments[u], o = n(i), a = o.length, c = 0; a > c; c++) {
                        var f = o[c];
                        t && r[f] !== void 0 || (r[f] = i[f])
                    }
                return r
            }
        },
        j = function(n) {
            if (!m.isObject(n)) return {};
            if (y) return y(n);
            d.prototype = n;
            var t = new d;
            return d.prototype = null, t
        },
        w = function(n) {
            return function(t) {
                return null == t ? void 0 : t[n]
            }
        },
        A = Math.pow(2, 53) - 1,
        O = w("length"),
        k = function(n) {
            var t = O(n);
            return "number" == typeof t && t >= 0 && A >= t
        };
    m.each = m.forEach = function(n, t, r) {
        t = b(t, r);
        var e, u;
        if (k(n))
            for (e = 0, u = n.length; u > e; e++) t(n[e], e, n);
        else {
            var i = m.keys(n);
            for (e = 0, u = i.length; u > e; e++) t(n[i[e]], i[e], n)
        }
        return n
    }, m.map = m.collect = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = Array(u), o = 0; u > o; o++) {
            var a = e ? e[o] : o;
            i[o] = t(n[a], a, n)
        }
        return i
    }, m.reduce = m.foldl = m.inject = n(1), m.reduceRight = m.foldr = n(-1), m.find = m.detect = function(n, t, r) {
        var e;
        return e = k(n) ? m.findIndex(n, t, r) : m.findKey(n, t, r), e !== void 0 && e !== -1 ? n[e] : void 0
    }, m.filter = m.select = function(n, t, r) {
        var e = [];
        return t = x(t, r), m.each(n, function(n, r, u) {
            t(n, r, u) && e.push(n)
        }), e
    }, m.reject = function(n, t, r) {
        return m.filter(n, m.negate(x(t)), r)
    }, m.every = m.all = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i] : i;
            if (!t(n[o], o, n)) return !1
        }
        return !0
    }, m.some = m.any = function(n, t, r) {
        t = x(t, r);
        for (var e = !k(n) && m.keys(n), u = (e || n).length, i = 0; u > i; i++) {
            var o = e ? e[i] : i;
            if (t(n[o], o, n)) return !0
        }
        return !1
    }, m.contains = m.includes = m.include = function(n, t, r, e) {
        return k(n) || (n = m.values(n)), ("number" != typeof r || e) && (r = 0), m.indexOf(n, t, r) >= 0
    }, m.invoke = function(n, t) {
        var r = l.call(arguments, 2),
            e = m.isFunction(t);
        return m.map(n, function(n) {
            var u = e ? t : n[t];
            return null == u ? u : u.apply(n, r)
        })
    }, m.pluck = function(n, t) {
        return m.map(n, m.property(t))
    }, m.where = function(n, t) {
        return m.filter(n, m.matcher(t))
    }, m.findWhere = function(n, t) {
        return m.find(n, m.matcher(t))
    }, m.max = function(n, t, r) {
        var e, u, i = -1 / 0,
            o = -1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++) e = n[a], e > i && (i = e)
        } else t = x(t, r), m.each(n, function(n, r, e) {
            u = t(n, r, e), (u > o || u === -1 / 0 && i === -1 / 0) && (i = n, o = u)
        });
        return i
    }, m.min = function(n, t, r) {
        var e, u, i = 1 / 0,
            o = 1 / 0;
        if (null == t && null != n) {
            n = k(n) ? n : m.values(n);
            for (var a = 0, c = n.length; c > a; a++) e = n[a], i > e && (i = e)
        } else t = x(t, r), m.each(n, function(n, r, e) {
            u = t(n, r, e), (o > u || 1 / 0 === u && 1 / 0 === i) && (i = n, o = u)
        });
        return i
    }, m.shuffle = function(n) {
        for (var t, r = k(n) ? n : m.values(n), e = r.length, u = Array(e), i = 0; e > i; i++) t = m.random(0, i), t !== i && (u[i] = u[t]), u[t] = r[i];
        return u
    }, m.sample = function(n, t, r) {
        return null == t || r ? (k(n) || (n = m.values(n)), n[m.random(n.length - 1)]) : m.shuffle(n).slice(0, Math.max(0, t))
    }, m.sortBy = function(n, t, r) {
        return t = x(t, r), m.pluck(m.map(n, function(n, r, e) {
            return {
                value: n,
                index: r,
                criteria: t(n, r, e)
            }
        }).sort(function(n, t) {
            var r = n.criteria,
                e = t.criteria;
            if (r !== e) {
                if (r > e || r === void 0) return 1;
                if (e > r || e === void 0) return -1
            }
            return n.index - t.index
        }), "value")
    };
    var F = function(n) {
        return function(t, r, e) {
            var u = {};
            return r = x(r, e), m.each(t, function(e, i) {
                var o = r(e, i, t);
                n(u, e, o)
            }), u
        }
    };
    m.groupBy = F(function(n, t, r) {
        m.has(n, r) ? n[r].push(t) : n[r] = [t]
    }), m.indexBy = F(function(n, t, r) {
        n[r] = t
    }), m.countBy = F(function(n, t, r) {
        m.has(n, r) ? n[r]++ : n[r] = 1
    }), m.toArray = function(n) {
        return n ? m.isArray(n) ? l.call(n) : k(n) ? m.map(n, m.identity) : m.values(n) : []
    }, m.size = function(n) {
        return null == n ? 0 : k(n) ? n.length : m.keys(n).length
    }, m.partition = function(n, t, r) {
        t = x(t, r);
        var e = [],
            u = [];
        return m.each(n, function(n, r, i) {
            (t(n, r, i) ? e : u).push(n)
        }), [e, u]
    }, m.first = m.head = m.take = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[0] : m.initial(n, n.length - t)
    }, m.initial = function(n, t, r) {
        return l.call(n, 0, Math.max(0, n.length - (null == t || r ? 1 : t)))
    }, m.last = function(n, t, r) {
        return null == n ? void 0 : null == t || r ? n[n.length - 1] : m.rest(n, Math.max(0, n.length - t))
    }, m.rest = m.tail = m.drop = function(n, t, r) {
        return l.call(n, null == t || r ? 1 : t)
    }, m.compact = function(n) {
        return m.filter(n, m.identity)
    };
    var S = function(n, t, r, e) {
        for (var u = [], i = 0, o = e || 0, a = O(n); a > o; o++) {
            var c = n[o];
            if (k(c) && (m.isArray(c) || m.isArguments(c))) {
                t || (c = S(c, t, r));
                var f = 0,
                    l = c.length;
                for (u.length += l; l > f;) u[i++] = c[f++]
            } else r || (u[i++] = c)
        }
        return u
    };
    m.flatten = function(n, t) {
        return S(n, t, !1)
    }, m.without = function(n) {
        return m.difference(n, l.call(arguments, 1))
    }, m.uniq = m.unique = function(n, t, r, e) {
        m.isBoolean(t) || (e = r, r = t, t = !1), null != r && (r = x(r, e));
        for (var u = [], i = [], o = 0, a = O(n); a > o; o++) {
            var c = n[o],
                f = r ? r(c, o, n) : c;
            t ? (o && i === f || u.push(c), i = f) : r ? m.contains(i, f) || (i.push(f), u.push(c)) : m.contains(u, c) || u.push(c)
        }
        return u
    }, m.union = function() {
        return m.uniq(S(arguments, !0, !0))
    }, m.intersection = function(n) {
        for (var t = [], r = arguments.length, e = 0, u = O(n); u > e; e++) {
            var i = n[e];
            if (!m.contains(t, i)) {
                for (var o = 1; r > o && m.contains(arguments[o], i); o++);
                o === r && t.push(i)
            }
        }
        return t
    }, m.difference = function(n) {
        var t = S(arguments, !0, !0, 1);
        return m.filter(n, function(n) {
            return !m.contains(t, n)
        })
    }, m.zip = function() {
        return m.unzip(arguments)
    }, m.unzip = function(n) {
        for (var t = n && m.max(n, O).length || 0, r = Array(t), e = 0; t > e; e++) r[e] = m.pluck(n, e);
        return r
    }, m.object = function(n, t) {
        for (var r = {}, e = 0, u = O(n); u > e; e++) t ? r[n[e]] = t[e] : r[n[e][0]] = n[e][1];
        return r
    }, m.findIndex = t(1), m.findLastIndex = t(-1), m.sortedIndex = function(n, t, r, e) {
        r = x(r, e, 1);
        for (var u = r(t), i = 0, o = O(n); o > i;) {
            var a = Math.floor((i + o) / 2);
            r(n[a]) < u ? i = a + 1 : o = a
        }
        return i
    }, m.indexOf = r(1, m.findIndex, m.sortedIndex), m.lastIndexOf = r(-1, m.findLastIndex), m.range = function(n, t, r) {
        null == t && (t = n || 0, n = 0), r = r || 1;
        for (var e = Math.max(Math.ceil((t - n) / r), 0), u = Array(e), i = 0; e > i; i++, n += r) u[i] = n;
        return u
    };
    var E = function(n, t, r, e, u) {
        if (!(e instanceof t)) return n.apply(r, u);
        var i = j(n.prototype),
            o = n.apply(i, u);
        return m.isObject(o) ? o : i
    };
    m.bind = function(n, t) {
        if (g && n.bind === g) return g.apply(n, l.call(arguments, 1));
        if (!m.isFunction(n)) throw new TypeError("Bind must be called on a function");
        var r = l.call(arguments, 2),
            e = function() {
                return E(n, e, t, this, r.concat(l.call(arguments)))
            };
        return e
    }, m.partial = function(n) {
        var t = l.call(arguments, 1),
            r = function() {
                for (var e = 0, u = t.length, i = Array(u), o = 0; u > o; o++) i[o] = t[o] === m ? arguments[e++] : t[o];
                for (; e < arguments.length;) i.push(arguments[e++]);
                return E(n, r, this, this, i)
            };
        return r
    }, m.bindAll = function(n) {
        var t, r, e = arguments.length;
        if (1 >= e) throw new Error("bindAll must be passed function names");
        for (t = 1; e > t; t++) r = arguments[t], n[r] = m.bind(n[r], n);
        return n
    }, m.memoize = function(n, t) {
        var r = function(e) {
            var u = r.cache,
                i = "" + (t ? t.apply(this, arguments) : e);
            return m.has(u, i) || (u[i] = n.apply(this, arguments)), u[i]
        };
        return r.cache = {}, r
    }, m.delay = function(n, t) {
        var r = l.call(arguments, 2);
        return setTimeout(function() {
            return n.apply(null, r)
        }, t)
    }, m.defer = m.partial(m.delay, m, 1), m.throttle = function(n, t, r) {
        var e, u, i, o = null,
            a = 0;
        r || (r = {});
        var c = function() {
            a = r.leading === !1 ? 0 : m.now(), o = null, i = n.apply(e, u), o || (e = u = null)
        };
        return function() {
            var f = m.now();
            a || r.leading !== !1 || (a = f);
            var l = t - (f - a);
            return e = this, u = arguments, 0 >= l || l > t ? (o && (clearTimeout(o), o = null), a = f, i = n.apply(e, u), o || (e = u = null)) : o || r.trailing === !1 || (o = setTimeout(c, l)), i
        }
    }, m.debounce = function(n, t, r) {
        var e, u, i, o, a, c = function() {
            var f = m.now() - o;
            t > f && f >= 0 ? e = setTimeout(c, t - f) : (e = null, r || (a = n.apply(i, u), e || (i = u = null)))
        };
        return function() {
            i = this, u = arguments, o = m.now();
            var f = r && !e;
            return e || (e = setTimeout(c, t)), f && (a = n.apply(i, u), i = u = null), a
        }
    }, m.wrap = function(n, t) {
        return m.partial(t, n)
    }, m.negate = function(n) {
        return function() {
            return !n.apply(this, arguments)
        }
    }, m.compose = function() {
        var n = arguments,
            t = n.length - 1;
        return function() {
            for (var r = t, e = n[t].apply(this, arguments); r--;) e = n[r].call(this, e);
            return e
        }
    }, m.after = function(n, t) {
        return function() {
            return --n < 1 ? t.apply(this, arguments) : void 0
        }
    }, m.before = function(n, t) {
        var r;
        return function() {
            return --n > 0 && (r = t.apply(this, arguments)), 1 >= n && (t = null), r
        }
    }, m.once = m.partial(m.before, 2);
    var M = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        I = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"];
    m.keys = function(n) {
        if (!m.isObject(n)) return [];
        if (v) return v(n);
        var t = [];
        for (var r in n) m.has(n, r) && t.push(r);
        return M && e(n, t), t
    }, m.allKeys = function(n) {
        if (!m.isObject(n)) return [];
        var t = [];
        for (var r in n) t.push(r);
        return M && e(n, t), t
    }, m.values = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++) e[u] = n[t[u]];
        return e
    }, m.mapObject = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = u.length, o = {}, a = 0; i > a; a++) e = u[a], o[e] = t(n[e], e, n);
        return o
    }, m.pairs = function(n) {
        for (var t = m.keys(n), r = t.length, e = Array(r), u = 0; r > u; u++) e[u] = [t[u], n[t[u]]];
        return e
    }, m.invert = function(n) {
        for (var t = {}, r = m.keys(n), e = 0, u = r.length; u > e; e++) t[n[r[e]]] = r[e];
        return t
    }, m.functions = m.methods = function(n) {
        var t = [];
        for (var r in n) m.isFunction(n[r]) && t.push(r);
        return t.sort()
    }, m.extend = _(m.allKeys), m.extendOwn = m.assign = _(m.keys), m.findKey = function(n, t, r) {
        t = x(t, r);
        for (var e, u = m.keys(n), i = 0, o = u.length; o > i; i++)
            if (e = u[i], t(n[e], e, n)) return e
    }, m.pick = function(n, t, r) {
        var e, u, i = {},
            o = n;
        if (null == o) return i;
        m.isFunction(t) ? (u = m.allKeys(o), e = b(t, r)) : (u = S(arguments, !1, !1, 1), e = function(n, t, r) {
            return t in r
        }, o = Object(o));
        for (var a = 0, c = u.length; c > a; a++) {
            var f = u[a],
                l = o[f];
            e(l, f, o) && (i[f] = l)
        }
        return i
    }, m.omit = function(n, t, r) {
        if (m.isFunction(t)) t = m.negate(t);
        else {
            var e = m.map(S(arguments, !1, !1, 1), String);
            t = function(n, t) {
                return !m.contains(e, t)
            }
        }
        return m.pick(n, t, r)
    }, m.defaults = _(m.allKeys, !0), m.create = function(n, t) {
        var r = j(n);
        return t && m.extendOwn(r, t), r
    }, m.clone = function(n) {
        return m.isObject(n) ? m.isArray(n) ? n.slice() : m.extend({}, n) : n
    }, m.tap = function(n, t) {
        return t(n), n
    }, m.isMatch = function(n, t) {
        var r = m.keys(t),
            e = r.length;
        if (null == n) return !e;
        for (var u = Object(n), i = 0; e > i; i++) {
            var o = r[i];
            if (t[o] !== u[o] || !(o in u)) return !1
        }
        return !0
    };
    var N = function(n, t, r, e) {
        if (n === t) return 0 !== n || 1 / n === 1 / t;
        if (null == n || null == t) return n === t;
        n instanceof m && (n = n._wrapped), t instanceof m && (t = t._wrapped);
        var u = s.call(n);
        if (u !== s.call(t)) return !1;
        switch (u) {
            case "[object RegExp]":
            case "[object String]":
                return "" + n == "" + t;
            case "[object Number]":
                return +n !== +n ? +t !== +t : 0 === +n ? 1 / +n === 1 / t : +n === +t;
            case "[object Date]":
            case "[object Boolean]":
                return +n === +t
        }
        var i = "[object Array]" === u;
        if (!i) {
            if ("object" != typeof n || "object" != typeof t) return !1;
            var o = n.constructor,
                a = t.constructor;
            if (o !== a && !(m.isFunction(o) && o instanceof o && m.isFunction(a) && a instanceof a) && "constructor" in n && "constructor" in t) return !1
        }
        r = r || [], e = e || [];
        for (var c = r.length; c--;)
            if (r[c] === n) return e[c] === t;
        if (r.push(n), e.push(t), i) {
            if (c = n.length, c !== t.length) return !1;
            for (; c--;)
                if (!N(n[c], t[c], r, e)) return !1
        } else {
            var f, l = m.keys(n);
            if (c = l.length, m.keys(t).length !== c) return !1;
            for (; c--;)
                if (f = l[c], !m.has(t, f) || !N(n[f], t[f], r, e)) return !1
        }
        return r.pop(), e.pop(), !0
    };
    m.isEqual = function(n, t) {
        return N(n, t)
    }, m.isEmpty = function(n) {
        return null == n ? !0 : k(n) && (m.isArray(n) || m.isString(n) || m.isArguments(n)) ? 0 === n.length : 0 === m.keys(n).length
    }, m.isElement = function(n) {
        return !(!n || 1 !== n.nodeType)
    }, m.isArray = h || function(n) {
        return "[object Array]" === s.call(n)
    }, m.isObject = function(n) {
        var t = typeof n;
        return "function" === t || "object" === t && !!n
    }, m.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(n) {
        m["is" + n] = function(t) {
            return s.call(t) === "[object " + n + "]"
        }
    }), m.isArguments(arguments) || (m.isArguments = function(n) {
        return m.has(n, "callee")
    }), "function" != typeof /./ && "object" != typeof Int8Array && (m.isFunction = function(n) {
        return "function" == typeof n || !1
    }), m.isFinite = function(n) {
        return isFinite(n) && !isNaN(parseFloat(n))
    }, m.isNaN = function(n) {
        return m.isNumber(n) && n !== +n
    }, m.isBoolean = function(n) {
        return n === !0 || n === !1 || "[object Boolean]" === s.call(n)
    }, m.isNull = function(n) {
        return null === n
    }, m.isUndefined = function(n) {
        return n === void 0
    }, m.has = function(n, t) {
        return null != n && p.call(n, t)
    }, m.noConflict = function() {
        return u._ = i, this
    }, m.identity = function(n) {
        return n
    }, m.constant = function(n) {
        return function() {
            return n
        }
    }, m.noop = function() {}, m.property = w, m.propertyOf = function(n) {
        return null == n ? function() {} : function(t) {
            return n[t]
        }
    }, m.matcher = m.matches = function(n) {
        return n = m.extendOwn({}, n),
            function(t) {
                return m.isMatch(t, n)
            }
    }, m.times = function(n, t, r) {
        var e = Array(Math.max(0, n));
        t = b(t, r, 1);
        for (var u = 0; n > u; u++) e[u] = t(u);
        return e
    }, m.random = function(n, t) {
        return null == t && (t = n, n = 0), n + Math.floor(Math.random() * (t - n + 1))
    }, m.now = Date.now || function() {
        return (new Date).getTime()
    };
    var B = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#x27;",
            "`": "&#x60;"
        },
        T = m.invert(B),
        R = function(n) {
            var t = function(t) {
                    return n[t]
                },
                r = "(?:" + m.keys(n).join("|") + ")",
                e = RegExp(r),
                u = RegExp(r, "g");
            return function(n) {
                return n = null == n ? "" : "" + n, e.test(n) ? n.replace(u, t) : n
            }
        };
    m.escape = R(B), m.unescape = R(T), m.result = function(n, t, r) {
        var e = null == n ? void 0 : n[t];
        return e === void 0 && (e = r), m.isFunction(e) ? e.call(n) : e
    };
    var q = 0;
    m.uniqueId = function(n) {
        var t = ++q + "";
        return n ? n + t : t
    }, m.templateSettings = {
        evaluate: /<%([\s\S]+?)%>/g,
        interpolate: /<%=([\s\S]+?)%>/g,
        escape: /<%-([\s\S]+?)%>/g
    };
    var K = /(.)^/,
        z = {
            "'": "'",
            "\\": "\\",
            "\r": "r",
            "\n": "n",
            "\u2028": "u2028",
            "\u2029": "u2029"
        },
        D = /\\|'|\r|\n|\u2028|\u2029/g,
        L = function(n) {
            return "\\" + z[n]
        };
    m.template = function(n, t, r) {
        !t && r && (t = r), t = m.defaults({}, t, m.templateSettings);
        var e = RegExp([(t.escape || K).source, (t.interpolate || K).source, (t.evaluate || K).source].join("|") + "|$", "g"),
            u = 0,
            i = "__p+='";
        n.replace(e, function(t, r, e, o, a) {
            return i += n.slice(u, a).replace(D, L), u = a + t.length, r ? i += "'+\n((__t=(" + r + "))==null?'':_.escape(__t))+\n'" : e ? i += "'+\n((__t=(" + e + "))==null?'':__t)+\n'" : o && (i += "';\n" + o + "\n__p+='"), t
        }), i += "';\n", t.variable || (i = "with(obj||{}){\n" + i + "}\n"), i = "var __t,__p='',__j=Array.prototype.join," + "print=function(){__p+=__j.call(arguments,'');};\n" + i + "return __p;\n";
        try {
            var o = new Function(t.variable || "obj", "_", i)
        } catch (a) {
            throw a.source = i, a
        }
        var c = function(n) {
                return o.call(this, n, m)
            },
            f = t.variable || "obj";
        return c.source = "function(" + f + "){\n" + i + "}", c
    }, m.chain = function(n) {
        var t = m(n);
        return t._chain = !0, t
    };
    var P = function(n, t) {
        return n._chain ? m(t).chain() : t
    };
    m.mixin = function(n) {
        m.each(m.functions(n), function(t) {
            var r = m[t] = n[t];
            m.prototype[t] = function() {
                var n = [this._wrapped];
                return f.apply(n, arguments), P(this, r.apply(m, n))
            }
        })
    }, m.mixin(m), m.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            var r = this._wrapped;
            return t.apply(r, arguments), "shift" !== n && "splice" !== n || 0 !== r.length || delete r[0], P(this, r)
        }
    }), m.each(["concat", "join", "slice"], function(n) {
        var t = o[n];
        m.prototype[n] = function() {
            return P(this, t.apply(this._wrapped, arguments))
        }
    }), m.prototype.value = function() {
        return this._wrapped
    }, m.prototype.valueOf = m.prototype.toJSON = m.prototype.value, m.prototype.toString = function() {
        return "" + this._wrapped
    }, "function" == typeof define && define.amd && define("underscore", [], function() {
        return m
    })
}).call(this);
var activeRGTimePeriodButtonDictionary = {};
var rgCurrentLimitValuesDictionary = {};
var resultHtml = {};
var limitInputFieldMaxValueByInterval = {};
var responsibleGamingManager = {
    setIntervalComponent: function(interval, buttonId, intervalElementId, currentLimitElementId, limitLabel, limitInputField, totalAccruedValueLabelElementId, totalAccruedDataValueElementId, isLimitSetElemtId, isInputFieldEditableElementId, setLimitButtonId) {
        document.getElementById(intervalElementId).value = interval;
        var isKeySet = intervalElementId in activeRGTimePeriodButtonDictionary;
        if (isKeySet) {
            document.getElementById(activeRGTimePeriodButtonDictionary[intervalElementId]).classList.remove("rg-active-period-button");
            this.setActiveTimePeriodButton(buttonId, intervalElementId);
        } else {
            this.setActiveTimePeriodButton(buttonId, intervalElementId);
        }
        if (currentLimitElementId && limitLabel && limitInputField) {
            this.synchronizeLimitTextData(currentLimitElementId, limitLabel, limitInputField);
        }
        if (totalAccruedValueLabelElementId && totalAccruedDataValueElementId && document.getElementById(totalAccruedDataValueElementId) != null) {
            var totalAccrued = document.getElementById(totalAccruedDataValueElementId).value;
            if (totalAccrued) {
                totalAccrued = ToThousandSeparator(totalAccrued);
            } else {
                totalAccrued = "0.00";
            }
            document.getElementById(totalAccruedValueLabelElementId).innerText = totalAccrued;
        } else if (totalAccruedValueLabelElementId) {
            document.getElementById(totalAccruedValueLabelElementId).innerText = "0.00";
        }
        if (isLimitSetElemtId && isInputFieldEditableElementId) {
            var isLimitSet = (document.getElementById(isLimitSetElemtId).value.toLowerCase() == 'true');
            var isInputFieldEditable = (document.getElementById(isInputFieldEditableElementId).value.toLowerCase() == 'true');
            if (!isLimitSet) {
                document.getElementById(limitInputField).disable = false;
                document.getElementById(setLimitButtonId).disable = false;
            } else {
                if (isLimitSet && !isInputFieldEditable) {
                    document.getElementById(limitInputField).disable = true;
                    document.getElementById(setLimitButtonId).disable = true;
                } else if (isInputFieldEditable) {
                    document.getElementById(limitInputField).disable = false;
                    document.getElementById(setLimitButtonId).disable = false;
                } else {
                    console.warn("not supposed to reach this...");
                }
            }
        }
    },
    synchronizeLimitTextData: function(currentLimitElementId, limitLabel, limitInputField) {
        if (limitLabel && currentLimitElementId) {
            var limit = document.getElementById(currentLimitElementId) == null ? 0 : document.getElementById(currentLimitElementId).value;
            if (limit) {
                limit = ToThousandSeparator(limit);
            } else {
                limit = "0.00";
            }
            document.getElementById(limitLabel).innerText = limit;
            if (document.contains(document.getElementById(limitInputField))) {
                document.getElementById(limitInputField).value = limit.toLocaleString().replace(/,/g, "");
            }
        } else if (limitLabel) {
            document.getElementById(limitLabel).innerText = "0.00";
        }
    },
    setActiveTimePeriodButton: function(buttonId, elementId) {
        document.getElementById(buttonId).classList.add("rg-active-period-button");
        activeRGTimePeriodButtonDictionary[elementId] = buttonId;
    },
    onResponsibleGamingBtnClick: function(formId, actionName, divContentToReplace) {
        var pageIsValid = false;
        if (checkForLite()) {
            pageIsValid = this.setLiteValidations(formId);
        } else {
            pageIsValid = $(`#${formId}`).valid();
        }
        if (pageIsValid) {
            if (!checkForLite()) {
                homePage.showOverlay();
            }
            var ele = document.getElementById(formId);
            data = Array.from(new FormData(ele), e => e.map(encodeURIComponent).join('=')).join('&');
            var xhttp = new XMLHttpRequest();
            xhttp.open("POST", '/ResponsibleGaming/' + actionName, true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    if (!checkForLite()) {
                        $(`#${divContentToReplace}`).html(this.response);
                        homePage.closeOverlay();
                    } else {
                        if (this.response.includes("exclusionLogoutRedirect")) {
                            window.location.href = '/Account/LogOut';
                        }
                        document.getElementById(divContentToReplace).innerHTML = this.response;
                        var elements = ['DepositLimitTimeIntervalId', 'LossLimitTimeIntervalId', 'WagerLimitTimeIntervalId', 'IntervalComponent'];
                        elements.forEach(el => {
                            var btnId = activeRGTimePeriodButtonDictionary[el];
                            document.getElementById(btnId).classList.add("rg-active-period-button");
                        });
                    }
                    if (this.response.includes("sessionLimitSuccess")) {
                        localStorage.removeItem("totalSeconds");
                        location.reload();
                    }
                }
            };
            xhttp.send(data);
        }
    },
    setCurrentLimitValue: function(interval, value) {
        rgCurrentLimitValuesDictionary[interval] = value;
    },
    onConfirmBtnClick: function(formId, actionName, divContentToReplace, headerText, content, contentNote, contentPeriod) {
        var pageIsValid = false;
        if (checkForLite()) {
            pageIsValid = this.setLiteValidations(formId);
        } else {
            pageIsValid = $(`#${formId}`).valid();
        }
        if (pageIsValid) {
            var placeholderValue;
            if (typeof contentPeriod !== "undefined" && contentPeriod !== '') {
                placeholderValue = '<strong>' + contentPeriod + '</strong>';
            } else {
                var periodValue = document.getElementById(formId).getElementsByClassName("periodValue")[0].value;
                periodValue = Number(periodValue).toLocaleString();
                var periodInterval = document.getElementById(formId).getElementsByClassName("rg-active-period-button")[0].textContent;
                placeholderValue = '<strong>' + periodValue + ' ' + periodInterval + '?</strong>';
            }
            if (!checkForLite()) {
                $('#genericModalHeader').html(headerText);
                $('#genericMiddleContent').html(content + placeholderValue).append("<br/>" + contentNote);
                if (actionName === 'SetSelfExclusion') {
                    language.translateAtRuntime($('#selfExclusionHeaderPopup'), "ResponsibleGamingContent", {
                        "data-translate-key": "SelfExclusionHeaderPopup"
                    });
                    language.translateAtRuntime($('#exclusionConfirmPopupContent'), "ResponsibleGamingContent", {
                        "data-translate-key": "ExclusionConfirmPopupContent"
                    });
                    language.translateAtRuntime($('#exclusionContentPleaseNote'), "ResponsibleGamingContent", {
                        "data-translate-key": "ExclusionContentPleaseNote"
                    });
                }
                if (actionName === 'SetCoolingOffPeriod') {
                    language.translateAtRuntime($('#coolOffHeaderPopup'), "ResponsibleGamingContent", {
                        "data-translate-key": "CoolOffHeaderPopup"
                    });
                    language.translateAtRuntime($('#exclusionConfirmPopupContent'), "ResponsibleGamingContent", {
                        "data-translate-key": "ExclusionConfirmPopupContent"
                    });
                    language.translateAtRuntime($('#exclusionContentPleaseNote'), "ResponsibleGamingContent", {
                        "data-translate-key": "ExclusionContentPleaseNote"
                    });
                }
                $('#genericConfirmBtns').show();
                $('#btnConfirm').text("Confirm");
                language.translateAtRuntime($('#btnConfirm'), "ResponsibleGamingContent", {
                    "data-translate-key": "ConfirmText"
                });
                $('#btn-back').text("Cancel");
                language.translateAtRuntime($('#btn-back'), "ResponsibleGamingContent", {
                    "data-translate-key": "CancelText"
                });
                $('#generic-modal').modal();
                $("#btnConfirm").off("click").click(function() {
                    responsibleGamingManager.onResponsibleGamingBtnClick(formId, actionName, divContentToReplace);
                    $("#generic-modal").modal('hide');
                });
            } else {
                document.getElementById(formId).getElementsByClassName("ConfirmExclusion")[0].innerHTML = content + placeholderValue + "<br/>" + contentNote;
                document.getElementById(formId).getElementsByClassName("LiteExclusionConfirm")[0].classList.remove('hidden');
            }
        }
        return false;
    },
    setLiteValidations: function(formId) {
        var periodValueLimit = document.getElementById(formId).getElementsByClassName("ValueValidation")[0];
        var errorMessageSpan = document.getElementById(formId).getElementsByClassName("error-message")[0];
        var pageIsValid = periodValueLimit.value !== "" && periodValueLimit.value !== undefined;
        if (!pageIsValid) {
            errorMessageSpan.innerHTML = periodValueLimit.getAttribute("data-val-required");
        } else {
            errorMessageSpan.innerHTML = "";
        }
        return pageIsValid;
    },
    executeSessionTimer: function(sessionTimer) {
        if (sessionTimer > 0) {
            var totalSeconds = localStorage.getItem("totalSeconds") ? localStorage.getItem("totalSeconds") : (sessionTimer * 60 - 60).toString();

            function checkTime() {
                if (totalSeconds <= 0) {
                    localStorage.removeItem("totalSeconds");
                    clearInterval(myInterval);
                    var ageVerificationEnabled = localStorage.getItem("ageVerificationEnabled") == "true";
                    var showAgeVerification = localStorage.getItem('showAgeVerification') == "true";
                    if (sessionTimerEnabled && sessionTimer > 0) {
                        if (ageVerificationEnabled && showAgeVerification) {
                            recheckTime();
                        } else {
                            if (!checkForLite()) {
                                $('#rgGamingLimitReached-modal').modal();
                                $('#rgGamingLimitReachedModalHeader').html("Reality Check");
                                $('#rgInfoModalMiddleContent').html($('#realityCheckPartial').html());
                                $('#rgConfirmBtns').hide();
                                $('#rgGamingLimitReached-modal').modal('show');
                                var signUpModalOptions = $('#rgGamingLimitReached-modal').data('bs.modal').options;
                                if (typeof signUpModalOptions !== "undefined" && signUpModalOptions !== null) {
                                    signUpModalOptions.backdrop = 'static';
                                }
                                $('#btnKeepPlaying').click(function() {
                                    recheckTime();
                                    $('#realityCheckPartial').hide();
                                });
                                $('#rgGamingLimitReached-modal').on('hidden.bs.modal', function() {
                                    recheckTime();
                                    $('#realityCheckPartial').hide();
                                });
                            } else {
                                var sessionModalElement = document.getElementById("realityCheckModal");
                                document.getElementById("realityCheckPartial").classList.remove("hidden");
                                sessionModalElement.classList.replace("overlay-hidden", "overlay-visible");
                                document.getElementById("btnKeepPlaying").addEventListener("click", function() {
                                    recheckTime();
                                    responsibleGamingManager.hideModalDisplay(sessionModalElement);
                                });
                                document.getElementById("closePopup").addEventListener("click", function() {
                                    recheckTime();
                                    responsibleGamingManager.hideModalDisplay(sessionModalElement);
                                });
                            }
                        }
                    }
                } else {
                    totalSeconds = totalSeconds - 60;
                    localStorage.setItem("totalSeconds", totalSeconds);
                }
            }

            function recheckTime() {
                clearInterval(myInterval);
                if (sessionTimerEnabled && sessionTimer > 0) {
                    totalSeconds = localStorage.getItem("totalSeconds") ? localStorage.getItem("totalSeconds") : (sessionTimer * 60 - 60).toString();
                    myInterval = setInterval(checkTime, 60000);
                }
            }
            var myInterval = setInterval(checkTime, 60000);
        }
    },
    onVerifyAgeBtnClick: function(e) {
        e.preventDefault();
        var dobDay = document.getElementsByClassName("DOBDropDownDay")[0].value,
            dobMonth = document.getElementsByClassName("DOBDropDownMonth")[0].value,
            dobYear = document.getElementsByClassName("DOBDropDownYear")[0].value;
        if (!this.isNullOrEmptyArray(dobDay, dobMonth, dobYear)) {
            var isDateValid = isValid(dobDay, dobMonth, dobYear);
            if (isDateValid) {
                var dob = dobYear + "-" + dobMonth + "-" + dobDay + ' 00:00';
                document.getElementById("btnProceed").disabled = true;
                ajax.post("/ResponsibleGaming/VerifyAgeForAccount", {
                    dateOfBirth: dob
                }, function(result) {
                    var data = JSON.parse(result);
                    if (data.Success) {
                        var currentAttempt = data.NumberOfAttempts;
                        var maxAttempts = data.MaxNumberOfAttempts;
                        if (data.IsValidAge) {
                            localStorage.setItem("showAgeVerification", false);
                            if (!checkForLite()) {
                                $('#generic-modal').modal('hide');
                            } else {
                                location.reload();
                            }
                        } else {
                            if (data.MaxNumberOfAttemptsExceeded || data.IsAccountLocked) {
                                location.href = 'Account/Logout';
                            } else {
                                if (!data.MaxNumberOfAttemptsExceeded && !data.IsValidAge) {
                                    document.getElementById("dob-error").classList.remove("hidden");
                                    document.getElementById("dob-error").innerText = " You have entered an incorrect Date of Birth, your account will be locked after " + maxAttempts + " attempts. You are on attempt " + currentAttempt;
                                    language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                                        "data-translate-key": "IncorrectDoB",
                                        "data-translate-type": "generic-html",
                                        "data-translate-value-0": maxAttempts,
                                        "data-translate-value-1": currentAttempt
                                    });
                                }
                            }
                        }
                    } else {
                        document.getElementById("dob-error").classList.remove("hidden");
                        document.getElementById("dob-error").innerText = data.ErrorMessage;
                        language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                            "data-translate-key": "AgeVerificationError"
                        });
                    }
                    document.getElementById("btnProceed").disabled = false;
                });
            } else if (checkForLite()) {
                document.getElementById("dob-error").classList.remove("hidden");
                document.getElementById("dob-error").innerText = "Please enter a valid date of birth.";
            }
        } else {
            document.getElementById("dob-error").classList.remove("hidden");
            document.getElementById("dob-error").innerText = "Date of Birth field cannot be empty.";
            language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                "data-translate-key": "EmptyDoB"
            });
        }
        return false;
    },
    onChangedInterval: function(limitInputFieldId, maxValue, setLimitButtonId) {
        limitInputFieldMaxValueByInterval[limitInputFieldId] = maxValue;
        this.OnChangeEvent(limitInputFieldId, setLimitButtonId, document.getElementById(limitInputFieldId).value);
    },
    OnChangeEvent: function(limitInputFieldId, setLimitButtonId, val) {
        var maxVal = limitInputFieldMaxValueByInterval[limitInputFieldId];
        if (maxVal && setLimitButtonId && val) {
            if (val > maxVal) {
                document.getElementById(setLimitButtonId).disabled = true;
            } else {
                document.getElementById(setLimitButtonId).disabled = false;
            }
        }
    },
    logOut: function() {
        if (!checkForLite()) {
            homePage.logout();
        }
        window.location.href = '/Account/LogOut';
    },
    isNullOrEmpty: function(str) {
        return (str === null || str.trim() === "");
    },
    isNullOrEmptyArray: function(...strArray) {
        if (strArray !== null)
            return strArray.includes(null) || strArray.includes("");
        else
            return true;
    },
    hideModalDisplay: function(sessionModalElement) {
        sessionModalElement.classList.replace("overlay-visible", "overlay-hidden");
        document.getElementById("realityCheckPartial").classList.add("hidden");
    }
}

function docReady(fn) {
    if (document.readyState === "complete" || document.readyState === "interactive") {
        setTimeout(fn, 1);
    } else {
        document.addEventListener("DOMContentLoaded", fn);
    }
}
docReady(function() {
    if (isUserLoggedIn && checkForLite() && ageVerificationEnabled && global.getCookie("showAgeVerification") === "true") {
        if (document.location.pathname.indexOf("ThankYou") == -1) {
            document.getElementById("main").textContent = '';
            document.getElementById("ageVerificationContent").classList.remove("hidden");
            document.getElementsByClassName("main-header")[0].classList.add("disable-section");
        }
    }
});;