(function(n, t) {
    "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : n.Blazy = t()
})(this, function() {
    function h(n) {
        var i = n._util;
        i.elements = b(n.options);
        i.count = i.elements.length;
        i.destroyed && (i.destroyed = !1, n.options.container && t(n.options.container, function(n) {
            r(n, "scroll", i.validateT)
        }), r(window, "resize", i.saveViewportOffsetT), r(window, "resize", i.validateT), r(window, "scroll", i.validateT));
        c(n)
    }

    function c(n) {
        for (var s, r, t, h, f = n._util, o = 0; o < f.count; o++) {
            s = f.elements[o];
            n: {
                if (t = s, r = n.options, h = t.getBoundingClientRect(), r.container && w && (t = t.closest(r.containerClass))) {
                    t = t.getBoundingClientRect();
                    r = u(t, i) ? u(h, {
                        top: t.top - r.offset,
                        right: t.right + r.offset,
                        bottom: t.bottom + r.offset,
                        left: t.left - r.offset
                    }) : !1;
                    break n
                }
                r = u(h, i)
            }(r || e(s, n.options.successClass)) && (n.load(s), f.elements.splice(o, 1), f.count--, o--)
        }
        0 === f.count && n.destroy()
    }

    function u(n, t) {
        return n.right >= t.left && n.bottom >= t.top && n.left <= t.right && n.top <= t.bottom
    }

    function l(i, u, h) {
        if (!e(i, h.successClass) && (u || h.loadInvisible || 0 < i.offsetWidth && 0 < i.offsetHeight))
            if (u = i.getAttribute(s) || i.getAttribute(h.src)) {
                u = u.split(h.separator);
                var l = u[p && 1 < u.length ? 1 : 0],
                    w = i.getAttribute(h.srcset),
                    b = "img" === i.nodeName.toLowerCase(),
                    k = (u = i.parentNode) && "picture" === u.nodeName.toLowerCase();
                if (b || void 0 === i.src) {
                    var c = new Image,
                        v = function() {
                            h.error && h.error(i, "invalid");
                            o(i, h.errorClass);
                            n(c, "error", v);
                            n(c, "load", y)
                        },
                        y = function() {
                            b ? k || a(i, l, w) : i.style.backgroundImage = 'url("' + l + '")';
                            f(i, h);
                            n(c, "load", y);
                            n(c, "error", v)
                        };
                    k && (c = i, t(u.getElementsByTagName("source"), function(n) {
                        var t = h.srcset,
                            i = n.getAttribute(t);
                        i && (n.setAttribute("srcset", i), n.removeAttribute(t))
                    }));
                    r(c, "error", v);
                    r(c, "load", y);
                    a(c, l, w)
                } else i.src = l, f(i, h)
            } else "video" === i.nodeName.toLowerCase() ? (t(i.getElementsByTagName("source"), function(n) {
                var t = h.src,
                    i = n.getAttribute(t);
                i && (n.setAttribute("src", i), n.removeAttribute(t))
            }), i.load(), f(i, h)) : (h.error && h.error(i, "missing"), o(i, h.errorClass))
    }

    function f(n, i) {
        o(n, i.successClass);
        i.success && i.success(n);
        n.removeAttribute(i.src);
        n.removeAttribute(i.srcset);
        t(i.breakpoints, function(t) {
            n.removeAttribute(t.src)
        })
    }

    function a(n, t, i) {
        i && n.setAttribute("srcset", i);
        n.src = t
    }

    function e(n, t) {
        return -1 !== (" " + n.className + " ").indexOf(" " + t + " ")
    }

    function o(n, t) {
        e(n, t) || (n.className += " " + t)
    }

    function b(n) {
        var i = [],
            t;
        for (n = n.root.querySelectorAll(n.selector), t = n.length; t--; i.unshift(n[t]));
        return i
    }

    function v(n) {
        i.bottom = (window.innerHeight || document.documentElement.clientHeight) + n;
        i.right = (window.innerWidth || document.documentElement.clientWidth) + n
    }

    function r(n, t, i) {
        n.attachEvent ? n.attachEvent && n.attachEvent("on" + t, i) : n.addEventListener(t, i, {
            capture: !1,
            passive: !0
        })
    }

    function n(n, t, i) {
        n.detachEvent ? n.detachEvent && n.detachEvent("on" + t, i) : n.removeEventListener(t, i, {
            capture: !1,
            passive: !0
        })
    }

    function t(n, t) {
        if (n && t)
            for (var r = n.length, i = 0; i < r && !1 !== t(n[i], i); i++);
    }

    function y(n, t, i) {
        var r = 0;
        return function() {
            var u = +new Date;
            u - r < t || (r = u, n.apply(i, arguments))
        }
    }
    var s, i, p, w;
    return function(r) {
        var e, u, f;
        document.querySelectorAll || (e = document.createStyleSheet(), document.querySelectorAll = function(n, t, i, r, u) {
            for (u = document.all, t = [], n = n.replace(/\[for\b/gi, "[htmlFor").split(","), i = n.length; i--;) {
                for (e.addRule(n[i], "k:v"), r = u.length; r--;) u[r].currentStyle.k && t.push(u[r]);
                e.removeRule(0)
            }
            return t
        });
        u = this;
        f = u._util = {};
        f.elements = [];
        f.destroyed = !0;
        u.options = r || {};
        u.options.error = u.options.error || !1;
        u.options.offset = u.options.offset || 100;
        u.options.root = u.options.root || document;
        u.options.success = u.options.success || !1;
        u.options.selector = u.options.selector || ".b-lazy";
        u.options.separator = u.options.separator || "|";
        u.options.containerClass = u.options.container;
        u.options.container = u.options.containerClass ? document.querySelectorAll(u.options.containerClass) : !1;
        u.options.errorClass = u.options.errorClass || "b-error";
        u.options.breakpoints = u.options.breakpoints || !1;
        u.options.loadInvisible = u.options.loadInvisible || !1;
        u.options.successClass = u.options.successClass || "b-loaded";
        u.options.validateDelay = u.options.validateDelay || 25;
        u.options.saveViewportOffsetDelay = u.options.saveViewportOffsetDelay || 50;
        u.options.srcset = u.options.srcset || "data-srcset";
        u.options.src = s = u.options.src || "data-src";
        w = Element.prototype.closest;
        p = 1 < window.devicePixelRatio;
        i = {};
        i.top = 0 - u.options.offset;
        i.left = 0 - u.options.offset;
        u.revalidate = function() {
            h(u)
        };
        u.load = function(n, i) {
            var r = this.options;
            void 0 === n.length ? l(n, i, r) : t(n, function(n) {
                l(n, i, r)
            })
        };
        u.destroy = function() {
            var i = this._util;
            this.options.container && t(this.options.container, function(t) {
                n(t, "scroll", i.validateT)
            });
            n(window, "scroll", i.validateT);
            n(window, "resize", i.validateT);
            n(window, "resize", i.saveViewportOffsetT);
            i.count = 0;
            i.elements.length = 0;
            i.destroyed = !0
        };
        f.validateT = y(function() {
            c(u)
        }, u.options.validateDelay, u);
        f.saveViewportOffsetT = y(function() {
            v(u.options.offset)
        }, u.options.saveViewportOffsetDelay, u);
        v(u.options.offset);
        t(u.options.breakpoints, function(n) {
            if (n.width >= window.screen.width) return s = n.src, !1
        });
        setTimeout(function() {
            h(u)
        })
    }
})