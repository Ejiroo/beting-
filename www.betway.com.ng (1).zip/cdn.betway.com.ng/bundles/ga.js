function load_css_async(n) {
    var t = function() {
            var t = document.createElement("link"),
                i;
            t.rel = "stylesheet";
            t.href = n;
            i = document.getElementsByTagName("head")[0];
            i.parentNode.insertBefore(t, i)
        },
        i = requestAnimationFrame || mozRequestAnimationFrame || webkitRequestAnimationFrame || msRequestAnimationFrame;
    i ? i(t) : window.addEventListener("load", t)
}
var confirmBetPOICount;
(function(n, t, i, r, u) {
    n[r] = n[r] || [];
    n[r].push({
        "gtm.start": (new Date).getTime(),
        event: "gtm.js"
    });
    var e = t.getElementsByTagName(i)[0],
        f = t.createElement(i),
        o = r != "dataLayer" ? "&l=" + r : "";
    f.async = !0;
    f.src = "https://www.googletagmanager.com/gtm.js?id=" + u + o;
    e.parentNode.insertBefore(f, e)
})(window, document, "script", "dataLayer", "GTM-NDNGV7K");
var gax = {},
    showConsoleLogs = !1,
    casinoCategory = "All",
    holdBankingTitle = "",
    registrationPOIString = "";
gax.SetRegistration_EventTracking_QueryString = function() {
    useGoogleAnalytics && (registrationPOIString = "Query String")
};
gax.SetRegistration_EventTracking_Header = function() {
    useGoogleAnalytics && (registrationPOIString = "Header")
};
gax.RegistrationInitiatedEvent_EventTracking = function() {
    useGoogleAnalytics && (registrationPOIString === "" && (registrationPOIString = "Other"), dataLayer.push({
        event: "RegistrationInitiatedEvent",
        registrationPOI: registrationPOIString
    }), showConsoleLogs && console.log(dataLayer))
};
gax.SuccessfulRegistration_EventTracking = function(n, t) {
    useGoogleAnalytics && (dataLayer.push({
        event: "RegistrationCompleteEvent",
        registrationPOI: registrationPOIString,
        offer: n,
        promotions: t
    }), showConsoleLogs && console.log(dataLayer))
};
gax.SearchEvents_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "SearchEventsEvent",
        SearchEventsText: n.toLowerCase()
    }), showConsoleLogs && console.log(dataLayer))
};
gax.SearchedEventSelection_EventTracking = function(n, t, i) {
    useGoogleAnalytics && (dataLayer.push({
        event: "SearchedEventSelectionEvent",
        SearchedEventSelectionDateTime: n,
        SearchedEventSelectionLeague: t,
        SearchedEventSelectionFixture: i
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingGeneric_EventTracking = function(n, t, i) {
    if (useGoogleAnalytics) {
        let r = i;
        r == null && (r = "");
        r = r.replace("Credit-Debit Card", "Peach Payments");
        dataLayer.push({
            section: n,
            event: t,
            method: r
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingVoucherProceed_EventTracking = function(n) {
    useGoogleAnalytics && (localStorage.setItem("LastProceedMethod", n), showConsoleLogs && console.log("LastProceedMethod set", n), dataLayer.push({
        event: "BankingVoucherRedeemClicked",
        method: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingDepositResultPageNoMethodSpecified_EventTracking = function(n) {
    if (useGoogleAnalytics)
        if ($(".newDepositModal").length == 0) {
            let t = localStorage.getItem("LastProceedMethod");
            t || (t = "");
            gax.BankingDepositResultPage_EventTracking(t, n)
        } else console.log("BankingDepositResultPageNoMethodSpecified_EventTracking: This method is obsolete and no longer used")
};
gax.BankingDepositResultPageNoMethodSpecifiedNew_EventTracking = function(n) {
    if (useGoogleAnalytics) {
        let t = localStorage.getItem("LastProceedMethod");
        t || (t = "");
        gax.BankingDepositResultPage_EventTracking(t, n)
    }
};
gax.BankingDepositResultPage_EventTracking = function(n, t) {
    if (useGoogleAnalytics) {
        let u = global.getCookie("BankingDepositVersion");
        if (u != null && u != undefined && (u == "" || u == "Old") || u == null || u == undefined) {
            var r = document.referrer != null ? document.referrer : "",
                i = localStorage.getItem("disallowRedirectForGa");
            i == null && (i = "0");
            n != null && n != "" && dataLayer.push({
                event: "BankingDepositResultPage",
                method: n,
                result: t,
                referrer: r
            });
            localStorage.setItem("LastProceedMethod", null);
            showConsoleLogs && console.log(dataLayer);
            i == "1" && object.addEventListener("beforeunload", function() {
                return !1
            })
        } else gax.BankingResultLog_EventTracking("deposits", t)
    }
};
gax.BankingResultLog_EventTracking = function(n, t) {
    if (useGoogleAnalytics) {
        let i = localStorage.getItem("LastProceedMethod");
        i || (i = "");
        let r = new Date,
            u = new Date(localStorage.getItem(n + "Opened-Method-" + i)),
            f = new Date(localStorage.getItem(n + "Opened"));
        dataLayer.push({
            version: "MoneyUI",
            event: "DepositResult",
            method: i,
            fromSource: "Vuvu",
            type: t,
            timeTakenFromMethodOpen: (r.getTime() - u.getTime()) / 1e3,
            timeTakenFromMainLoad: (r.getTime() - f.getTime()) / 1e3
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingDepositProceed_EventTracking = function(n, t) {
    if (useGoogleAnalytics) {
        let i = t;
        i == null && (i = "");
        i = i.replace("Credit-Debit Card", "Peach Payments");
        localStorage.setItem("LastProceedMethod", i);
        showConsoleLogs && console.log("LastProceedMethod set", i);
        dataLayer.push({
            event: "BankingDepositProceedClicked",
            amount: n,
            method: i
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingDepositAmount_EventTracking = function(n, t) {
    if (useGoogleAnalytics) {
        let i = t;
        i == null && (i = "");
        i = i.replace("Credit-Debit Card", "Peach Payments");
        dataLayer.push({
            event: "BankingDepositAmountSelected",
            amount: n,
            method: i
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingDepositInfo_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingDepositInfo",
        clicked: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingDepositInfo_EventTrackingLong = function(n, t) {
    if (useGoogleAnalytics) {
        let i = t;
        i == null && (i = "");
        i = i.replace("Credit-Debit Card", "Peach Payments");
        dataLayer.push({
            event: "BankingDepositInfo",
            clicked: n,
            method: i
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingDepositEntryPoint_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingDepositEntryPoint",
        From: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.ReverseWithdrawal_EventTracking = function(n, t, i, r = "", u = "", f = "") {
    if (useGoogleAnalytics) {
        let e = n == "" ? document.location.href.toString().indexOf("WithdrawFunds") != -1 ? "Withdrawals" : "Deposits" : n;
        e = document.location.href.toString().indexOf("ReverseWithdrawalTransactions") != -1 ? "My Pending Withdrawals" : e;
        dataLayer.push({
            event: "ReverseWithdrawal",
            area: e,
            step: t,
            action: i,
            extraTitle: r,
            paymentMethod: u,
            amount: f
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingModal_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingModalDepositEvent",
        DepositModal: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingModalTitle_EventTracking = function(n) {
    if (useGoogleAnalytics) {
        let t = n;
        t == null && (t = "");
        t = t.replace("Credit-Debit Card", "Peach Payments");
        holdBankingTitle = t;
        dataLayer.push({
            event: "BankingOptionEvent",
            BankingMethod: t
        });
        showConsoleLogs && console.log(dataLayer)
    }
};
gax.BankingTitle_EventTracking = function(n) {
    useGoogleAnalytics && (holdBankingTitle = n, dataLayer.push({
        event: "BankingOptionEvent",
        BankingMethod: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingPresetDepositAmount_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingPresetDepositAmountEvent",
        BankingMethod: holdBankingTitle,
        BankingPresetDepositAmount: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingConfirm_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingProceedDepositEvent",
        BankingMethod: holdBankingTitle,
        BankingDepositAmount: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingDepositSuccess_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "BankingDepositSuccessEvent",
        DepositID: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.BankingDepositErrorEvent_EventTracking = function(n, t) {
    useGoogleAnalytics && (t === "" && (t = 0), dataLayer.push({
        event: "BankingDepositErrorEvent",
        BankingMethod: holdBankingTitle,
        BankingDepositAmount: t,
        BankingErrorMsg: n
    }), showConsoleLogs && console.log(dataLayer))
};
gax.SetCasinoCategory = function(n) {
    useGoogleAnalytics && (casinoCategory = n)
};
gax.CasinoGameLaunch_EventTracking = function(n) {
    useGoogleAnalytics && (dataLayer.push({
        event: "CasinoGameLaunchEvent",
        CasinoGameName: n,
        CasinoGameCategory: casinoCategory
    }), showConsoleLogs && console.log(dataLayer))
};
var betPOICount = 0,
    betPOI = [],
    singleOrMultiBetType = "MultiBet";
gax.SetBetPOI = function(n, t) {
    if (console.log("useGoogleAnalytics", useGoogleAnalytics), typeof betPOI == "undefined" && (betPOI = []), typeof betPOICount == "undefined" && (betPOICount = -1), betPOICount++, useGoogleAnalytics) {
        var i = !1;
        betPOI.forEach(function(n, r) {
            typeof n != "undefined" && n !== null && n.outcome === t && (betPOI.pop(r), i = !0)
        });
        i || betPOI.push({
            poi: n,
            outcome: t
        });
        betPOICount = betPOI.length - 1;
        gax.SetGAData("GABetPOI", betPOI.poi);
        gax.SetGAData("GABetOutcome", betPOI.outcome)
    }
    console.log("betPOI", betPOI)
};
gax.SetSingleOrMultiBet = function(n) {
    useGoogleAnalytics && (n === "SingleBet" ? gax.SetGAData("GASingleBet", !0) : gax.SetGAData("GASingleBet", !1), singleOrMultiBetType = n)
};
gax.RemoveBetSlipPOI = function(n) {
    if (useGoogleAnalytics) {
        var i = [],
            r = 0,
            t = 0;
        typeof betPOI == "undefined" && (betPOI = []);
        betPOI.forEach(function() {
            t !== n && (i[r] = betPOI[t], r++);
            t++
        });
        betPOI = i;
        gax.SetGAData("GABetPOI", betPOI);
        betPOICount > 0 && (betPOICount--, gax.SetGAData("GABetPOICount", betPOICount))
    }
};
gax.ResetBetSlipPOICount = function() {
    useGoogleAnalytics && (betPOICount = 0, confirmBetPOICount = 0, betPOI = [], gax.SetGAData("GABetPOICount", betPOICount))
};
gax.AddToBetslip_EventTracking = function(n, t, i, r, u, f, e) {
    var s = "",
        o;
    if (e !== null && e.length > 0 && (s = e.split(",")), typeof betPOI == "undefined" && (betPOI = []), typeof betPOICount == "undefined" && (betPOICount = -1), useGoogleAnalytics) {
        o = [];
        try {
            o = betPOI.length < 1 || betPOICount === -1 ? [] : betPOI[betPOICount].poi
        } catch (h) {
            o = []
        }
        dataLayer.push({
            event: "AddToBetslipEvent",
            BetOutcome: n,
            BetType: t,
            BetFixture: i,
            BetOdds: r,
            BetPOI: o,
            BetLeague: u,
            BetSport: f,
            eventId: s
        });
        console.log("dataLayer", dataLayer);
        betPOICount++;
        gax.SetGAData("GABetPOICount", betPOICount);
        showConsoleLogs && console.log(dataLayer)
    }
};
confirmBetPOICount = 0;
gax.reconWithBetslip = function() {
    var t = JSON.parse(GetBetslip()),
        i = [],
        n;
    for (typeof betPOI == "undefined" && (betPOI = []), betPOI.forEach(function(n) {
            for (var r = !1, u = 0; u <= t.length - 1; u++) r || t[u].OutcomeId !== n.outcome || (r = !0);
            r || i.push(n.outcome)
        }), n = betPOI.length - 1; n >= 0; n--) i.includes(betPOI[n].outcome) && betPOI.splice(n, 1);
    gax.SetGAData("GABetPOI", betPOI)
};
gax.ConfirmBet = function(n, t) {
    var f = "",
        i, r, u;
    t !== null && t.length > 0 && (f = t.split(","));
    useGoogleAnalytics && (i = "", gax.reconWithBetslip(), singleOrMultiBetType === "MultiBet" ? (r = !1, u = !1, betPOI.forEach(function(n) {
        n === "Sport Page" && (r = !0);
        n === "Search" && (u = !0)
    }), i = r && u ? "Multi Bet POI from both Sport Page and Search" : betPOI[confirmBetPOICount]) : (i = betPOI[confirmBetPOICount], confirmBetPOICount++), dataLayer.push({
        event: "CompleteBetslipTransactionEvent",
        betslipID: n,
        BetPOI: i,
        eventId: f
    }), showConsoleLogs && console.log(dataLayer))
};
gax.SetBetslipOptionsGA = function(n) {
    var t = "betslipStorageOptionsGA";
    lsTest() === !0 ? localStorage.setItem(t, JSON.stringify(n)) : setCookie(t, JSON.stringify(n), .01)
};
gax.GetBetslipOptionsGA = function() {
    var n = "betslipStorageOptionsGA";
    return lsTest() === !0 ? localStorage.getItem(n) === null ? "" : localStorage.getItem(n) : getCookie(n)
};
gax.SetGAData = function(n, t) {
    var r = gax.GetBetslipOptionsGA(),
        i = {};
    r !== "" && (i = JSON.parse(r));
    i[n] = t;
    gax.SetBetslipOptionsGA(i)
};
gax.GetGAData = function(n) {
    var t = gax.GetBetslipOptionsGA(),
        i = {};
    return t !== "" && (i = JSON.parse(t)), i[n]
};
gax.GetGASavedLocalData = function() {
    gax.GetGAData("GABetPOICount") !== null && (betPOICount = gax.GetGAData("GABetPOICount"));
    gax.GetGAData("GABetPOI") !== null && (betPOI = gax.GetGAData("GABetPOI"));
    gax.GetGAData("GASingleBet") === !0 && (singleOrMultiBetType = "SingleBet")
};
gax.ToggleLIPStreaming = function(n) {
    useGoogleAnalytics && (n === "open" ? (console.log("open"), dataLayer.push({
        event: "viewLiveStreamEvent"
    })) : n === "close" && (console.log("close"), dataLayer.push({
        event: "closeLiveStreamEvent"
    })))
};
gax.LightbulbClickEvent = function(n, t) {
    useGoogleAnalytics && (dataLayer.push({
        event: "LightbulbClickEvent",
        sport: n,
        league: t
    }), showConsoleLogs && console.log(dataLayer))
}