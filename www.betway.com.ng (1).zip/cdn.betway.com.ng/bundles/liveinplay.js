function SortSBVOutcomes(n) {
    var t = $(n).attr("data-display-sortingtype"),
        i;
    t != constId.OutcomeDisplaySorting_Default && (i = $(n).find(".panel-body > div").sort(function(n, i) {
        var f = $(n).find(".outcomes-advancedbetting > div"),
            s = $(i).find(".outcomes-advancedbetting > div"),
            h, c, l, a, e, o, r, u;
        if (t == constId.OutcomeDisplaySorting_PriceDecimal || t == constId.OutcomeDisplaySorting_PriceDecimalDesc) return (h = f.find(".outcome-pricedecimal").attr("data-lip-pricedecimal"), c = s.find(".outcome-pricedecimal").attr("data-lip-pricedecimal"), t == constId.OutcomeDisplaySorting_PriceDecimal) ? h > c ? 1 : -1 : h < c ? 1 : -1;
        if (t == constId.OutcomeDisplaySorting_Title || t == constId.OutcomeDisplaySorting_TitleDesc) return (l = f.find(".outcome-title:first-child").text(), a = f.find(".outcome-title:first-child").text(), t == constId.OutcomeDisplaySorting_Title) ? l > a ? 1 : -1 : l < a ? 1 : -1;
        if (t == constId.OutcomeDisplaySorting_SBVDesc || t == constId.OutcomeDisplaySorting_SBV) return (e = f.attr("data-lip-sbv"), o = s.attr("data-lip-sbv"), t == constId.OutcomeDisplaySorting_SBVDesc) ? e > o ? -1 : e < o ? 1 : 0 : e < o ? -1 : e > o ? 1 : 0;
        if (t == constId.OutcomeDisplaySorting_FeedId || t == constId.OutcomeDisplaySorting_FeedIdDesc) return (r = f.attr("data-sroutcomefeedid"), u = s.attr("data-sroutcomefeedid"), t == constId.OutcomeDisplaySorting_FeedIdDesc) ? r > u ? -1 : r < u ? 1 : 0 : (console.error(`${r} > ${u}: ${r>u} `), r < u ? -1 : r > u ? 1 : 0);
        console.error("Display Sorting Type not supported")
    }), i.appendTo($(n).find(".panel-body")))
}
$(function() {
    function it() {
        return 1
    }

    function ei(n) {
        return n.CashoutProbability
    }

    function oi(n) {
        return n.PriceDecimal === 0 ? 0 : 1 / n.PriceDecimal
    }

    function si(n) {
        return n.ResultingStatusId === constId.ResultingStatus_Win ? it(n) : n.ResultingStatusId === constId.ResultingStatus_Void ? it(n) : n.FeedDataTypeId === constId.feedDataType_LIP && n.MarketTypeHasEarlyCashout ? ei(n) : oi(n)
    }

    function hi(n) {
        var t = 1;
        return n.Bets.forEach(function(n) {
            t *= si(n)
        }), t
    }

    function ci(n) {
        var t = 1;
        return n.Bets.forEach(function(n) {
            n.ResultingStatusId !== constId.ResultingStatus_Void && (t *= n.HistoricPriceDecimal)
        }), t
    }

    function li(n) {
        var i = ci(n),
            r = hi(n),
            t = n.WagerAmount * i;
        return t > n.MaxPayoutAmount && (!et(n) || !ai(n)) && (t = n.MaxPayoutAmount), t * r * CASHOUT_MARGIN
    }

    function s(n) {
        return n.ResultingStatusId === constId.ResultingStatus_NotResulted
    }

    function rt(n) {
        return n.MarketTypeHasEarlyCashout
    }

    function ut(n) {
        var t = n.Bets.filter(s);
        return t.every(rt)
    }

    function ft(n) {
        var t = n.Bets.filter(s),
            i = t.filter(rt);
        return i.every(function(n) {
            return n.AllowEarlyCashout
        })
    }

    function et(n) {
        return n.Bets.every(function(n) {
            return n.IsPreMatch
        })
    }

    function ai(n) {
        return n.Bets.every(s)
    }

    function vi(n, t) {
        n === undefined && (n = 1);
        t === undefined && (t = 0);
        var i = t / n;
        return i > MAX_CASHOUT_LIMIT ? !1 : i < MIN_CASHOUT_LIMIT ? !1 : !0
    }

    function yi(n) {
        var i = n.Bets.filter(s),
            t = i.sort(function(n, t) {
                return new Date(t.StartDateTime) - new Date(n.StartDateTime)
            });
        return t[t.length - 1].MarketTypeHasEarlyCashout
    }

    function pi(n, t) {
        return (t === undefined && (t = 0), t <= 0) ? !1 : n.Bets.every(function(n) {
            return n.ResultingStatusId !== constId.ResultingStatus_Loss
        }) ? ut(n) && ft(n) ? et(n) || vi(n.PotentialReturnAmount, t) : yi(n) && ut(n) && ft(n) ? !0 : !1 : !1
    }

    function ot(n) {
        if (n.length > 0 && CASHOUTBETS.length > 0) {
            var t = CASHOUTBETS.filter(function(t) {
                return n.includes(t.BetslipId)
            });
            t.forEach(function(n) {
                var i = li(n),
                    u = pi(n, i),
                    t, r;
                u ? (t = (i / n.PotentialReturnAmount * 100).toFixed(2), r = t < 20 ? "red" : t >= 20 && t < 50 ? "orange" : "green", $(".co-bar-" + n.BetslipSequenceId).css({
                    width: t + "%",
                    "background-color": r
                }), ($(".cancelBetAmount-" + n.BetslipSequenceId) != undefined || $(".cancelBetAmount-" + n.BetslipSequenceId) != null) && $(".cancelBetAmount-" + n.BetslipSequenceId).html(n.WagerAmount.toFixed(2)), $(".cashOutAmount-" + n.BetslipSequenceId).html(i.toFixed(2)), $(".cashoutBtn-" + n.BetslipSequenceId).prop("disabled", !1)) : ($(".co-bar-" + n.BetslipSequenceId).css({
                    width: "0%"
                }), ($(".cancelBetAmount-" + n.BetslipSequenceId) != undefined || $(".cancelBetAmount-" + n.BetslipSequenceId) != null) && $(".cancelBetAmount-" + n.BetslipSequenceId).html('<span class="fa fa-lock"><\/span>'), $(".cashOutAmount-" + n.BetslipSequenceId).html('<span class="fa fa-lock"><\/span>'), $(".cashoutBtn-" + n.BetslipSequenceId).prop("disabled", !0))
            })
        }
    }

    function wi() {
        var n = [],
            t = $("*[selected-betslip-outcomeid-value]");
        return t.length === 0 ? n : (t.each(function() {
            n.push($(this).attr("selected-betslip-outcomeid-value"))
        }), n)
    }

    function bi() {
        var n = [],
            t = $("*[data-live-outcome-id]");
        return t.length === 0 ? n : (t.each(function() {
            n.push($(this).attr("data-live-outcome-id"))
        }), n)
    }

    function ki(n) {
        var u = [],
            t, i, f, r;
        return n && (t = JSON.parse(n), t.OutcomeUpdates.length > 0 && (i = t.OutcomeUpdates.filter(function(n) {
            return n.markets.length > 0
        }).map(function(n) {
            return n.markets
        }), i.length > 0 && (f = i.reduce(function(n, t) {
            return n.concat(t)
        }).filter(function(n) {
            return n.Outcomes.length > 0
        }), r = f.map(function(n) {
            return n.Outcomes
        }), r.length > 0 && (u = r.reduce(function(n, t) {
            return n.concat(t)
        }))))), u
    }

    function st(n) {
        var f = [],
            i, e, r, u, t;
        if (n && CASHOUTBETS.length > 0 && (i = ki(n), i.length > 0)) {
            for (e = CASHOUTBETS.map(function(n) {
                    return n.Bets
                }).reduce(function(n, t) {
                    return n.concat(t)
                }), r = 0; r < i.length; r++)
                for (u = e.filter(function(n) {
                        return n.OutcomeId === i[r].OutcomeId
                    }), t = 0; t < u.length; t++) u[t].PriceDecimal = i[r].PriceDecimal, u[t].CurrentPrice = i[r].PriceDecimal, u[t].CashoutProbability = i[r].CashoutProbability, u[t].AllowEarlyCashout = i[r].AllowEarlyCashout, u[t].AllowCancelBet = i[r].AllowCancelBet, u[t].FeedDataTypeId = i[r].FeedDataTypeId, f.includes(u[t].BetslipId) || f.push(u[t].BetslipId);
            ot(f)
        }
    }

    function h(n) {
        if (typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE && typeof CASHOUTBETS != "undefined" && CASHOUTBETS.length > 0) {
            var t = [];
            t = typeof n == "undefined" || n.length === 0 ? ht() : n;
            ot(t);
            CASHOUTBETS_INITIALIZED = !0
        }
    }

    function ht() {
        var n = [],
            t;
        return typeof CASHOUTBETS != "undefined" && CASHOUTBETS.length > 0 && (t = CASHOUTBETS.map(function(n) {
            return n.BetslipId
        }), n = t), n
    }

    function y() {
        return typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE
    }

    function c(n, t, i) {
        var r = $(i);
        return n < t ? r.fadeOut("normal", function() {
            r.addClass("higher");
            r.removeClass("lower");
            r.fadeIn("normal", function() {}).delay(2e3).fadeIn("normal", function() {
                r.removeClass("lower");
                r.removeClass("higher")
            })
        }) : n > t && r.fadeOut("normal", function() {
            r.addClass("lower");
            r.removeClass("higher");
            r.fadeIn("normal", function() {}).delay(2e3).fadeIn("normal", function() {
                r.removeClass("lower");
                r.removeClass("higher")
            })
        }), t
    }

    function r(n, t, i) {
        var e;
        t = parseFloat(t).toFixed(2);
        typeof i == "undefined" && (i = window.useFractional);
        var f = $('li[betslipoutcomeid="' + n + '"]').find(".betslipPriceDecimal")[0],
            u = $('div.outcome-pricedecimal[data-lip-value="' + n + '"]')[0],
            o = $(u).text(),
            r = t,
            s = $("form[id=PlaceBetSlip] :input[value='" + n + "']")[0];
        typeof s != "undefined" && (e = s.id.replace("__OutcomeId", "__PriceDecimal"), e !== null && $("#" + e).val(t));
        i ? $(u).text(oddsFormatter.convertFromDecimalToFraction(r)) : $(u).text(r);
        $(u).attr("data-lip-pricedecimal", r);
        c(o, r, u);
        f !== null && (i ? $(f).text(oddsFormatter.convertFromDecimalToFraction(r)) : $(f).text(r), c(o, r, u));
        outcomeOddsUpdated_BetBooster(n, r)
    }

    function di(n, t, i) {
        var e;
        t = parseFloat(t).toFixed(2);
        typeof i == "undefined" && (i = window.useFractional);
        var f = $('li[betslipoutcomeid="' + n + '"]').find(".betslipPriceDecimal")[0],
            u = $("#" + n).find(".outcome-decimal")[0],
            o = $(u).text(),
            r = t,
            s = $("form[id=PlaceBetSlip] :input[value='" + n + "']")[0];
        typeof s != "undefined" && (e = s.id.replace("__OutcomeId", "__PriceDecimal"), e !== null && $("#" + e).val(t));
        i ? $(u).text(oddsFormatter.convertFromDecimalToFraction(r)) : $(u).text(r);
        $(u).attr("data-pd", r);
        c(o, r, u);
        f !== null && (i ? $(f).text(oddsFormatter.convertFromDecimalToFraction(r)) : $(f).text(r), c(o, r, u));
        outcomeOddsUpdated_BetBooster(n, r)
    }

    function ct(n, t) {
        var i = JSON.parse(GetBetslip()),
            r;
        i !== null && i.length > 0 && (r = i.findIndex(GetIndexOfBetByOutcomeId, n), r > -1 && (i[r].PriceDecimal = t));
        SetBetslip(i)
    }

    function gi(n, t, i, r) {
        var u, s, c, h, o, f;
        typeof r != "undefined" && r !== null && r !== "" ? (r = " | " + r + " ", $(".space").text = " ") : $(".space").text = "";
        typeof i != "undefined" && i !== null && i !== "" && (i = " | " + i);
        u = $('*[data-event-id="' + n + '"]');
        u != null && typeof u != "undefined" && (s = u.find("[data-event-status]"), s.length > 0 && (t !== null && t.toLowerCase() === "ended" && (e[$(u).data("value")] = refreshLIPInterval / 1e3), s.data("data-event-status", t), s.text(t), language.translateAtRuntime(s, "SportContent", {
            "data-translate-key": language.generateKey(t)
        })));
        c = u.find("[data-event-score]");
        c.length > 0 && (c.data("data-event-score", i), c.text(i));
        h = u.find("[data-event-time]");
        h.length > 0 && (h.data("data-event-time", r), r === "" ? h.text("") : h.text(r));
        o = "";
        u = $('*[data-event-id-flyout="' + n + '"]');
        u.length > 0 && (f = u.find("[data-event-combined]"), f.length > 0 && (o += t + r + i, f.data("data-event-combined", o), f.html("<b>" + o + "<\/b>")));
        u = $('*[data-event-id-top-games="' + n + '"]');
        u.length > 0 && (f = u.find("[data-event-combined]"), f.length > 0 && (o += t + r + i, f.data("data-event-combined", o), f.html("<b>" + o + "<\/b>")))
    }

    function n(n, t, i) {
        var r, f, u;
        ToggleDisableOutcome_betbooster(n, t, i);
        r = $("#" + n);
        !t || i ? r.is("option") ? (r.hide(), r.parent("span.toggleOption").length === 0 && r.wrap('<span class="toggleOption" style="display: none;" />')) : (f = typeof $("#" + n).data("feeddatatype") != "undefined" && $("#" + n).data("feeddatatype").length > 0, f ? (u = $(".inplay[id='" + n + "']:not(.disableElement)"), u.each(function(n, t) {
            t.classList.add("disableElement");
            p($("#priceDecimal-" + t.id), t.id)
        })) : (u = $(".inplay[id='" + n + "']:not(.disableElement)"), u.each(function(n, t) {
            t.classList.contains("isSelectedInPlay") ? t.classList.add("disableSelectedElement") : t.classList.add("disableElement");
            p($("#priceDecimal-" + t.id), t.id)
        }))) : r.is("option") ? (r.prop("disabled", !1).show().css({
            display: "block",
            color: "green"
        }), r.parent("span.toggleOption").length && r.unwrap()) : ($("div[id*=" + n + "]").removeClass("disableElement disableSelectedElement"), typeof $("button[id*=" + n + "]") != "undefined" && $("button[id*=" + n + "]").length > 0 && ($("button[id*=" + n + "]").removeClass("disableElement disableSelectedElement"), $("button[id*=" + n + "]").prop("disabled", !1), $("button[id*=" + n + "]").show(), $("button[id*=" + n + "]").parent().parent().show()), $("#SelectedCheckBoxForBetslip-" + n).is(":checked") || $("#SelectedCheckBoxForBetslip-" + n).click().attr("disabled", !1), $("#priceDecimal-" + n).removeClass("locked").html($("#priceDecimal-" + n).attr("data-pd")), $("#SelectedOutcomeForBetslip-" + n).css({
            color: "#000000"
        }), dynamicLIPBetslipCalculationEnabled && toggleMultiSelectorOutcome(null, null, tempLockedOutcomes));
        i && $("div[id*=" + n + "]").parent().parent().remove()
    }

    function nr(n) {
        return n.IsActive === !1
    }

    function tr(n) {
        for (var r, u, f, i, t = 0; t < n.length; t++)
            for (r = $("#" + n[t].EventId), u = document.getElementById("MultiMarket"), u !== null && (r = $("#" + u.id)), f = r.find(".btn-bettingmatch"), i = 0; i < f.length; i++) ir(f[i].id)
    }

    function p(n, t) {
        setTimeout(function() {
            n.addClass("locked").html('<span class="material-icons-outlined" style="font-size: 15px;">lock<\/span>');
            $("#SelectedCheckBoxForBetslip-" + t).is(":checked") && $("#SelectedCheckBoxForBetslip-" + t).click().attr("disabled", !0);
            $("#SelectedOutcomeForBetslip-" + t).css({
                color: "#c9c9c9"
            })
        }, 100)
    }

    function ir(n) {
        var t = document.getElementById(n);
        t.classList.contains("disableElement") || t.classList.add("disableElement");
        p($("#priceDecimal-" + n), n);
        ToggleDisableOutcome_betbooster(n, !0, !0)
    }

    function lt(n) {
        var t = JSON.parse(n),
            r, i;
        for (g = t.ElapsedMilliseconds, t.OutcomeUpdates.length > 0 && ur(t.PotentialReturnAmount), r = t.OutcomeUpdates.filter(nr), r.length > 0 && tr(r), i = 0; i < t.OutcomeUpdates.length; ++i) fr(t.IsInstantBet, t.OutcomeUpdates[i], t.AcceptLatestOdds), at()
    }

    function ur(n) {
        var t = parseFloat(getTotalPriceDecimalFromBetslip()).toFixed(2),
            i;
        $("#TotalPriceDecimal").text(t);
        $("#TotalPriceDecimal").val(t);
        $("#betslip-totalpricedecimal")[0] !== null && ($("#betslip-totalpricedecimal")[0].innerHTML = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(t) : t);
        $("#PlaceBetSlip").find("#TotalPriceDecimal") !== null && $("#PlaceBetSlip").find("#TotalPriceDecimal").val(t);
        $("#isInstantBetsVar").val() === "True";
        n > 0 && (i = n.toFixed(2), $("#potentialReturn").text(i), $("#potentialReturn").val(i), $("#PotentialReturnAmount").val(i), $("#potentialReturnConfirm").text(i), at())
    }

    function fr(t, i, e) {
        var a, y, ot, st, p, o, g, dt, rt, b, at, nt, vt, tt, d, k, v, h, et;
        gi(i.EventId, i.InPlayStatus, i.InPlayScore, i.InPlayTime);
        var l = [],
            s = [],
            it = [],
            c, kt = JSON.parse(GetBetslip());
        if (i.markets.length > 0 && kt !== null && kt.length > 0) {
            for (a = 0; a < i.markets.length; ++a)
                for (y = 0; y < i.markets[a].Outcomes.length; ++y) e ? ct(i.markets[a].Outcomes[y].OutcomeId, i.markets[a].Outcomes[y].PriceDecimal.toFixed(2)) : BetslipHasLiveBets() && ct(i.markets[a].Outcomes[y].OutcomeId, i.markets[a].Outcomes[y].PriceDecimal.toFixed(2));
            UpdateBetslipFullVersion()
        }
        ot = !1;
        st = document.getElementById("MultiMarket");
        st !== null && (ot = st.getAttribute("data-event-id") === i.EventId);
        p = global.getCookie("oddsFormat") === "fraction";
        window.useFractional = p;
        var ht = $("#MultiMarket").is(":visible") && ii() && ot,
            lt = typeof $("#feedDataType") != "undefined" && typeof $("#feedDataType").val() != "undefined" && $("#feedDataType").val().toLowerCase() === constId.feedDataType_LiveOutrights,
            gt = [];
        for (o = 0; o < i.markets.length; ++o) {
            if (ht) {
                for (c = $('*[data-markettype="' + i.markets[o].MarketTypeId + '"]'), fi.includes(i.markets[o].MarketTypeId) && console.trace(i.markets[o]), g = !1, dt = !1, rt = 0; rt < i.markets[o].Outcomes.length; rt++) $(`#${i.markets[o].Outcomes[rt].OutcomeId}`).length > 0 && (g = !0), $(`#${i.markets[o].MarketId}`).length > 0 && (dt = !0);
                if (c.length > 0 && g)
                    for (b = $(c), m = 0; m < b.length; m++) {
                        if (s = [], k = !0, g) k = !1;
                        else
                            for (v = 0; v < i.markets.length; v++) $(b[m]).data("market") === i.markets[v].MarketId && (k = !1);
                        if (k) {
                            for (s = u(s, i.markets[o].Outcomes), s = f(s, JSON.stringify), s.length > 0 && bt(t, i.EventId, i.markets[o], s, !0, $(b[m]).data("market")), h = 0; h < i.markets[o].Outcomes.length; ++h) r(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].PriceDecimal.toFixed(2), p), n(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].IsActive, i.markets[o].Outcomes[h].IsHidden);
                            SetOutcomeButtons()
                        } else {
                            if ($(b[m]).data("market") === i.markets[o].MarketId || i.markets[o].GroupSBVMarket)
                                for (l = w($(b[m]), i.markets[o]), s = u(l, i.markets[o].Outcomes), s = f(s, JSON.stringify), s.length > 0 && bt(t, i.EventId, i.markets[o], s, !1, $(b[m]).data("market")), h = 0; h < i.markets[o].Outcomes.length; ++h) r(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].PriceDecimal.toFixed(2), p), n(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].IsActive, i.markets[o].Outcomes[h].IsHidden);
                            SetOutcomeButtons()
                        }
                    } else if (i.markets[o].Outcomes.length > 0) {
                        for (at = !0, nt = 0; nt < i.markets[o].Outcomes.length; nt++) i.markets[o].Outcomes[nt].IsHidden ? (vt = $(`#${i.markets[o].Outcomes[nt].OutcomeId}`), vt.length > 0 && (console.error("removing hidden outcome from view."), vt.parent().parent().remove())) : at = !1;
                        if (at) console.log("Do not add market " + i.markets[o].title + " since all outcomes are hidden");
                        else {
                            console.log("Appending new market");
                            c = $('*[data-lip-event="' + i.EventId + '"]');
                            c = $(c[0]);
                            l = [];
                            s = u(l, i.markets[o].Outcomes);
                            s = f(s, JSON.stringify);
                            var yt = i.markets[o].SortIndex,
                                pt = br(t, i.EventId, i.markets[o], s),
                                ut = null,
                                ft = $(c).find("[data-market-sortindex]");
                            ft.length > 0 ? (tt = $(ft[0]).attr("data-market-sortindex"), yt < tt ? ut = $(ft[0]) : ft.each(function() {
                                var n = parseInt($(this).attr("data-market-sortindex"));
                                tt <= yt && yt <= n ? (ut = this, tt = n) : tt = n
                            }), ut === null ? $(".container-panel").append(pt) : $(ut).before(pt)) : $(".container-panel").append(pt)
                        }
                    }
            } else if (lt) {
                for (i.IsVisibleAuto ? $("#" + i.EventId).show() : $("#" + i.EventId).hide(), d = $("#" + i.markets[o].EventId + ""), s = [], k = !0, v = 0; v < i.markets.length; v++) d.length > 0 && $(d).data("value") === i.markets[v].EventId && (k = !1);
                if (k) {
                    for (s = u(s, i.markets[o].Outcomes), s = f(s, JSON.stringify), s.length > 0 && ni(t, i.EventId, i.EventTitle, i.LeagueId, i.markets[o], s, !0, $(d).data("value")), h = 0; h < i.markets[o].Outcomes.length; ++h) r(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].PriceDecimal.toFixed(2), p), n(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].IsActive, i.markets[o].Outcomes[h].IsHidden);
                    SetOutcomeButtons()
                } else {
                    for (l = w($(d), i.markets[o], !0), s = u(l, i.markets[o].Outcomes), s = f(s, JSON.stringify), s.length > 0 && ni(t, i.EventId, i.EventTitle, i.LeagueId, i.markets[o], s, !1, $(d).data("value")), h = 0; h < i.markets[o].Outcomes.length; ++h) r(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].PriceDecimal.toFixed(2), p), n(i.markets[o].Outcomes[h].OutcomeId, i.markets[o].Outcomes[h].IsActive, i.markets[o].Outcomes[h].IsHidden);
                    SetOutcomeButtons()
                }
            } else {
                if (c = $('*[data-value="' + i.EventId + '"]'), refreshLIPEnabled && (it.length <= 0 && (c == null || typeof c == "undefined" || c.length == 0) && i.EventId != null && i.EventId != "" && it.push(i.EventId), i.InPlayStatus !== null && i.InPlayStatus === "Ended")) continue;
                if (c.data("markettype") === i.markets[o].MarketTypeId)
                    if (c.data("market") !== i.markets[o].MarketId) l = [], s = u(l, i.markets[o].Outcomes), s = f(s, JSON.stringify), wt(t, i.EventId, i.markets[o], s);
                    else if (c.data("market") !== i.markets[o].MarketId) hr(c, i.markets[o]) && (l = w(c, i.markets[o]), s = u(l, i.markets[o].Outcomes), s = f(s, JSON.stringify), wt(t, i.EventId, i.markets[o], s));
                else
                    for (let t = 0; t < i.markets[o].Outcomes.length; ++t) r(i.markets[o].Outcomes[t].OutcomeId, i.markets[o].Outcomes[t].PriceDecimal.toFixed(2), p), n(i.markets[o].Outcomes[t].OutcomeId, i.markets[o].Outcomes[t].IsActive, i.markets[o].Outcomes[t].IsHidden);
                SetOutcomeButtons()
            }
            if (!g)
                for (et = 0; et < i.markets[o].Outcomes.length; et++) gt.push(i.markets[o].Outcomes[et].OutcomeId)
        }!ht && !lt && it.length > 0 && iu(it);
        ht && (er(i), or(i));
        lt && sr()
    }

    function er(n) {
        var t = !1;
        typeof t != "undefined" && t && n.markets.forEach(function(n) {
            n.Outcomes.forEach(function(t) {
                var i = "block";
                t.IsHidden ? i = "none" : $("*[data-market=" + n.MarketId + "]").show();
                $("#" + t.OutcomeId).parent() !== null && $("#" + t.OutcomeId).parent()[0] !== null && $("#" + t.OutcomeId).parent()[0] !== undefined && ($("#" + t.OutcomeId).parent()[0].style.display = i);
                $("#header-" + n.MarketId).find(".outcomes-advancedbetting:visible").length == 0 ? $("*[data-market=" + n.MarketId + "]").hide() : $("*[data-market=" + n.MarketId + "]").show()
            })
        });
        $(".row .search-link:not(:first):not(:has(.btn-bettingmatch))").remove()
    }

    function or() {
        var t = !0,
            n;
        typeof t != "undefined" && t && (n = [], $('[data-groupsbv="true"]').each(function() {
            n.push($(this).data().markettype)
        }), n.forEach(n => {
            var t = $('[data-markettype="' + n + '"]'),
                r, i;
            if (t.length > 1) {
                for (r = "", i = 1; i < t.length; i++) r += $($(t)[i]).find(".panel-body").html(), $($(t)[i]).remove();
                $($(t)[0]).find(".panel-body").append(r);
                SortSBVOutcomes(t[0])
            }
        }))
    }

    function sr() {
        var n = $.map($(".liveoutrighthead"), function(n) {
                return $(n).attr("value")
            }),
            t;
        if (n != null && n.length > 0)
            for (t = 0; t < n.length; t++) $("#Tournaments_" + n[t]).length > 0 && ($("#Tournaments_" + n[t]).find(".evtHead :visible").length == 0 && $("#Tournaments_" + n[t]).find(".alert-info").length == 0 ? $("#Tournaments_" + n[t]).find(".accordionHolder").append('<div class="alert alert-info" style="padding: 10px 10px 10px 36px !important; position: relative !important; top: 5px !important;"><span> No betting options available for this league at the moment.Please check back shortly.<\/span><\/div>') : $("#Tournaments_" + n[t]).find(".alert-info").remove())
    }

    function at() {
        var r = ".stake-input",
            f = ".stake-return-amount",
            n, i;
        isThousandSeperatorEnabled && (r += ".numberSeperatorMask", f += ".numberSeperatorMask");
        var e = $(r),
            o = $(r).parentsUntil($("li.SelectedOutcomeForBetslip")).find(".betslipPriceDecimal"),
            t = $("#betslip-list").find(f),
            u = GetBetslipOption("MaxPayoutSingle");
        for (n = 0; n < e.length; n++) i = parseFloat($(e[n]).val()) * parseFloat($(o[n]).text()).toFixed(2), i > u ? ($(t[n]).val(u.toFixed(2)), $(t[n]).text(u.toFixed(2))) : ($(t[n]).val(i.toFixed(2)), $(t[n]).text(i.toFixed(2)));
        UpdateVisualElementsOnBetslip()
    }

    function hr(n, t) {
        var u = $(n[0]),
            i = u.find("button"),
            f = !1,
            e = !1,
            o, r;
        if (i.length === 0 && (i = u.find("option"), e = !0), i.length > 0)
            for (o = e ? $.map($(i), function(n) {
                    return $(n).data("lip-value")
                }) : $.map($(i), function(n) {
                    var t = $(n).find("div.outcome-pricedecimal");
                    return $(t).data("lip-value")
                }), r = 0; r < t.Outcomes.length; ++r)
                if (!o.includes(t.Outcomes[r].OutcomeId)) {
                    f = !0;
                    break
                }
        return f
    }

    function w(n, t, i = false) {
        var r = n.find(".outcomes-advancedbetting"),
            y = !1,
            v, f, o, h, s, c, l, e, u;
        if (r.length === 0 && (r = n.find("option"), y = !0), v = [], y)
            for (e = 0; e < r.length; ++e) i || (f = $(r[e]).data("outcometitle"), o = $(r[e]).data("lip-pricedecimal"), h = $(r[e]).data("sortindex"), s = $(r[e]).hasClass("disableElement"), c = $(r[e]).data("lipSbv"), f !== "Make a selection" && (l = new a(t.MarketId, r[e].id, f, s, null, o, h, c, !0), v.push(l)));
        else
            for (u = 0; u < r.length; ++u) i ? (f = $(r[u]).find("div.hiddenOutcomeRow > span"), f.length <= 0 && (f = $(r[u]).find("div.outcome-title > span")), o = $(r[u]).find("div.outcome-decimal"), o.length <= 0 && (o = $(r[u]).find("div.outcome-pricedecimal")), h = $(r[u]).data("sortindex"), s = !$(r[u]).hasClass("disableElement"), c = $(r[u]).data("data-lip-sbv"), l = new a(t.MarketId, r[u].id, f[0].innerText, s, null, o[0].innerText, h, c, !0), s && v.push(l)) : (f = $(r[u]).find("div.outcome-title"), o = $(r[u]).find("div.outcome-pricedecimal"), h = $(r[u]).data("sortindex"), s = !$(r[u]).hasClass("disableElement"), c = $(r[u]).data("data-lip-sbv"), l = new a(t.MarketId, r[u].children[0].id, f[0].innerText, s, null, o[0].innerText, h, c, !0), s && v.push(l));
        return v
    }

    function cr() {
        var i = [],
            o = "00000000-0000-0000-0000-000000000000",
            n = "00000000-0000-0000-0000-000000000000",
            l, a, s, u, f, h, c, r, e;
        if (($("*[data-lip-value]").is(":visible") || v()) && (typeof $("#feedDataType") == "undefined" || typeof $("#feedDataType").val() == "undefined" || $("#feedDataType").val().toLowerCase() !== constId.feedDataType_LiveOutrights)) {
            if (!t) return;
            t = !1;
            $("#MultiMarket").is(":visible") ? (l = $("*[data-isliveinplay-multimarket]").data("isliveinplay-multimarket"), a = l === "True", a && (s = $("*[data-event-id]").map(function() {
                return $(this).data("event-id")
            }).get(), i.includes(s[0]) || _.uniq(s).forEach(n => i.push(n))), n = $("*[data-sportconfigid]").data("sportconfigid")) : (i = $('*[data-event-id][data-markettypecategory="00000000-0000-0000-da7a-000000580003"]').map(function() {
                return $(this).data("event-id")
            }).get(), o = $("*[data-markettype]").data("markettype"));
            $(".row.eventRow.eventIsInplay").each(function() {
                i.push($(this).data("event-id"))
            });
            r = $(JSON.parse(GetBetslip())).map(function() {
                if (this.IsLiveInPlay) return this.OutcomeId
            }).get();
            u = $(".mg-tabs .mg-tab span.selected").parent().attr("id");
            (u == null || u == "selectButton") && $("#extra-groups").children(".selected")[0] != null && (u = $("#extra-groups").children(".selected")[0].id);
            f = [];
            $("#multimarketTabPages").find("div.search-link:visible").each(function(n, t) {
                f.push($(t).attr("data-markettype"))
            });
            h = $("#potentialWager").val();
            v() && (c = [], c = typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE ? wi() : bi(), c.forEach(function(n) {
                r.push(n)
            }));
            i.length > 0 || r.length > 0 ? ((n === null || n === undefined || n === "" || n === constId.emptyGuid) && (n = localStorage.getItem("currentSportId")), pt(i, r, o, n, h, u, f)) : t = !0
        } else typeof $("#feedDataType") != "undefined" && typeof $("#feedDataType") != "undefined" && $("#feedDataType").length > 0 && typeof $("#feedDataType").val() != "undefined" && $("#feedDataType").val().toLowerCase() === constId.feedDataType_LiveOutrights && (i = $(".evtHead").map(function() {
            return $(this).attr("id")
        }).get(), r = $(JSON.parse(GetBetslip())).map(function() {
            if (this.IsLiveInPlay) return this.OutcomeId
        }).get(), i.length > 0 && (e = [], e = $(".evtHead").map(function() {
            return $(this).attr("sport-config")
        }).get(), e.length > 0 && (n = e[0])), (i.length > 0 || r.length > 0) && ((n === null || n === undefined || n === "" || n === constId.emptyGuid) && (n = localStorage.getItem("currentSportId")), pt(i, r, o, n, h, u, f)))
    }

    function lr(n) {
        var u = localStorage.getItem("LastScoreUpdate"),
            f = [],
            i = [],
            t, r, e;
        try {
            for (t = 0; t < n.length; t++) f.push({
                EventId: n[t].EventId,
                InPlayStatus: n[t].InPlayStatus,
                InPlayScore: n[t].InPlayScore,
                InPlayTime: n[t].InPlayTime,
                LastUpdateDateTime: new Date
            });
            if (u === undefined || u === null) localStorage.setItem("LastScoreUpdate", JSON.stringify(f));
            else {
                for (i = JSON.parse(u), t = 0; t < i.length; t++)
                    for (r = 0; r < n.length; r++) i[t].EventId == n[r].EventId && (i[t].InPlayStatus = n[r].InPlayStatus, i[t].InPlayScore = n[r].InPlayScore, i[t].InPlayTime = n[r].InPlayTime, i[t].LastUpdateDateTime = new Date);
                e = f.filter(function(n) {
                    return !i.map(n => n.EventId).includes(n.EventId)
                });
                e.length > 0 && e.forEach(function(n) {
                    i.push(n)
                });
                localStorage.setItem("LastScoreUpdate", JSON.stringify(i))
            }
        } catch (o) {
            console.error(o)
        }
    }

    function vt(n) {
        var i, u, t, r, f, e, o;
        if (n)
            for (i = JSON.parse(n), i !== null && i.OutcomeUpdates !== null && i.OutcomeUpdates.length > 0 && (lastScorePollMilliseconds = i.ElapsedMilliseconds, lr(i.OutcomeUpdates)), u = 0; u < i.OutcomeUpdates.length; u++) t = i.OutcomeUpdates[u], r = !1, $("#event-score-" + t.EventId).length > 0 && (t.InplayStatus !== null && t.InPlayStatus !== "" && ($("#event-score-" + t.EventId).show(), f = $("#inplay-status-" + t.EventId).html().trim() + " ", f !== t.InPlayStatus + " | " && (r = !0), $("[id='inplay-status-" + t.EventId + "']").html(t.InPlayStatus + " | "), language.translateAtRuntime($("[id='inplay-status-" + t.EventId + "']"), "MyBetsContent", {
                "data-translate-key": language.generateKey(t.InPlayStatus),
                "data-translate-type": "generic-html",
                "data-translate-value-0": " | "
            }), t.InPlayStatus === "Ended" && $("[id='live-indicator-" + t.EventId + "']").html("")), t.InPlayTime !== null && t.InPlayTime.trim() !== "" && (e = $("#inplay-time-" + t.EventId).html().trim() + " ", e !== t.InPlayTime + " | " && (r = !0), $("[id='inplay-time-" + t.EventId + "']").html(t.InPlayTime + " | ")), t.InPlayScore !== null && t.InPlayScore !== "" && (o = $("#inplay-score-" + t.EventId).html().trim(), o !== t.InPlayScore && (r = !0), $("[id='inplay-score-" + t.EventId + "']").html(t.InPlayScore))), r && ($("[id='event-score-" + t.EventId + "']").addClass("blinking"), setTimeout(function() {
                $(".blinking").removeClass("blinking")
            }, 2500))
    }

    function yt() {
        if (!window.PollingProbability) {
            window.PollingProbability = !0;
            var n = $("*[data-betslip-id]");
            n.length !== 0 && (i === null && (i = {
                AccountId: $("#co-accountId").val(),
                BrandId: $("#co-brandId").val(),
                TimeZone: $("#co-timeZone").val()
            }), i.FetchCurrent = window.FetchCurrentCashoutValues, i.BetslipSeqIds = n.filter(function() {
                return $(this).is(":visible")
            }).map(function() {
                return $(this).data("betslip-id")
            }).filter(function() {
                return this !== 0
            }).get(), i !== null && i.BetslipSeqIds.length > 0 && $.ajax({
                url: "/LiveUpdate/GetLiveInPlayProbabilityUpdatesV2",
                type: "POST",
                dataType: "json",
                data: {
                    cashoutPollerModel: i
                },
                success: function(n) {
                    var r, t, i, u;
                    if (n)
                        for (n.length > 0 && (window.FetchCurrentCashoutValues = !1), r = 0; r < n.length; r++) t = n[r], t.AllowEarlyCashout ? (i = (t.EarlyCashoutAmount / t.PotentialReturnAmount * 100).toFixed(2), u = i < 20 ? "red" : i >= 20 && i < 50 ? "orange" : "green", $(".co-bar-" + t.BetslipSequenceId).css({
                            width: i + "%",
                            "background-color": u
                        }), $(".cashOutAmountSymbol-" + t.BetslipSequenceId).addClass("co-value").css("display", "inline-block"), ($(".cancelBetAmount-" + t.BetslipSequenceId) != undefined || $(".cancelBetAmount-" + t.BetslipSequenceId) != null) && $(".cancelBetAmount-" + t.BetslipSequenceId).html(t.WagerAmount.toFixed(2)), $(".cashOutAmount-" + t.BetslipSequenceId).html(t.EarlyCashoutAmount.toFixed(2)), $(".cashoutBtn-" + t.BetslipSequenceId).prop("disabled", !1)) : ($(".co-bar-" + t.BetslipSequenceId).css({
                            width: "0%"
                        }), ($(".cancelBetAmount-" + t.BetslipSequenceId) != undefined || $(".cancelBetAmount-" + t.BetslipSequenceId) != null) && $(".cancelBetAmount-" + t.BetslipSequenceId).html('<span class="fa fa-lock"><\/span>'), $(".cashOutAmount-" + t.BetslipSequenceId).html('<span class="fa fa-lock"><\/span>'), $(".cashoutBtn-" + t.BetslipSequenceId).prop("disabled", !0))
                },
                complete: function() {
                    console.log("setting polling flag!");
                    window.PollingProbability = !1;
                    t = !0
                }
            }))
        }
    }

    function pt(n, i, r, u, f, e, o) {
        var a = 1,
            h = global.getCookie("selectedSportPageNo"),
            s, c, v, y;
        h === undefined || h === "" || isNaN(h) || (a = parseInt(h));
        s = [];
        $("li.league-item.isChecked").each(function() {
            s.push($(this).attr("id"))
        });
        c = !1;
        typeof $("#feedDataType") != "undefined" && typeof $("#feedDataType").val() != "undefined" && $("#feedDataType").val().toLowerCase() === constId.feedDataType_LiveOutrights && (c = !0, s.push($.map($(".liveoutrighthead"), function(n) {
            return $(n).attr("value")
        })));
        v = ar();
        y = "Eid=" + l(n) + "&Oid=" + l(i) + "&mt=" + r + "&sId=" + u + "&lps=" + window.clientLastPollDate + "&sGroupId=" + e + "&mts=" + l(o) + "&set=" + a + "&lIds=" + l(s) + "&fId=" + (c ? constId.feedDataType_LiveOutrights : null);
        window.tempBypassPolling = y.length > 2e3 ? !0 : !1;
        window.useGETForPolling != null && window.useGETForPolling === !0 && window.tempBypassPolling != null && window.tempBypassPolling === !1 ? $.ajax({
            url: v + "/LiveUpdate/GetLiveInPlayOutcomeUpdates?" + y,
            type: "GET",
            dataType: "html",
            crossDomain: "true",
            success: function(n) {
                n && (lt(n), ti() && (vt(n), typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE && st(n)), window.clientLastPollDate = JSON.parse(n).ElapsedMilliseconds)
            },
            error: function(n, t, i) {
                console.log(n.status);
                console.log(i)
            },
            complete: function() {
                t = !0
            }
        }) : $.ajax({
            url: v + "/LiveUpdate/GetLiveInPlayOutcomeUpdates?",
            type: "POST",
            dataType: "html",
            crossDomain: "true",
            data: {
                eventIds: n,
                outcomeIds: i,
                marketTypeId: r,
                sportConfigId: u,
                potentialWager: f,
                sessionid: window.clientSessionId,
                lastPollString: window.clientLastPollDate,
                selectedGroupId: e,
                popularMarketTypes: o,
                lastPollMilliseconds: g,
                set: a,
                leagueIds: s,
                feedDataTypeId: c ? constId.feedDataType_LiveOutrights : null
            },
            success: function(n) {
                n && (lt(n), ti() && (vt(n), typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE && st(n)))
            },
            error: function(n, t, i) {
                console.log(n.status);
                console.log(i)
            },
            complete: function() {
                t = !0
            }
        })
    }

    function l(n) {
        return n != null && n.length > 0 && n.sort(), n = [...new Set(n)], n.toString().replaceAll("0000-0000-0000-000000000000", "*")
    }

    function ar() {
        if (!ui) {
            var n = window.location.hostname;
            return n.startsWith("www") ? new URL(window.location.protocol + "//" + window.location.hostname.replace("www.", "lip.")) : n.startsWith("betway.datafree.co") ? (tt = 8e3, new URL(window.location.protocol + "//" + window.location.hostname.replace("betway.datafree.co.", "lip.betway.co.za"))) : n.startsWith("betway.datafree.ng") ? (tt = 8e3, new URL(window.location.protocol + "//" + window.location.hostname.replace("betway.datafree.ng.", "lip.betway.com.ng"))) : n.startsWith("uat") ? new URL(window.location.protocol + "//" + window.location.hostname.replace("uat.", "uat-lip.")) : n.startsWith("qa") ? new URL(window.location.protocol + "//" + window.location.hostname.replace("qa.", "qa.")) : n.startsWith("dev") ? new URL(window.location.protocol + "//" + window.location.hostname.replace("dev.", "dev-lip.")) : document.location.hostname.localeCompare("localhost") === 0 ? new URL("http://lip.localhost:51933/") : new URL("http://172.27.216.131")
        }
        return new URL("")
    }

    function wt(n, t, i, r) {
        var l = $('*[data-value="' + t + '"],[data-market="' + i.MarketId + '"]'),
            c, u, f, e, o, s, h;
        if (l.data("market", i.MarketId), c = l.find("[data-elementtype=outcomeRow]"), c.html(""), u = document.createElement("DIV"), r.length > 3) {
            for (f = document.createElement("INPUT"), f.id = "selectedOutcomeValue", f.setAttribute("type", "hidden"), f.value = "", u.appendChild(f), e = yr(t, i), o = document.createElement("OPTION"), o.value = "EMPTY", o.innerHTML = " Make a selection", e.appendChild(o), s = 0; s < r.length; ++s) e.appendChild(pr(t, i, r[s]));
            u.appendChild(e)
        } else
            for (h = 0; h < r.length; ++h) u.appendChild(vr(r.length, n, t, i, r[h]));
        c.html(u)
    }

    function vr(n, t, i, r, u) {
        var s = document.createElement("DIV"),
            e, h, o, f;
        return s.className = n <= 2 ? "col-xs-6 outcomebuttonDiv ob-50" : general.bootstrapColumns(4), e = document.createElement("DIV"), e.id = u.OutcomeId, s.appendChild(e), h = "btn btn-group btn-bettingmatch  inplay", u.IsActive || (h += " disableElement"), u.IsHidden && console.log(u.id + " hidden"), e.className = h, d(i), e.onclick = function() {
            SendToBetslip(u.OutcomeId, u.OutcomeTitle, u.PriceDecimal, $("#" + i).attr("data-sporttitle"), r.MarketTitle, u.SpecialBetValue, u.OutcomeTitle, new Date($("#" + i).attr("data-eventdate")).toLocaleString(), i, "True", u.FeedDataTypeId, u.AllowEarlyCashout)
        }, o = document.createElement("DIV"), o.className = "outcome-title", o.innerHTML = "<span>" + u.OutcomeTitle + "<\/span>", e.appendChild(o), f = document.createElement("DIV"), f.className = "outcome-pricedecimal", f.setAttribute("data-markettypecategory", r.FeedDataTypeId), f.setAttribute("data-lip-value", u.OutcomeId), f.setAttribute("data-lip-pricedecimal", u.PriceDecimal.toFixed(2)), f.setAttribute("data-sortindex", u.SortIndex), f.setAttribute("data-lip-sbv", u.SpecialBetValue), f.innerHTML = parseFloat(u.PriceDecimal).toFixed(2), e.appendChild(f), s
    }

    function yr() {
        var n = document.createElement("SELECT");
        return n.className = "ddlCorrectScore", n.onfocus = function() {
            eventDisplay.onOutcomeDropDownFocus(this)
        }, n.onchange = function() {
            AddSelectedItemToBetslip(this)
        }, n
    }

    function pr(n, t, i) {
        var r = document.createElement("OPTION"),
            u = "inner  inplay",
            f = "SendToBetslip('" + i.OutcomeId + "','" + i.OutcomeTitle + "','" + i.PriceDecimal.toFixed(2) + "','" + $("#" + n).attr("data-sporttitle") + "','" + t.MarketTitle + "','" + i.SpecialBetValue + "','" + $("#" + n).attr("data-eventtitle") + "','" + new Date($("#" + n).attr("data-eventdate")).toLocaleString() + "','" + n + "',true," + i.AllowEarlyCashout + ")";
        return i.IsActive || (u += " disableElement", r.disabled = "disabled"), r.className = u, r.id = i.OutcomeId, r.setAttribute("data-lip-value", i.OutcomeId), r.setAttribute("data-lip-pricedecimal", i.PriceDecimal.toFixed(2)), r.setAttribute("data-outcometitle", i.OutcomeTitle), r.setAttribute("data-markettypecategory", t.FeedDataTypeId), r.setAttribute("data-sortindex", i.SortIndex), r.setAttribute("data-lip-sbv", i.SpecialBetValue), r.setAttribute("data-js", f), r.innerHTML = i.OutcomeTitle + " : " + i.PriceDecimal.toFixed(2), r.setAttribute("value", i.OutcomeId), r
    }

    function bt(n, t, i, r, u, f) {
        var e, h, c, o, l, s;
        if (u) console.log("Adding new market " + i), e = $("#header-" + i.MarketId), e == null || typeof e == "undefined" || e.length <= 0 ? (e = $("#header-" + f), $(e.parent()).attr("data-market", f), $(e.parent()).data("market", f), e.data("market", f)) : ($(e.parent()).attr("data-market", i.MarketId), $(e.parent()).data("market", i.MarketId), e.data("market", i.MarketId)), e.innerHTML = "", h = kt(n, t, i, r), e.replaceWith(h);
        else {
            if (c = i.DisplayLayout === 2 ? 4 : i.DisplayLayout === 3 ? 3 : 6, o = document.getElementById("header-" + i.MarketId), (o == null || typeof o == "undefined" || o.length <= 0) && (o = document.getElementById("header-" + f), i.MarketId = f), o === null) return;
            for (l = o.children[0].children[0], s = 0; s < r.length; s++) wr(l, t, i, r[s], c)
        }
    }

    function wr(t, i, u, f, e) {
        var s, o, h;
        if ($(`[id=${f.OutcomeId}]`).length > 0) r(f.OutcomeId, f.PriceDecimal.toFixed(2)), n(f.OutcomeId, f.IsActive, f.isHidden);
        else {
            for (s = $(t).find("div.panel-body > div").children(), o = 0; o < s.length; o++) typeof $(s[o]).find("div").data("marketid") != "undefined" && $(s[o]).find("div").data("marketid") != u.MarketId && $(s[o]).remove();
            h = dt(i, u, f, e);
            $(t).find("div.panel-body > div").append(h)
        }
    }

    function br(n, t, i, r) {
        var u = document.createElement("DIV");
        return u.className = "row search-link", u.setAttribute("data-market", i.MarketId), u.setAttribute("data-markettitle", i.MarketTitle), u.setAttribute("data-markettype", i.MarketTypeId), u.setAttribute("data-market-sortindex", i.SortIndex), u.setAttribute("data-markettypecategory", "00000000-0000-0000-da7a-000000580003"), u.setAttribute("data-groupsbv", i.GroupSBVMarket), u.setAttribute("data-display-sortingtype", i.DisplaySorting), u.setAttribute("data-market-sortindex", i.SortIndex), u.appendChild(kt(n, t, i, r)), u
    }

    function kt(t, i, u, f) {
        var c = document.createElement("DIV"),
            l, s, e, k, a, v, y, p, w, tt, h, b, d, g, nt, it, o, rt;
        if (c.id = "header-" + u.MarketId, l = document.createElement("DIV"), l.id = "accordion", l.className = "panel-group", c.setAttribute("data-value", u.MarketId), c.setAttribute("data-market", u.MarketId), c.appendChild(l), s = document.createElement("DIV"), s.className = "panel panel-default subheading-panel", l.appendChild(s), e = document.createElement("a"), e.className = "acc-header not-collapsed", e.setAttribute("data-value", u.MarketTypeId), e.setAttribute("aria-expanded", "true"), e.setAttribute("data-toggle", "collapse"), e.setAttribute("onclick", "marketGrouping.toggleMultimarketAccordion('moremarketsToggle-" + u.MarketId + "', 'multimarket')"), e.href = "#" + u.MarketId, k = document.getElementById("tt-" + u.MarketId), k !== undefined && k !== null && s.appendChild(k), s.appendChild(e), a = document.createElement("DIV"), a.className = "panel-collapse collapse in", e.setAttribute("aria-expanded", "true"), a.id = "" + u.MarketId, v = document.createElement("DIV"), v.className = "panel-body", a.appendChild(v), s.appendChild(a), y = document.createElement("DIV"), y.className = "panel-heading panel-left-header", e.appendChild(y), p = document.createElement("h4"), $("#colapse-Acc").css("display", "none") !== !0 ? (p.className = "accordionArrows fa widget-angle fa-angle-up", $("#colapse-Acc").css("display", "inline-block")) : (p.className = "accordionArrows fa widget-angle fa-angle-down", $("#expand-Acc").css("display", "inline-block")), p.id = "moremarketsToggle-" + u.MarketId, y.appendChild(p), w = document.createElement("h4"), w.className = "panel-title theFont", w.innerHTML = u.MarketTitle, u.Outcomes.length > 0 && u.Outcomes[0].AllowEarlyCashout && (tt = document.createElement("span"), tt.className = "co-img-mm co-img-white", w.appendChild(tt)), y.appendChild(w), h = document.createElement("DIV"), f.length >= 3 && !$("#MultiMarket").is(":visible")) {
            for (b = document.createElement("INPUT"), b.id = "selectedOutcomeValue", b.setAttribute("type", "hidden"), b.value = "", h.appendChild(b), d = kr(i, u), g = document.createElement("OPTION"), g.value = "EMPTY", g.innerHTML = " Make a selection", d.appendChild(g), nt = 0; nt < f.length; ++nt) d.appendChild(dr(i, u, f[nt]));
            h.appendChild(d);
            v.appendChild(h)
        } else
            for (it = u.DisplayLayout === 2 ? 4 : u.DisplayLayout === 3 ? 3 : 6, v.appendChild(h), o = 0; o < f.length; o++) $(`#${f[o].OutcomeId}`).length > 0 ? (r(f[o].OutcomeId, f[o].PriceDecimal.toFixed(2)), n(f[o].OutcomeId, f[o].IsActive, f[o].isHidden)) : (rt = dt(i, u, f[o], it), h.appendChild(rt));
        return c
    }

    function dt(n, t, i, r) {
        var f = document.createElement("DIV"),
            u, e;
        return f.className = general.bootstrapColumns(r), f.className += " outcomes-advancedbetting", u = document.createElement("div"), u.id = i.OutcomeId, u.name = i.OutcomeId, e = "btn btn-group btn-bettingmatch inplay", i.IsActive || (e += " disableElement", u.disabled = "disabled"), u.className = e, u.style.flexWrap = "wrap", d(n), u.setAttribute("onClick", `SendToBetslip(
                "${i.OutcomeId}",
                "${i.OutcomeTitle}",
                "${i.PriceDecimal}",
                "${$("#"+n).attr("data-sporttitle")}",
                "${t.MarketTitle}",
                "${i.SpecialBetValue}",
                "${i.OutcomeTitle}",
                "${$("#"+n).attr("data-eventdate")}", //don't format this for IE and safari
                "${n}",
                "True",
                "${i.AllowEarlyCashout}"
            )`), u.setAttribute("data-markettypecategory", t.FeedDataTypeId), u.setAttribute("data-marketid", i.MarketId), u.setAttribute("data-lip-sbv", i.SpecialBetValue), u.setAttribute("data-sroutcomefeedid", i.FeedId), u.setAttribute("data-sortindex", i.SortIndex), u.setAttribute("data-lip-pricedecimal", i.PriceDecimal.toFixed(2)), gt(u, i, t), f.appendChild(u), f
    }

    function gt(n, t, i) {
        var s = i.DisplayMultilineStartingCharacter,
            h = !1,
            f, v = s === 0 ? null : s === 1 ? "Or " : s === 2 ? "& " : s === 3 ? "/ " : s === 4 ? "( " : "By ",
            e = i.DisplayOutcomeText,
            c = "",
            u = t.OutcomeTitle,
            r = u.split(" or "),
            y, l, o, a;
        e === 1 ? (h = !0, c = "doublechance", r = t.OutcomeTitle.split(" or "), u = r[0]) : e === 2 ? (h = !0, c = "doublechance", f = u.lastIndexOf("&"), f !== -1 && (r = [], r.push(u.substr(0, f)), r.push(u.substr(f + 1)), u = r[0])) : (h = !0, c = "doublechance", e === 3 ? (f = u.lastIndexOf("/"), f !== -1 && (r = [], r.push(u.substr(0, f)), r.push(u.substr(f + 1)), u = r[0])) : e === 4 ? (f = u.lastIndexOf(" "), f !== -1 && (r = [], r.push(u.substr(0, f)), r.push(u.substr(f + 1)), u = r[0])) : e === 5 ? (f = u.lastIndexOf("("), f !== -1 && (r = [], r.push(u.substr(0, f)), r.push(u.substr(f + 1)), u = r[0])) : e === 6 && (r = u.split(" by "), u = r[0]));
        y = u;
        l = document.createElement("DIV");
        l.className = "outcome-title " + c;
        l.innerHTML = "<span>" + y + "<\/span>";
        o = document.createElement("DIV");
        o.className = "outcome-pricedecimal";
        o.setAttribute("data-lip-value", t.OutcomeId);
        o.setAttribute("data-lip-pricedecimal", t.PriceDecimal.toFixed(2));
        o.innerHTML = t.PriceDecimal.toFixed(2);
        n.appendChild(l);
        n.appendChild(o);
        h && r.length > 1 && v && (a = document.createElement("DIV"), a.className = "outcome-title doublechance", a.innerHTML = "<span>" + v + r[1] + "<\/span>", n.appendChild(a))
    }

    function kr(n, t) {
        var r = t.FeedDataTypeId === constId.feedDataType_LIP,
            i = document.createElement("SELECT");
        return i.id = t.MarketTypeId, i.className = "mmddl ddlCorrectScore ddlCorrectScoreInplay", i.onfocus = function() {
            eventDisplay.onOutcomeDropDownFocus(this)
        }, i.onchange = function() {
            events.onOutcomeDropDownSelectMultiMarket(this, n, "eventDisplay.actionBetslip", "", "", "", r, t.MarketTypeId)
        }, i
    }

    function dr(n, t, i) {
        var f = t.FeedDataTypeId === constId.feedDataType_LIP,
            r = document.createElement("OPTION"),
            u = "inner  inplay";
        return i.IsActive || (u += " disableElement", r.disabled = "disabled"), r.className = u, r.id = i.OutcomeId, r.setAttribute("data-lip-value", i.OutcomeId), r.setAttribute("data-lip-pricedecimal", i.PriceDecimal.toFixed(2)), r.setAttribute("data-outcometitle", i.OutcomeTitle), r.setAttribute("data-markettypecategory", t.FeedDataTypeId), r.setAttribute("data-lip-sbv", i.SpecialBetValue), r.innerHTML = i.OutcomeTitle + " : " + i.PriceDecimal.toFixed(2), r.setAttribute("value", i.OutcomeId), r.onchange = function() {
            events.onOutcomeDropDownSelectMultiMarket(this, n, "eventDisplay.actionBetslip", i.OutcomeId, i.OutcomeTitle, i.PriceDecimal, f, t.MarketTypeId)
        }, r
    }

    function ni(n, t, i, r, u, f, e, o) {
        var s, l, a, v, h, y, c;
        if (e) console.log("Adding new event " + u.EventId), s = $("#" + u.EventId), (s == null || typeof s == "undefined" || s.length <= 0) && o != null && typeof o != "undefined" ? (s = $("#" + o), $(s).attr("data-prev", o), $(s).data("prev", o), s.data("value", o), u.EventId = o) : ($(s).attr("data-value", u.EventId), $(s.parent()).data("value", u.EventId), s.data("value", u.EventId)), l = nu(n, t, i, u, f), s != null && typeof s != "undefined" && s.length > 0 ? (s.innerHTML = "", s.replaceWith(l)) : $("#Tournaments_" + r).children("#outrights").children("div").length > 0 && (a = $("#Tournaments_" + r).children("#outrights").children("div")[0], a.appendChild(l));
        else {
            if (v = 4, h = document.getElementById(u.EventId), (h == null || typeof h == "undefined" || h.length <= 0) && (h = document.getElementById(o), u.EventId = o), h === null) return;
            for (y = h.children[1], c = 0; c < f.length; c++) gr(y, t, u, f[c], v)
        }
    }

    function gr(t, i, r, u, f) {
        var e, o;
        if ($(t).find("button#" + u.OutcomeId).length > 0) di(u.OutcomeId, u.PriceDecimal.toFixed(2)), n(u.OutcomeId, u.IsActive, u.isHidden);
        else if (u.length > 1)
            for (e = 0; e < u.length; e++) o = b(i, r, u[e], f), $(t).append(o);
        else o = b(i, r, u, f), $(t).append(o)
    }

    function nu(n, t, i, r, u) {
        var f = document.createElement("DIV"),
            e, o, c, l, s, v, h, y, a, p;
        for (f.setAttribute("class", "row evtHead"), f.id = r.EventId, f.setAttribute("data-value", r.EventId), e = document.createElement("a"), e.setAttribute("data-toggle", "collapse"), e.setAttribute("onclick", "marketGrouping.toggleMultimarketAccordion('moremarketsToggle-" + r.EventId + "', 'outrights')"), e.href = "#", o = document.createElement("DIV"), o.setAttribute("class", "couponAcc margin--bottom"), e.appendChild(o), c = document.createElement("DIV"), c.setAttribute("class", "col-xs-10 col-sm-11"), o.appendChild(c), l = document.createElement("DIV"), l.setAttribute("class", "col-xs-2 col-sm-1 inner-acc-arrow"), o.appendChild(l), s = document.createElement("h4"), s.setAttribute("class", "theFont"), s.setAttribute("data-value", r.EventId), s.innerHTML = i, c.append(s), v = document.createElement("h4"), v.setAttribute("class", "accordionArrows fa fa-angle-down pull-right widget-angle"), l.appendChild(v), h = document.createElement("DIV"), h.id = "moremarketsToggle-" + r.EventId, h.setAttribute("class", "acc-header123 collapse outcome-group-tourney"), f.appendChild(e), y = u.length > 2 ? 4 : 6, a = 0; a < u.length; a++) p = b(t, r, u[a], y), h.appendChild(p);
        return f.appendChild(h), f
    }

    function b(n, t, i, r) {
        var f = document.createElement("DIV"),
            e, u, o;
        return f.className = general.bootstrapColumns(r), f.className += " no-pad", e = document.createElement("DIV"), e.className = " outcomes-advancedbetting", u = document.createElement("button"), u.id = i.OutcomeId, u.name = i.OutcomeId, o = "btn btn-group btn-bettingmatch inplay", i.IsActive || (o += " disableElement"), u.className = o, u.style.flexWrap = "wrap", d(n), u.onclick = function() {
            SendToBetslip(i.OutcomeId, i.OutcomeTitle, i.PriceDecimal, $("#" + n).attr("data-sporttitle"), t.MarketTitle, i.SpecialBetValue, i.OutcomeTitle, $("#" + n).attr("data-eventdate"), n, "True", i.AllowEarlyCashout)
        }, u.setAttribute("data-markettypecategory", t.FeedDataTypeId), u.setAttribute("data-feeddatatype", t.FeedDataTypeId), gt(u, i, t), e.appendChild(u), f.appendChild(e), f
    }

    function dr(n, t, i) {
        var f = t.FeedDataTypeId === constId.feedDataType_LiveOutrights,
            r = document.createElement("OPTION"),
            u = "inner  inplay";
        return i.IsActive || (u += " disableElement", r.disabled = "disabled"), r.className = u, r.id = i.OutcomeId, r.setAttribute("data-lip-value", i.OutcomeId), r.setAttribute("data-lip-pricedecimal", i.PriceDecimal.toFixed(2)), r.setAttribute("data-outcometitle", i.OutcomeTitle), r.setAttribute("data-markettypecategory", t.FeedDataTypeId), r.setAttribute("data-lip-sbv", i.SpecialBetValue), r.innerHTML = i.OutcomeTitle + " : " + i.PriceDecimal.toFixed(2), r.setAttribute("value", i.OutcomeId), r.onchange = function() {
            events.onOutcomeDropDownSelectMultiMarket(this, n, "eventDisplay.actionBetslip", i.OutcomeId, i.OutcomeTitle, i.PriceDecimal, f, t.MarketTypeId)
        }, r
    }

    function a(n, t, i, r, u, f, e, o, s, h) {
        this.MarketId = n;
        this.OutcomeId = t;
        this.OutcomeTitle = i;
        this.IsActive = r;
        this.IsHidden = h;
        this.OutcomeEditedDateTime = u;
        this.PriceDecimal = parseFloat(f);
        this.SortIndex = e;
        this.FeedDataTypeId = constId.feedDataType_LIP;
        this.SpecialBetValue = o;
        this.ExistingOutcome = s !== undefined && s;
        this.AppendSpecialBetValueToTitle = o !== undefined && o !== null && o.length > 0 && o[0] === "(" && i && i !== null && i.toString().indexOf(o) < 0
    }

    function u(n, t) {
        for (var r, u, i = 0; i < t.length; ++i) i.IsHidden ? console.log("Not Adding" + i.title) : (r = t[i].OutcomeTitle, u = new a(t[i].MarketId, t[i].OutcomeId, r, t[i].IsActive, null, t[i].PriceDecimal, t[i].SortIndex, t[i].SpecialBetValue, !1, t[0].IsHidden), n.push(u));
        return n
    }

    function f(n, t) {
        var i = {};
        return n.filter(function(n) {
            var r = t(n.OutcomeId);
            return n.IsHidden ? !1 : n.OutcomeId === "" ? !1 : n.OutcomeTitle === null ? !1 : i.hasOwnProperty(r) ? !1 : i[r] = !0
        })
    }

    function ti() {
        return ri() && global.getCookie("InCashoutPoller") === "true" && global.getCookie("ActivateCashoutPolling") === "true" || o.toLowerCase().indexOf("/mybets") > -1
    }

    function ii() {
        return o.toLowerCase().indexOf("/event/inplay") > -1 || o.toLowerCase().indexOf("/event/livesport") > -1 || window.location.search.toLowerCase().indexOf("inplay=true") > -1 || $("#multi-head").hasClass("inPlayBg") || $(".liveoutrighthead") !== null || $(".row.eventRow").hasClass("eventIsInplay")
    }

    function v() {
        if (ri()) return global.setCookie("InCashoutPoller", "true"), $("#openTab").length > 0 && $("#openTab").hasClass("active") ? (global.setCookie("ActivateCashoutPolling", "true"), y() && !CASHOUTBETS_INITIALIZED && h()) : global.setCookie("ActivateCashoutPolling", "false"), !0;
        global.setCookie("InCashoutPoller", "false");
        global.setCookie("ActivateCashoutPolling", "false");
        var n = o.toLowerCase().indexOf("/mybets") > -1 && $("#openTab").length > 0 && $("#openTab").hasClass("active");
        return n & y() && !CASHOUTBETS_INITIALIZED && h(), n
    }

    function ri() {
        return $(".betslip-mybetsBtn")[0] && !(o.toLowerCase().indexOf("/mybets") > -1) ? !0 : !1
    }

    function iu(n) {
        var i = [],
            f, t, u;
        $("li.league-item.isChecked").each(function() {
            i.push($(this).attr("id"))
        });
        var o = $(`*[data-filtermarket-list-markettypecategory*=${constId.feedDataType_LIP}]`),
            e = o.find("li.isActive").attr("id"),
            r = {
                eventIds: n,
                leagueIds: i,
                sportConfigId: localStorage.getItem("currentSportId"),
                marketTypeId: e,
                feedDataTypeId: constId.feedDataType_LIP
            },
            s = r.sportConfigId != null && r.sportConfigId != undefined && n !== null && n.length > 0 ? !0 : !1;
        if (s) {
            if (f = 1, t = global.getCookie("selectedSportPageNo"), t === undefined || t === "" || isNaN(t) || (f = parseInt(t)), u = {
                    couponTypeId: e,
                    FeedDataTypeId: r.feedDataTypeId,
                    sportConfigId: r.sportConfigId,
                    set: f
                }, i.length > 0 && (u.leagueIds = i), n.length > 0) u.eventIds = n;
            else return;
            pat.post("/Event/FilterEvents", u).done(function(n) {
                var f = $("#fixturesToReplace"),
                    i, r, u, t;
                if ($(n).find(".row.eventRow").length > 0 && (i = $(n).find(".row.eventRow"), i != null))
                    for (r = 0; r < i.length; r++) u = $(i[r]) != null && typeof $(i[r]) != "undefined" ? $(i[r]).attr("id") : null, u != null && (t = $('*[data-value="' + u + '"]'), (t == null || typeof t == "undefined" || t.length <= 0) && (t = $("#" + u)), (t == null || typeof t == "undefined" || t.length <= 0) && f.append($(i[r])));
                newEventElements = []
            })
        }
    }

    function ru() {
        for (let n of Object.keys(e)) e[n] <= 0 ? ($('*[data-value="' + n + '"]').remove(), e.splice(n, 1)) : e[n] = e[n] - nt / 1e3
    }

    function d(n) {
        var t = $('[data-event-id="' + n + '"]');
        t.hasClass("eventIsInplay") || t.addClass("eventIsInplay")
    }
    var t = !0,
        g = 0,
        i = null,
        nt = 3e3,
        tt = 0,
        e = [],
        ui = !1,
        fi = [],
        o = window.location.pathname,
        tu, k;
    (ii() || BetslipHasLiveBets() || v()) && (tu = window.setInterval(function() {
        $("#modalloading:visible").length || t === !1 || $("#modal-container-bet-confirmation:visible").length > 0 || cr();
        refreshLIPEnabled && ru()
    }, nt));
    v() && (k = window.setInterval(function() {
        if (y()) {
            clearInterval(k);
            var n = window.setInterval(function() {
                var r = global.getCookie("InCashoutPoller") === "true",
                    t = global.getCookie("ActivateCashoutPolling") === "true",
                    i;
                typeof CASHOUTBETS != "undefined" && CASHOUTBETS.length > 0 && t && (i = ht(), r && (t || $("#openTab").hasClass("active")) ? (h(i), clearInterval(n)) : r || t || (h(i), clearInterval(n)))
            }, 4e3)
        } else typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && (clearInterval(k), window.setInterval(function() {
            var n = global.getCookie("InCashoutPoller") === "true",
                t = global.getCookie("ActivateCashoutPolling") === "true";
            n && t ? yt() : n || t || yt()
        }, 4e3))
    }))
})