var SelectedTransactionTypeSourceId = '00000000-0000-0000-0000-000000000000';
var redirectCount = 5;
var avscounter = 0;
var account = {
    OnPasswordResetRedirect: function() {
        $('#confirmPasswordReset').prop('disabled', true);
        var countdown = setInterval(account.testFunc, 1000);
    },
    testFunc: function() {
        $("#redirectMessage").html('Redirecting in ' + redirectCount + " seconds");
        language.translateAtRuntime($("#redirectMessage"), "ManagePasswordContent", {
            "data-translate-key": "RedirectingIn",
            "data-translate-type": "generic-html",
            "data-translate-value-0": redirectCount,
        });
        if (redirectCount === 0) {
            clearInterval(countdown);
            $("#redirectMessage").html('');
            homePage.showOverlay();
            window.location = '/';
        }
        redirectCount--;
    },
    ResetPassword: function(e, data) {
        e.preventDefault();
        homePage.showOverlay();
        pat.post("/Account/ResetPassword", data, {
            dataType: "html"
        }).done(function(data) {
            $('#subsection').html(data).show();
            homePage.closeOverlay();
        });
    },
    CapitecVoucherTokenBalance: function(prefix, brandPaymentMethodId, minimumDeposit, currencySymbol, controllerCallback) {
        homePage.showOverlay();
        $('#' + prefix + 'MMerror').html('');
        var code = $('#' + prefix + '_Token').val();
        $.get('/Deposit/GetWiCodeBalance', {
            wiCode: code,
            brandPaymentMethodId: brandPaymentMethodId
        }, function(response) {
            var responseObject = $.parseJSON(response);
            var status = responseObject.isSuccess
            if (status === true) {
                var balance = responseObject.balance / 100;
                var minDeposit = parseInt(parseInt(minimumDeposit).toFixed());
                var difference = balance - minDeposit;
                var counter = 0;
                var interval = (difference / 4).toFixed();
                var lastNumber = minDeposit;
                var numbersList = [balance, minDeposit];
                $('#' + prefix + '_Amount').val(balance);
                $('#' + prefix + '_MaximumDeposit').val(balance);
                $('#' + prefix + '_deposit_div').show();
                $('#' + prefix + '_wiBalance_div').hide();
                $('#' + prefix + '_voucherBalance').html('Voucher Balance: <br> R' + balance);
                $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts isAmountSelected" onclick="account.setAmount(' + balance + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')">' + balance + '</div></div>')
                $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + minDeposit + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(minDeposit) + '</div></div>')
                $('#' + prefix + '_btnDepositNow_div').append('<input type="button" data-translate-set="@Sets.DepositFundsContent" data-translate-key="@Key.Generate(WebResources.DepositNow)" data-translate-type="value" name="SaveButton" value="Deposit Now" onclick="account.ValidateMobilePayment(\'' + prefix + '\',' + minDeposit + ',' + balance + ',\'' + currencySymbol + '\', \'' + controllerCallback + '\'); gaLogMMClick(this)" class="btn btn-success" style="width: 100%;" />')
                while (counter < 3) {
                    debugger;
                    var newNumber = parseFloat(interval) + parseFloat(lastNumber);
                    lastNumber = Math.round(newNumber / 10) * 10;
                    if (numbersList.includes(lastNumber)) {
                        lastNumber = newNumber;
                        $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + lastNumber + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(lastNumber) + '</div></div>');
                        counter++;
                    } else {
                        $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + lastNumber + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(lastNumber) + '</div></div>');
                        counter++;
                    }
                }
                homePage.closeOverlay();
            } else {
                $('#' + prefix + 'MMerror').html(responseObject.responseMessage);
                homePage.closeOverlay();
            }
        });
    },
    ConfirmResetPassword: function(e) {
        if (typeof e !== "undefined")
            e.preventDefault();
        let confirmPassElement = document.getElementById("ConfirmPassword");
        var ignoreResetCode = localStorage.getItem("isAccountSecurityOptionSelected") == null ? false : localStorage.getItem("isAccountSecurityOptionSelected");
        if ((ignoreResetCode == 'false' && document.getElementById("ResetCode").value === '') || document.getElementById("NewPassword").value === '' || (confirmPassElement !== null && confirmPassElement.value === '')) {
            document.getElementById('confirmResetPW').style.display = "block";
            return false;
        } else {
            document.getElementById('confirmResetPW').style.display = "none";
            if (!checkForLite() && useCaptchaForPasswordReset && !passwordCaptchaValid) {
                resetRecaptchaData();
                homePage.closeOverlay();
            } else if (!checkForLite()) {
                homePage.showOverlay();
                let formData = $('#ConfirmResetPassword').serializeArray();
                pat.post("/Account/ConfirmPasswordReset", formData).done(function(result) {
                    if (result && accountOptionsPopUpEnabled && accountOptionManagePasswordEnabled && isLoggedIn) {
                        $('.accountOptionsBody').html(result);
                    } else {
                        if ($('#subsection').length > 0) {
                            $('#subsection').html(result);
                            $('#subsection').show();
                        } else {
                            if ($("#resetP") !== null)
                                $("#resetP").html(result);
                        }
                    }
                    homePage.closeOverlay();
                });
            } else {
                const formEntries = new FormData(document.getElementById('ConfirmResetPassword')).entries();
                let formDataLite = Object.assign(...Array.from(formEntries, ([x, y]) => ({
                    [x]: y
                })));
                ajax.post("/Account/ConfirmPasswordReset", formDataLite, confirmPasswordResetCallBack);
            }
        }
    },
    numberFormat: function(number, decimals, dec_point, thousands_sep) {
        var n = !isFinite(+number) ? 0 : +number,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
            dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
            toFixedFix = function(n, prec) {
                var k = Math.pow(10, prec);
                return Math.round(n * k) / k;
            },
            s = (prec ? toFixedFix(n, prec) : Math.round(n)).toString().split('.');
        if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
        }
        if ((s[1] || '').length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1).join('0');
        }
        return s.join(dec);
    },
    ValidateOrSubmit: function(elementIdSuffix, avsRetryCounter, isAvsEnabled) {
        if (isAvsEnabled.toLowerCase() == "true") {
            account.ValidateAvs(elementIdSuffix, avsRetryCounter, isAvsEnabled);
        } else {
            if ($("#submit_" + elementIdSuffix).length > 0) {
                $("#submit_" + elementIdSuffix).click();
            } else {
                $("#frmEft" + elementIdSuffix).submit();
            }
            return true;
        }
    },
    ValidateAvs: function(elementIdSuffix, retryCounter, isAvsEnabled) {
        var bankAccountNumber = $("#BankAccountNumber" + elementIdSuffix).val();
        var branchCode = $("#BranchCodeInput" + elementIdSuffix).val();
        var accountType = $("#BankAccountType" + elementIdSuffix).val();
        var bankName = $("#Banks" + elementIdSuffix + " :selected").text();
        var amount = $("#amount" + elementIdSuffix).val();
        var brandPaymentMethodId = $("#BrandPaymentMethodId" + elementIdSuffix).val();
        if (bankAccountNumber == "" || branchCode == "" || accountType == "") {
            if ($("#submit_" + elementIdSuffix).length > 0) {
                $("#submit_" + elementIdSuffix).click();
            } else {
                $("#frmEft" + elementIdSuffix).submit();
            }
            return;
        }
        if (avscounter <= parseInt(retryCounter)) {
            pat.post("/Account/VbsBankAccountVerification", {
                accountNumber: bankAccountNumber,
                brachCode: branchCode,
                accountType,
                bankName: bankName,
                amount: amount,
                brandPaymentMethodId: brandPaymentMethodId
            }, {
                dataType: "json"
            }).done(function(result) {
                if (result.Response == '400') {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                    $("#BankAccountValidationMessage" + elementIdSuffix).val("Bank Account verification failed : Could not verify account against player ID number");
                    if (avscounter == parseInt(retryCounter)) {
                        $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                        $("#BankAccountValidationMessage" + elementIdSuffix).val("Bank Account verification failed : Could not verify account against player ID number");
                        Swal.fire({
                            icon: 'warning',
                            title: 'Incorrect Bank Account',
                            text: '',
                            html: '<div class="deposit-result-message-heading"><br><div style="text-align:left; line-height: 150%;">Unfortunately we still couldn\'t verify your bank account number: <b>' + bankAccountNumber + '</b><br><br>You can still continue but it may take a bit longer for us to approve your withdrawal.<br><br>To fast track the process, please email your bank statement and Betway account number to <a href="mailto:fica@betway.co.za">fica@betway.co.za</a></div><br><button onclick="account.ContinueWithAvs(\'' + elementIdSuffix + '\');" autofocus="false" class="swal2-confirm swal2-styled swal2-styled-no-border" style="width: 180px; ">Continue</button><button onclick="account.CancelAvsWithdrawal(\'' + elementIdSuffix + '\');" autofocus="false" class="swal2-confirm swal2-styled swal2-styled-no-border" style="width: 180px; color: #439539; background-color: #fff !important;border: solid 1px #439539">Cancel Withdrawal</button></div>',
                            showCancelButton: false,
                            showConfirmButton: false
                        });
                        gax.BankingGeneric_EventTracking('avs', 'popup2shown', 'eft')
                        return;
                    }
                    Swal.fire({
                        icon: 'warning',
                        title: 'Incorrect Bank Account',
                        text: '',
                        html: '<div class="deposit-result-message-heading"><br><div style="text-align:left">We couldn\'t verify your bank account number: <b>' + bankAccountNumber + '</b><br><br>To avoid delays with paying your withdrawal, please check the bank account number and the following details:<bR><br><ul style="line-height: 150%; padding-left: 15px;"><li>The bank account is registered in your name (the Betway account holder)</li><li>The bank account number has the correct number of digits</li><li>There are no special characters or spaces in the bank account number</li></ul></div><br><button onclick="gax.BankingGeneric_EventTracking(\'avs\', \'popup1backbuttonclicked\', \'eft\');swal.close();try{enabledWithdrawSubmitButton();} catch(e){}" autofocus="false" class="swal2-confirm swal2-styled swal2-styled-no-border" style="width: 180px;">Back</button></div>',
                        showCancelButton: false,
                        showConfirmButton: false
                    });
                    gax.BankingGeneric_EventTracking('avs', 'popup1shown', 'eft')
                    avscounter++;
                    return false;
                } else if (result.Response == '425') {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                    $("#BankAccountValidationMessage" + elementIdSuffix).val("Request already submitted");
                    avscounter = parseInt(retryCounter);
                    if ($("#submit_" + elementIdSuffix).length > 0) {
                        $("#submit_" + elementIdSuffix).click();
                    } else {
                        $("#frmEft" + elementIdSuffix).submit();
                    }
                    return true;
                } else if (result.Response == '500') {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                    $("#BankAccountValidationMessage" + elementIdSuffix).val("Bank Account verification failed : Internal Server error");
                    avscounter = parseInt(retryCounter);
                    if ($("#submit_" + elementIdSuffix).length > 0) {
                        $("#submit_" + elementIdSuffix).click();
                    } else {
                        $("#frmEft" + elementIdSuffix).submit();
                    }
                    return true;
                } else if (result.Response == '505') {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                    $("#BankAccountValidationMessage" + elementIdSuffix).val("Bank not supported by AVS");
                    avscounter = parseInt(retryCounter);
                    if ($("#submit_" + elementIdSuffix).length > 0) {
                        $("#submit_" + elementIdSuffix).click();
                    } else {
                        $("#frmEft" + elementIdSuffix).submit();
                    }
                    return true;
                } else if (result.Response == '600') {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(false);
                    $("#BankAccountValidationMessage" + elementIdSuffix).val("Bank Account verification failed : Could not verify account against player ID number");
                    avscounter = parseInt(retryCounter);
                    if ($("#submit_" + elementIdSuffix).length > 0) {
                        $("#submit_" + elementIdSuffix).click();
                    } else {
                        $("#frmEft" + elementIdSuffix).submit();
                    }
                    return true;
                } else {
                    $("#IsBankAccountValidated" + elementIdSuffix).val(true);
                    avscounter = parseInt(retryCounter);
                    if ($("#submit_" + elementIdSuffix).length > 0) {
                        $("#submit_" + elementIdSuffix).click();
                    } else {
                        $("#frmEft" + elementIdSuffix).submit();
                    }
                    return true;
                }
            });
        }
    },
    ContinueWithAvs: function(elementIdSuffix) {
        $("#Confirmed" + elementIdSuffix).val(true);
        Swal.close();
        homePage.showOverlay();
        pat.post('/Account/Withdraw', $("#frmEft" + elementIdSuffix).serialize(), {
            dataType: "html"
        }).done(function(result) {
            $('#withdrawalType').html(result);
            $('#withdrawalType').show();
        });
        homePage.closeOverlay();
        gax.BankingGeneric_EventTracking('avs', 'popup2continueclicked', 'eft')
    },
    CancelAvsWithdrawal: function(elementIdSuffix) {
        Swal.close();
        $('#collapse' + elementIdSuffix).collapse('hide')
        enabledWithdrawSubmitButton();
        gax.BankingGeneric_EventTracking('avs', 'popup2cancelclicked', 'eft')
    },
    setActiveOption: function(element, elements) {
        var parsed = JSON.parse(elements.replace(/&quot;/g, '"'));
        if (!checkForLite()) {
            for (var i = 0; i < parsed.length; i++) {
                if (element.toLowerCase() === parsed[i].toLowerCase()) {
                    $('#' + parsed[i].toLowerCase()).addClass('selectedOption');
                } else {
                    $("#" + parsed[i].toLowerCase()).removeClass('selectedOption');
                }
            }
        }
    },
    GetAccountOption: function(option) {
        homePage.showOverlay();
        window.location.href = option;
    },
    GetNextPage: function() {
        var current = parseInt($('#CurrentPage').val());
        current++;
        $('#CurrentPage').val(current);
        this.GetTransactions();
    },
    GetPreviousPage: function() {
        var current = parseInt($('#CurrentPage').val());
        current--;
        $('#CurrentPage').val(current);
        this.GetTransactions();
    },
    GetTransactions: function(transactionTypeSource, isSourceChanged) {
        homePage.showOverlay();
        $('#showPrevious').prop('disabled', true);
        $('.transShowMore').prop('disabled', true);
        var current = parseInt($('#CurrentPage').val());
        var lastTransactionTotalAmount = parseFloat($('#LastTransactionTotalAmount').val());
        if (typeof isSourceChanged !== 'undefined') {
            if (typeof transactionTypeSource !== 'undefined') {
                SelectedTransactionTypeSourceId = transactionTypeSource;
                current = 1;
                $('#CurrentPage').val(current);
                $(".transactionSummaryBody").html("");
                var filtername = $("#Source_" + transactionTypeSource).text().trim() + " Transactions";
                $("#filtertransaction-button").html(filtername + '<span class="glyphicon glyphicon-menu-down fade-a-bit" style="position: relative; right: 0px; top: -2px; margin-top: 0px; margin-left: 10px;"></span>');
            }
        }
        if ($("#last100Btn").hasClass("active")) {
            $('#PageSize').val(100);
        } else {
            $('#PageSize').val(25);
        }
        pat.post("/Account/_TransactionSummaryPage", {
            model: {
                TransactionTypeSourceId: SelectedTransactionTypeSourceId,
                isSourceChange: isSourceChanged,
                currentPage: current,
                recordTotal: $('#RecordTotal').val(),
                pageSize: $('#PageSize').val(),
                LastTransactionTotalAmount: lastTransactionTotalAmount
            }
        }, {
            dataType: "html"
        }).done(function(result) {
            var JsonResult = jQuery.parseJSON(result);
            if (JsonResult.data.length > 25) {
                $('.transactionSummaryBody').html(JsonResult.data);
            }
            $('#RecordTotal').val(JsonResult.modelData.RecordTotal);
            account.isShowMoreVisible(current, $('#PageSize').val(), $('#RecordTotal').val());
            if (typeof isSourceChanged === 'undefined') {
                $('.transShowMore').prop('diabled', true);
            }
            homePage.closeOverlay();
            var list = $("#transactionSummaryBody").children().length;
            if ($("#last100Btn").hasClass("active")) {
                $('.showMoreDiv').hide();
            } else {
                var model = JSON.parse(result).modelData;
                $('.showMoreDiv').show();
                if (model.RecordTotal > model.CurrentPage * model.PageSize) {
                    $('.transShowMore').prop('diabled', false);
                } else if (JsonResult.data.length <= 25) {
                    $('.transShowMore').prop('diabled', true);
                }
                if (model.CurrentPage === 1) {
                    $('#showPrevious').prop('disabled', true);
                } else if (model.CurrentPage > 1) {
                    $('#showPrevious').prop('disabled', false);
                }
            }
            if (list <= 0) {
                $('.srcError').show();
            } else {
                $('.srcError').hide();
            }
            if ((transactionTypeSource === '00000000-0000-0000-da7a-f33d50000012') || (transactionTypeSource === '00000000-0000-0000-da7a-f33d50000013')) {
                $('#references').html('<span onclick="account.tableSort(\'id\', \'transactionSummaryBody\');"><span data-translate-set="@Sets.TransactionSummaryContent" data-translate-key="@(Key.Generate(@WebResources.TransactionSummary_DepositReference))" value="DepositReference">Reference Number</span><br /><i class="material-icons-outlined ma-tnxsummary-angle-down">expand_more</i><i class="material-icons-outlined ma-tnxsummary-angle-up">expand_less</i></span>');
                language.translateAtRuntime($('#references'), "TransactionSummaryContent", {
                    "data-translate-key": "DepositReference"
                });
            } else {
                $('#references').html('<span onclick="account.tableSort(\'id\', \'transactionSummaryBody\');"><span data-translate-set="@Sets.TransactionSummaryContent" data-translate-key="@(Key.Generate(@WebResources.BetId_Name))" value="BetID">Bet ID</span><br /><i class="material-icons-outlined ma-tnxsummary-angle-down">expand_more</i><i class="material-icons-outlined ma-tnxsummary-angle-up">expand_less</i></span>');
                language.translateAtRuntime($('#references'), "TransactionSummaryContent", {
                    "data-translate-key": "BetID"
                });
            }
        })
    },
    CapitecVoucherTokenBalance: function(prefix, brandPaymentMethodId, minimumDeposit, currencySymbol, controllerCallback) {
        homePage.showOverlay();
        $('#' + prefix + 'MMerror').html('');
        var code = $('#' + prefix + '_Token').val();
        $.get('/Deposit/GetWiCodeBalance', {
            wiCode: code,
            brandPaymentMethodId: brandPaymentMethodId
        }, function(response) {
            var responseObject = $.parseJSON(response);
            var status = responseObject.isSuccess
            if (status === true) {
                var balance = responseObject.balance / 100;
                var minDeposit = parseInt(parseInt(minimumDeposit).toFixed());
                var difference = balance - minDeposit;
                var counter = 0;
                var interval = (difference / 4).toFixed();
                var lastNumber = minDeposit;
                var numbersList = [balance, minDeposit];
                $('#' + prefix + '_Amount').val(balance);
                $('#' + prefix + '_MaximumDeposit').val(balance);
                $('#' + prefix + '_deposit_div').show();
                $('#' + prefix + '_wiBalance_div').hide();
                $('#' + prefix + '_voucherBalance').html('Voucher Balance: <br> R' + balance);
                $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts isAmountSelected" onclick="account.setAmount(' + balance + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')">' + balance + '</div></div>')
                $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + minDeposit + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(minDeposit) + '</div></div>')
                $('#' + prefix + '_btnDepositNow_div').append('<input type="button" data-translate-set="@Sets.DepositFundsContent" data-translate-key="@Key.Generate(WebResources.DepositNow)" data-translate-type="value" name="SaveButton" value="Deposit Now" onclick="account.ValidateMobilePayment(\'' + prefix + '\',' + minDeposit + ',' + balance + ',\'' + currencySymbol + '\', \'' + controllerCallback + '\'); gaLogMMClick(this)" class="btn btn-success" style="width: 100%;" />')
                while (counter < 3) {
                    var newNumber = parseFloat(interval) + parseFloat(lastNumber);
                    lastNumber = Math.round(newNumber / 10) * 10;
                    if (numbersList.includes(lastNumber)) {
                        lastNumber = newNumber;
                        $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + lastNumber + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(lastNumber) + '</div></div>');
                        counter++;
                    } else {
                        $('#' + prefix + '_btnGroup').append('<div class="col-xs-2-5 col-sm-2 col-lg-2"> <div class="btn btn-amounts" onclick="account.setAmount(' + lastNumber + ',\'' + prefix + '\',' + "this" + ',' + "'_Amount'" + ')"  >' + Math.trunc(lastNumber) + '</div></div>');
                        counter++;
                    }
                }
                homePage.closeOverlay();
            } else {
                $('#' + prefix + 'MMerror').html(responseObject.responseMessage);
                homePage.closeOverlay();
            }
        });
    },
    GetLiteTransactions: function(nextPage, transactionTypeSource, isSourceChanged) {
        var current = parseInt(document.getElementById('CurrentPage').value);
        var recordTotalElement = document.getElementById('RecordTotal');
        var pageSizeValue = document.getElementById('PageSize').value;
        var lastTransactionTotalAmount = parseFloat($('#LastTransactionTotalAmount').val());
        current = nextPage ? ++current : current > 1 ? --current : 1;
        document.getElementById('CurrentPage').value = current;
        if (typeof isSourceChanged != 'undefined') {
            if (typeof transactionTypeSource != 'undefined') {
                SelectedTransactionTypeSourceId = transactionTypeSource;
                current = 1;
                document.getElementById('CurrentPage').value = current;
                document.getElementById('transactionSummaryBody').innerHTML = "";
            }
        }
        document.getElementById("showPrev").disabled = true;
        document.getElementById("showMore").disabled = true;
        ajax.post("/Account/_TransactionSummaryPage", {
            TransactionTypeSourceId: SelectedTransactionTypeSourceId,
            isSourceChange: isSourceChanged,
            currentPage: current,
            recordTotal: recordTotalElement.value,
            pageSize: pageSizeValue,
            LastTransactionTotalAmount: lastTransactionTotalAmount
        }, function(result) {
            var jsonResult = JSON.parse(result);
            if (jsonResult.data.length > 25) {
                document.getElementById('transactionSummaryBody').innerHTML = jsonResult.data;
                document.getElementById("noTransactions").classList.add("hidden");
            } else {
                document.getElementById('transactionSummaryBody').innerHTML = "";
                document.getElementById("noTransactions").classList.remove("hidden");
            }
            recordTotalElement.value = jsonResult.modelData.RecordTotal;
            document.getElementById("showPrev").disabled = current == 1;
            account.isShowMoreVisible(current, pageSizeValue, recordTotalElement.value);
        });
    },
    isShowMoreVisible: function(page, pagesize, recordcount) {
        var ipage = parseInt(page);
        var ipagesize = parseInt(pagesize);
        if (ipage * ipagesize < recordcount) {
            account.showHideShowMore('show');
        } else {
            account.showHideShowMore('hide');
        }
    },
    showHideShowMore: function(state) {
        if (state === 'hide') {
            document.getElementById("showMore").disabled = true;
        } else {
            document.getElementById("showMore").disabled = false;
        }
    },
    onWithdrawClick: function(url, model) {
        try {
            homePage.showOverlay();
            pat.post(url, model).done(function(result) {
                $('#withdrawalType').html(result);
                $('#withdrawalType').show();
                homePage.closeOverlay();
            });
        } catch (e) {
            alert(e)
        }
    },
    onVoucherClick: function(data) {
        homePage.showOverlay();
        pat.post("/Account/Deposit", data, {
            dataType: "html"
        }).done(function(result) {
            if (result.indexOf("voucherPartial") >= 0) {
                $("#voucherPartial").html('');
                $("#voucherPartial").html(result);
            } else {
                $('#deposit-form').html('');
                $('#deposit-form').html(result);
            }
            homePage.closeOverlay();
        });
    },
    onOTTVoucherClick: function(data) {
        homePage.showOverlay();
        pat.post("/Account/OTTVoucherDeposit?", $('#' + "ottVoucherForm").serializeArray(), {
            dataType: "html"
        }).done(function(result) {
            var resultObj = JSON.parse(result);
            $('#ottErrorDiv').html('');
            $('#ottSuccessDiv').html('');
            if (resultObj.Error) {
                $('#ottErrorDiv').html(resultObj.Message);
            } else {
                homePage.RefreshCashBalance(true);
                $('#ottSuccessDiv').html(resultObj.Message);
            }
            homePage.closeOverlay();
        });
    },
    VoucherDeposit: function(data, controllerCallback, methodName) {
        var clearVoucherNumberOnSubmitDone = false;
        homePage.showOverlay();
        pat.post(controllerCallback, data, {
            dataType: "html"
        }).done(function(result) {
            var resultObj = JSON.parse(result);
            $('#' + methodName + 'errorDiv').html('');
            $('#' + methodName + 'successDiv').html('');
            if (clearVoucherNumberOnSubmitDone) {
                $('#' + methodName + 'voucherCode').val("");
            }
            $("#" + methodName + "submitVoucher").prop('disabled', true);
            if (resultObj.Error) {
                gax.BankingDepositResultPage_EventTracking(methodName, 'Failed');
                $('#' + methodName + 'errorDiv').html(resultObj.Message);
            } else {
                homePage.RefreshCashBalance(true);
                gax.BankingDepositResultPage_EventTracking(methodName, 'Success');
                $('#' + methodName + 'successDiv').html(resultObj.Message);
            }
            if (resultObj.Action == "Reload") {
                location.reload(true);
            }
            homePage.closeOverlay();
        });
    },
    onVoucherDepositClick: function(data) {
        homePage.showOverlay();
        pat.post("/Account/DepositVoucher", data, {
            dataType: "html"
        }).done(function(result) {
            if (result.indexOf("voucherPartial") >= 0) {
                $("#voucherPartial").html('');
                $("#voucherPartial").html(result);
            } else {
                $('#deposit-form').html('');
                $('#deposit-form').html(result);
            }
            homePage.closeOverlay();
        });
    },
    onRegisterDepositConfirmation: function() {
        homePage.showOverlay();
        pat.post("/Account/RegisterDepositConfirmation", null, {
            dataType: "html"
        }).done(function(result) {
            if (result.indexOf("voucherPartial") >= 0) {
                $("#voucherPartial").html('');
                $("#voucherPartial").html(result);
            } else {
                $('#deposit-form').html('');
                $('#deposit-form').html(result);
            }
            homePage.closeOverlay();
        });
    },
    togglePagerBtns: function(state) {
        if (state === 'settled') {
            if ($('#betsContainerSettled .betSrcCont').length <= 10) {
                $('.pageBtns').hide();
            } else {
                $('.pageBtns').show();
            }
        } else if ($('#openTab').hasClass('active') || state === 'open') {
            if ($('#betsContainer .betSrcCont').length <= 10) {
                $('.pageBtns').hide();
            } else {
                $('.pageBtns').show();
            }
        }
        if ($('#bgBtn').hasClass('active')) {
            $('.pageBtns').hide();
        }
    },
    checkFltr: function(state) {
        $('.srcError').hide();
        var lbl = $(".fltrBtns label");
        if (state === 'open') {
            lbl.css("pointer-events", "none");
            $('.fltrBtns').hide();
        } else {
            lbl.css("pointer-events", "auto");
            lbl.removeAttr('disabled');
            if ($('#dfBtn').hasClass('active'))
                $('.fltrBtns').show();
            else $('.fltrBtns').hide();
        }
        $('.fltrBtns label').removeClass('active');
        $('.fltrBtns #All').parent().addClass('active');
        account.togglePagerBtns(state);
    },
    fltrOutcomes: function(oc) {
        $('.default-bets .settledBets').hide();
        $("#page_navigation_settled").hide();
        if (oc === "won") {
            $('div[outcome="2"], div[outcome="3"], div[outcome="7"]').show().removeClass('hidden');
            if ($('.default-bets .settledBets:visible').length >= 1) {
                $('.srcError').hide();
            } else {
                $('.srcError').show();
            }
            $('.pageBtns').hide();
        } else if (oc === "lost") {
            $('div[outcome="4"], div[outcome="5"]').show().removeClass('hidden');
            if ($('.default-bets .settledBets:visible').length >= 1) {
                $('.srcError').hide();
            } else {
                $('.srcError').show();
            }
            $('.pageBtns').hide();
        } else {
            $('.default-bets .settledBets').show().removeClass('hidden');
            if ($('.default-bets .settledBets:visible').length >= 1) {
                $('.srcError').hide();
            } else {
                $('.srcError').show();
            }
            account.pagerSettled();
            account.togglePagerBtns('settled');
        }
    },
    betSort: function(param, direction) {
        var list, i, switching, b, shouldSwitch, dir, switchcount = 0;
        list = $('#betsContainer');
        switching = true;
        if (direction === '' || direction === null) {
            dir = "asc";
        } else {
            dir = direction;
        }
        var sortCol = ".bet-" + param;
        while (switching) {
            switching = false;
            b = list.children('.betSrcCont');
            b.hide();
            for (i = 0; i < (b.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(b[i]).find(sortCol).find("span").html();
                var holderNext = $(b[i + 1]).find(sortCol).find("span").html();
                if (param === 'date') {
                    holder = $(b[i]).find(sortCol).find("p").html();
                    holderNext = $(b[i + 1]).find(sortCol).find("p").html();
                } else if (param !== 'date' || param !== 'id') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                b[i].parentNode.insertBefore(b[i + 1], b[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        b.slice(0, 9).show();
    },
    betSortNew: function(param, type) {
        homePage.showOverlay();
        pat.post("/MyBets/BetSort", {
            field: param,
            type: type
        }).done(function(data) {
            $('.sports-open-bets').html(data);
            homePage.closeOverlay();
        });
    },
    betSortSet: function(param, direction) {
        var list, i, switching, s, shouldSwitch, dir, switchcount = 0;
        list = $('#betsContainerSettled');
        switching = true;
        if (direction === '' || direction === null) {
            dir = "asc";
        } else {
            dir = direction;
        }
        var sortCol = ".bet-" + param;
        while (switching) {
            switching = false;
            s = list.children('.settledBets');
            if (!$(".fltrBtns #Won").parent('label').hasClass("active") && !$(".fltrBtns #Lost").parent('label').hasClass("active")) {
                s.addClass('hidden').hide();
            }
            for (i = 0; i < (s.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(s[i]).find(sortCol).find("span").html().toLowerCase();
                var holderNext = $(s[i + 1]).find(sortCol).find("span").html().toLowerCase();
                if (param === 'date') {
                    holder = $(s[i]).find(sortCol).find("p").html().toLowerCase();
                    holderNext = $(s[i + 1]).find(sortCol).find("p").html().toLowerCase();
                } else if (param !== 'date' || param !== 'id') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                s[i].parentNode.insertBefore(s[i + 1], s[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        if ($(".fltrBtns #All").parent('label').hasClass("active")) {
            s.slice(0, 10).removeClass('hidden').show();
        } else if (!$(".fltrBtns #Won").parent('label').hasClass("active") && !$(".fltrBtns #Lost").parent('label').hasClass("active")) {
            s.removeClass('hidden').show();
        }
    },
    betSortSetVirtual: function(param, betType) {
        var list, i, switching, s, shouldSwitch, dir, switchcount = 0;
        list = $('#mybetsContainer');
        $('#mybetsContainer').attr("data-sort", param);
        switching = true;
        dir = "asc";
        var sortCol = ".virtual-" + param;
        while (switching) {
            switching = false;
            if (betType === "open") {
                s = list.children('.openBets');
            } else {
                s = list.children('.settledBets');
            }
            s.hide().addClass('hidden');
            for (i = 0; i < (s.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(s[i]).find(sortCol).html().trim().toLowerCase();
                var holderNext = $(s[i + 1]).find(sortCol).html().trim().toLowerCase();
                if (param === 'wagerAmount' || param === 'actualReturn') {
                    holder = $(s[i]).find(sortCol).html().toLowerCase().trim();
                    holderNext = $(s[i + 1]).find(sortCol).html().toLowerCase().trim();
                }
                if (param !== 'date' && param !== 'id' && param !== 'description') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                s[i].parentNode.insertBefore(s[i + 1], s[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        s.show().removeClass('hidden');
    },
    betSortSetScoutGaming: function(param, betType) {
        var list, i, switching, s, shouldSwitch, dir, switchcount = 0;
        list = $('#mybetsContainer');
        $('#mybetsContainer').attr("data-sort", param);
        switching = true;
        dir = "asc";
        var sortCol = ".scoutGaming-" + param;
        while (switching) {
            switching = false;
            if (betType === "open") {
                s = list.children('.openBets');
            } else {
                s = list.children('.settledBets');
            }
            s.hide().addClass('hidden');
            for (i = 0; i < (s.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(s[i]).find(sortCol).html().trim().toLowerCase();
                var holderNext = $(s[i + 1]).find(sortCol).html().trim().toLowerCase();
                if (param === 'wagerAmount' || param === 'actualReturn' || param === 'rake') {
                    holder = $(s[i]).find(sortCol).html().toLowerCase().trim();
                    holderNext = $(s[i + 1]).find(sortCol).html().toLowerCase().trim();
                }
                if (param !== 'date' && param !== 'id' && param !== 'description') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                s[i].parentNode.insertBefore(s[i + 1], s[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        s.show().removeClass('hidden');
    },
    betSortSetLiveGames: function(param, betType) {
        var list, i, switching, s, shouldSwitch, dir, switchcount = 0;
        list = $('#mybetsContainer');
        switching = true;
        dir = "asc";
        var sortCol = ".live-" + param;
        while (switching) {
            switching = false;
            if (betType === "open") {
                s = list.children('.openBets');
            } else {
                s = list.children('.settledBets');
            }
            s.hide().addClass('hidden');
            for (i = 0; i < (s.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(s[i]).find(sortCol).html().toLowerCase();
                var holderNext = $(s[i + 1]).find(sortCol).html().toLowerCase();
                if (param === 'wagerAmount' || param === 'actualReturn') {
                    holder = $(s[i]).find(sortCol).html().toLowerCase().trim().replace(/\D/g, '');
                    holderNext = $(s[i + 1]).find(sortCol).html().toLowerCase().trim().replace(/\D/g, '');
                }
                if (param !== 'date') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                s[i].parentNode.insertBefore(s[i + 1], s[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        s.show().removeClass('hidden');
    },
    tableSort: function(param, id, direction) {
        var list, i, switching, s, shouldSwitch, dir, switchcount = 0;
        list = $('.' + id);
        switching = true;
        if (direction === '' || direction === null || typeof(direction) === 'undefined') {
            dir = "asc";
        } else {
            dir = direction;
        }
        var sortCol = "." + id + "-" + param;
        while (switching) {
            switching = false;
            s = list.children().not('script').not("#BetslipSummaryPopUp");
            s.hide();
            for (i = 0; i < (s.length - 1); i++) {
                shouldSwitch = false;
                var holder = $(s[i]).find(sortCol).html();
                if (holder) {
                    holder = holder.toLowerCase();
                } else {
                    holder = "";
                }
                var holderNext = $(s[i + 1]).find(sortCol).html();
                if (holderNext) {
                    holderNext = holderNext.toLowerCase();
                } else {
                    holderNext = "";
                }
                if (param !== 'date' && param !== 'type' && param !== 'pool') {
                    holder = parseFloat(holder.replace(/\D/g, ''));
                    holderNext = parseFloat(holderNext.replace(/\D/g, ''));
                }
                if (dir === "asc") {
                    if (holder > holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                } else if (dir === "desc") {
                    if (holder < holderNext) {
                        shouldSwitch = true;
                        break;
                    }
                }
            }
            if (shouldSwitch) {
                s[i].parentNode.insertBefore(s[i + 1], s[i]);
                switching = true;
                switchcount++;
            } else {
                if (switchcount === 0 && dir === "asc") {
                    dir = "desc";
                    switching = true;
                }
            }
        }
        if ($("#allBtn").hasClass("active")) {
            s.slice(0, 25).show();
        } else if ($("#last100Btn").hasClass("active")) {
            s.slice(0, 100).show();
        } else {
            s.slice(0, 9).show();
        }
    },
    pagerOpenVirtualSport: function() {
        var show_per_page = 10;
        var number_of_items = $('#VirtualOpenBetsList').children().length;
        var number_of_pages_settled = Math.ceil(number_of_items / show_per_page);
        $('#current_page_open').val(0);
        $('#show_per_page_open').val(show_per_page);
        var navigation_html = '<a class="previous_link btn btn-primary" href="javascript:account.previousStld();">Prev</a>';
        var current_link = 0;
        while (number_of_pages_settled > current_link) {
            navigation_html += '<a class="page_link btn btn-primary" href="javascript:account.go_to_pageStld(' + current_link + ')" longdesc="' + current_link + '">' + (current_link + 1) + '</a>';
            current_link++;
        }
        navigation_html += '<a class="next_link btn btn-primary" href="javascript:account.nextStld();">Next</a>';
        $('#page_navigation_open.rr').html(navigation_html);
        $('#page_navigation_open.rr .page_link:first').addClass('active_page');
        $('#VirtualOpenBetsList').children().hide();
        $('#VirtualOpenBetsList').children().slice(0, show_per_page).css('display', '');
        if ($('#VirtualOpenBetsList').children().length > show_per_page) {
            $('#page_navigation_open.rr').css('display', 'block');
        } else {
            $('#page_navigation_open.rr').css('display', 'none');
        }
        account.pageNo();
    },
    pagerSettledVirtualSport: function() {
        var show_per_page = 10;
        var number_of_items = $('#VirtualSettledBetsList').children().length;
        var number_of_pages_settled = Math.ceil(number_of_items / show_per_page);
        $('#current_page_settled').val(0);
        $('#show_per_page_settled').val(show_per_page);
        var navigation_html = '<a class="previous_link btn btn-primary" href="javascript:account.previousStld();">Prev</a>';
        var current_link = 0;
        while (number_of_pages_settled > current_link) {
            navigation_html += '<a class="page_link btn btn-primary" href="javascript:account.go_to_pageStld(' + current_link + ')" longdesc="' + current_link + '">' + (current_link + 1) + '</a>';
            current_link++;
        }
        navigation_html += '<a class="next_link btn btn-primary" href="javascript:account.nextStld();">Next</a>';
        $('#page_navigation_settled.rr').html(navigation_html);
        $('#page_navigation_settled.rr .page_link:first').addClass('active_page');
        $('#VirtualSettledBetsList').children().hide();
        $('#VirtualSettledBetsList').children().slice(0, show_per_page).css('display', '');
        if ($('#VirtualSettledBetsList').children().length > show_per_page) {
            $('#page_navigation_settled.rr').css('display', 'block');
        } else {
            $('#page_navigation_settled.rr').css('display', 'none');
        }
        account.pageNoSettled();
    },
    pagerSettled: function() {
        var show_per_page = 10;
        var number_of_items = $('#betsContainerSettled').children().length;
        var number_of_pages_settled = Math.ceil(number_of_items / show_per_page);
        $('#current_page_settled').val(0);
        $('#show_per_page_settled').val(show_per_page);
        var navigation_html = '<a class="previous_link btn btn-primary" href="javascript:account.previousStld();">Prev</a>';
        var current_link = 0;
        while (number_of_pages_settled > current_link) {
            navigation_html += '<a class="page_link btn btn-primary" href="javascript:account.go_to_pageStld(' + current_link + ')" longdesc="' + current_link + '">' + (current_link + 1) + '</a>';
            current_link++;
        }
        navigation_html += '<a class="next_link btn btn-primary" href="javascript:account.nextStld();">Next</a>';
        $('#page_navigation_settled').html(navigation_html);
        $('#page_navigation_settled .page_link:first').addClass('active_page');
        $('#betsContainerSettled').children().css('display', 'none');
        $('#betsContainerSettled').children().slice(0, show_per_page).css('display', 'block');
        account.pageNoSettled();
    },
    previousStld: function() {
        var new_page = parseInt($('#current_page_settled').val()) - 1;
        if ($('#page_navigation_settled .active_page').prev('.page_link').length === true) {
            account.go_to_pageStld(new_page);
        }
        account.pageNoSettled();
    },
    nextStld: function() {
        var new_page = parseInt($('#current_page_settled').val()) + 1;
        if ($('#page_navigation_settled .active_page').next('.page_link').length === true) {
            account.go_to_pageStld(new_page);
        }
        account.pageNoSettled();
    },
    go_to_pageStld: function(page_num) {
        var param = $('#VirtualOpenBetsList').attr("data-sort");
        var show_per_page;
        if ($('#show_per_page_settled').length) {
            show_per_page = parseInt($('#show_per_page_settled').val());
        } else {
            show_per_page = parseInt($('#show_per_page_open').val());
        }
        var start_from = page_num * show_per_page;
        var end_on = start_from + show_per_page;
        $('#betsContainerSettled').children().css('display', 'none').slice(start_from, end_on).css('display', 'block').removeClass("hidden");
        $('#page_navigation_settled .page_link[longdesc=' + page_num + ']').addClass('active_page').siblings('.active_page').removeClass('active_page');
        $('#page_navigation_settled.rr .page_link[longdesc=' + page_num + ']').addClass('active_page').siblings('.active_page').removeClass('active_page');
        $('#page_navigation_open.page_link[longdesc=' + page_num + ']').addClass('active_page').siblings('.active_page').removeClass('active_page');
        $('#page_navigation_open.rr .page_link[longdesc=' + page_num + ']').addClass('active_page').siblings('.active_page').removeClass('active_page');
        $('#current_page_settled').val(page_num);
        $('#current_page_open').val(page_num);
        account.pageNoSettled();
    },
    pageNoSettled: function() {
        var show_per_page = 10;
        var number_of_items = $('#betsContainerSettled').children().length;
        var number_of_pages_settled = Math.ceil(number_of_items / show_per_page);
        if ($('#current_page_settled').val() === 0) {
            $('#page_navigation_settled .previous_link').css('pointer-events', 'none');
            $('#page_navigation_settled .previous_link').attr('disabled', 'disabled');
            $('#page_navigation_settled .next_link').css('pointer-events', 'all');
            $('#page_navigation_settled .next_link').removeAttr('disabled');
        } else if ($('#current_page_settled').val() === (number_of_pages_settled - 1)) {
            $('#page_navigation_settled .next_link').css('pointer-events', 'none');
            $('#page_navigation_settled .next_link').attr('disabled', 'disabled');
            $('#page_navigation_settled .previous_link').css('pointer-events', 'all');
            $('#page_navigation_settled .previous_link').removeAttr('disabled');
        } else {
            $('#page_navigation_settled .previous_link, #page_navigation_settled .next_link').css('pointer-events', 'all');
            $('#page_navigation_settled .previous_link, #page_navigation_settled .next_link').removeAttr('disabled');
        }
        if (number_of_pages_settled <= 1) {
            $('#page_navigation_settled .previous_link').css('pointer-events', 'none');
            $('#page_navigation_settled .previous_link').attr('disabled', 'disabled');
            $('#page_navigation_settled .next_link').css('pointer-events', 'none');
            $('#page_navigation_settled .next_link').attr('disabled', 'disabled');
        }
    },
    pager: function() {
        var show_per_page = 10;
        var number_of_items = $('#betsContainer').children().length;
        var number_of_pages = Math.ceil(number_of_items / show_per_page);
        $('#current_page').val(0);
        $('#show_per_page').val(show_per_page);
        var navigation_html = '<a class="previous_link btn btn-primary" href="javascript:account.previous();">Prev</a>';
        var current_link = 0;
        while (number_of_pages > current_link) {
            navigation_html += '<a class="page_link btn btn-primary" href="javascript:account.go_to_page(' + current_link + ')" longdesc="' + current_link + '">' + (current_link + 1) + '</a>';
            current_link++;
        }
        navigation_html += '<a class="next_link btn btn-primary" href="javascript:account.next();">Next</a>';
        $('#page_navigation_open').html(navigation_html);
        $('#page_navigation_open .page_link:first').addClass('active_page');
        $('#betsContainer').children().css('display', 'none');
        $('#betsContainer').children().slice(0, show_per_page).css('display', 'block');
        account.pageNo();
        account.pagerOpenVirtualSport();
    },
    previous: function() {
        var new_page = parseInt($('#current_page').val()) - 1;
        if ($('#page_navigation_open .active_page').prev('.page_link').length === true) {
            account.go_to_page(new_page);
        }
        account.pageNo();
    },
    next: function() {
        var new_page = parseInt($('#current_page').val()) + 1;
        if ($('#page_navigation_open .active_page').next('.page_link').length === true) {
            account.go_to_page(new_page);
        }
        account.pageNo();
    },
    go_to_page: function(page_num) {
        var show_per_page = parseInt($('#show_per_page').val());
        var start_from = page_num * show_per_page;
        var end_on = start_from + show_per_page;
        $('#betsContainer').children().css('display', 'none').slice(start_from, end_on).css('display', 'block');
        $('#page_navigation_open .page_link[longdesc=' + page_num + ']').addClass('active_page').siblings('.active_page').removeClass('active_page');
        $('#current_page').val(page_num);
        account.pageNo();
    },
    pageNo: function() {
        var show_per_page = 10;
        var number_of_items = $('#betsContainer').children().length;
        var number_of_pages = Math.ceil(number_of_items / show_per_page);
        if ($('#current_page').val() === 0) {
            $('.previous_link').css('pointer-events', 'none');
            $('.previous_link').attr('disabled', 'disabled');
            $('.next_link').css('pointer-events', 'all');
            $('.next_link').removeAttr('disabled');
        } else if ($('#current_page').val() === (number_of_pages - 1)) {
            $('.next_link').css('pointer-events', 'none');
            $('.next_link').attr('disabled', 'disabled');
            $('.previous_link').css('pointer-events', 'all');
            $('.previous_link').removeAttr('disabled');
        } else {
            $('.previous_link, .next_link').css('pointer-events', 'all');
            $('.previous_link, .next_link').removeAttr('disabled');
        }
        if (number_of_pages <= 1) {
            $('.previous_link').css('pointer-events', 'none');
            $('.previous_link').attr('disabled', 'disabled');
            $('.next_link').css('pointer-events', 'none');
            $('.next_link').attr('disabled', 'disabled');
        }
    },
    FetchBranchDetails: function(bankId, elementSuffix) {
        homePage.showOverlay();
        $('#submit' + elementSuffix).prop('disabled', false);
        $('#error' + elementSuffix).html('');
        $('#BankId' + elementSuffix).val(bankId);
        $('#BranchCode' + elementSuffix).val("");
        $('#BranchCodeInput' + elementSuffix).val("");
        var list = document.querySelector("select#Branches" + elementSuffix);
        if (list != undefined && list != null) list.options.length = 0;
        var opt = document.createElement('option');
        opt.innerHTML = "Select Branch";
        opt.value = "";
        if (list != undefined && list != null) list.appendChild(opt);
        let url = "/Account/GetBranches";
        if ($('#directIncludeParentPath').length > 0) {
            url = $('#directIncludeParentPath').val() + url
        }
        pat.post(url, {
            bankId: bankId
        }).done(function(data) {
            if (data.length === 1) {
                var opt = document.createElement('option');
                opt.innerHTML = data[0].Name;
                opt.value = data[0].Code;
                if (list != undefined && list != null) {
                    list.appendChild(opt);
                    list.selectedIndex = 1;
                    list.setAttribute("disabled", "disabled");
                }
                $('#BranchCode' + elementSuffix).val(data[0].Code);
                account.PrepopulateBranchCode($('#BranchCode' + elementSuffix).val(), elementSuffix);
            } else {
                for (var i = 0; i < data.length; i++) {
                    var opts = document.createElement('option');
                    opts.innerHTML = data[i].Name;
                    opts.value = data[i].Code;
                    if (list != undefined && list != null) list.appendChild(opts);
                }
                if (list != undefined && list != null) list.removeAttribute("disabled");
            }
            homePage.closeOverlay();
        });
    },
    PrepopulateBankDetails: function(bankId, elementSuffix) {
        if (bankId !== "00000000-0000-0000-0000-000000000000") {
            homePage.showOverlay();
            $('#BankId' + elementSuffix).val(bankId);
            $('#Banks' + elementSuffix).val(bankId);
            var list = document.querySelector("select#Branches" + elementSuffix);
            if (list == undefined || list == null) {
                homePage.closeOverlay();
                return;
            }
            var opt = document.createElement('option');
            if (list != undefined && list != null) list.options.length = 0;
            opt.innerHTML = "Select Branch";
            opt.value = "";
            if (list != undefined && list != null) list.appendChild(opt);
            let url = "/Account/GetBranches";
            if ($('#directIncludeParentPath').length > 0) {
                url = $('#directIncludeParentPath').val() + url
            }
            pat.post(url, {
                bankId: bankId
            }).done(function(data) {
                var opt = document.createElement('option');
                if (data.length === 1) {
                    opt.innerHTML = data[0].Name;
                    opt.value = data[0].Code;
                    if (list != undefined && list != null) {
                        list.appendChild(opt);
                        list.selectedIndex = 1;
                        list.setAttribute("disabled", "disabled");
                    }
                } else {
                    for (var i = 0; i < data.length; i++) {
                        opt = document.createElement('option');
                        opt.innerHTML = data[i].Name;
                        opt.value = data[i].Code;
                        if (list != undefined && list != null) list.appendChild(opt);
                    }
                    account.PrepopulateBranchCode($('#BranchCode' + elementSuffix).val(), elementSuffix);
                    if (list != undefined && list != null) list.removeAttribute("disabled");
                }
                if ($('#SavedBankAccountType' + elementSuffix).val() !== "") {
                    $("#BankAccountType" + elementSuffix).val($('#SavedBankAccountType' + elementSuffix).val());
                }
                homePage.closeOverlay();
            });
        }
    },
    PrepopulateBranchCode: function(branchCode, elementSuffix) {
        if (elementSuffix !== '') {
            $('#submit' + elementSuffix).prop('disabled', false);
            $('#error' + elementSuffix).html('');
        }
        $('#Branches' + elementSuffix).val(branchCode);
        $('#BranchCode' + elementSuffix).val(branchCode);
        $('#BranchCodeInput' + elementSuffix).prop('readOnly', true);
        $('#BranchCodeInput' + elementSuffix).val(branchCode);
        if ($('#BranchCode' + elementSuffix).val() === "") {
            $('#BranchCode' + elementSuffix).prop('readOnly', false);
        }
        if ($("#BrandCodeInput" + elementSuffix).length) {
            $('#BranchCodeInput' + elementSuffix).prop('readOnly', true);
            document.getElementById("BranchCodeInput" + elementSuffix).value = branchCode
        }
    },
    PrepopulateBranchCodeNg: function(e) {
        if (e !== "00000000-0000-0000-0000-000000000000") {
            $('[id=Banks]').val(e.toLowerCase());
            $("[id=BankId]").val(e);
        }
    },
    PrepopulateBankAccount: function(obj = null) {
        let parent = document.body
        if (obj != null) {
            parent = document.getElementById(obj)
        }
        var value = $(parent).find("#bankAccountNumberdId option:selected").val();
        if (value === "Select New Account" || value === "") {
            $(parent).find("#Banks").val(null)
            $(parent).find("#accountNumberSectiontId").show()
            $(parent).find("#AccountNumberId").val('');
            account.ResetListOfBanks(parent);
        } else {
            $(parent).find("#accountNumberSectiontId").hide()
            account.FilterBankByAccount(value);
            $(parent).find("#AccountNumberId").val(value);
        }
        var dropdown = $(parent).find('#bankAccountNumberdId');
        var ind = dropdown[0].selectedIndex;
        if (dropdown[0].options.length > 1) {
            if (dropdown[0].selectedIndex === 0) {
                $(parent).find('#DeleteAccount').addClass('hidden');
                $(parent).find('#saveMyDetails').removeClass('hidden');
            } else {
                $(parent).find('#DeleteAccount').removeClass('hidden');
                $(parent).find('#saveMyDetails').addClass('hidden');
            }
        } else {
            $(parent).find('#DeleteAccount').addClass('hidden');
            $(parent).find('#saveMyDetails').removeClass('hidden');
        }
    },
    ResetListOfBanks: function(parent) {
        $("[id=Banks]").val($(parent).find("#Banks option:selected").val());
        $("[id=BankId]").val($(parent).find("#Banks option:selected").val());
    },
    FilterBankByAccount: function(e) {
        var bankId = "";
        $("#accountAttributesId > option").each(function() {
            if (this.value === e) {
                bankId = this.text;
                account.SetSelectedBank(bankId);
            }
        });
    },
    SetSelectedBank: function(bankId) {
        $('#Banks').val(bankId.toLowerCase());
        account.PrepopulateBranchCodeNg(bankId);
    },
    getBankNameAfterSave: function() {
        var bank = document.getElementById("bankNameId").value;
        var typeOfAccount = $("#bankAccountNumberdId option:selected").val();
        var accountNumber = document.getElementById("AccountNumberId").value;
        var isNewAccount = (typeOfAccount === "" || typeOfAccount === "Select New Account");
        if (bank !== "" && isNewAccount) {
            account.SetSelectedBank(bank);
            document.getElementById("accountNumberSectiontId").style.display = "block";
        }
        if (accountNumber === "" && isNewAccount) {
            account.ResetListOfBanks();
            document.getElementById("accountNumberSectiontId").style.display = "block";
        }
        if (bank !== "" && !isNewAccount) {
            account.SetSelectedBank(bank);
            document.getElementById("accountNumberSectiontId").style.display = "none";
        }
    },
    OnDeleteAccount: function() {
        var selectedBank = $("#BankId option:selected").text();
        var selectedAccountNumber = document.getElementById("AccountNumberId").value;
        var accountAttribute = document.getElementById("accountGroupId").value;
        $("#accountGroupId > option").each(function() {
            var data = this.text;
            var value = data.split('|');
            var accountNumber = value[0];
            var bank = value[1];
            if (bank === selectedBank && accountNumber === selectedAccountNumber) {
                account.RemoveAccountAttribute(this.value);
                account.ResetListOfBanks();
                document.getElementById("AccountNumberId").value = "";
                $("#bankAccountNumberdId option[value=" + accountNumber + "]").remove();
            }
        });
        location.reload();
    },
    ReadOnlyEmptyDropdown: function(elementName) {
        var ele = document.getElementById(elementName);
        if (ele !== null) {
            if (ele.options.length === 1)
                ele.setAttribute("readonly", true);
            ele.setAttribute("onclick", "return false;");
        }
    },
    ValidatePayment: function(pre, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var firstNameText = document.getElementById(pre + "PaygatePaymentRequest_FirstName");
        var lastNameText = document.getElementById(pre + "PaygatePaymentRequest_LastName");
        var emailNameText = document.getElementById(pre + "PaygatePaymentRequest_Email");
        var line1Text = document.getElementById(pre + "PaygatePaymentRequest_Line1");
        var paymentAmount = document.getElementById(pre + "PaygatePaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (paymentAmount !== null) {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of R" + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMinimumLimit",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of R" + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            if (maxPayoutAmount > 0 && paymentAmount > maxPayoutAmount) {
                feedbackDiv.innerHTML = "This amount is above the maximum limit of R" + maxPayoutAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountAboveMaximumLimit",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": maxPayoutAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is above the maximum limit of R" + maxPayoutAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            if (pre === "BT") {
                if (firstNameText.value.length + lastNameText.value.length > 21) {
                    feedbackDiv.innerHTML = "The maximum amount of characters on EFT payments for First Name and Last Name is 21";
                    language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                        "data-translate-key": "MaxAmountEFTPaymentsCharacters21"
                    });
                    document.getElementById(pre + "_lastNamefield").style.display = "";
                    firstNameText.focus();
                    document.getElementById(pre + "_firstNamefield").style.display = "";
                    canConfirmBankingEventPush = false;
                    return false;
                }
            }
            var numericResult = parseInt(paymentAmount);
            var validationResult = true;
            if (numericResult > 0) {
                if (pre === "BT") {
                    if (emailNameText.value.length <= 0) {
                        feedbackDiv.innerHTML = "Please complete email";
                        language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                            "data-translate-key": "PleaseCompleteEmail"
                        });
                        emailNameText.focus();
                        document.getElementById(pre + "_emailfield").style.display = "";
                        validationResult = false;
                    }
                    if (firstNameText.value.length <= 0) {
                        feedbackDiv.innerHTML = "Please complete first name";
                        language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                            "data-translate-key": "PleaseCompleteFirstName"
                        });
                        firstNameText.focus();
                        document.getElementById(pre + "_firstNamefield").style.display = "";
                        validationResult = false;
                    }
                    if (lastNameText.value.length <= 0) {
                        feedbackDiv.innerHTML = "Please complete last name";
                        language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                            "data-translate-key": "PleaseCompleteLastName"
                        });
                        lastNameText.focus();
                        document.getElementById(pre + "_lastNamefield").style.display = "";
                        validationResult = false;
                    }
                    if (line1Text.value.length <= 0) {
                        feedbackDiv.innerHTML = "Please complete address line 1";
                        language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                            "data-translate-key": "PleaseCompleteAddressLine1"
                        });
                        document.getElementById(pre + "_line1field").style.display = "";
                        line1Text.focus();
                        validationResult = false;
                    }
                }
                if (validationResult) {
                    window.location.hash = '#' + pre + "_payframeInfo";
                    if (pre === "iPay_") {
                        account.InitIPay(pre);
                    } else {
                        account.InitPaygate(pre);
                    }
                } else {
                    canConfirmBankingEventPush = false;
                    return false;
                }
            } else {
                var errorDiv = document.getElementById(pre + "errorDiv");
                errorDiv.innerHTML = "Please enter an amount";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "PleaseEnterAmount"
                });
                gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
                canConfirmBankingEventPush = false;
                return false;
            }
            homePage.showOverlay();
            if (canConfirmBankingEventPush) {
                gax.BankingConfirm_EventTracking(paymentAmount);
            }
            return true;
        }
        return false;
    },
    ValidateEftPayment: function(pre, minAmount, maxAmount, currencySymbol, controllerCallback) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (paymentAmount !== null) {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of " + currencySymbol + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMinimumLimitOf",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": currencySymbol,
                    "data-translate-value-1": minPayAmount
                });
                window.setTimeout(function() {
                    if (clearFeedbackAfterTimeout) feedbackDiv.innerHTML = "";
                }, 5000);
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of " + currencySymbol + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            if (maxPayoutAmount > 0 && paymentAmount > maxPayoutAmount) {
                feedbackDiv.innerHTML = "This amount is above the maximum limit of " + currencySymbol + maxPayoutAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountAboveMaxLimitOf",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": currencySymbol,
                    "data-translate-value-1": maxPayoutAmount
                });
                window.setTimeout(function() {
                    if (clearFeedbackAfterTimeout) feedbackDiv.innerHTML = "";
                }, 5000);
                gax.BankingDepositErrorEvent_EventTracking("This amount is above the maximum limit of " + currencySymbol + maxPayoutAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            var validationResult = true;
            if (numericResult > 0) {
                if (validationResult) {
                    account.InitPayment(pre, controllerCallback);
                } else {
                    canConfirmBankingEventPush = false;
                    return false;
                }
            } else {
                var errorDiv = document.getElementById(pre + "errorDiv");
                errorDiv.innerHTML = "Please enter an amount";
                language.translateAtRuntime(errorDiv, "ErrorMessages", {
                    "data-translate-key": "PleaseEnterAmount"
                });
                gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
                canConfirmBankingEventPush = false;
                return false;
            }
            homePage.showOverlay();
            if (canConfirmBankingEventPush) {
                gax.BankingConfirm_EventTracking(paymentAmount);
            }
            return true;
        }
        return false;
    },
    ValidatePaymentStack: function(pre, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "PaystackPaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (!paymentAmount.match(/^\d+$/)) {
            feedbackDiv.innerHTML = "This amount is invalid. Please provide a valid amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is invalid. Please provide a valid amount", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is greater than the maximum limit allowed", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (typeof document.getElementById(pre + "PaystackPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of NGN" + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMinLimitOfNGN",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of NGN" + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            if (maxPayoutAmount > 0 && Number(paymentAmount) > maxPayoutAmount) {
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                account.InitPaystack(pre);
            } else {
                canConfirmBankingEventPush = false;
                return false;
            }
        } else {
            var errorDiv = document.getElementById(pre + "errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(errorDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
            canConfirmBankingEventPush = false;
            return false;
        }
        homePage.showOverlay();
        if (canConfirmBankingEventPush) {
            gax.BankingConfirm_EventTracking(paymentAmount);
        }
        return true;
    },
    ValidatePaymentDPO: function(pre, minAmount, maxAmount, currencySymbol) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "DPOPaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (paymentAmount.length > 20) {
            feedbackDiv.innerHTML = "Invalid Amount Entered, Please try again!";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmountTryAgain"
            });
            gax.BankingDepositErrorEvent_EventTracking("Invalid Amount Entered, Please try again!", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is greater than the maximum limit allowed", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (typeof document.getElementById(pre + "PaystackPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of " + currencySymbol + minPayAmount;
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMaxLimitOf",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": currencySymbol,
                    "data-translate-value-1": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of " + currencySymbol + minPayAmount, paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            if (maxPayoutAmount > 0 && Number(paymentAmount) > maxPayoutAmount) {
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                account.InitDPO(pre);
            } else {
                canConfirmBankingEventPush = false;
                return false;
            }
        } else {
            var errorDiv = document.getElementById(pre + "errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(errorDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
            canConfirmBankingEventPush = false;
            return false;
        }
        homePage.showOverlay();
        if (canConfirmBankingEventPush) {
            gax.BankingConfirm_EventTracking(paymentAmount);
        }
        return true;
    },
    depositAmountFieldFocus: function(input) {
        var selectText = false;
        var clearText = true;
        if ($(input).length > 0 && selectText) {
            setTimeout(function() {
                $(input).select()
            }, 20)
        }
        if ($(input).length > 0 && clearText) {
            setTimeout(function() {
                $(input).val('')
            }, 20)
        }
    },
    ClearButtons: function(inputName) {
        $('.btn-amounts').removeClass('isAmountSelected');
        var val = document.getElementById(inputName).value;
        var charIndex = val.length;
        var currentValue = val[charIndex - 1]
        if (isNaN(currentValue)) {
            val = val.substr(0, charIndex - 1);
        }
        document.getElementById(inputName).value = val;
    },
    ValidatePaymentMTN: function(pre, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "MTNPaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (!paymentAmount.match(/^\d+$/)) {
            feedbackDiv.innerHTML = "This amount is invalid. Please provide a valid amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is invalid. Please provide a valid amount", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is greater than the maximum limit allowed", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (typeof document.getElementById(pre + "PaystackPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of GHS" + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", "AmountBelowMinLimitGHS", {
                    "data-translate-key": "AmountBelowMinLimitGHS",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of GHS" + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                account.InitMTN(pre);
            } else {
                canConfirmBankingEventPush = false;
                return false;
            }
        } else {
            var errorDiv = document.getElementById(pre + "errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(errorDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
            canConfirmBankingEventPush = false;
            return false;
        }
        homePage.showOverlay();
        if (canConfirmBankingEventPush) {
            gax.BankingConfirm_EventTracking(paymentAmount);
        }
        return true;
    },
    ValidatePaymentAirtelZambia: function(pre, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById("errorDiv");
        var paymentAmount = document.getElementById(pre + "AirtelZambiaPaymentRequest_Amount").value;
        var clearFeedbackAfterTimeout = false;
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            return false;
        }
        if (typeof document.getElementById(pre + "AirtelZambiaPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of ZMW" + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMinZMW",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": minPayAmount
                });
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                this.InitAirtelZAmbia(pre);
            } else {
                return false;
            }
        } else {
            var errorDiv = document.getElementById("errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(errorDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAmount"
            });
            return false;
        }
        homePage.showOverlay();
        return true;
    },
    ValidatePaymentMTNGhana: function(pre, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "MTNGhanaPaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (!paymentAmount.match(/^\d+$/)) {
            feedbackDiv.innerHTML = "This amount is invalid. Please provide a valid amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is invalid. Please provide a valid amount", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is greater than the maximum limit allowed", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (typeof document.getElementById(pre + "PaystackPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of GHS" + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountBelowMinLimitGHS",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of GHS" + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                account.InitMTNGhana(pre);
            } else {
                canConfirmBankingEventPush = false;
                return false;
            }
        } else {
            var errorDiv = document.getElementById(pre + "errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(errorDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAnAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
            canConfirmBankingEventPush = false;
            return false;
        }
        homePage.showOverlay();
        if (canConfirmBankingEventPush) {
            gax.BankingConfirm_EventTracking(paymentAmount);
        }
        return true;
    },
    ValidatePaymentMTNPaymentRequest: function(pre, minAmount, maxAmount, currency) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(pre + "errorDiv");
        var paymentAmount = document.getElementById(pre + "MTNPaymentRequest_Amount").value;
        var canConfirmBankingEventPush = true;
        var clearFeedbackAfterTimeout = false;
        if (!paymentAmount.match(/^\d+$/)) {
            feedbackDiv.innerHTML = "This amount is invalid. Please provide a valid amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is invalid. Please provide a valid amount", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is greater than the maximum limit allowed", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (typeof document.getElementById(pre + "MTNPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of " + currency + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountAboveMaxLimitOf",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": currency,
                    "data-translate-value-1": minPayAmount
                });
                gax.BankingDepositErrorEvent_EventTracking("This amount is below the minimum limit of " + currency + minPayAmount + ".", paymentAmount);
                canConfirmBankingEventPush = false;
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                account.InitMTNPayment(pre);
            } else {
                canConfirmBankingEventPush = false;
                return false;
            }
        } else {
            var errorDiv = document.getElementById(pre + "errorDiv");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAnAmount"
            });
            gax.BankingDepositErrorEvent_EventTracking("Please enter an amount", 0);
            canConfirmBankingEventPush = false;
            return false;
        }
        homePage.showOverlay();
        if (canConfirmBankingEventPush) {
            gax.BankingConfirm_EventTracking(paymentAmount);
        }
        return true;
    },
    expandDepositItem: function() {
        $("input[id$='Amount']").each(function(i, el) {
            if (el.valueAsNumber > 0) {
                var theForm = el.form;
                if (el.value != '') {
                    el.value = parseInt(el.value)
                }
                account.highlightValue(theForm, el.valueAsNumber);
            }
        });
    },
    highlightValue: function(theForm, currentvalue) {
        var items = $(theForm).parent().parent().parent().find(".btn-amounts");
        items.each(function(i, el) {
            $(el).removeClass("isAmountSelected");
        });
        items.each(function(i, el) {
            if (parseInt($(el).text()) === parseInt(currentvalue))
                $(el).addClass("isAmountSelected");
        });
    },
    setAmount: function(amount, prefix, selectedButton, method) {
        var objHeading = null;
        if ($(selectedButton).closest('.methodOption').length > 0 && $(selectedButton).closest('.methodOption').find('.methodTitle').length > 0) {
            objHeading = $(selectedButton).closest('.methodOption').find('.methodTitle');
            gax.BankingDepositAmount_EventTracking(amount, $(objHeading).text());
        } else if ($(selectedButton).closest('.panel').length > 0 && $(selectedButton).closest('.panel').find('.accordionHeader').length > 0 && $(selectedButton).closest('.panel').find('.accordionHeader').find('span').length > 1) {
            objHeading = $(selectedButton).closest('.panel').find('.accordionHeader').find('span').eq(1);
            gax.BankingDepositAmount_EventTracking(amount, $(objHeading).text());
        }
        var paymentAmount = document.getElementById(prefix + method);
        if (paymentAmount !== null) {
            paymentAmount.value = amount;
        }
        if (selectedButton !== null) {
            $(".isAmountSelected").removeClass("isAmountSelected");
            selectedButton.className += " isAmountSelected";
        }
    },
    ValidatePaymentSafaricom: function(prefix, minAmount, maxAmount) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(prefix + "errorDiv");
        var paymentAmount = document.getElementById(prefix + "SafaricomPaymentRequest_Amount").value;
        var clearFeedbackAfterTimeout = false;
        if (paymentAmount.length > 20) {
            feedbackDiv.innerHTML = "Invalid Amount Entered, Please try again.!";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmountTryAgain"
            });
            return false;
        }
        if (!paymentAmount.match(/^\d+$/)) {
            feedbackDiv.innerHTML = "This amount is invalid. Please provide a valid amount without decimals!";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmountDecimals"
            });
            gax.BankingDepositErrorEvent_EventTracking("This amount is invalid. Please provide a valid amount without decimals!", paymentAmount);
            canConfirmBankingEventPush = false;
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "MaxLimitAmountGreater"
            });
            return false;
        }
        if (minPayAmount > 0 && paymentAmount < minPayAmount) {
            feedbackDiv.innerHTML = "This amount is below the minimum limit of KSH" + minPayAmount + ".";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-Key": "AmountBelowMinLimitKSH",
                "data-translate-type": "generic-html",
                "data-translate-value-1": minPayAmount
            });
            return false;
        }
        if (maxPayoutAmount > 0 && Number(paymentAmount) > maxPayoutAmount) {
            console.log('error  3487956183794562893746589273465');
            return false;
        }
        var numericResult = parseInt(paymentAmount);
        var validationResult = true;
        if (numericResult > 0) {
            if (validationResult) {
                window.location.hash = '#' + prefix + "_payframeInfo";
                account.InitSafaricom(prefix);
            }
        } else {
            return false;
        }
        homePage.showOverlay();
        return true;
    },
    ValidateMobilePayment: function(prefix, minAmount, maxAmount, currencySymbol, controllerCallback) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 2;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById(prefix + "MMerror");
        var paymentAmount = document.getElementById(prefix + "_Amount").value;
        var clearFeedbackAfterTimeout = false;
        if (paymentAmount.length > 20) {
            feedbackDiv.innerHTML = "Invalid Amount Entered, Please try again.!";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "InvalidAmountTryAgain"
            });
            return false;
        }
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit allowed";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "GreaterAmount"
            });
            return false;
        }
        if (minPayAmount > 0 && paymentAmount < minPayAmount) {
            feedbackDiv.innerHTML = "This amount is below the minimum limit of " + currencySymbol + minPayAmount + ".";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "AmountBelowMinimumLimitOf",
                "data-translate-type": "generic-html",
                "data-translate-value-0": currencySymbol,
                "data-translate-value-1": minPayAmount
            });
            return false;
        }
        if (maxPayoutAmount > 0 && Number(paymentAmount) > maxPayoutAmount) {
            console.log('error  3487956183794562893746589273465');
            return false;
        }
        var numericResult = parseInt(paymentAmount);
        if (numericResult > 0) {
            window.location.hash = '#' + prefix + "_payframeInfo";
            account.InitPayment(prefix, controllerCallback);
        } else {
            return false;
        }
        homePage.showOverlay();
        gax.BankingPresetDepositAmount_EventTracking(paymentAmount);
        return true;
    },
    formatMoney: function(el) {
        el.value = Number(el.value).toFixed(0);
        account.highlightValue(el.form, el.value);
    },
    InitPaygate: function(pre) {
        if (document.body.contains(document.getElementById("frmPayDetails"))) {
            document.getElementById("frmPayDetails").remove();
        }
        if (document.body.contains(document.getElementById("PayGateFramed_" + pre))) {
            document.getElementById("PayGateFramed_" + pre).remove();
        }
        pat.post("/account/Init_Paygate?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "PaygateContainer")[0].innerHTML = data;
        }).done(function(result) {
            account.embedBankingResponseIframe();
            homePage.closeOverlay();
        });
    },
    InitPaystack: function(pre) {
        if (document.body.contains(document.getElementById("frmPayDetails"))) {
            document.getElementById("frmPayDetails").remove();
        }
        if (document.body.contains(document.getElementById("PayStackFramed_" + pre))) {
            document.getElementById("PayStackFramed_" + pre).remove();
        }
        pat.post("/account/Init_Paystack?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "PaystackContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitDPO: function(pre) {
        if (document.body.contains(document.getElementById("frmPayDetails"))) {
            document.getElementById("frmPayDetails").remove();
        }
        if (document.body.contains(document.getElementById("DPOFramed_" + pre))) {
            document.getElementById("DPOFramed_" + pre).remove();
        }
        pat.post("/account/Init_DPO?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "DPOContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitIPay: function(pre) {
        pat.post("/account/Init_ipay?", $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "IpayContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitMTN: function(pre) {
        pat.post("/account/Init_MTN?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "MTNContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitMTNPayment: function(pre) {
        pat.post("/account/Init_MTNPayment?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "MTNContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitMTNGhana: function(pre) {
        pat.post("/account/Init_ITC?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "MTNGhanaContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitAirtelZAmbia: function(pre) {
        pat.post("/account/Init_AirtelZambia?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "AirtelZambiaContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    InitSafaricom: function(pre) {
        pat.post("/account/Init_Safaricom?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "SafaricomContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    ToggleRemoveButton: function(e, sub) {
        if (typeof e !== 'undefined' && e !== null) {
            if (e.value !== "") {
                $('#' + sub + 'removeCardButton').removeClass('hidden');
                $('#SaveMyDetails').prop('checked', false);
                $('#NewDetails').prop('checked', false);
            } else {
                $('#' + sub + 'removeCardButton').addClass('hidden');
                $('#SaveMyDetails').prop('checked', true);
                $('#NewDetails').prop('checked', true);
            }
        } else {
            if ($('#' + sub + 'selSavedtoken') !== null && $('#' + sub + 'selSavedtoken').selectedIndex > 0) {
                $('#' + sub + 'removeCardButton').removeClass('hidden');
                $('#SaveMyDetails').prop('checked', true);
                $('#NewDetails').prop('checked', true);
            } else {
                $('#' + sub + 'removeCardButton').addClass('hidden');
                $('#SaveMyDetails').prop('checked', true);
                $('#NewDetails').prop('checked', true);
            }
        }
    },
    currentCard: null,
    currentCardHiddenKey: '',
    RemoveSelectedCardNew: function(e, confirmType, sub, paymentMethodModel) {
        if (typeof e !== 'undefined' && e !== null) {
            var cardKey = $(e).parents('.radio-inline').find('.cardSelect').attr('value');
            var cardNumber = $(e).parents('.radio-inline').find('.cardKey').text();
            var hiddenKey = $(e).parents('.radio-inline').attr('data-card-key');
            var displayMessages = "Are you sure you want to remove card ending in";
            pat.post("/account/confirmDelete", {
                model: {
                    CardNumber: cardNumber,
                    CardKey: encodeURIComponent(cardKey),
                    DisplayMessage: displayMessages,
                    ConfirmType: confirmType,
                    Sub: sub,
                    PaymentMethodName: paymentMethodModel
                }
            }).done(function(data) {
                $('#' + sub + 'confirmModal').on('hidden.bs.modal', function(event) {
                    event.stopImmediatePropagation();
                    event.stopPropagation();
                    return false;
                });
                $('#' + sub + 'confirmModalContent').html(data);
                $('#' + sub + 'confirmModal').modal('show');
                $('#' + sub + 'confirmModal [data-dismiss=modal]').on('click', function(event) {
                    $('#card-remove-confirmation-modal').parents('.modal').eq(0).modal('hide');
                    event.stopImmediatePropagation();
                    event.stopPropagation();
                })
                account.currentCardHiddenKey = hiddenKey;
                account.currentCard = $(e).parents('.radio-inline');
            });
        }
    },
    RemoveSelectedDebitCreditCard: function(e, confirmType, sub, paymentMethodModel) {
        if (typeof e !== 'undefined' && e !== null) {
            var cardKey = document.getElementById(sub + 'selSavedtoken').value;
            var cardNumber = document.getElementById(sub + 'selSavedtoken').options[document.getElementById(sub + 'selSavedtoken').selectedIndex].text;
            var hiddenKey = document.getElementById(sub + 'selSavedtoken').options[document.getElementById(sub + 'selSavedtoken').selectedIndex].getAttribute('data-card-key');
            var displayMessages = "Are you sure you want to remove card ending in";
            pat.post("/account/confirmDelete", {
                model: {
                    CardNumber: cardNumber,
                    CardKey: encodeURIComponent(cardKey),
                    DisplayMessage: displayMessages,
                    ConfirmType: confirmType,
                    Sub: sub,
                    PaymentMethodName: paymentMethodModel
                }
            }).done(function(data) {
                $('#' + sub + 'confirmModalContent').html(data);
                $('#' + sub + 'confirmModal').modal('show');
                homePage.setSession(hiddenKey, "remove", 100000);
            });
        }
    },
    RemoveSelectedCard: function(confirmType) {
        var cardKey = document.getElementById("selSavedtoken").value;
        var cardNumber = document.getElementById("selSavedtoken").options[document.getElementById("selSavedtoken").selectedIndex].text;
        var displayMessages = "Are you sure you want to remove card ending in "
        pat.post("/account/confirmDelete", {
            model: {
                CardNumber: cardNumber,
                CardKey: encodeURIComponent(cardKey),
                DisplayMessage: displayMessages,
                ConfirmType: confirmType
            }
        }).done(function(data) {
            $("#confirmModalContent").html(data);
            $("#confirmModal").modal('show');
        });
    },
    RemoveSavedPaymentToken: function(tokenIdentifier, sub, cardNumber, paymentMethodModel) {
        if (account.currentCard != null) {
            $(account.currentCard).remove();
        }
        if (account.currentCardHiddenKey != '') {
            homePage.setSession(account.currentCardHiddenKey, "remove", 100000);
        }
        if ($('.cardSelect:visible').length > 0) {
            $('.cardSelect:visible').eq(0).prop('checked', true)
        }
        pat.post('/Account/' + paymentMethodModel + 'RemoveSavedPaymenToken', {
            brandPaymentMethodId: sub,
            tokenIdentifier: tokenIdentifier
        }).done(function(data) {
            var message = "The card ending in " + cardNumber + " has been removed";
            language.translateAtRuntime(message, "ErrorMessages", {
                "data-translate-key": "CardDeletion",
                "data-translate-type": "generic-html",
                "data-translate-value-0": cardNumber
            });
            if (data.result === true) {
                pat.post("/account/MessageBox?message=" + message + "&header=Card Deletion").done(function(data) {
                    $('#' + sub + 'confirmModal').on('hidden.bs.modal', function(event) {
                        event.stopImmediatePropagation();
                        event.stopPropagation();
                        return false;
                    });
                    $('#' + sub + 'confirmModalContent').html(data);
                    $('#' + sub + 'confirmModal').modal('show');
                    $('#' + sub + 'confirmModal [data-dismiss=modal]').on('click', function(event) {
                        $(this).parents('.modal').eq(0).modal('hide');
                        event.stopImmediatePropagation();
                        event.stopPropagation();
                    })
                });
                var dd = document.getElementById('selSavedtoken');
                if (typeof sub !== 'undefined')
                    dd = document.getElementById(sub + 'selSavedtoken');
                for (var i = 0; i <= dd.length; i++) {
                    if (dd[i].value === tokenIdentifier) {
                        dd.removeChild(dd[i]);
                        if (dd.options.length > 1) {
                            dd.selectedIndex = 1;
                        } else {
                            dd.selectedIndex = 0;
                        }
                        if (sub.length === 0)
                            account.ToggleRemoveButton();
                        else
                            account.ToggleRemoveButton(dd, sub);
                    }
                }
            }
        });
    },
    RemoveAccountAttribute: function(groupId) {
        pat.post("/Account/DeleteAccountAttribute", {
            groupId: groupId
        }).done(function(data) {});
    },
    GetInputValue: function(minimumWithdrawalAmount, maximumWithdrawalAmount, remainingwithdrawalBalance) {
        var withdrawalAmount = $("#Amount").val();
        if (withdrawalAmount > maximumWithdrawalAmount) {
            document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit</p>";
            language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
            });
        } else if (withdrawalAmount < minimumWithdrawalAmount) {
            document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than withdrawal daily limit</p>";
            language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
            });
        } else if (withdrawalAmount > remainingwithdrawalBalance) {
            document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit</p>";
            language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
            });
        } else {
            document.getElementById("withdrawalLimit").innerHTML = "<p></p>";
        }
    },
    OnConfirmDeleteWithdrawAccount: function(confirmType) {
        var selectedBank = $("#Banks option:selected").text();
        var selectedAccountNumber = document.getElementById("bankAccountNumberdId").value;
        var selectedAccountNumberText = document.getElementById("bankAccountNumberdId").options[document.getElementById("bankAccountNumberdId").selectedIndex].text;
        var accountAttribute = document.getElementById("accountGroupId").value;
        var displayMessages = "Are you sure you want to delete the account ending in ";
        $("#accountGroupId > option").each(function() {
            var data = this.text;
            var value = data.split('|');
            var accountNumber = value[0];
            var bank = value[1];
            if (bank === selectedBank && accountNumber === selectedAccountNumber) {
                pat.post("/account/confirmDelete", {
                    model: {
                        CardNumber: selectedAccountNumberText,
                        CardKey: encodeURIComponent(accountAttribute),
                        DisplayMessage: displayMessages,
                        ConfirmType: confirmType,
                        Sub: accountNumber
                    }
                }).done(function(data) {
                    $("#confirmModalContent").html(data);
                    $("#confirmModal").modal('show');
                });
            }
        });
    },
    OnDeleteWithdrawAccount: function(accountAttribute, accountNumber, cardNumber) {
        account.RemoveAccountAttribute(accountAttribute);
        account.PrepopulateBankAccount();
        account.ResetListOfBanks();
        document.getElementById("bankAccountNumberdId").value = "";
        var message = "The account ending in " + cardNumber + " has been removed.";
        language.translateAtRuntime(message, "ErrorMessages", {
            "data-translate-key": "CardDeletion",
            "data-translate-type": "generic-html",
            "data-translate-value-0": cardNumber
        });
        $("#bankAccountNumberdId option[value=" + accountNumber + "]").remove();
        pat.post("/account/MessageBox?message=" + message + "&header=Account Deletion").done(function(data) {
            $('#confirmModalContent').html(data);
            $('#confirmModal').modal('show');
        });
    },
    GetBetslipDetail: function(betslipId, settlementStatus, smallView) {
        var id = '#Settled_' + betslipId;
        if (settlementStatus === 1) {
            var label = $(".stldBtn_" + betslipId);
            $(".betView").not(id).hide();
            $(".betDetailsBtn").not(label).html('Details');
        } else {
            id = '#Open_' + betslipId;
            label = $(".opnBtn_" + betslipId);
            $(".betView").not(id).hide();
            $(".betDetailsBtn").not(label).html('Details');
        }
        $(id).toggle();
        if (smallView) {
            if ($('.btnRoundArrow-' + betslipId).hasClass('glyphicon-triangle-bottom')) {
                $('.btnRoundDownArrow').removeClass('glyphicon-triangle-top').addClass('glyphicon-triangle-bottom');
                $('.btnRoundArrow-' + betslipId).addClass('glyphicon-triangle-top').removeClass('glyphicon-triangle-bottom');
            } else {
                $('.btnRoundArrow-' + betslipId).addClass('glyphicon-triangle-bottom').removeClass('glyphicon-triangle-top');
            }
        } else {
            if (($('.opnBtn_' + betslipId)).html() === "Details") {
                ($('.opnBtn_' + betslipId)).html('Close');
            } else {
                ($('.opnBtn_' + betslipId)).html('Details');
            }
            if (($('.stldBtn_' + betslipId)).html() === "Details") {
                ($('.stldBtn_' + betslipId)).html('Close');
            } else {
                ($('.stldBtn_' + betslipId)).html('Details');
            }
        }
    },
    SetSelectedWithdrawalType: function(cardlessOrEft) {
        document.getElementById('SelectedWithdrawalType').value = cardlessOrEft;
    },
    ValidatePaymentMTNZambia: function(pre, minAmount, maxAmount, currency) {
        var minPayAmount = minAmount;
        if (minPayAmount === 0)
            minPayAmount = 10;
        var maxPayoutAmount = maxAmount;
        var feedbackDiv = document.getElementById("MMerrorMTN");
        var paymentAmount = document.getElementById(pre + "MTNZambiaPaymentRequest_Amount").value;
        var clearFeedbackAfterTimeout = false;
        if (parseFloat(paymentAmount).toPrecision(21) > maxPayoutAmount) {
            feedbackDiv.innerHTML = "This amount is greater than the maximum limit of " + currency + maxPayoutAmount + ".";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanMinLimitOf",
                "data-translate-type": "generic-html",
                "data-translate-value-0": currency,
                "data-translate-value-1": maxPayoutAmount
            });
            return false;
        }
        if (typeof document.getElementById(pre + "MTNZambiaPaymentRequest_Amount") !== 'undefined') {
            if (minPayAmount > 0 && paymentAmount < minPayAmount) {
                feedbackDiv.innerHTML = "This amount is below the minimum limit of " + currency + minPayAmount + ".";
                language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                    "data-translate-key": "AmountGreaterThanLimitOf",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": currency,
                    "data-translate-value-1": maxPayoutAmount
                });
                return false;
            }
            var numericResult = parseInt(paymentAmount);
            if (numericResult > 0) {
                window.location.hash = '#' + pre + "_payframeInfo";
                this.InitMTNZambia(pre);
            } else {
                return false;
            }
        } else {
            var errorDiv = document.getElementById("MMerrorMTN");
            errorDiv.innerHTML = "Please enter an amount";
            language.translateAtRuntime(feedbackDiv, "ErrorMessages", {
                "data-translate-key": "PleaseEnterAmount"
            });
            return false;
        }
        homePage.showOverlay();
        return true;
    },
    InitPayment: function(pre, controllerCallback) {
        pat.post(controllerCallback, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            if ($('#' + pre + "PaymentContainerHidden").length > 0) {
                $('#' + pre + "PaymentContainerHidden")[0].innerHTML = data;
            } else {
                $('#' + pre + "PaymentContainer")[0].innerHTML = data;
            }
        }).done(function(result) {
            account.embedBankingResponseIframe();
            homePage.closeOverlay();
        });
    },
    InitMTNZambia: function(pre) {
        pat.post("/account/Init_MTNZambia?PaymentMethod=" + pre, $('#' + pre + "_paymentInit").serializeArray()).done(function(data) {
            $('#' + pre + "MTNZambiaContainer")[0].innerHTML = data;
        }).done(function(result) {
            if (document.getElementById("frmPayDetails") !== null) {
                document.getElementById("frmPayDetails").submit();
            }
            homePage.closeOverlay();
        });
    },
    roundToX: function(num, X) {
        return +(Math.round(num + "e+" + X) + "e-" + X);
    },
    toggleTrans: function(val) {
        $('.toggleBtn').css({
            'background-color': 'white',
            'color': 'black'
        }).removeClass('active');
        $('#' + val + 'Btn').css({
            'background-color': '#439539',
            'color': 'white'
        }).addClass('active');
        if (val === 'all') {
            $('.showMoreDiv').show();
            $('#CurrentPage').val(1);
        } else if (val === 'last100') {
            $('#filtertransaction-button').html("Select Transaction Type <span class='glyphicon glyphicon-menu-down fade-a-bit' style='position: relative; right: 0px; top: -2px; margin-top: 0px; margin-left: 10px;'></span>");
            $('.showMoreDiv').hide();
        }
    },
    toggleShowButton: function() {
        if ($('#allBtn').hasClass('active')) {
            $('.showMoreDiv').show();
        }
        if ($('#last100Btn').hasClass('active') && ($('.transactionSummaryBody').children().length >= 75 || $('.transactionSummaryBody').children().length === 100)) {
            $('.showMoreDiv').hide();
        }
    },
    transFilterChange: function() {
        $('.showMoreDiv').show();
        $('#CurrentPage').val(1);
    },
    staticBankingCarousel: function(parent, accountNo) {
        var settings = {
            dots: false,
            infinite: false,
            speed: 300,
            arrows: true,
            variableWidth: false,
            slidesToScroll: 1,
            respondTo: 'min',
            prevArrow: '<i class="fa fa-angle-left fa-3x" aria-hidden="true"></i>',
            nextArrow: '<i class="fa fa-angle-right fa-3x" aria-hidden="true"></i>',
            responsive: [{
                breakpoint: 2560,
                settings: {
                    slidesToShow: 6,
                }
            }, {
                breakpoint: 1920,
                settings: {
                    slidesToShow: 5,
                }
            }, {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                }
            }, {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3,
                }
            }, {
                breakpoint: 425,
                settings: {
                    slidesToShow: 1,
                }
            }]
        };
        $(parent).find('.cell_carousel').attr('style', 'display: flex !important');
        $(parent).find('.cell_carousel').not('.slick-initialized').slick(settings);
        var accNoFallback = $(parent).find('.accNo')
        if (accNoFallback.length > 0) {
            accNoFallback.text(accountNo);
        }
    },
    confirmLeave: async function(messageType, title, message) {
        Swal.fire({
            icon: 'warning',
            title: 'Confirm Leave',
            text: 'Are you sure you want to leave this page?',
            showCancelButton: true,
            confirmButtonText: 'Yes, I am sure!',
            cancelButtonText: "No, cancel it!"
        }).then(function(e) {
            if (e.isConfirmed) {
                account.depositPamentForm();
                closeDepositModal();
            }
        });
    },
    depositPamentForm: function() {
        $('#depositingModal').unbind('hide.bs.modal');
        $('.methodOption:visible').find('iframe').remove();
        $('.methodOption:visible').find('.EFTContainer').children().show();
        $('.PayInProgressHide').show();
        $('#paymentBackBtn').remove();
    },
    embedBankingResponseIframe: function() {
        if (document.getElementById("frmGMPayDetails") !== null) {
            var form = document.getElementById("frmGMPayDetails");
            if (window.location.hostname === "localhost") {
                var iframe = document.getElementById("noGMreferer");
                var iframeDoc = iframe.document;
                iframeDoc = iframeDoc == null ? iframe.contentDocument : iframeDoc;
                iframeDoc.body.innerHTML = form.outerHTML;
                iframeDoc.getElementById("frmGMPayDetails").submit();
                return;
            }
            $(form).submit();
        }
        if (document.getElementById("frmPayDetails") !== null) {
            if ($('#iframeForPaygate').length > 0) {
                $('#paygatetemp').appendTo($('body'));
                $('#paygatetemp').on('shown.bs.modal', function(e) {
                    $('#depositingModal').modal('hide')
                    if ($(window).width() <= 768) {
                        $('#paygatetemp').find('.modal-dialog').css('height', '100vh');
                        $('#paygatetemp').find('.modal-dialog').css('margin', '0px')
                        $('#paygatetemp').find('.modal-content').css('height', '100%')
                        $('#paygatetemp').find('.modal-body').css('height', '100%')
                        $('#paygatetemp').find('.modal-body').css('padding', '0px')
                        $('#paygatetemp').find('.modal-body').css('overflow-x', 'hidden');
                    } else {
                        $('#paygatetemp').find('.modal-body').css('height', '550px')
                        $('#paygatetemp').find('.modal-body').css('min-height', '550px')
                        $('#paygatetemp').find('.modal-body').css('min-height', '550px')
                        $('#paygatetemp').find('.modal-content').css('height', '550px')
                        $('#paygatetemp').find('.modal-body').css('overflow-x', 'hidden');
                    }
                })
                $('#paygatetemp').on('hidden.bs.modal', function(e) {
                    $('#depositingModal').modal('show')
                })
                $(`#paygatetemp`).modal('show')
                setTimeout(function() {
                    document.getElementById("frmPayDetails").target = '_parent';
                    document.getElementById("frmPayDetails").target = 'DPOiFrameTemp';
                    document.getElementById("frmPayDetails").submit();
                }, 1000)
            } else {
                document.getElementById("frmPayDetails").submit();
            }
        }
    },
    addMobileNumber: function() {
        homePage.showOverlay();
        var number = $('#AddAccountMobileNumber').val();
        var errorMessage = "Error";
        while (number.charAt(0) === '0') {
            number = number.substr(1);
        }
        var numberStartsWithBrandDialingCode = number.startsWith(BrandDialingCode);
        var isNumberCorrectLength = false;
        var mobileNumberRequiredLength = 9;
        if (Brand == "F8A8D16A-D619-4B49-AA8C-F21211403C92") {
            mobileNumberRequiredLength = 10;
        }
        if (numberStartsWithBrandDialingCode) {
            isNumberCorrectLength = false;
        } else {
            isNumberCorrectLength = number.length === mobileNumberRequiredLength;
            number = BrandDialingCode + number;
        }
        if (!isNumberCorrectLength) {
            errorMessage = "Please Enter a Valid Mobile Number";
            $('.account-numbers-message').text(errorMessage).fadeIn().removeClass('hide');
            homePage.closeOverlay();
            account.closeAlert();
            return;
        }
        if (number !== "") {
            $('.addnumber-error').addClass('hide');
            homePage.showOverlay();
            pat.post('/Account/AddAccountMobileNumber', {
                mobileNumber: number.trim()
            }).done(function(data) {
                if (data.Success) {
                    if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                        localStorage.setItem("IsPrimaryNumberUpdateAttempt", true);
                        var accountMobileNo = data.MobileNumbers.find(a => a.MobileNumber == number.trim());
                        var mobileNo = accountMobileNo.MobileNumber;
                        var accountMobileNoId = accountMobileNo.AccountMobileNumberId;
                        var templateHtml = document.getElementById('otp-container-popupTemplate').innerHTML;
                        templateHtml = templateHtml.split("%newMobileNumber%").join(mobileNo);
                        templateHtml = templateHtml.split("%newAccountMobileNumberId%").join(accountMobileNoId);
                        $('#genericModalHeader').html("Add a new number");
                        $('#genericMiddleContent').html(templateHtml);
                        $('#generic-modal').addClass("verify-number").modal({
                            backdrop: 'static',
                            keyboard: false
                        });
                        $('#genericConfirmBtns').hide();
                        $('.verify-number').find('.close-button').hide();
                        homePage.closeOverlay();
                    } else {
                        location.reload();
                    }
                } else {
                    $('.account-numbers-message').text(data.Message).fadeIn().removeClass('hide');
                    homePage.closeOverlay();
                }
                account.closeAlert();
            });
        } else {
            var addNumberError = $('.addnumber-error')[0];
            addNumberError.classList.remove('hide');
            addNumberError.textContent = errorMessage;
            homePage.closeOverlay();
            $('.account-numbers-message').fadeIn();
        }
    },
    deleteMobileNumber: function(accountMobileNumberId, removeFromDb) {
        homePage.showOverlay();
        pat.post('/Account/DeleteAccountMobileNumber', {
            accountMobileNumberId: accountMobileNumberId,
            removeFromDB: removeFromDb
        }).done(function(data) {
            console.log(data);
            if (data.Success) {
                if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                    localStorage.setItem("IsPrimaryNumberUpdateAttempt", false);
                    $('#generic-modal').css("display", "none");
                    window.location.href = '/Account/UpdateDetails'
                } else {
                    location.reload();
                }
            } else {
                homePage.closeOverlay();
            }
            account.closeAlert();
        });
    },
    makeMobileNumberPrimary: function(accountMobileNumberId) {
        homePage.showOverlay();
        pat.post('/Account/SetPrimaryAccountMobileNumber', {
            accountMobileNumberId: accountMobileNumberId
        }).done(function(data) {
            console.log(data);
            if (data.Success) {
                if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                    if ($('btnConfirmChangePrimaryNumber')) {
                        $("#generic-modal").css("display", "none");
                    }
                    location.reload();
                } else {
                    location.reload();
                }
            } else {
                homePage.closeOverlay();
            }
            account.closeAlert();
        });
    },
    showOtpPopup: function() {
        $('#genericModalHeader').html("Add a new number");
        $('#genericMiddleContent').html($('#otp-popup-content').html());
        $('#generic-modal').addClass("verify-number").modal({
            backdrop: 'static',
            keyboard: false
        });
        $('#genericConfirmBtns').hide();
        $('.verify-number').find('.close-button').hide();
    },
    showConfirmPrimaryNumberChangePopup: function(accountMobileNumberId, elemId) {
        var previousPrimaryNumber = $('div[class*="cbPrimary active"]').find('input')[0];
        if (elemId.id == previousPrimaryNumber.id) {
            account.CheckPrimaryNumberCheckbox(elemId.id);
            return;
        }
        $('.cbPrimary').each(function() {
            $(this).find('input').prop('checked', false);
        });
        account.CheckPrimaryNumberCheckbox(elemId.id);
        document.getElementById('btnConfirmChangePrimaryNumber').setAttribute("onclick", "account.CheckPrimaryNumberCheckbox('" + elemId.id + "'); account.makeMobileNumberPrimary('" + accountMobileNumberId + "');");
        document.getElementById('btnCancelChangePrimaryNumber').setAttribute("onclick", "account.CheckPrimaryNumberCheckbox('" + previousPrimaryNumber.id + "'); $('#generic-modal').removeClass('verify-number'); homePage.closeOverlay(); $('#generic-modal').modal('hide')");
        $('#genericModalHeader').html('New Primary Number');
        $('#genericMiddleContent').html($('#NewPrimaryNumber-popup-content').html());
        $('#generic-modal').addClass('verify-number').modal();
        if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
            $("#generic-modal").css("display", "block");
        }
        $('#genericConfirmBtns').hide();
        homePage.closeOverlay();
    },
    CheckPrimaryNumberCheckbox: function(elemId) {
        $('.cbPrimary').each(function() {
            document.getElementById($(this).find('input').attr('id')).checked = false;
        });
        document.getElementById(elemId).checked = true;
    },
    DisableDeLinkCheckbox: function(elemId) {
        var state = $('#' + elemId.id).is(":checked");
        if (state) {
            document.getElementById("Number_deLink").checked = true;
            document.getElementById("Number_deLink").disabled = false;
            document.getElementById("Number_deLink").setAttribute("checked", true);
        } else {
            document.getElementById("Number_deLink").checked = false;
            document.getElementById("Number_deLink").disabled = true;
            document.getElementById("Number_deLink").setAttribute("checked", false);
        }
    },
    verifyNumber: function(accountMobileNumberId) {
        var otpCode = $('[data-otp="' + accountMobileNumberId + '"]').val();
        if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
            otpCode = $('#genericMiddleContent [data-otp="' + accountMobileNumberId + '"]').val();
        }
        if (otpCode !== '') {
            var makeNumberPrimary = $('[data-amnid="' + accountMobileNumberId + '"]').is(':checked');
            var deLinkPrevious = $('[data-amnid="' + accountMobileNumberId + '-deLink' + '"]').is(':checked');
            if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                makeNumberPrimary = $('#genericMiddleContent [data-amnid="' + accountMobileNumberId + '"]').is(':checked');
                deLinkPrevious = $('#genericMiddleContent [data-amnid="' + accountMobileNumberId + '-deLink' + '"]').is(':checked');
            }
            homePage.showOverlay();
            pat.post('/Account/VerifyAccountNumber', {
                accountMobileNumberId: accountMobileNumberId,
                otpCode: otpCode,
                makePrimary: makeNumberPrimary,
                deLink: deLinkPrevious
            }).done(function(data) {
                if (data.Success) {
                    if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                        if (makeNumberPrimary) {
                            location.reload();
                        } else {
                            homePage.closeOverlay();
                            if ($('#accountNumberOTP')) $("#generic-modal").css("display", "none");
                            homePage.ShowAccountOptionsModal('/Account/UpdateDetails', 'accountOption_updatedetails', 'Update Details');
                        }
                    } else {
                        location.reload();
                    }
                } else {
                    $('.otp-messages').addClass('alert-danger').text(data.Message).fadeIn().removeClass('hide');
                    homePage.closeOverlay();
                    location.reload();
                }
                account.closeAlert();
            });
        } else {
            $('.otp-messages').addClass('alert-danger').text('Please enter the OTP number').fadeIn().removeClass('hide');
            account.closeAlert();
        }
    },
    reSendOtpCode: function(accountMobileNumberId, number) {
        homePage.showOverlay();
        pat.post('/Account/ReSendOtpCode', {
            accountMobileNumberId: accountMobileNumberId,
            mobileNumber: number
        }).done(function(data) {
            if (data.Success) {
                $('.otp-messages').removeClass('alert-danger').fadeIn().removeClass('hide').addClass('alert-success').text('OTP has been sent.');
            } else {
                $('.otp-messages').text(data.Message).fadeIn().removeClass('hide');
                homePage.closeOverlay();
            }
            homePage.closeOverlay();
            account.closeAlert();
        });
    },
    closeAlert: function() {
        setTimeout(function() {
            $('.account-numbers-message').fadeOut();
        }, 5000);
    },
    setExternalLoginModalCallbacks: function() {
        $("#loginForm").submit(function(event) {
            event.preventDefault();
            homePage.showOverlay();
            data = {
                mobileNumber: $('#menuMobileNumber').val(),
                password: $('#menuPassword').val(),
                dialingCode: $('#menuDialingCode').val()
            };
            var postUrl = "/Account/Login";
            if (redirectUrl != null && redirectUrl != "") {
                data.ReturnURL = redirectUrl;
            }
            pat.post(postUrl, {
                loginModel: data,
                origin: 'externalLogin'
            }).done(function(result) {
                handleLogin(result);
            }).fail(function(xhr) {
                console.error(xhr);
                homePage.closeOverlay();
            });
        });
    },
    verifyPHONE: function() {
        this.showSwiftEndPopup();
        account.pleaseWait();
        pat.post("/Account/SwiftEndVerification", {
            type: swiftEndVerificationType.PHONE_NUMBER,
            value: $('#MobileNumber_tmpl').val()
        }).done(function(result) {
            if (result !== null) {
                if (result.ResponseInfo.ResponseCode === "00") {
                    $('.please-wait, .verification-inputs, .swiftend-btns, #verification-error').hide();
                    account.swiftVerified(result);
                    console.log(result.ResponseData.DateOfBirth);
                } else {
                    $('#verification-error').text(result.ResponseInfo.Message).show();
                    $('.please-wait').hide();
                    $('.verification-inputs, .swiftend-btns, #btnVerifyNin, .NIN-section').show();
                }
            }
        }).fail(function(xhr) {
            console.error(xhr);
        });
    },
    verifyNIN: function() {
        account.pleaseWait();
        pat.post("/Account/SwiftEndVerification", {
            type: swiftEndVerificationType.NATIONAL_IDENTITY_NUMBER,
            value: $('#txtNIN').val()
        }).done(function(result) {
            if (result !== null) {
                if (result.ResponseInfo.ResponseCode === "00") {
                    $('.please-wait, .verification-inputs, .swiftend-btns, #verification-error').hide();
                    account.swiftVerified(result);
                } else {
                    $('#verification-error').text(result.ResponseInfo.Message).show();
                    $('.please-wait, .NIN-section, #btnVerifyNin').hide();
                    $('.verification-inputs, .swiftend-btns, #btnVerifyBvn, .BVN-section').show();
                }
            }
        }).fail(function(xhr) {
            console.error(xhr);
        });
    },
    verifyBVN: function() {
        account.pleaseWait();
        pat.post("/Account/SwiftEndVerification", {
            type: swiftEndVerificationType.BABK_VERIFICATION_NUMBER,
            value: $('#txtBVN').val()
        }).done(function(result) {
            if (result !== null) {
                if (result.ResponseInfo.ResponseCode === "00") {
                    $('.please-wait, .verification-inputs, .swiftend-btns, #verification-error').hide();
                    account.swiftVerified(result);
                } else {
                    $('#verification-error').text(result.ResponseInfo.Message).show();
                    $('.please-wait').hide();
                    $('#bvn-failed-message').show();
                }
            }
        }).fail(function(xhr) {
            console.error(xhr);
        });
    },
    showSwiftEndPopup: function() {
        $('#swiftend-modal').modal({
            backdrop: 'static',
            keyboard: false
        }, 'show');
    },
    swiftVerified: function(result) {
        $('#FirstName_tmpl').val(result.ResponseData.Firstname).trigger('change');
        $('#LastName_tmpl').val(result.ResponseData.Lastname).trigger('change');
        setTimeout(function() {
            $('#FirstName_tmpl, #LastName_tmpl').prop('readonly', true);
        }, 800);
        $('#DateOfBirth_tmpl').val(new Date(+(result.ResponseData.DateOfBirth.replace(/\D/g, ''))).toLocaleDateString('en-US')).trigger('change');
        account.selectStepHeaderByIndex('#regPills', 2);
        $('#swiftend-modal').modal('hide');
        $("#SignUpModal").modal('show');
    },
    pleaseWait: function() {
        $('.please-wait').show();
        $('.account-verified, .verification-inputs, .swiftend-btns, #verification-error').hide();
    },
    bankingChangeNumber: function() {
        if ($('#bConfirmAccountDetailsPopUp').length > 0) {
            account.ConfirmAccountDetailsPopUp();
            sideMenu.closeMenu();
        } else {
            document.location.href = '/Account/UpdateDetails#changeNumber'
        }
    },
    ConfirmAccountDetailsPopUp: function() {
        homePage.showOverlay();
        pat.get("/Account/ConfirmAccountDetails").done(function(data) {
            $("#confirmAccountDetailsPopUp").html(data);
            $('#confirmAccountDetailsPopUp').modal();
            homePage.closeOverlay();
        });
    },
    ConfirmAccountDetailsPost: function() {
        $("#caIdnumberError").text("");
        if (useInternalCaptchaForAccountDetailsPopUp != undefined) {
            if (useInternalCaptchaForAccountDetailsPopUp && !cadCaptchaValid) {
                resetData();
                homePage.closeOverlay();
            }
        }
        if (typeof cadCaptchaValid == 'undefined' || cadCaptchaValid) {
            homePage.showOverlay();
            pat.post("/Account/ConfirmAccountDetails", $("#confirmAccountDetails").serialize()).done(function(data) {
                if (data.Data)
                    if (accountOptionsPopUpEnabled && accountOptionUpdateDetailsEnabled) {
                        homePage.ShowAccountOptionsModal('/Account/UpdateDetails?modal=accountdetails', 'accountOption_updatedetails');
                        $("#confirmAccountDetailsPopUp").modal("hide");
                        $("#confirmAccountDetails").modal("hide");
                    } else {
                        window.location.href = '/Account/UpdateDetails';
                    }
                else {
                    $("#confirmAccountDetailsContainer").html(data)
                }
                homePage.closeOverlay();
            });
        }
        return false;
    },
    UpdateDetailsSubmitBtn: function() {
        var updateFormData = $("#updateDetailsForm").serialize();
        var amnClone = $('.account-number-change').html();
        var idTypeClone = $('#IDType_tmpl').html();
        pat.post("/Account/UpdateDetails", updateFormData).done(function(data) {
            if (data) {
                $('.accountOptionsBody').html(data);
                $('.account-number-change').html(amnClone);
                $('#IDType_tmpl').html(idTypeClone);
                $('userdetails-confirmation').show();
            }
        });
    },
    openPasswordResetView: function() {
        var formData = $("#ResetPassword").serialize();
        pat.post("/Account/ResetPassword", formData).done(function(data) {
            if (data) {
                $('.accountOptionsBody').html(data);
            }
        });
    },
    updateBalanceProgress: function() {
        pat.get("/Account/GetSessionBalances").done(function(data) {
            if (data !== null) {
                $('.sports-bonus-bar').val(data.SportsBonusProgress);
                $('.casino.bar').val(data.CasinoBonusProgress);
                if (typeof data.SportsBonuses ? .AwardedBonus !== "undefined" && data.SportsBonuses ? .AwardedBonus > 0) {
                    if (typeof data.SportsBonuses ? .IsProtected !== "undefined" && data.SportsBonuses.IsProtected) {
                        $('.IsProtectedLock').text('lock');
                        $('.sportsBonusProtectedMode').text('lock');
                    } else {
                        $('.IsProtectedLock').text('lock_open');
                        $('.sportsBonusProtectedMode').text('lock_open');
                    }
                } else {
                    $('.IsProtectedLock').text('');
                    $('.sportsBonusProtectedMode').text('');
                }
                if (removeElements) {
                    var text = '{ "message" : "Balance", "data" : { "cashBalance" : ' + (Math.floor(data.Balances.CashBalance * 100) / 100).toFixed(2) +
                        ', "freeBetBalance" : ' + (Math.floor(data.Balances.BonusBalance * 100) / 100).toFixed(2) +
                        ', "bonusBalance" : ' + (Math.floor(data.Balances.PlaythroughBalance * 100) / 100).toFixed(2) +
                        ', "sportBonusBalance" : ' + (Math.floor(data.Balances.SportBonusBalance * 100) / 100).toFixed(2) +
                        ', "bonusBalancePercentage" : ' + parseInt(data.CasinoBonusProgress) +
                        ', "sportBonusBalancePercentage" : ' + parseInt(data.SportsBonusProgress) +
                        ', "sportInactiveBonuses" : ' + (data.Balances.SportsBonusesCount > 0 ? (data.Balances.SportsBonusesCount - 1) : 0) +
                        ', "casinoInactiveBonuses" : ' + 0 +
                        ', "currencySymbol" : "' + currency + '" } }';
                    if (global.getCookie('isIosApp') === 'true') {
                        webkit.messageHandlers.PostData.postMessage(text);
                    } else {
                        window.Data.postData(text);
                    }
                }
            }
        });
    },
    requestOtpForReg: function(isResend = false) {
        homePage.showOverlay();
        var mobileNumber = $("#MobileNumber_tmpl").val();
        var password = $("#Password_tmpl").val();
        var errorMessage = "Error";
        var isOTPSuccessful = false;
        if (isResend = false) {
            isOTPSuccessful = true;
        } else isOTPSuccessful = false;
        var numberStartsWithBrandDialingCode = mobileNumber.startsWith(BrandDialingCode);
        var isNumberCorrectLength = false;
        var mobileNumberRequiredLength = 9;
        var passwordLength = false;
        var minPasswordRequiredLength = 5;
        if (minPasswordRequiredLength < 5) {
            passwordLength = false;
        } else {
            passwordLength = password.length >= minPasswordRequiredLength;
        }
        if (mobileNumber.charAt(0) === '0') {
            mobileNumber = mobileNumber.substr(1);
        }
        if (Brand == constId.BrandId_Nigeria.toLowerCase()) {
            mobileNumberRequiredLength = 10;
        }
        if (numberStartsWithBrandDialingCode) {
            isNumberCorrectLength = false;
        } else {
            isNumberCorrectLength = mobileNumber.length === mobileNumberRequiredLength;
            mobileNumber = BrandDialingCode + mobileNumber;
        }
        if (!isNumberCorrectLength || !passwordLength) {
            errorMessage = "Please Enter a Valid Mobile Number";
            homePage.closeOverlay();
            return;
        }
        $("#SignUpModal").css('display', 'none');
        pat.post('/Account/OtpRegistration', {
            MobileNumber: mobileNumber.trim(),
            IsOTPSuccessful: isOTPSuccessful
        }).done(function(data) {
            if (data !== null || data !== undefined) {
                $("#SignUpModal").modal('hide');
                $('.ng-otpRegbody').html(data);
                $('.ng-otpRegbody').modal('show');
            }
            homePage.closeOverlay();
        });
    },
    otpRegistrationSubmitBtn: function(isResend = false) {
        homePage.showOverlay();
        var mobileNumber = $("#MobileNumber_tmpl").val();
        var otpCode = $('#OTPVerificationCode').val();
        var brand = constId.BrandId_Nigeria.toLowerCase();
        var countryCode = $('#DialingCode').val();
        if (isResend) {
            isOTPSuccessful = true;
        } else isOTPSuccessful = false;
        pat.post("/Account/VerifyRegistrationOtp", {
            MobileNumber: mobileNumber.trim(),
            OTPVerificationCode: otpCode,
            CountryCode: countryCode,
            BrandId: brand,
            IsOTPSuccessful: isOTPSuccessful
        }).done(function(data) {
            if (data) {
                if (data.Success) {
                    if (swiftEndEnabled) {
                        account.verifyPHONE(mobileNumber.trim());
                    } else {
                        account.selectStepHeaderByIndex('#regPills', 2);
                        $("#SignUpModal").modal('show');
                    }
                    $('.ng-otpRegbody').modal('hide');
                    $('#bckBtn').hide();
                } else {
                    otpAttempt = data.OTPAttemptCount;
                    if (otpAttempt > otpRegistrationLimit) {
                        $('#supportDiv').show();
                        $('#timerDiv').hide();
                        $("#otpResponse").hide();
                    } else {
                        $('#supportDiv').hide();
                        $('#timerDiv').show();
                        $("#otpResponse").text(data.Message);
                    }
                }
            }
            homePage.closeOverlay();
        });
    },
    otpRegBackBtn: function() {
        homePage.showOverlay();
        $('.nav-pills > .active').prev('li').find('a').trigger('click');
        $("#step1-header,#nxtBtn").show();
        $("#step2-header").hide();
        $('.ng-otpRegbody').modal('hide');
        $('#SignUpModal').modal('show');
        homePage.closeOverlay();
    },
    selectStepHeaderByIndex: function(selector, index) {
        var target = document.querySelector(selector);
        for (var i = 0; i < target.children.length; i++) {
            if (i == index) {
                target.children[i].children[0].click()
            } else {
                target.children[i].children[0].classList.remove('active');
            }
        }
    },
    profileSetupToggleStep: function(_step) {
        $('.profile-step').hide();
        switch (_step) {
            case "1":
                $('#Step1').show();
                break;
            case "2":
                localStorage.setItem('profileSetup', '2');
                $('#Step2, .step-2-btn').show();
                $('#reg-progress').attr('style', 'width:60%');
                $('.step-1-btn').hide();
                $('#post-reg-title').text('Offer and Account Security');
                break;
            case "3":
                $('#Step3, #profile-completed-btns').show();
                $('.step-1-btn, .step-2-btn').hide();
                break;
        }
    },
    handlePostRegStep2: function(regType) {
        var chosenOffer = $('#ddlWelcomeOffer').val();
        if (chosenOffer === 'Select') {
            $('#lblOfferError').show();
        } else {
            if (chosenOffer === 'Sport' || chosenOffer === "Casino") {
                var chosen = chosenOffer + " welcome offer (you have 7 days to make a deposit and receive your bonus. Min deposit of R10 is required)";
                language.translateAtRuntime($('chosenOffer'), "ThankYouDialog", {
                    "data-translate-key": chosenOffer + "WelcomeOffer"
                });
                $('#chosenOffer').text(chosen);
            } else {
                $('#chosenOffer').text(chosenOffer);
            }
            var chosenQuestion = $('#ddlSecurityQuestion').val();
            if (chosenQuestion !== 'Select') {
                $('#chosenQuestion').text($('#ddlSecurityQuestion :selected').text());
                $('#chosenQuestionAnswer').text($('#SecurityQuestionAnswer').val());
                if ($('#SecurityQuestionAnswer').val() === "") {
                    $('#lblAnswerError').show();
                    return;
                } else {
                    $('#lblAnswerError').hide();
                }
            }
            $('#reg-progress').attr('style', 'width:100%');
            this.postRegSaveSelections(chosenOffer, chosenQuestion, $('#SecurityQuestionAnswer').val(), regType);
        }
    },
    postRegSaveSelections: function(selectedOffer, securityQuestionId, securityAnswer, regType) {
        homePage.showOverlay();
        pat.post('/Account/SavePostRegSelections', {
            selectedOffer,
            securityQuestionId,
            securityAnswer
        }).done(function(data) {
            homePage.closeOverlay();
            if (data.success) {
                if (regType !== "South African ID") {
                    account.handleCompletionStatus(false);
                    if (aDocApproved.toLowerCase() !== 'true') {
                        $('#verificationStatus').text('Pending');
                        $('#IdVerification').show();
                        $('#manual-verify').show();
                        $('#profile-completed-btns').hide();
                    } else {
                        $('#profile-completed-btns').show();
                    }
                } else {
                    var _nameVerified = localStorage.getItem('_nameVerified');
                    $('#lblOfferError').hide();
                    $('#profile-completed-btns').show();
                    account.handleCompletionStatus(true);
                    if (_nameVerified !== null && _nameVerified === "no-names") {
                        $('#verificationStatus').text('Pending');
                        $('#IdVerification').show();
                        $('#manual-verify').show();
                        $('#profile-completed-btns').hide();
                    }
                }
                localStorage.removeItem('_nameVerified');
                localStorage.removeItem('profileSetup');
                $('#post-reg-title').text('Successfully Registered');
                $('#Step2, .step-1-btn, .step-2-btn').hide();
                $('#Step3').show();
            } else {
                alert(data.error);
            }
        });
    },
    getVerifyNames: function(nameVerification) {
        var regStep = localStorage.getItem('profileSetup');
        if (regStep !== null && regStep !== '1')
            return;
        homePage.showOverlay();
        var idNumber = global.getCookie('regIdNumber');
        var selectedname = nameVerification ? $('.name.selected').find('.cpb-name').text() : "";
        pat.get('/Account/GetVerifyCPBNamesForAccount', {
            IdNumber: idNumber,
            selectedName: selectedname
        }).done(function(res) {
            homePage.closeOverlay();
            if (res !== null) {
                if (res.success) {
                    if (selectedname !== "") {
                        $('#verificationStatus').text(res.IsVerified ? 'Successful' : 'Unsuccessful');
                        $('#IdVerification').show();
                        aDocApproved = res.IsVerified.toString();
                        account.profileSetupToggleStep('2');
                        localStorage.setItem('_nameVerified', res.IsVerified);
                    } else {
                        if (res.names.length > 0) {
                            $('#name-selection').show();
                            for (var x = 0; x < res.names.length; x++) {
                                var _name = res.names[x].FirstNames + ' ' + res.names[x].Surname;
                                $('#listOfNames').append('<div class="name"><span class="material-icons-outlined cpb-name-status">radio_button_unchecked</span><span class="cpb-name">' + _name + '</span></div>');
                            }
                            initNameClick();
                            $('.step-1-btn').hide();
                        } else {
                            localStorage.setItem('_nameVerified', 'no-names');
                        }
                    }
                }
            }
        });
    },
    handleCompletionStatus: function(isSuccessful) {
        var _nameVerified = localStorage.getItem('_nameVerified');
        var allGood = _nameVerified !== null ? (isSuccessful && _nameVerified === "true") : isSuccessful;
        if (_nameVerified !== null) {
            $('#verificationStatus').text(_nameVerified === "true" ? 'Successful' : 'Unsuccessful');
            $('#IdVerification').show();
            if (_nameVerified !== "true") {
                $('#manual-verify').show();
                $('#profile-completed-btns').hide();
            }
        }
        allGood = (aDocApproved.toLowerCase() === 'true');
        $('#profileCompletionIcon').addClass(allGood ? 'check' : 'caution').text(allGood ? 'check_circle' : 'info');
        $('#profileCompletionText').text(allGood ? 'You have successfully completed your profile!' : 'You have partially completed your profile!');
    },
    handlePosRegContinuation: function(step) {
        pat.get('/Account/GetPostRegModal').done(function(res) {
            $('#PostReg').html(res);
            $('#RegistrationWelcomeSetupModal').modal();
            account.profileSetupToggleStep(step);
        });
    }
};
$(document).ready(function() {
    if (document.location.pathname.indexOf('PaymentResult') == -1 && document.location.pathname.indexOf('ThankYouDeposit') == -1 && document.location.pathname.indexOf('CompleteApplePayDeposit') == -1 && document.location.pathname.indexOf('PaymentReturn') == -1) localStorage.setItem('Current_location', document.location.pathname)
    var postRegStage = localStorage.getItem('profileSetup');
    if (postRegStage !== null && postRegStage !== 'completed') {
        if (isLoggedIn) {
            account.handlePosRegContinuation(postRegStage);
        }
    }
});
$("#Amount").keyup(function() {
    var withdrawalAmount = $("#Amount").val();
    if (document.getElementById("withdrawalLimit")) {
        document.getElementById("withdrawalLimit").innerHTML = "<p>" + withdrawalAmount + "</p>";
    }
});
$(document).ready(function() {
    if (constId.BrandId_Nigeria.toLowerCase()) {
        if (otpRegistrationNigeriaEnabled && !document.getElementById('TabHeader_3')) {
            var childLength = document.getElementById('regPills') !== null && document.getElementById('regPills') !== 'undefined' ? document.getElementById('regPills').children.length : 0;
            var li = document.createElement('li');
            li.id = 'TabHeader_3';
            li.innerHTML = `<a href="#TemplateGroup_3" data-toggle="tab">3</a>`;
            document.getElementById('regPills') !== null && document.getElementById('regPills') !== 'undefined' ? document.getElementById('regPills').children[childLength - 1].after(li) : 0;
        }
    }
    $('#AccountNumberId').keypress(function() {
        return this.value.length < 10;
    });
    $('#Amount').keypress(function() {
        return this.value.length < 20;
    });
    account.tableSort('date', 'transactionSummary', 'desc');
    $('#transSearch').keyup(function() {
        var txt = $(this).val();
        $('.srcError').hide();
        $('.betsHeader').hide();
        $('.betsHeader').each(function() {
            if ($(this).text().toUpperCase().indexOf(txt.toUpperCase()) !== -1) {
                $(this).show();
            }
        });
        if (!$('.betsHeader').is(":visible")) {
            $('.srcError').show();
        } else {
            $('.srcError').hide();
        }
        if ($('#transSearch').val()) {
            $("#searchclear").show();
            $('.showMoreDiv').hide();
        } else {
            $("#searchclear").hide();
        }
        if ($(this).val() === "" || $(this).val() === null) {
            $('.srcError').hide();
            account.toggleShowButton();
        }
    });
    $("#searchclear").click(function() {
        $("#transSearch").val('');
        $("#searchclear").hide();
        $('.betsHeader').show();
        $('.srcError').hide();
        account.toggleShowButton();
    });
});

function BuildMultipleAccountNumberVisual(newList, isPrimaryActive, m, isPrimaryChecked) {
    var actionHTML = m.IsVerified ? "<div class='actions'>" +
        "<div class='primary cbPrimary " + isPrimaryActive + " onclick='account.showConfirmPrimaryNumberChangePopup('" + m.AccountMobileNumberId + ", this)'>" +
        "<input type='checkbox' " + isPrimaryChecked + " id='Number_" + m.MobileNumber + "' name='SetAsPrimaryNumber' />" +
        "<label for='Number_" + m.MobileNumber + "'>Primary</label></div>" +
        "<div class='delete' onclick='account.deleteMobileNumber(" + m.AccountMobileNumberId + ")'>" +
        "<i class='fa fa-times'></i>Delete</div></div>" : "<div class='number-veification'>" +
        "<input type = 'text' name = 'accountNumberOTP' class='form-control' id = 'accountNumberOTP' />" +
        "<a href='javascript:void(0);'  class='btn btn-default' onclick='account.verifyNumber('" + m.AccountMobileNumberId + ")'>Verify</a>" +
        "<a href='javascript:void(0);' class='btn btn-default' onclick='account.reSendOtpCode('" + m.AccountMobileNumberId + "','" + m.MobileNumber + "')'>Re-Send</a></div>";
    newList += "<div class='item'>" + actionHTML + "<i class='fa fa-phone'></i>" + m.MobileNumber + "</div>";
    return newList;
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function confirmPasswordResetCallBack(result) {
    let resetPElement = result.includes('confirmResetErrorsDiv') ? document.getElementById('resetPasswordErrorsDiv') : document.getElementById('resetP');
    if (resetPElement !== null && typeof resetPElement !== "undefined") {
        resetPElement.innerHTML = result;
        document.getElementById('confirmResetPW').style.display = "none";
        let responseMessageElement = document.getElementById('responseMessage');
        if (responseMessageElement !== null && typeof responseMessageElement !== "undefined") {
            window.location = "/";
        }
    }
}

function recaptchaDataCallback() {
    $('#recaptchaResetError').addClass("hidden");
    passwordCaptchaValid = true;
}

function resetRecaptchaData() {
    $('#recaptchaResetError').removeClass("hidden");
    passwordCaptchaValid = false;
}

function onPasswordResetSubmit() {
    account.ConfirmResetPassword();
    grecaptcha.reset();
};
var fica = {
    toggleFICAUploadActive: function(fileTypeValid, fileSizeValid) {
        var filesSelected = false;
        var proofId = document.getElementById("proofIdFile").innerHTML;
        var proofIdMobile = document.getElementById("proofIdFileMobile").innerHTML;
        (proofId !== "" && proofId !== noFileSelectedText) ? filesSelected = true: "";
        (proofIdMobile !== "" && proofIdMobile !== noFileSelectedText) ? filesSelected = true: "";
        (filesSelected && proofIdMobileSize && fileTypeValid && fileSizeValid) ? (document.getElementById("fica-submission-button-mobile").disabled = false, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button-mobile").disabled = true, document.getElementById("fileuploads").className = "fica-subheading-disabled");
        (filesSelected && proofIdSize && fileTypeValid && fileSizeValid) ? (document.getElementById("fica-submission-button").disabled = false, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button").disabled = true, document.getElementById("fileuploads").className = "fica-subheading-disabled");
    },
    toggleDocumentUploadActive: function(fileTypeValid, fileSizeValid, btnSubmitElement, fileNameDiv) {
        var documentUpload = document.getElementById(fileNameDiv).innerHTML;
        var filesSelected = documentUpload !== "" && documentUpload !== noFileSelectedText;
        document.getElementById(btnSubmitElement).disabled = !(filesSelected && fileTypeValid && fileSizeValid);
    },
    setDisplay: function(elementId, text) {
        var filename = text.split("\\");
        text.length === 0 ? document.getElementById(elementId).innerHTML = noFileSelectedText : ((filename.length > 0 && filename.constructor === Array) ? (text = filename[filename.length - 1], document.getElementById(elementId).innerHTML = text) : "");
        fica.toggleFICAUploadActive();
    },
    closeOverlay: function() {
        jQuery(".loading").hide();
        jQuery("#modalloading").hide();
    },
    showFICAPopup: function() {
        fica.BindFileUploads();
        $("#fica-popup-modal").modal({
            backdrop: "static",
            keyboard: false
        });
    },
    VerifyFicaDetails: function() {
        pat.get("/Account/VerifyFicaDetails").done(function(data) {
            window.promptFICANotification = (data.toLowerCase() === 'true');
        });
    },
    showFICAStatusConfirmation: function() {
        if (window.promptFICANotification && !checkForLite()) {
            $('#modal-container-ficastatus-confirmation').modal().show();
        }
    },
    FicaUploadFormDisplay: function(isOperaMini) {
        if (!checkForLite()) {
            pat.post("/Account/SubmitFICADetails", null, {
                dataType: "html"
            }).done(function(data) {
                if (typeof isOperaMini !== 'undefined' && isOperaMini.toLowerCase() === 'true') {
                    $('#OperaminiModalHolderContent').html(data);
                    $('#OperaminiModalHolderContent').find('#fica-modal,#fica-popup-modal').attr('id', '').removeClass('modal');
                    $('html,body').removeClass('modal-open');
                    $('#main').css('margin-top', '0px');
                    $('#OperaminiModalHolder').show();
                    $('#ficaModal').hide();
                } else if (docUploadEnabled === 'True') {
                    location.href = '/DocumentUpload';
                } else {
                    $('#modal-container-ficastatus-upload').html(data).modal();
                }
            });
        } else {
            if (docUploadEnabled) {
                location.href = '/DocumentUpload';
            } else {
                ajax.post("/Account/SubmitFICADetails", null, ficaUploadFormDisplayCallBack)
            }
        }
    },
    DelayFicaNotification: function(isOperaMini) {
        if (typeof isOperaMini !== 'undefined' && isOperaMini.toLowerCase() === 'true') {
            window.location.href = '/';
        } else {
            pat.post("/Account/DelayFICANotification", null, {
                dataType: "html"
            }).done(function(data) {
                window.promptFICANotification = false;
            });
        }
    },
    ficaButtonBack: function() {
        $('#OperaminiModalHolder').hide();
        $('#ficaModal').show();
    },
    submitFicaDetailsAsync: function(isMobile, isOperaMini, event) {
        if (isOperaMini.toLowerCase() === "false") {
            var dataString = null;
            var divToUse;
            isMobile === "true" ? divToUse = $("#ficaProofMobile") : divToUse = $("#ficaProof");
            var action = divToUse.attr("action");
            homePage.showOverlay();
            var contentType = "";
            var processData = "";
            divToUse.attr("enctype") === "multipart/form-data" ? (dataString = new FormData(divToUse.get(0)), contentType = false, processData = false) : "";
            $.ajax({
                type: "POST",
                url: action,
                data: dataString,
                dataType: "html",
                contentType: contentType,
                processData: processData,
                success: function(result) {
                    isOperaMini.toLowerCase() === "true" ? window.location.href = "/Account/MyAccount" : ($(".modal-backdrop.fade.in").remove(), $("#fica-modal-upload-items").html(result), $("#fica-modal-upload-items").hide(), $("#modal-container-ficauploadresult").show(), fica.closeOverlay());
                },
                error: function(jqXhr, textStatus, errorThrown) {
                    $('#subsection').innerHTML = errorThrown;
                    $('#subsection').show();
                    homePage.closeOverlay();
                }
            });
        }
    },
    submitFicaDetailsKICAsync: function(isMobile, isOperaMini, formId) {
        var dataString = null;
        var divToUse;
        isMobile === "true" ? divToUse = $("#ficaProofMobile") : divToUse = $("#ficaProof");
        var action = "/account/SubmitFICADetailsKIC";
        homePage.showOverlay();
        var contentType = "";
        var processData = "";
        dataString = new FormData(divToUse.get(0)), contentType = false, processData = false;
        $.ajax({
            type: "POST",
            url: action,
            data: dataString,
            dataType: "html",
            contentType: contentType,
            processData: processData,
            success: function(data) {
                homePage.closeOverlay();
                if (isOperaMini.toLowerCase() === "true") {
                    window.location.reload();
                } else {
                    $('#confirmModalContent').html(data);
                    $('#confirmModal').modal('show');
                    $('#confirmModal').on('hidden.bs.modal', function(e) {
                        window.location.reload();
                    });
                }
            },
            error: function(jqXhr, textStatus, errorThrown) {
                $('#subsection').innerHTML = errorThrown;
                $('#subsection').show();
                homePage.closeOverlay();
            }
        });
    },
    showFicaComplete: function() {
        if (!checkForLite()) {
            $('#modal-container-ficauploadresult').modal();
            $('#modal-container-ficauploadresult').show();
            $('#modal-container-ficastatus-upload').hide();
        }
    },
    clearFICAValidationError: function(elementId) {
        if (elementId !== null) {
            var elemRemove = document.getElementById(elementId);
            if (elemRemove !== null) {
                elemRemove.remove();
            }
            var count = document.querySelectorAll("#fica-errors ul li").length;
            if (count === 0) {
                var elem = document.querySelector('#fica-errors div');
                elem.parentNode.removeChild(elem);
                document.querySelector("#fica-errors div").append("validation-summary-valid");
                var ficaErrors = document.querySelector("#fica-errors div");
                ficaErrors.classList.remove("validation-summary-errors");
                ficaErrors.classList.add("validation-summary-valid");
            }
        } else {
            document.querySelectorAll("#fica-errors ul>li").forEach(li => li.remove());
            var elemRem = document.querySelector("#fica-errors div");
            elemRem.classList.remove("validation-summary-errors");
            document.querySelector("#fica-errors div").classList.add("validation-summary-valid");
        }
    },
    setFICAValidationError: function(errorString, elementId) {
        var ficaErrorsDiv = document.querySelector("#fica-errors div");
        ficaErrorsDiv.classList.remove("validation-summary-valid");
        ficaErrorsDiv.classList.add("validation-summary-errors");
        let elemAdd = document.createElement('li');
        elemAdd.setAttribute("id", elementId);
        elemAdd.innerHTML = errorString;
        document.querySelector("#fica-errors ul").appendChild(elemAdd);
    },
    BindFileUploads: function() {
        var proofIdElement = document.getElementById("proofId");
        var proofIdMobileElement = document.getElementById("proofIdMobile");
        proofIdElement.addEventListener('change', function() {
            fica.validateUpload('proofId', this);
        });
        proofIdMobileElement.addEventListener('change', function() {
            fica.validateUpload('proofIdMobile', this);
        });
    },
    validateUpload: function(inputId, inutBox) {
        fica.validateDocument(inputId, inutBox, "proof-of-id-error", "The ID proof document is too large.", false);
    },
    validateDocument: function(inputId, inutBox, elementError, fileSizeErrorMsg, documentUploadEnabled, btnSubmitElement, fileNameDiv) {
        var fileTypeValid = true;
        var fileSizeValid = true;
        fica.clearFICAValidationError(elementError);
        fica.clearFICAValidationError("file-type-error");
        if (inutBox.files !== null && inutBox.files.length > 0) {
            let actualsize = inutBox.files[0].size / 1024;
            let minFileSize = minDocumentUploadFileSize == null || minDocumentUploadFileSize == undefined ? 0 : minDocumentUploadFileSize;
            if (!this.between(actualsize, minFileSize, 4096)) {
                fileSizeValid = false;
                fica.setFICAValidationError(fileSizeErrorMsg, elementError);
                if (!checkForLite()) {
                    language.translateAtRuntime($(elementError), "SubmitFICADetailsDialog", {
                        "data-translate-key": "IDProofdocumentTooLarge"
                    });
                }
            }
            var acceptedTypesArray = inutBox.getAttribute('accept').toLowerCase().split(",");
            var fileExtension = "." + inutBox.files[0].name.toLowerCase().split(".").pop();
            if (acceptedTypesArray !== null && !acceptedTypesArray.includes(fileExtension)) {
                fileTypeValid = false;
                fica.setFICAValidationError("The selected document format/file-type is not supported. Please see below for acceptable file types", "file-type-error");
                if (!checkForLite()) {
                    language.translateAtRuntime($("#file-type-error"), "SubmitFICADetailsDialog", {
                        "data-translate-key": "SelectedFormatNotSupported"
                    });
                }
            }
        }
        if (documentUploadEnabled)
            fica.toggleDocumentUploadActive(fileTypeValid, fileSizeValid, btnSubmitElement, fileNameDiv);
        else
            fica.toggleFICAUploadActive(fileTypeValid, fileSizeValid);
    },
    submitDocumentUploadDetailsAsync: function(formId, divToReplace = "uploadSection") {
        var form = document.getElementById(formId);
        var otpInput = document.getElementById("DocumentUploadLoggedOutModel_OTPVerificationCode");
        var cloneOtp = null;
        if (otpInput != undefined && otpInput != null) {
            cloneOtp = otpInput.cloneNode(true);
            form.appendChild(cloneOtp);
        }
        var mobileNumberInput = document.getElementById("DocumentUploadLoggedOutModel_MobileNumber");
        var cloneMobileNumber = null;
        if (mobileNumberInput != undefined && mobileNumberInput != null) {
            cloneMobileNumber = mobileNumberInput.cloneNode(true);
            form.appendChild(cloneMobileNumber);
        }
        if (form.getAttribute("enctype") === "multipart/form-data") {
            var xhr = new XMLHttpRequest();
            xhr.open(form.method, form.action, true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    if (xhr.responseText !== null && xhr.responseText.trim() !== "") {
                        if (!checkForLite()) {
                            homePage.closeOverlay();
                        }
                        document.getElementById(divToReplace).innerHTML = xhr.responseText;
                        if (xhr.responseText.includes("documentForceReload")) {
                            if (xhr.responseText.includes("documentFinChatResponseText") || xhr.responseText.includes("documentResponseText")) {
                                setTimeout(function() {
                                    fica.SwitchToViewStatusOnUploadSuccess();
                                }, 4000);
                            } else {
                                location.reload();
                            }
                        }
                    }
                }
            };
            xhr.send(new FormData(form));
        }
        if (mobileNumberInput != undefined && mobileNumberInput != null) {
            cloneMobileNumber.remove();
        }
        if (otpInput != undefined && otpInput != null) {
            cloneOtp.remove();
        }
    },
    SwitchToViewStatusOnUploadSuccess: function() {
        if (document.getElementById("uploadSectionTab").classList.contains("active")) {
            document.getElementById("statusSectionTab").classList.add("active");
            document.getElementById("uploadSectionTab").classList.remove("active");
            document.getElementById("uploadSection").classList.remove("active");
            document.getElementById("statusSection").classList.add("active");
            document.getElementById("statusSection").classList.add("in");
            document.getElementById("uploadSection").classList.remove("in");
            fica.getDocumentsInfoForAccount(1);
        } else {
            document.getElementById("uploadSectionTab").classList.add("active");
            document.getElementById("statusSectionTab").classList.remove("active");
            document.getElementById("uploadSection").classList.add("active");
            document.getElementById("statusSection").classList.add("hidden");
            document.getElementById("statusSection").classList.remove("in");
            document.getElementById("uploadSection").classList.add("in");
            document.getElementsByClassName('documentStatus')[0].style.display = 'none';
            if (document.getElementById("documentResponseText") !== null) {
                document.getElementById("documentResponseText").classList.add("hidden");
            }
        }
    },
    reloadUploadSection: function() {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        $.get("/DocumentUpload/GetUploadSectionView", function(data) {
            if (!checkForLite()) {
                homePage.closeOverlay();
            } else {
                fica.toggleSectionTabs(false);
            }
            document.getElementById("uploadSection").innerHTML = data;
        });
    },
    BindFileUpload: function(element, fileSizeErrorMsg, btnSubmitElement, fileNameDiv) {
        if (element !== null && typeof element !== "undefined") {
            fica.setFileNameDisplay(fileNameDiv, element.value);
            fica.validateDocument(element.id, element, "proof-of-document-error", fileSizeErrorMsg, true, btnSubmitElement, fileNameDiv);
        }
    },
    setFileNameDisplay: function(elementId, text) {
        var filename = text.split("\\");
        if (text.length === 0) {
            document.getElementById(elementId).innerHTML = noFileSelectedText;
        } else if (filename.length > 0 && filename.constructor === Array) {
            text = filename[filename.length - 1];
            document.getElementById(elementId).innerHTML = text;
        }
        if (document.getElementById("documentResponseText") !== null) {
            document.getElementById("documentResponseText").classList.add("hidden");
        }
    },
    getDocumentsInfoForAccount: function(pageNo = 1) {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        ajax.get("/DocumentUpload/GetDocumentsInfoForAccount", {
            pageNo: pageNo
        }, function(result) {
            if (!checkForLite()) {
                homePage.closeOverlay();
            } else {
                fica.toggleSectionTabs(false);
            }
            document.getElementById("statusSection").innerHTML = result;
            var currentPage = document.getElementById("CurrentPage") !== null ? parseInt(document.getElementById("CurrentPage").value) : null;
            var pageSize = document.getElementById("PageSize") !== null ? parseInt(document.getElementById("PageSize").value) : 0;
            var recordTotal = document.getElementById("RecordTotal") !== null ? parseInt(document.getElementById("RecordTotal").value) : 0;
            if (recordTotal > pageSize) {
                document.getElementById("showMoreDiv").classList.remove("hidden");
            } else {
                document.getElementById("showMoreDiv").classList.add("hidden");
            }
            if (currentPage !== null) {
                document.getElementById("showPrevious").disabled = currentPage == 1;
                account.isShowMoreVisible(currentPage, pageSize, recordTotal);
            }
        }, true);
    },
    toggleSectionTabs: function(isUploadTab) {
        if (isUploadTab) {
            document.getElementById('btnStatusToggle').classList.remove("active");
            document.getElementById('btnUploadToggle').classList.add("active");
            document.getElementById('uploadSection').classList.remove("hidden");
            document.getElementById('statusSection').classList.add("hidden");
        } else {
            document.getElementById('btnUploadToggle').classList.remove("active");
            document.getElementById('btnStatusToggle').classList.add("active");
            document.getElementById('uploadSection').classList.add("hidden");
            document.getElementById('statusSection').classList.remove("hidden");
        }
    },
    viewDocumentFile: function(documentId) {
        if (!checkForLite()) {
            homePage.showOverlay();
        }
        ajax.get("/DocumentUpload/GetDocumentFile", {
            documentId: documentId
        }, function(result) {
            if (!checkForLite()) {
                $('#document-file-modal').html(result);
                $('#document-file-modal').modal();
                homePage.closeOverlay();
            }
        }, true);
    },
    getNextPage: function() {
        var current = parseInt(document.getElementById('CurrentPage').value);
        current++;
        document.getElementById('CurrentPage').value = current;
        this.getDocumentsInfoForAccount(current);
    },
    getPreviousPage: function() {
        var current = parseInt(document.getElementById('CurrentPage').value);
        current--;
        document.getElementById('CurrentPage').value = current < 1 ? 1 : current;
        this.getDocumentsInfoForAccount(current);
    },
    showFicaModalContainer: function() {
        $('#modal-container-ficastatus-confirmation').modal().show();
        sideMenu.closeMenu();
    },
    between: function(value, min, max) {
        return value >= min && value <= max;
    }
};

function ficaUploadFormDisplayCallBack(result) {
    document.getElementById("ficaStatusDiv").outerHTML = result;
    fica.BindFileUploads();
}

function requestOTP(isResend = false) {
    homePage.showOverlay();
    var mobileNumber = $("#DocumentUploadLoggedOutModel_MobileNumber").val();
    var isOTPSuccessful = false;
    if (isResend) {
        isOTPSuccessful = true;
    }
    while (mobileNumber.charAt(0) === '0') {
        mobileNumber = mobileNumber.substr(1);
    }
    var numberStartsWithBrandDialingCode = mobileNumber.startsWith(BrandDialingCode);
    var isNumberCorrectLength = false;
    var mobileNumberRequiredLength = 9;
    if (Brand == "F8A8D16A-D619-4B49-AA8C-F21211403C92") {
        mobileNumberRequiredLength = 10;
    }
    if (numberStartsWithBrandDialingCode) {
        isNumberCorrectLength = false;
    } else {
        isNumberCorrectLength = mobileNumber.length === mobileNumberRequiredLength;
        mobileNumber = BrandDialingCode + mobileNumber;
    }
    if (!isNumberCorrectLength) {
        errorMessage = "Please Enter a Valid Mobile Number";
        $("#docUploadErrors").text(errorMessage);
        homePage.closeOverlay();
        return;
    } else {
        $("#docUploadErrors").text("");
    }
    pat.post('/DocumentUpload/_RequestLoggedOutDocumentUpload', {
        mobileNumber: mobileNumber,
        isOTPSuccessful: isOTPSuccessful
    }).done(function(data) {
        $("#myOTP").html(data);
        if (data.includes("successfulOtp")) {
            document.getElementById("btnRequestOtp").style.display = 'none';
        }
        homePage.closeOverlay();
    });
};
var SelectedTransactionTypeSourceId = '00000000-0000-0000-0000-000000000000';
var AdminSecret = undefined;
var useInternalCaptchaForAccountDetailsPopUp = undefined;
var noFileSelectedText = "No file selected.";
var proofIdSize = true;
var proofResidenceSize = true;
var proofIdMobileSize = true;
var fileTypeValid = false;
var proofResidenceMobileSize = true;
window.promptFICANotification = false;
CASHOUTBETS = [];
CASHOUTBETS_INITIALIZED = false;
CASHOUT_MARGIN = 0.9;
MIN_CASHOUT_LIMIT = 0.2;
MAX_CASHOUT_LIMIT = 0.8;
var constId = {};
constId.emptyGuid = '00000000-0000-0000-0000-000000000000';
constId.feedDataType_LIP = '00000000-0000-0000-da7a-000000580003';
constId.feedDataType_Prematch = '00000000-0000-0000-da7a-000000580001';
constId.feedDataType_LiveOutrights = '00000000-0000-0000-da7a-000000580008';
constId.BrandIdZA = 'BD66EBE1-080B-4455-9094-BF0464D4ADBF';
constId.soccerId = '00000000-0000-0000-DA7A-000000550001';
constId.BetYourWay = '00000000-0000-0000-da7a-000000550072';
constId.FormulaOne = '00000000-0000-0000-da7a-000000550100';
constId.Golf = '00000000-0000-0000-da7a-000000550007';
constId.MotorSport = '00000000-0000-0000-da7a-000000550009';
constId.esportId = '00000000-0000-0000-da7a-000000550064';
constId.Trending = '00000000-0000-0000-da7a-000000550101';
constId.Accumulators = '00000000-0000-0000-da7a-000000550102';
constId.BuildABet = '00000000-0000-0000-da7a-000000710003';
constId.ResultingStatus_NotResulted = 0;
constId.ResultingStatus_Win = 1;
constId.ResultingStatus_Loss = 2;
constId.ResultingStatus_Void = 3;
constId.ResultingStatus_EarlySettlement = 6;
constId.ResultingStatus_ManualResultingRequired = 7;
constId.ResultingStatus_EarlyCashout = 9;
constId.ResultingStatus_WinWithDeadHeatFactor = 10;
constId.LiveOutrightSports = [constId.Golf.toLowerCase(), constId.MotorSport.toLowerCase(), constId.FormulaOne.toLowerCase()];
window.promptForCompleteProfile = false;
constId.OutcomeDisplaySorting_Default = 0;
constId.OutcomeDisplaySorting_Title = 1;
constId.OutcomeDisplaySorting_TitleDesc = 2;
constId.OutcomeDisplaySorting_PriceDecimal = 3;
constId.OutcomeDisplaySorting_PriceDecimalDesc = 4;
constId.OutcomeDisplaySorting_SBV = 5;
constId.OutcomeDisplaySorting_SBVDesc = 6;
constId.OutcomeDisplaySorting_FeedId = 7;
constId.OutcomeDisplaySorting_FeedIdDesc = 8;
var swiftEndVerificationType = {};
swiftEndVerificationType.PHONE_NUMBER = "Phone Number";
swiftEndVerificationType.NATIONAL_IDENTITY_NUMBER = "National Identity Number";
swiftEndVerificationType.BABK_VERIFICATION_NUMBER = "Bank Verification Number";
constId.BrandId_Nigeria = "F8A8D16A-D619-4B49-AA8C-F21211403C92";
var global = {
    setCookie: function(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue.replace(/"/g, "'") + ";" + expires + ";path=/";
    },
    setCookieWithAllSubDomain: function(cname, cvalue, exdays) {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue.replace(/"/g, "'") + ";" + expires + ";path=/; hostOnly=false; domain=" + `.${window.location.host.toString()}`;
    },
    getCookie: function(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(";");
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) === " ") {
                c = c.substring(1);
            }
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length).replace(/'/g, '"');
            }
        }
        return "";
    },
    eraseCookie: function(name) {
        global.setCookie(name, "", -1);
    },
    isMobile: function() {
        var viewportWidth = $(window).width();
        var isMobileScreen = viewportWidth > 768 ? false : true;
        return isMobileScreen;
    },
    PostAppMessage: function(messageJsonString) {
        if (removeElements) {
            if (this.getCookie('isIosApp') === 'true') {
                webkit.messageHandlers.PostData.postMessage(messageJsonString);
            } else {
                window.Data.postData(messageJsonString);
            }
        }
    }
};
var TaxCalculation = {};
TaxCalculation.Winnings = 2;
TaxCalculation.Payout = 3;
var EmailValidator = {
    validateEmail: function() {
        var currentValue = document.querySelector('.email-input').value;
        if (currentValue !== "" && !/(.+)@(.+){2,}\.(.+){3,}/.test(currentValue)) {
            return false;
        } else {
            return true;
        }
    }
}

function syntaxHighlightForJson(json) {
    if (typeof json != 'string') {
        json = JSON.stringify(json, undefined, 2);
    }
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
};
! function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = t || self).Sweetalert2 = e()
}(this, function() {
    "use strict";

    function r(t) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }

    function a(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function o(t, e) {
        for (var n = 0; n < e.length; n++) {
            var o = e[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(t, o.key, o)
        }
    }

    function c(t, e, n) {
        return e && o(t.prototype, e), n && o(t, n), t
    }

    function s() {
        return (s = Object.assign || function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = arguments[e];
                for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o])
            }
            return t
        }).apply(this, arguments)
    }

    function u(t) {
        return (u = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
            return t.__proto__ || Object.getPrototypeOf(t)
        })(t)
    }

    function l(t, e) {
        return (l = Object.setPrototypeOf || function(t, e) {
            return t.__proto__ = e, t
        })(t, e)
    }

    function d() {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
            return Date.prototype.toString.call(Reflect.construct(Date, [], function() {})), !0
        } catch (t) {
            return !1
        }
    }

    function i(t, e, n) {
        return (i = d() ? Reflect.construct : function(t, e, n) {
            var o = [null];
            o.push.apply(o, e);
            var i = new(Function.bind.apply(t, o));
            return n && l(i, n.prototype), i
        }).apply(null, arguments)
    }

    function p(t, e) {
        return !e || "object" != typeof e && "function" != typeof e ? function(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t
        }(t) : e
    }

    function f(t, e, n) {
        return (f = "undefined" != typeof Reflect && Reflect.get ? Reflect.get : function(t, e, n) {
            var o = function(t, e) {
                for (; !Object.prototype.hasOwnProperty.call(t, e) && null !== (t = u(t)););
                return t
            }(t, e);
            if (o) {
                var i = Object.getOwnPropertyDescriptor(o, e);
                return i.get ? i.get.call(n) : i.value
            }
        })(t, e, n || t)
    }

    function m(e) {
        return Object.keys(e).map(function(t) {
            return e[t]
        })
    }

    function h(t) {
        return Array.prototype.slice.call(t)
    }

    function g(t, e) {
        var n;
        n = '"'.concat(t, '" is deprecated and will be removed in the next major release. Please use "').concat(e, '" instead.'), -1 === z.indexOf(n) && (z.push(n), _(n))
    }

    function v(t) {
        return t && "function" == typeof t.toPromise
    }

    function b(t) {
        return v(t) ? t.toPromise() : Promise.resolve(t)
    }

    function y(t) {
        return t && Promise.resolve(t) === t
    }

    function w(t) {
        return t instanceof Element || "object" === r(e = t) && e.jquery;
        var e
    }

    function t(t) {
        var e = {};
        for (var n in t) e[t[n]] = "swal2-" + t[n];
        return e
    }

    function C(t) {
        var e = Q();
        return e ? e.querySelector(t) : null
    }

    function e(t) {
        return C(".".concat(t))
    }

    function n() {
        var t = $();
        return h(t.querySelectorAll(".".concat(Y.icon)))
    }

    function k() {
        var t = n().filter(function(t) {
            return vt(t)
        });
        return t.length ? t[0] : null
    }

    function x() {
        return e(Y.title)
    }

    function P() {
        return e(Y.content)
    }

    function A() {
        return e(Y.image)
    }

    function B() {
        return e(Y["progress-steps"])
    }

    function S() {
        return e(Y["validation-message"])
    }

    function E() {
        return C(".".concat(Y.actions, " .").concat(Y.confirm))
    }

    function O() {
        return C(".".concat(Y.actions, " .").concat(Y.cancel))
    }

    function T() {
        return e(Y.actions)
    }

    function L() {
        return e(Y.header)
    }

    function j() {
        return e(Y.footer)
    }

    function q() {
        return e(Y["timer-progress-bar"])
    }

    function I() {
        return e(Y.close)
    }

    function V() {
        var t = h($().querySelectorAll('[tabindex]:not([tabindex="-1"]):not([tabindex="0"])')).sort(function(t, e) {
                return t = parseInt(t.getAttribute("tabindex")), (e = parseInt(e.getAttribute("tabindex"))) < t ? 1 : t < e ? -1 : 0
            }),
            e = h($().querySelectorAll('\n  a[href],\n  area[href],\n  input:not([disabled]),\n  select:not([disabled]),\n  textarea:not([disabled]),\n  button:not([disabled]),\n  iframe,\n  object,\n  embed,\n  [tabindex="0"],\n  [contenteditable],\n  audio[controls],\n  video[controls],\n  summary\n')).filter(function(t) {
                return "-1" !== t.getAttribute("tabindex")
            });
        return function(t) {
            for (var e = [], n = 0; n < t.length; n++) - 1 === e.indexOf(t[n]) && e.push(t[n]);
            return e
        }(t.concat(e)).filter(function(t) {
            return vt(t)
        })
    }

    function M() {
        return !J() && !document.body.classList.contains(Y["no-backdrop"])
    }

    function R() {
        return $().hasAttribute("data-loading")
    }

    function H(e, t) {
        var n;
        e.textContent = "", t && (n = (new DOMParser).parseFromString(t, "text/html"), h(n.querySelector("head").childNodes).forEach(function(t) {
            e.appendChild(t)
        }), h(n.querySelector("body").childNodes).forEach(function(t) {
            e.appendChild(t)
        }))
    }

    function D(t, e) {
        if (e) {
            for (var n = e.split(/\s+/), o = 0; o < n.length; o++)
                if (!t.classList.contains(n[o])) return;
            return 1
        }
    }

    function N(t, e, n) {
        var o, i;
        if (i = e, h((o = t).classList).forEach(function(t) {
                -1 === m(Y).indexOf(t) && -1 === m(Z).indexOf(t) && -1 === m(i.showClass).indexOf(t) && o.classList.remove(t)
            }), e.customClass && e.customClass[n]) {
            if ("string" != typeof e.customClass[n] && !e.customClass[n].forEach) return _("Invalid type of customClass.".concat(n, '! Expected string or iterable object, got "').concat(r(e.customClass[n]), '"'));
            mt(t, e.customClass[n])
        }
    }
    var U = "SweetAlert2:",
        _ = function(t) {
            console.warn("".concat(U, " ").concat(t))
        },
        F = function(t) {
            console.error("".concat(U, " ").concat(t))
        },
        z = [],
        W = function(t) {
            return "function" == typeof t ? t() : t
        },
        K = Object.freeze({
            cancel: "cancel",
            backdrop: "backdrop",
            close: "close",
            esc: "esc",
            timer: "timer"
        }),
        Y = t(["container", "shown", "height-auto", "iosfix", "popup", "modal", "no-backdrop", "no-transition", "toast", "toast-shown", "toast-column", "show", "hide", "close", "title", "header", "content", "html-container", "actions", "confirm", "cancel", "footer", "icon", "icon-content", "image", "input", "file", "range", "select", "radio", "checkbox", "label", "textarea", "inputerror", "validation-message", "progress-steps", "active-progress-step", "progress-step", "progress-step-line", "loading", "styled", "top", "top-start", "top-end", "top-left", "top-right", "center", "center-start", "center-end", "center-left", "center-right", "bottom", "bottom-start", "bottom-end", "bottom-left", "bottom-right", "grow-row", "grow-column", "grow-fullscreen", "rtl", "timer-progress-bar", "timer-progress-bar-container", "scrollbar-measure", "icon-success", "icon-warning", "icon-info", "icon-question", "icon-error"]),
        Z = t(["success", "warning", "info", "question", "error"]),
        Q = function() {
            return document.body.querySelector(".".concat(Y.container))
        },
        $ = function() {
            return e(Y.popup)
        },
        J = function() {
            return document.body.classList.contains(Y["toast-shown"])
        },
        X = {
            previousBodyPadding: null
        };

    function G(t, e) {
        if (!e) return null;
        switch (e) {
            case "select":
            case "textarea":
            case "file":
                return gt(t, Y[e]);
            case "checkbox":
                return t.querySelector(".".concat(Y.checkbox, " input"));
            case "radio":
                return t.querySelector(".".concat(Y.radio, " input:checked")) || t.querySelector(".".concat(Y.radio, " input:first-child"));
            case "range":
                return t.querySelector(".".concat(Y.range, " input"));
            default:
                return gt(t, Y.input)
        }
    }

    function tt(t) {
        var e;
        t.focus(), "file" !== t.type && (e = t.value, t.value = "", t.value = e)
    }

    function et(t, e, n) {
        t && e && ("string" == typeof e && (e = e.split(/\s+/).filter(Boolean)), e.forEach(function(e) {
            t.forEach ? t.forEach(function(t) {
                n ? t.classList.add(e) : t.classList.remove(e)
            }) : n ? t.classList.add(e) : t.classList.remove(e)
        }))
    }

    function nt(t, e, n) {
        n || 0 === parseInt(n) ? t.style[e] = "number" == typeof n ? "".concat(n, "px") : n : t.style.removeProperty(e)
    }

    function ot(t, e) {
        var n = 1 < arguments.length && void 0 !== e ? e : "flex";
        t.style.opacity = "", t.style.display = n
    }

    function it(t) {
        t.style.opacity = "", t.style.display = "none"
    }

    function rt(t, e, n) {
        e ? ot(t, n) : it(t)
    }

    function at(t) {
        return !!(t.scrollHeight > t.clientHeight)
    }

    function ct(t) {
        var e = window.getComputedStyle(t),
            n = parseFloat(e.getPropertyValue("animation-duration") || "0"),
            o = parseFloat(e.getPropertyValue("transition-duration") || "0");
        return 0 < n || 0 < o
    }

    function st(t, e) {
        var n = 1 < arguments.length && void 0 !== e && e,
            o = q();
        vt(o) && (n && (o.style.transition = "none", o.style.width = "100%"), setTimeout(function() {
            o.style.transition = "width ".concat(t / 1e3, "s linear"), o.style.width = "0%"
        }, 10))
    }

    function ut() {
        return "undefined" == typeof window || "undefined" == typeof document
    }

    function lt(t) {
        sn.isVisible() && ft !== t.target.value && sn.resetValidationMessage(), ft = t.target.value
    }

    function dt(t, e) {
        t instanceof HTMLElement ? e.appendChild(t) : "object" === r(t) ? wt(t, e) : t && H(e, t)
    }

    function pt(t, e) {
        var n = T(),
            o = E(),
            i = O();
        e.showConfirmButton || e.showCancelButton || it(n), N(n, e, "actions"), xt(o, "confirm", e), xt(i, "cancel", e), e.buttonsStyling ? function(t, e, n) {
            mt([t, e], Y.styled), n.confirmButtonColor && (t.style.backgroundColor = n.confirmButtonColor);
            n.cancelButtonColor && (e.style.backgroundColor = n.cancelButtonColor); {
                var o;
                R() || (o = window.getComputedStyle(t).getPropertyValue("background-color"), t.style.borderLeftColor = o, t.style.borderRightColor = o)
            }
        }(o, i, e) : (ht([o, i], Y.styled), o.style.backgroundColor = o.style.borderLeftColor = o.style.borderRightColor = "", i.style.backgroundColor = i.style.borderLeftColor = i.style.borderRightColor = ""), e.reverseButtons && o.parentNode.insertBefore(i, o)
    }
    var ft, mt = function(t, e) {
            et(t, e, !0)
        },
        ht = function(t, e) {
            et(t, e, !1)
        },
        gt = function(t, e) {
            for (var n = 0; n < t.childNodes.length; n++)
                if (D(t.childNodes[n], e)) return t.childNodes[n]
        },
        vt = function(t) {
            return !(!t || !(t.offsetWidth || t.offsetHeight || t.getClientRects().length))
        },
        bt = '\n <div aria-labelledby="'.concat(Y.title, '" aria-describedby="').concat(Y.content, '" class="').concat(Y.popup, '" tabindex="-1">\n   <div class="').concat(Y.header, '">\n     <ul class="').concat(Y["progress-steps"], '"></ul>\n     <div class="').concat(Y.icon, " ").concat(Z.error, '"></div>\n     <div class="').concat(Y.icon, " ").concat(Z.question, '"></div>\n     <div class="').concat(Y.icon, " ").concat(Z.warning, '"></div>\n     <div class="').concat(Y.icon, " ").concat(Z.info, '"></div>\n     <div class="').concat(Y.icon, " ").concat(Z.success, '"></div>\n     <img class="').concat(Y.image, '" />\n     <h2 class="').concat(Y.title, '" id="').concat(Y.title, '"></h2>\n     <button type="button" class="').concat(Y.close, '"></button>\n   </div>\n   <div class="').concat(Y.content, '">\n     <div id="').concat(Y.content, '" class="').concat(Y["html-container"], '"></div>\n     <input class="').concat(Y.input, '" />\n     <input type="file" class="').concat(Y.file, '" />\n     <div class="').concat(Y.range, '">\n       <input type="range" />\n       <output></output>\n     </div>\n     <select class="').concat(Y.select, '"></select>\n     <div class="').concat(Y.radio, '"></div>\n     <label for="').concat(Y.checkbox, '" class="').concat(Y.checkbox, '">\n       <input type="checkbox" />\n       <span class="').concat(Y.label, '"></span>\n     </label>\n     <textarea class="').concat(Y.textarea, '"></textarea>\n     <div class="').concat(Y["validation-message"], '" id="').concat(Y["validation-message"], '"></div>\n   </div>\n   <div class="').concat(Y.actions, '">\n     <button type="button" class="').concat(Y.confirm, '">OK</button>\n     <button type="button" class="').concat(Y.cancel, '">Cancel</button>\n   </div>\n   <div class="').concat(Y.footer, '"></div>\n   <div class="').concat(Y["timer-progress-bar-container"], '">\n     <div class="').concat(Y["timer-progress-bar"], '"></div>\n   </div>\n </div>\n').replace(/(^|\n)\s*/g, ""),
        yt = function(t) {
            var e, n, o, i, r, a, c, s, u, l, d, p, f, m, h, g = !!(e = Q()) && (e.parentNode.removeChild(e), ht([document.documentElement, document.body], [Y["no-backdrop"], Y["toast-shown"], Y["has-column"]]), !0);
            ut() ? F("SweetAlert2 requires document to initialize") : ((n = document.createElement("div")).className = Y.container, g && mt(n, Y["no-transition"]), H(n, bt), (o = "string" == typeof(i = t.target) ? document.querySelector(i) : i).appendChild(n), r = t, (a = $()).setAttribute("role", r.toast ? "alert" : "dialog"), a.setAttribute("aria-live", r.toast ? "polite" : "assertive"), r.toast || a.setAttribute("aria-modal", "true"), c = o, "rtl" === window.getComputedStyle(c).direction && mt(Q(), Y.rtl), s = P(), u = gt(s, Y.input), l = gt(s, Y.file), d = s.querySelector(".".concat(Y.range, " input")), p = s.querySelector(".".concat(Y.range, " output")), f = gt(s, Y.select), m = s.querySelector(".".concat(Y.checkbox, " input")), h = gt(s, Y.textarea), u.oninput = lt, l.onchange = lt, f.onchange = lt, m.onchange = lt, h.oninput = lt, d.oninput = function(t) {
                lt(t), p.value = d.value
            }, d.onchange = function(t) {
                lt(t), d.nextSibling.value = d.value
            })
        },
        wt = function(t, e) {
            t.jquery ? Ct(e, t) : H(e, t.toString())
        },
        Ct = function(t, e) {
            if (t.textContent = "", 0 in e)
                for (var n = 0; n in e; n++) t.appendChild(e[n].cloneNode(!0));
            else t.appendChild(e.cloneNode(!0))
        },
        kt = function() {
            if (ut()) return !1;
            var t = document.createElement("div"),
                e = {
                    WebkitAnimation: "webkitAnimationEnd",
                    OAnimation: "oAnimationEnd oanimationend",
                    animation: "animationend"
                };
            for (var n in e)
                if (Object.prototype.hasOwnProperty.call(e, n) && void 0 !== t.style[n]) return e[n];
            return !1
        }();

    function xt(t, e, n) {
        var o;
        rt(t, n["show".concat((o = e).charAt(0).toUpperCase() + o.slice(1), "Button")], "inline-block"), H(t, n["".concat(e, "ButtonText")]), t.setAttribute("aria-label", n["".concat(e, "ButtonAriaLabel")]), t.className = Y[e], N(t, n, "".concat(e, "Button")), mt(t, n["".concat(e, "ButtonClass")])
    }

    function Pt(t, e) {
        var n, o, i, r, a, c, s, u, l = Q();
        l && (n = l, "string" == typeof(o = e.backdrop) ? n.style.background = o : o || mt([document.documentElement, document.body], Y["no-backdrop"]), !e.backdrop && e.allowOutsideClick && _('"allowOutsideClick" parameter requires `backdrop` parameter to be set to `true`'), i = l, (r = e.position) in Y ? mt(i, Y[r]) : (_('The "position" parameter is not valid, defaulting to "center"'), mt(i, Y.center)), a = l, !(c = e.grow) || "string" != typeof c || (s = "grow-".concat(c)) in Y && mt(a, Y[s]), N(l, e, "container"), (u = document.body.getAttribute("data-swal2-queue-step")) && (l.setAttribute("data-queue-step", u), document.body.removeAttribute("data-swal2-queue-step")))
    }

    function At(t, e) {
        t.placeholder && !e.inputPlaceholder || (t.placeholder = e.inputPlaceholder)
    }
    var Bt = {
            promise: new WeakMap,
            innerParams: new WeakMap,
            domCache: new WeakMap
        },
        St = ["input", "file", "range", "select", "radio", "checkbox", "textarea"],
        Et = function(t) {
            if (!jt[t.input]) return F('Unexpected type of input! Expected "text", "email", "password", "number", "tel", "select", "radio", "checkbox", "textarea", "file" or "url", got "'.concat(t.input, '"'));
            var e = Lt(t.input),
                n = jt[t.input](e, t);
            ot(n), setTimeout(function() {
                tt(n)
            })
        },
        Ot = function(t, e) {
            var n = G(P(), t);
            if (n)
                for (var o in ! function(t) {
                        for (var e = 0; e < t.attributes.length; e++) {
                            var n = t.attributes[e].name; - 1 === ["type", "value", "style"].indexOf(n) && t.removeAttribute(n)
                        }
                    }(n), e) "range" === t && "placeholder" === o || n.setAttribute(o, e[o])
        },
        Tt = function(t) {
            var e = Lt(t.input);
            t.customClass && mt(e, t.customClass.input)
        },
        Lt = function(t) {
            var e = Y[t] ? Y[t] : Y.input;
            return gt(P(), e)
        },
        jt = {};
    jt.text = jt.email = jt.password = jt.number = jt.tel = jt.url = function(t, e) {
        return "string" == typeof e.inputValue || "number" == typeof e.inputValue ? t.value = e.inputValue : y(e.inputValue) || _('Unexpected type of inputValue! Expected "string", "number" or "Promise", got "'.concat(r(e.inputValue), '"')), At(t, e), t.type = e.input, t
    }, jt.file = function(t, e) {
        return At(t, e), t
    }, jt.range = function(t, e) {
        var n = t.querySelector("input"),
            o = t.querySelector("output");
        return n.value = e.inputValue, n.type = e.input, o.value = e.inputValue, t
    }, jt.select = function(t, e) {
        var n;
        return t.textContent = "", e.inputPlaceholder && (n = document.createElement("option"), H(n, e.inputPlaceholder), n.value = "", n.disabled = !0, n.selected = !0, t.appendChild(n)), t
    }, jt.radio = function(t) {
        return t.textContent = "", t
    }, jt.checkbox = function(t, e) {
        var n = G(P(), "checkbox");
        n.value = 1, n.id = Y.checkbox, n.checked = Boolean(e.inputValue);
        var o = t.querySelector("span");
        return H(o, e.inputPlaceholder), t
    }, jt.textarea = function(e, t) {
        var n, o;
        return e.value = t.inputValue, At(e, t), "MutationObserver" in window && (n = parseInt(window.getComputedStyle($()).width), o = parseInt(window.getComputedStyle($()).paddingLeft) + parseInt(window.getComputedStyle($()).paddingRight), new MutationObserver(function() {
            var t = e.offsetWidth + o;
            $().style.width = n < t ? "".concat(t, "px") : null
        }).observe(e, {
            attributes: !0,
            attributeFilter: ["style"]
        })), e
    };

    function qt(t, e) {
        var n, o, i, r, a, c = P().querySelector("#".concat(Y.content));
        e.html ? (dt(e.html, c), ot(c, "block")) : e.text ? (c.textContent = e.text, ot(c, "block")) : it(c), n = t, o = e, i = P(), r = Bt.innerParams.get(n), a = !r || o.input !== r.input, St.forEach(function(t) {
            var e = Y[t],
                n = gt(i, e);
            Ot(t, o.inputAttributes), n.className = e, a && it(n)
        }), o.input && (a && Et(o), Tt(o)), N(P(), e, "content")
    }

    function It() {
        return Q() && Q().getAttribute("data-queue-step")
    }

    function Vt(t, s) {
        var u = B();
        if (!s.progressSteps || 0 === s.progressSteps.length) return it(u), 0;
        ot(u), u.textContent = "";
        var l = parseInt(void 0 === s.currentProgressStep ? It() : s.currentProgressStep);
        l >= s.progressSteps.length && _("Invalid currentProgressStep parameter, it should be less than progressSteps.length (currentProgressStep like JS arrays starts from 0)"), s.progressSteps.forEach(function(t, e) {
            var n, o, i, r, a, c = (n = t, o = document.createElement("li"), mt(o, Y["progress-step"]), H(o, n), o);
            u.appendChild(c), e === l && mt(c, Y["active-progress-step"]), e !== s.progressSteps.length - 1 && (r = s, a = document.createElement("li"), mt(a, Y["progress-step-line"]), r.progressStepsDistance && (a.style.width = r.progressStepsDistance), i = a, u.appendChild(i))
        })
    }

    function Mt(t, e) {
        var n, o, i, r, a, c, s, u, l = L();
        N(l, e, "header"), Vt(0, e), n = t, o = e, (r = Bt.innerParams.get(n)) && o.icon === r.icon && k() ? N(k(), o, "icon") : (Dt(), o.icon && (-1 !== Object.keys(Z).indexOf(o.icon) ? (i = C(".".concat(Y.icon, ".").concat(Z[o.icon])), ot(i), Ut(i, o), Nt(), N(i, o, "icon"), mt(i, o.showClass.icon)) : F('Unknown icon! Expected "success", "error", "warning", "info" or "question", got "'.concat(o.icon, '"')))),
            function(t) {
                var e = A();
                if (!t.imageUrl) return it(e);
                ot(e, ""), e.setAttribute("src", t.imageUrl), e.setAttribute("alt", t.imageAlt), nt(e, "width", t.imageWidth), nt(e, "height", t.imageHeight), e.className = Y.image, N(e, t, "image")
            }(e), a = e, c = x(), rt(c, a.title || a.titleText), a.title && dt(a.title, c), a.titleText && (c.innerText = a.titleText), N(c, a, "title"), s = e, u = I(), H(u, s.closeButtonHtml), N(u, s, "closeButton"), rt(u, s.showCloseButton), u.setAttribute("aria-label", s.closeButtonAriaLabel)
    }

    function Rt(t, e) {
        var n, o, i, r;
        n = e, o = $(), nt(o, "width", n.width), nt(o, "padding", n.padding), n.background && (o.style.background = n.background), zt(o, n), Pt(0, e), Mt(t, e), qt(t, e), pt(0, e), i = e, r = j(), rt(r, i.footer), i.footer && dt(i.footer, r), N(r, i, "footer"), "function" == typeof e.onRender && e.onRender($())
    }

    function Ht() {
        return E() && E().click()
    }
    var Dt = function() {
            for (var t = n(), e = 0; e < t.length; e++) it(t[e])
        },
        Nt = function() {
            for (var t = $(), e = window.getComputedStyle(t).getPropertyValue("background-color"), n = t.querySelectorAll("[class^=swal2-success-circular-line], .swal2-success-fix"), o = 0; o < n.length; o++) n[o].style.backgroundColor = e
        },
        Ut = function(t, e) {
            t.textContent = "", e.iconHtml ? H(t, _t(e.iconHtml)) : "success" === e.icon ? H(t, '\n      <div class="swal2-success-circular-line-left"></div>\n      <span class="swal2-success-line-tip"></span> <span class="swal2-success-line-long"></span>\n      <div class="swal2-success-ring"></div> <div class="swal2-success-fix"></div>\n      <div class="swal2-success-circular-line-right"></div>\n    ') : "error" === e.icon ? H(t, '\n      <span class="swal2-x-mark">\n        <span class="swal2-x-mark-line-left"></span>\n        <span class="swal2-x-mark-line-right"></span>\n      </span>\n    ') : H(t, _t({
                question: "?",
                warning: "!",
                info: "i"
            }[e.icon]))
        },
        _t = function(t) {
            return '<div class="'.concat(Y["icon-content"], '">').concat(t, "</div>")
        },
        Ft = [],
        zt = function(t, e) {
            t.className = "".concat(Y.popup, " ").concat(vt(t) ? e.showClass.popup : ""), e.toast ? (mt([document.documentElement, document.body], Y["toast-shown"]), mt(t, Y.toast)) : mt(t, Y.modal), N(t, e, "popup"), "string" == typeof e.customClass && mt(t, e.customClass), e.icon && mt(t, Y["icon-".concat(e.icon)])
        };

    function Wt() {
        var t = $();
        t || sn.fire(), t = $();
        var e = T(),
            n = E();
        ot(e), ot(n, "inline-block"), mt([t, e], Y.loading), n.disabled = !0, t.setAttribute("data-loading", !0), t.setAttribute("aria-busy", !0), t.focus()
    }

    function Kt() {
        return new Promise(function(t) {
            var e = window.scrollX,
                n = window.scrollY;
            Xt.restoreFocusTimeout = setTimeout(function() {
                Xt.previousActiveElement && Xt.previousActiveElement.focus ? (Xt.previousActiveElement.focus(), Xt.previousActiveElement = null) : document.body && document.body.focus(), t()
            }, 100), void 0 !== e && void 0 !== n && window.scrollTo(e, n)
        })
    }

    function Yt() {
        if (Xt.timeout) return function() {
            var t = q(),
                e = parseInt(window.getComputedStyle(t).width);
            t.style.removeProperty("transition"), t.style.width = "100%";
            var n = parseInt(window.getComputedStyle(t).width),
                o = parseInt(e / n * 100);
            t.style.removeProperty("transition"), t.style.width = "".concat(o, "%")
        }(), Xt.timeout.stop()
    }

    function Zt() {
        if (Xt.timeout) {
            var t = Xt.timeout.start();
            return st(t), t
        }
    }

    function Qt(t) {
        return Object.prototype.hasOwnProperty.call(Gt, t)
    }

    function $t(t) {
        return ee[t]
    }

    function Jt(t) {
        for (var e in t) Qt(i = e) || _('Unknown parameter "'.concat(i, '"')), t.toast && (o = e, -1 !== ne.indexOf(o) && _('The parameter "'.concat(o, '" is incompatible with toasts'))), $t(n = e) && g(n, $t(n));
        var n, o, i
    }
    var Xt = {},
        Gt = {
            title: "",
            titleText: "",
            text: "",
            html: "",
            footer: "",
            icon: void 0,
            iconHtml: void 0,
            toast: !1,
            animation: !0,
            showClass: {
                popup: "swal2-show",
                backdrop: "swal2-backdrop-show",
                icon: "swal2-icon-show"
            },
            hideClass: {
                popup: "swal2-hide",
                backdrop: "swal2-backdrop-hide",
                icon: "swal2-icon-hide"
            },
            customClass: void 0,
            target: "body",
            backdrop: !0,
            heightAuto: !0,
            allowOutsideClick: !0,
            allowEscapeKey: !0,
            allowEnterKey: !0,
            stopKeydownPropagation: !0,
            keydownListenerCapture: !1,
            showConfirmButton: !0,
            showCancelButton: !1,
            preConfirm: void 0,
            confirmButtonText: "OK",
            confirmButtonAriaLabel: "",
            confirmButtonColor: void 0,
            cancelButtonText: "Cancel",
            cancelButtonAriaLabel: "",
            cancelButtonColor: void 0,
            buttonsStyling: !0,
            reverseButtons: !1,
            focusConfirm: !0,
            focusCancel: !1,
            showCloseButton: !1,
            closeButtonHtml: "&times;",
            closeButtonAriaLabel: "Close this dialog",
            showLoaderOnConfirm: !1,
            imageUrl: void 0,
            imageWidth: void 0,
            imageHeight: void 0,
            imageAlt: "",
            timer: void 0,
            timerProgressBar: !1,
            width: void 0,
            padding: void 0,
            background: void 0,
            input: void 0,
            inputPlaceholder: "",
            inputValue: "",
            inputOptions: {},
            inputAutoTrim: !0,
            inputAttributes: {},
            inputValidator: void 0,
            validationMessage: void 0,
            grow: !1,
            position: "center",
            progressSteps: [],
            currentProgressStep: void 0,
            progressStepsDistance: void 0,
            onBeforeOpen: void 0,
            onOpen: void 0,
            onRender: void 0,
            onClose: void 0,
            onAfterClose: void 0,
            onDestroy: void 0,
            scrollbarPadding: !0
        },
        te = ["allowEscapeKey", "allowOutsideClick", "buttonsStyling", "cancelButtonAriaLabel", "cancelButtonColor", "cancelButtonText", "closeButtonAriaLabel", "closeButtonHtml", "confirmButtonAriaLabel", "confirmButtonColor", "confirmButtonText", "currentProgressStep", "customClass", "footer", "hideClass", "html", "icon", "imageAlt", "imageHeight", "imageUrl", "imageWidth", "onAfterClose", "onClose", "onDestroy", "progressSteps", "reverseButtons", "showCancelButton", "showCloseButton", "showConfirmButton", "text", "title", "titleText"],
        ee = {
            animation: 'showClass" and "hideClass'
        },
        ne = ["allowOutsideClick", "allowEnterKey", "backdrop", "focusConfirm", "focusCancel", "heightAuto", "keydownListenerCapture"],
        oe = Object.freeze({
            isValidParameter: Qt,
            isUpdatableParameter: function(t) {
                return -1 !== te.indexOf(t)
            },
            isDeprecatedParameter: $t,
            argsToParams: function(o) {
                var i = {};
                return "object" !== r(o[0]) || w(o[0]) ? ["title", "html", "icon"].forEach(function(t, e) {
                    var n = o[e];
                    "string" == typeof n || w(n) ? i[t] = n : void 0 !== n && F("Unexpected type of ".concat(t, '! Expected "string" or "Element", got ').concat(r(n)))
                }) : s(i, o[0]), i
            },
            isVisible: function() {
                return vt($())
            },
            clickConfirm: Ht,
            clickCancel: function() {
                return O() && O().click()
            },
            getContainer: Q,
            getPopup: $,
            getTitle: x,
            getContent: P,
            getHtmlContainer: function() {
                return e(Y["html-container"])
            },
            getImage: A,
            getIcon: k,
            getIcons: n,
            getCloseButton: I,
            getActions: T,
            getConfirmButton: E,
            getCancelButton: O,
            getHeader: L,
            getFooter: j,
            getTimerProgressBar: q,
            getFocusableElements: V,
            getValidationMessage: S,
            isLoading: R,
            fire: function() {
                for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                return i(this, e)
            },
            mixin: function(r) {
                return function(t) {
                    ! function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && l(t, e)
                    }(i, t);
                    var n, o, e = (n = i, o = d(), function() {
                        var t, e = u(n);
                        return p(this, o ? (t = u(this).constructor, Reflect.construct(e, arguments, t)) : e.apply(this, arguments))
                    });

                    function i() {
                        return a(this, i), e.apply(this, arguments)
                    }
                    return c(i, [{
                        key: "_main",
                        value: function(t) {
                            return f(u(i.prototype), "_main", this).call(this, s({}, r, t))
                        }
                    }]), i
                }(this)
            },
            queue: function(t) {
                var r = this;
                Ft = t;

                function a(t, e) {
                    Ft = [], t(e)
                }
                var c = [];
                return new Promise(function(i) {
                    ! function e(n, o) {
                        n < Ft.length ? (document.body.setAttribute("data-swal2-queue-step", n), r.fire(Ft[n]).then(function(t) {
                            void 0 !== t.value ? (c.push(t.value), e(n + 1, o)) : a(i, {
                                dismiss: t.dismiss
                            })
                        })) : a(i, {
                            value: c
                        })
                    }(0)
                })
            },
            getQueueStep: It,
            insertQueueStep: function(t, e) {
                return e && e < Ft.length ? Ft.splice(e, 0, t) : Ft.push(t)
            },
            deleteQueueStep: function(t) {
                void 0 !== Ft[t] && Ft.splice(t, 1)
            },
            showLoading: Wt,
            enableLoading: Wt,
            getTimerLeft: function() {
                return Xt.timeout && Xt.timeout.getTimerLeft()
            },
            stopTimer: Yt,
            resumeTimer: Zt,
            toggleTimer: function() {
                var t = Xt.timeout;
                return t && (t.running ? Yt : Zt)()
            },
            increaseTimer: function(t) {
                if (Xt.timeout) {
                    var e = Xt.timeout.increase(t);
                    return st(e, !0), e
                }
            },
            isTimerRunning: function() {
                return Xt.timeout && Xt.timeout.isRunning()
            }
        });

    function ie() {
        var t, e = Bt.innerParams.get(this);
        e && (t = Bt.domCache.get(this), e.showConfirmButton || (it(t.confirmButton), e.showCancelButton || it(t.actions)), ht([t.popup, t.actions], Y.loading), t.popup.removeAttribute("aria-busy"), t.popup.removeAttribute("data-loading"), t.confirmButton.disabled = !1, t.cancelButton.disabled = !1)
    }

    function re() {
        null === X.previousBodyPadding && document.body.scrollHeight > window.innerHeight && (X.previousBodyPadding = parseInt(window.getComputedStyle(document.body).getPropertyValue("padding-right")), document.body.style.paddingRight = "".concat(X.previousBodyPadding + function() {
            var t = document.createElement("div");
            t.className = Y["scrollbar-measure"], document.body.appendChild(t);
            var e = t.getBoundingClientRect().width - t.clientWidth;
            return document.body.removeChild(t), e
        }(), "px"))
    }

    function ae() {
        return !!window.MSInputMethodContext && !!document.documentMode
    }

    function ce() {
        var t = Q(),
            e = $();
        t.style.removeProperty("align-items"), e.offsetTop < 0 && (t.style.alignItems = "flex-start")
    }
    var se = function() {
            navigator.userAgent.match(/(CriOS|FxiOS|EdgiOS|YaBrowser|UCBrowser)/i) || $().scrollHeight > window.innerHeight - 44 && (Q().style.paddingBottom = "".concat(44, "px"))
        },
        ue = function() {
            var e, t = Q();
            t.ontouchstart = function(t) {
                e = le(t.target)
            }, t.ontouchmove = function(t) {
                e && (t.preventDefault(), t.stopPropagation())
            }
        },
        le = function(t) {
            var e = Q();
            return t === e || !(at(e) || "INPUT" === t.tagName || at(P()) && P().contains(t))
        },
        de = {
            swalPromiseResolve: new WeakMap
        };

    function pe(t, e, n, o) {
        var i;
        n ? he(t, o) : (Kt().then(function() {
            return he(t, o)
        }), Xt.keydownTarget.removeEventListener("keydown", Xt.keydownHandler, {
            capture: Xt.keydownListenerCapture
        }), Xt.keydownHandlerAdded = !1), e.parentNode && !document.body.getAttribute("data-swal2-queue-step") && e.parentNode.removeChild(e), M() && (null !== X.previousBodyPadding && (document.body.style.paddingRight = "".concat(X.previousBodyPadding, "px"), X.previousBodyPadding = null), D(document.body, Y.iosfix) && (i = parseInt(document.body.style.top, 10), ht(document.body, Y.iosfix), document.body.style.top = "", document.body.scrollTop = -1 * i), "undefined" != typeof window && ae() && window.removeEventListener("resize", ce), h(document.body.children).forEach(function(t) {
            t.hasAttribute("data-previous-aria-hidden") ? (t.setAttribute("aria-hidden", t.getAttribute("data-previous-aria-hidden")), t.removeAttribute("data-previous-aria-hidden")) : t.removeAttribute("aria-hidden")
        })), ht([document.documentElement, document.body], [Y.shown, Y["height-auto"], Y["no-backdrop"], Y["toast-shown"], Y["toast-column"]])
    }

    function fe(t) {
        var e, n, o, i = $();
        i && (e = Bt.innerParams.get(this)) && !D(i, e.hideClass.popup) && (n = de.swalPromiseResolve.get(this), ht(i, e.showClass.popup), mt(i, e.hideClass.popup), o = Q(), ht(o, e.showClass.backdrop), mt(o, e.hideClass.backdrop), function(t, e, n) {
            var o = Q(),
                i = kt && ct(e),
                r = n.onClose,
                a = n.onAfterClose;
            if (r !== null && typeof r === "function") {
                r(e)
            }
            if (i) {
                me(t, e, o, a)
            } else {
                pe(t, o, J(), a)
            }
        }(this, i, e), void 0 !== t ? (t.isDismissed = void 0 !== t.dismiss, t.isConfirmed = void 0 === t.dismiss) : t = {
            isDismissed: !0,
            isConfirmed: !1
        }, n(t || {}))
    }
    var me = function(t, e, n, o) {
            Xt.swalCloseEventFinishedCallback = pe.bind(null, t, n, J(), o), e.addEventListener(kt, function(t) {
                t.target === e && (Xt.swalCloseEventFinishedCallback(), delete Xt.swalCloseEventFinishedCallback)
            })
        },
        he = function(t, e) {
            setTimeout(function() {
                "function" == typeof e && e(), t._destroy()
            })
        };

    function ge(t, e, n) {
        var o = Bt.domCache.get(t);
        e.forEach(function(t) {
            o[t].disabled = n
        })
    }

    function ve(t, e) {
        if (!t) return !1;
        if ("radio" === t.type)
            for (var n = t.parentNode.parentNode.querySelectorAll("input"), o = 0; o < n.length; o++) n[o].disabled = e;
        else t.disabled = e
    }
    var be = function() {
            function n(t, e) {
                a(this, n), this.callback = t, this.remaining = e, this.running = !1, this.start()
            }
            return c(n, [{
                key: "start",
                value: function() {
                    return this.running || (this.running = !0, this.started = new Date, this.id = setTimeout(this.callback, this.remaining)), this.remaining
                }
            }, {
                key: "stop",
                value: function() {
                    return this.running && (this.running = !1, clearTimeout(this.id), this.remaining -= new Date - this.started), this.remaining
                }
            }, {
                key: "increase",
                value: function(t) {
                    var e = this.running;
                    return e && this.stop(), this.remaining += t, e && this.start(), this.remaining
                }
            }, {
                key: "getTimerLeft",
                value: function() {
                    return this.running && (this.stop(), this.start()), this.remaining
                }
            }, {
                key: "isRunning",
                value: function() {
                    return this.running
                }
            }]), n
        }(),
        ye = {
            email: function(t, e) {
                return /^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.-]+\.[a-zA-Z0-9-]{2,24}$/.test(t) ? Promise.resolve() : Promise.resolve(e || "Invalid email address")
            },
            url: function(t, e) {
                return /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_+.~#?&/=]*)$/.test(t) ? Promise.resolve() : Promise.resolve(e || "Invalid URL")
            }
        };

    function we(t) {
        var e, n;
        (e = t).inputValidator || Object.keys(ye).forEach(function(t) {
            e.input === t && (e.inputValidator = ye[t])
        }), t.showLoaderOnConfirm && !t.preConfirm && _("showLoaderOnConfirm is set to true, but preConfirm is not defined.\nshowLoaderOnConfirm should be used together with preConfirm, see usage example:\nhttps://sweetalert2.github.io/#ajax-request"), t.animation = W(t.animation), (n = t).target && ("string" != typeof n.target || document.querySelector(n.target)) && ("string" == typeof n.target || n.target.appendChild) || (_('Target parameter is not valid, defaulting to "body"'), n.target = "body"), "string" == typeof t.title && (t.title = t.title.split("\n").join("<br />")), yt(t)
    }

    function Ce(t) {
        var e = Q(),
            n = $();
        "function" == typeof t.onBeforeOpen && t.onBeforeOpen(n);
        var o = window.getComputedStyle(document.body).overflowY;
        je(e, n, t), Te(e, n), M() && (Le(e, t.scrollbarPadding, o), h(document.body.children).forEach(function(t) {
            t === Q() || function(t, e) {
                if ("function" == typeof t.contains) return t.contains(e)
            }(t, Q()) || (t.hasAttribute("aria-hidden") && t.setAttribute("data-previous-aria-hidden", t.getAttribute("aria-hidden")), t.setAttribute("aria-hidden", "true"))
        })), J() || Xt.previousActiveElement || (Xt.previousActiveElement = document.activeElement), "function" == typeof t.onOpen && setTimeout(function() {
            return t.onOpen(n)
        }), ht(e, Y["no-transition"])
    }

    function ke(t) {
        var e, n = $();
        t.target === n && (e = Q(), n.removeEventListener(kt, ke), e.style.overflowY = "auto")
    }

    function xe(t, e) {
        "select" === e.input || "radio" === e.input ? Me(t, e) : -1 !== ["text", "email", "number", "tel", "textarea"].indexOf(e.input) && (v(e.inputValue) || y(e.inputValue)) && Re(t, e)
    }

    function Pe(t, e) {
        t.disableButtons(), e.input ? Ne(t, e) : Ue(t, e, !0)
    }

    function Ae(t, e) {
        t.disableButtons(), e(K.cancel)
    }

    function Be(t, e) {
        t.closePopup({
            value: e
        })
    }

    function Se(e, t, n, o) {
        t.keydownTarget && t.keydownHandlerAdded && (t.keydownTarget.removeEventListener("keydown", t.keydownHandler, {
            capture: t.keydownListenerCapture
        }), t.keydownHandlerAdded = !1), n.toast || (t.keydownHandler = function(t) {
            return ze(e, t, o)
        }, t.keydownTarget = n.keydownListenerCapture ? window : $(), t.keydownListenerCapture = n.keydownListenerCapture, t.keydownTarget.addEventListener("keydown", t.keydownHandler, {
            capture: t.keydownListenerCapture
        }), t.keydownHandlerAdded = !0)
    }

    function Ee(t, e, n) {
        var o = V(),
            i = 0;
        if (i < o.length) return (e += n) === o.length ? e = 0 : -1 === e && (e = o.length - 1), o[e].focus();
        $().focus()
    }

    function Oe(t, e, n) {
        Bt.innerParams.get(t).toast ? Qe(t, e, n) : (Je(e), Xe(e), Ge(t, e, n))
    }
    var Te = function(t, e) {
            kt && ct(e) ? (t.style.overflowY = "hidden", e.addEventListener(kt, ke)) : t.style.overflowY = "auto"
        },
        Le = function(t, e, n) {
            var o;
            (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream || "MacIntel" === navigator.platform && 1 < navigator.maxTouchPoints) && !D(document.body, Y.iosfix) && (o = document.body.scrollTop, document.body.style.top = "".concat(-1 * o, "px"), mt(document.body, Y.iosfix), ue(), se()), "undefined" != typeof window && ae() && (ce(), window.addEventListener("resize", ce)), e && "hidden" !== n && re(), setTimeout(function() {
                t.scrollTop = 0
            })
        },
        je = function(t, e, n) {
            mt(t, n.showClass.backdrop), ot(e), mt(e, n.showClass.popup), mt([document.documentElement, document.body], Y.shown), n.heightAuto && n.backdrop && !n.toast && mt([document.documentElement, document.body], Y["height-auto"])
        },
        qe = function(t) {
            return t.checked ? 1 : 0
        },
        Ie = function(t) {
            return t.checked ? t.value : null
        },
        Ve = function(t) {
            return t.files.length ? null !== t.getAttribute("multiple") ? t.files : t.files[0] : null
        },
        Me = function(e, n) {
            function o(t) {
                return He[n.input](i, De(t), n)
            }
            var i = P();
            v(n.inputOptions) || y(n.inputOptions) ? (Wt(), b(n.inputOptions).then(function(t) {
                e.hideLoading(), o(t)
            })) : "object" === r(n.inputOptions) ? o(n.inputOptions) : F("Unexpected type of inputOptions! Expected object, Map or Promise, got ".concat(r(n.inputOptions)))
        },
        Re = function(e, n) {
            var o = e.getInput();
            it(o), b(n.inputValue).then(function(t) {
                o.value = "number" === n.input ? parseFloat(t) || 0 : "".concat(t), ot(o), o.focus(), e.hideLoading()
            }).catch(function(t) {
                F("Error in inputValue promise: ".concat(t)), o.value = "", ot(o), o.focus(), e.hideLoading()
            })
        },
        He = {
            select: function(t, e, i) {
                function r(t, e, n) {
                    var o = document.createElement("option");
                    o.value = n, H(o, e), i.inputValue.toString() === n.toString() && (o.selected = !0), t.appendChild(o)
                }
                var a = gt(t, Y.select);
                e.forEach(function(t) {
                    var e, n = t[0],
                        o = t[1];
                    Array.isArray(o) ? ((e = document.createElement("optgroup")).label = n, e.disabled = !1, a.appendChild(e), o.forEach(function(t) {
                        return r(e, t[1], t[0])
                    })) : r(a, o, n)
                }), a.focus()
            },
            radio: function(t, e, a) {
                var c = gt(t, Y.radio);
                e.forEach(function(t) {
                    var e = t[0],
                        n = t[1],
                        o = document.createElement("input"),
                        i = document.createElement("label");
                    o.type = "radio", o.name = Y.radio, o.value = e, a.inputValue.toString() === e.toString() && (o.checked = !0);
                    var r = document.createElement("span");
                    H(r, n), r.className = Y.label, i.appendChild(o), i.appendChild(r), c.appendChild(i)
                });
                var n = c.querySelectorAll("input");
                n.length && n[0].focus()
            }
        },
        De = function o(n) {
            var i = [];
            return "undefined" != typeof Map && n instanceof Map ? n.forEach(function(t, e) {
                var n = t;
                "object" === r(n) && (n = o(n)), i.push([e, n])
            }) : Object.keys(n).forEach(function(t) {
                var e = n[t];
                "object" === r(e) && (e = o(e)), i.push([t, e])
            }), i
        },
        Ne = function(e, n) {
            var o = function(t, e) {
                var n = t.getInput();
                if (!n) return null;
                switch (e.input) {
                    case "checkbox":
                        return qe(n);
                    case "radio":
                        return Ie(n);
                    case "file":
                        return Ve(n);
                    default:
                        return e.inputAutoTrim ? n.value.trim() : n.value
                }
            }(e, n);
            n.inputValidator ? (e.disableInput(), Promise.resolve().then(function() {
                return b(n.inputValidator(o, n.validationMessage))
            }).then(function(t) {
                e.enableButtons(), e.enableInput(), t ? e.showValidationMessage(t) : Ue(e, n, o)
            })) : e.getInput().checkValidity() ? Ue(e, n, o) : (e.enableButtons(), e.showValidationMessage(n.validationMessage))
        },
        Ue = function(e, t, n) {
            t.showLoaderOnConfirm && Wt(), t.preConfirm ? (e.resetValidationMessage(), Promise.resolve().then(function() {
                return b(t.preConfirm(n, t.validationMessage))
            }).then(function(t) {
                vt(S()) || !1 === t ? e.hideLoading() : Be(e, void 0 === t ? n : t)
            })) : Be(e, n)
        },
        _e = ["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown", "Left", "Right", "Up", "Down"],
        Fe = ["Escape", "Esc"],
        ze = function(t, e, n) {
            var o = Bt.innerParams.get(t);
            o.stopKeydownPropagation && e.stopPropagation(), "Enter" === e.key ? We(t, e, o) : "Tab" === e.key ? Ke(e, o) : -1 !== _e.indexOf(e.key) ? Ye() : -1 !== Fe.indexOf(e.key) && Ze(e, o, n)
        },
        We = function(t, e, n) {
            if (!e.isComposing && e.target && t.getInput() && e.target.outerHTML === t.getInput().outerHTML) {
                if (-1 !== ["textarea", "file"].indexOf(n.input)) return;
                Ht(), e.preventDefault()
            }
        },
        Ke = function(t) {
            for (var e = t.target, n = V(), o = -1, i = 0; i < n.length; i++)
                if (e === n[i]) {
                    o = i;
                    break
                }
            t.shiftKey ? Ee(0, o, -1) : Ee(0, o, 1), t.stopPropagation(), t.preventDefault()
        },
        Ye = function() {
            var t = E(),
                e = O();
            document.activeElement === t && vt(e) ? e.focus() : document.activeElement === e && vt(t) && t.focus()
        },
        Ze = function(t, e, n) {
            W(e.allowEscapeKey) && (t.preventDefault(), n(K.esc))
        },
        Qe = function(e, t, n) {
            t.popup.onclick = function() {
                var t = Bt.innerParams.get(e);
                t.showConfirmButton || t.showCancelButton || t.showCloseButton || t.input || n(K.close)
            }
        },
        $e = !1,
        Je = function(e) {
            e.popup.onmousedown = function() {
                e.container.onmouseup = function(t) {
                    e.container.onmouseup = void 0, t.target === e.container && ($e = !0)
                }
            }
        },
        Xe = function(e) {
            e.container.onmousedown = function() {
                e.popup.onmouseup = function(t) {
                    e.popup.onmouseup = void 0, t.target !== e.popup && !e.popup.contains(t.target) || ($e = !0)
                }
            }
        },
        Ge = function(n, o, i) {
            o.container.onclick = function(t) {
                var e = Bt.innerParams.get(n);
                $e ? $e = !1 : t.target === o.container && W(e.allowOutsideClick) && i(K.backdrop)
            }
        };
    var tn = function(t, e, n) {
            var o = q();
            it(o), e.timer && (t.timeout = new be(function() {
                n("timer"), delete t.timeout
            }, e.timer), e.timerProgressBar && (ot(o), setTimeout(function() {
                t.timeout.running && st(e.timer)
            })))
        },
        en = function(t, e) {
            if (!e.toast) return W(e.allowEnterKey) ? e.focusCancel && vt(t.cancelButton) ? t.cancelButton.focus() : e.focusConfirm && vt(t.confirmButton) ? t.confirmButton.focus() : void Ee(0, -1, 1) : nn()
        },
        nn = function() {
            document.activeElement && "function" == typeof document.activeElement.blur && document.activeElement.blur()
        };
    var on, rn = function(t) {
            for (var e in t) t[e] = new WeakMap
        },
        an = Object.freeze({
            hideLoading: ie,
            disableLoading: ie,
            getInput: function(t) {
                var e = Bt.innerParams.get(t || this),
                    n = Bt.domCache.get(t || this);
                return n ? G(n.content, e.input) : null
            },
            close: fe,
            closePopup: fe,
            closeModal: fe,
            closeToast: fe,
            enableButtons: function() {
                ge(this, ["confirmButton", "cancelButton"], !1)
            },
            disableButtons: function() {
                ge(this, ["confirmButton", "cancelButton"], !0)
            },
            enableInput: function() {
                return ve(this.getInput(), !1)
            },
            disableInput: function() {
                return ve(this.getInput(), !0)
            },
            showValidationMessage: function(t) {
                var e = Bt.domCache.get(this);
                H(e.validationMessage, t);
                var n = window.getComputedStyle(e.popup);
                e.validationMessage.style.marginLeft = "-".concat(n.getPropertyValue("padding-left")), e.validationMessage.style.marginRight = "-".concat(n.getPropertyValue("padding-right")), ot(e.validationMessage);
                var o = this.getInput();
                o && (o.setAttribute("aria-invalid", !0), o.setAttribute("aria-describedBy", Y["validation-message"]), tt(o), mt(o, Y.inputerror))
            },
            resetValidationMessage: function() {
                var t = Bt.domCache.get(this);
                t.validationMessage && it(t.validationMessage);
                var e = this.getInput();
                e && (e.removeAttribute("aria-invalid"), e.removeAttribute("aria-describedBy"), ht(e, Y.inputerror))
            },
            getProgressSteps: function() {
                return Bt.domCache.get(this).progressSteps
            },
            _main: function(t) {
                Jt(t), Xt.currentInstance && Xt.currentInstance._destroy(), Xt.currentInstance = this;
                var e = function(t) {
                    var e = s({}, Gt.showClass, t.showClass),
                        n = s({}, Gt.hideClass, t.hideClass),
                        o = s({}, Gt, t);
                    if (o.showClass = e, o.hideClass = n, t.animation === false) {
                        o.showClass = {
                            popup: "swal2-noanimation",
                            backdrop: "swal2-noanimation"
                        };
                        o.hideClass = {}
                    }
                    return o
                }(t);
                we(e), Object.freeze(e), Xt.timeout && (Xt.timeout.stop(), delete Xt.timeout), clearTimeout(Xt.restoreFocusTimeout);
                var n = function(t) {
                    var e = {
                        popup: $(),
                        container: Q(),
                        content: P(),
                        actions: T(),
                        confirmButton: E(),
                        cancelButton: O(),
                        closeButton: I(),
                        validationMessage: S(),
                        progressSteps: B()
                    };
                    return Bt.domCache.set(t, e), e
                }(this);
                return Rt(this, e), Bt.innerParams.set(this, e),
                    function(n, o, i) {
                        return new Promise(function(t) {
                            var e = function t(e) {
                                n.closePopup({
                                    dismiss: e
                                })
                            };
                            de.swalPromiseResolve.set(n, t);
                            o.confirmButton.onclick = function() {
                                return Pe(n, i)
                            };
                            o.cancelButton.onclick = function() {
                                return Ae(n, e)
                            };
                            o.closeButton.onclick = function() {
                                return e(K.close)
                            };
                            Oe(n, o, e);
                            Se(n, Xt, i, e);
                            if (i.toast && (i.input || i.footer || i.showCloseButton)) {
                                mt(document.body, Y["toast-column"])
                            } else {
                                ht(document.body, Y["toast-column"])
                            }
                            xe(n, i);
                            Ce(i);
                            tn(Xt, i, e);
                            en(o, i);
                            setTimeout(function() {
                                o.container.scrollTop = 0
                            })
                        })
                    }(this, n, e)
            },
            update: function(e) {
                var t = $(),
                    n = Bt.innerParams.get(this);
                if (!t || D(t, n.hideClass.popup)) return _("You're trying to update the closed or closing popup, that won't work. Use the update() method in preConfirm parameter or show a new popup.");
                var o = {};
                Object.keys(e).forEach(function(t) {
                    sn.isUpdatableParameter(t) ? o[t] = e[t] : _('Invalid parameter to update: "'.concat(t, '". Updatable params are listed here: https://github.com/sweetalert2/sweetalert2/blob/master/src/utils/params.js'))
                });
                var i = s({}, n, o);
                Rt(this, i), Bt.innerParams.set(this, i), Object.defineProperties(this, {
                    params: {
                        value: s({}, this.params, e),
                        writable: !1,
                        enumerable: !0
                    }
                })
            },
            _destroy: function() {
                var t = Bt.domCache.get(this),
                    e = Bt.innerParams.get(this);
                e && (t.popup && Xt.swalCloseEventFinishedCallback && (Xt.swalCloseEventFinishedCallback(), delete Xt.swalCloseEventFinishedCallback), Xt.deferDisposalTimer && (clearTimeout(Xt.deferDisposalTimer), delete Xt.deferDisposalTimer), "function" == typeof e.onDestroy && e.onDestroy(), delete this.params, delete Xt.keydownHandler, delete Xt.keydownTarget, rn(Bt), rn(de))
            }
        }),
        cn = function() {
            function r() {
                if (a(this, r), "undefined" != typeof window) {
                    "undefined" == typeof Promise && F("This package requires a Promise library, please include a shim to enable it in this browser (See: https://github.com/sweetalert2/sweetalert2/wiki/Migration-from-SweetAlert-to-SweetAlert2#1-ie-support)"), on = this;
                    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    var o = Object.freeze(this.constructor.argsToParams(e));
                    Object.defineProperties(this, {
                        params: {
                            value: o,
                            writable: !1,
                            enumerable: !0,
                            configurable: !0
                        }
                    });
                    var i = this._main(this.params);
                    Bt.promise.set(this, i)
                }
            }
            return c(r, [{
                key: "then",
                value: function(t) {
                    return Bt.promise.get(this).then(t)
                }
            }, {
                key: "finally",
                value: function(t) {
                    return Bt.promise.get(this).finally(t)
                }
            }]), r
        }();
    s(cn.prototype, an), s(cn, oe), Object.keys(an).forEach(function(t) {
        cn[t] = function() {
            if (on) return on[t].apply(on, arguments)
        }
    }), cn.DismissReason = K, cn.version = "9.17.2";
    var sn = cn;
    return sn.default = sn
}), void 0 !== this && this.Sweetalert2 && (this.swal = this.sweetAlert = this.Swal = this.SweetAlert = this.Sweetalert2);
"undefined" != typeof document && function(e, t) {
    var n = e.createElement("style");
    if (e.getElementsByTagName("head")[0].appendChild(n), n.styleSheet) n.styleSheet.disabled || (n.styleSheet.cssText = t);
    else try {
        n.innerHTML = t
    } catch (e) {
        n.innerText = t
    }
}(document, ".swal2-popup.swal2-toast{flex-direction:row;align-items:center;width:auto;padding:.625em;overflow-y:hidden;background:#fff;box-shadow:0 0 .625em #d9d9d9}.swal2-popup.swal2-toast .swal2-header{flex-direction:row;padding:0}.swal2-popup.swal2-toast .swal2-title{flex-grow:1;justify-content:flex-start;margin:0 .6em;font-size:1em}.swal2-popup.swal2-toast .swal2-footer{margin:.5em 0 0;padding:.5em 0 0;font-size:.8em}.swal2-popup.swal2-toast .swal2-close{position:static;width:.8em;height:.8em;line-height:.8}.swal2-popup.swal2-toast .swal2-content{justify-content:flex-start;padding:0;font-size:1em}.swal2-popup.swal2-toast .swal2-icon{width:2em;min-width:2em;height:2em;margin:0}.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:1.8em;font-weight:700}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-popup.swal2-toast .swal2-icon .swal2-icon-content{font-size:.25em}}.swal2-popup.swal2-toast .swal2-icon.swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line]{top:.875em;width:1.375em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:.3125em}.swal2-popup.swal2-toast .swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:.3125em}.swal2-popup.swal2-toast .swal2-actions{flex-basis:auto!important;width:auto;height:auto;margin:0 .3125em}.swal2-popup.swal2-toast .swal2-styled{margin:0 .3125em;padding:.3125em .625em;font-size:1em}.swal2-popup.swal2-toast .swal2-styled:focus{box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(50,100,150,.4)}.swal2-popup.swal2-toast .swal2-success{border-color:#a5dc86}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line]{position:absolute;width:1.6em;height:3em;transform:rotate(45deg);border-radius:50%}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.8em;left:-.5em;transform:rotate(-45deg);transform-origin:2em 2em;border-radius:4em 0 0 4em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.25em;left:.9375em;transform-origin:0 1.5em;border-radius:0 4em 4em 0}.swal2-popup.swal2-toast .swal2-success .swal2-success-ring{width:2em;height:2em}.swal2-popup.swal2-toast .swal2-success .swal2-success-fix{top:0;left:.4375em;width:.4375em;height:2.6875em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line]{height:.3125em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=tip]{top:1.125em;left:.1875em;width:.75em}.swal2-popup.swal2-toast .swal2-success [class^=swal2-success-line][class$=long]{top:.9375em;right:.1875em;width:1.375em}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-toast-animate-success-line-tip .75s;animation:swal2-toast-animate-success-line-tip .75s}.swal2-popup.swal2-toast .swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-toast-animate-success-line-long .75s;animation:swal2-toast-animate-success-line-long .75s}.swal2-popup.swal2-toast.swal2-show{-webkit-animation:swal2-toast-show .5s;animation:swal2-toast-show .5s}.swal2-popup.swal2-toast.swal2-hide{-webkit-animation:swal2-toast-hide .1s forwards;animation:swal2-toast-hide .1s forwards}.swal2-container{display:flex;position:fixed;z-index:1060;top:0;right:0;bottom:0;left:0;flex-direction:row;align-items:center;justify-content:center;padding:.625em;overflow-x:hidden;transition:background-color .1s;-webkit-overflow-scrolling:touch}.swal2-container.swal2-backdrop-show,.swal2-container.swal2-noanimation{background:rgba(0,0,0,.4)}.swal2-container.swal2-backdrop-hide{background:0 0!important}.swal2-container.swal2-top{align-items:flex-start}.swal2-container.swal2-top-left,.swal2-container.swal2-top-start{align-items:flex-start;justify-content:flex-start}.swal2-container.swal2-top-end,.swal2-container.swal2-top-right{align-items:flex-start;justify-content:flex-end}.swal2-container.swal2-center{align-items:center}.swal2-container.swal2-center-left,.swal2-container.swal2-center-start{align-items:center;justify-content:flex-start}.swal2-container.swal2-center-end,.swal2-container.swal2-center-right{align-items:center;justify-content:flex-end}.swal2-container.swal2-bottom{align-items:flex-end}.swal2-container.swal2-bottom-left,.swal2-container.swal2-bottom-start{align-items:flex-end;justify-content:flex-start}.swal2-container.swal2-bottom-end,.swal2-container.swal2-bottom-right{align-items:flex-end;justify-content:flex-end}.swal2-container.swal2-bottom-end>:first-child,.swal2-container.swal2-bottom-left>:first-child,.swal2-container.swal2-bottom-right>:first-child,.swal2-container.swal2-bottom-start>:first-child,.swal2-container.swal2-bottom>:first-child{margin-top:auto}.swal2-container.swal2-grow-fullscreen>.swal2-modal{display:flex!important;flex:1;align-self:stretch;justify-content:center}.swal2-container.swal2-grow-row>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-grow-column{flex:1;flex-direction:column}.swal2-container.swal2-grow-column.swal2-bottom,.swal2-container.swal2-grow-column.swal2-center,.swal2-container.swal2-grow-column.swal2-top{align-items:center}.swal2-container.swal2-grow-column.swal2-bottom-left,.swal2-container.swal2-grow-column.swal2-bottom-start,.swal2-container.swal2-grow-column.swal2-center-left,.swal2-container.swal2-grow-column.swal2-center-start,.swal2-container.swal2-grow-column.swal2-top-left,.swal2-container.swal2-grow-column.swal2-top-start{align-items:flex-start}.swal2-container.swal2-grow-column.swal2-bottom-end,.swal2-container.swal2-grow-column.swal2-bottom-right,.swal2-container.swal2-grow-column.swal2-center-end,.swal2-container.swal2-grow-column.swal2-center-right,.swal2-container.swal2-grow-column.swal2-top-end,.swal2-container.swal2-grow-column.swal2-top-right{align-items:flex-end}.swal2-container.swal2-grow-column>.swal2-modal{display:flex!important;flex:1;align-content:center;justify-content:center}.swal2-container.swal2-no-transition{transition:none!important}.swal2-container:not(.swal2-top):not(.swal2-top-start):not(.swal2-top-end):not(.swal2-top-left):not(.swal2-top-right):not(.swal2-center-start):not(.swal2-center-end):not(.swal2-center-left):not(.swal2-center-right):not(.swal2-bottom):not(.swal2-bottom-start):not(.swal2-bottom-end):not(.swal2-bottom-left):not(.swal2-bottom-right):not(.swal2-grow-fullscreen)>.swal2-modal{margin:auto}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-container .swal2-modal{margin:0!important}}.swal2-popup{display:none;position:relative;box-sizing:border-box;flex-direction:column;justify-content:center;width:32em;max-width:100%;padding:1.25em;border:none;border-radius:.3125em;background:#fff;font-family:inherit;font-size:1rem}.swal2-popup:focus{outline:0}.swal2-popup.swal2-loading{overflow-y:hidden}.swal2-header{display:flex;flex-direction:column;align-items:center;padding:0 1.8em}.swal2-title{position:relative;max-width:100%;margin:0 0 .4em;padding:0;color:#595959;font-size:1.875em;font-weight:600;text-align:center;text-transform:none;word-wrap:break-word}.swal2-actions{display:flex;z-index:1;flex-wrap:wrap;align-items:center;justify-content:center;width:100%;margin:1.25em auto 0}.swal2-actions:not(.swal2-loading) .swal2-styled[disabled]{opacity:.4}.swal2-actions:not(.swal2-loading) .swal2-styled:hover{background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1))}.swal2-actions:not(.swal2-loading) .swal2-styled:active{background-image:linear-gradient(rgba(0,0,0,.2),rgba(0,0,0,.2))}.swal2-actions.swal2-loading .swal2-styled.swal2-confirm{box-sizing:border-box;width:2.5em;height:2.5em;margin:.46875em;padding:0;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border:.25em solid transparent;border-radius:100%;border-color:transparent;background-color:transparent!important;color:transparent!important;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-actions.swal2-loading .swal2-styled.swal2-cancel{margin-right:30px;margin-left:30px}.swal2-actions.swal2-loading :not(.swal2-styled).swal2-confirm::after{content:\"\";display:inline-block;width:15px;height:15px;margin-left:5px;-webkit-animation:swal2-rotate-loading 1.5s linear 0s infinite normal;animation:swal2-rotate-loading 1.5s linear 0s infinite normal;border:3px solid #999;border-radius:50%;border-right-color:transparent;box-shadow:1px 1px 1px #fff}.swal2-styled{margin:.3125em;padding:.625em 2em;box-shadow:none;font-weight:500}.swal2-styled:not([disabled]){cursor:pointer}.swal2-styled.swal2-confirm{border:0;border-radius:.25em;background:initial;background-color:#3085d6;color:#fff;font-size:1.0625em}.swal2-styled.swal2-cancel{border:0;border-radius:.25em;background:initial;background-color:#aaa;color:#fff;font-size:1.0625em}.swal2-styled:focus{outline:0;box-shadow:0 0 0 1px #fff,0 0 0 3px rgba(50,100,150,.4)}.swal2-styled::-moz-focus-inner{border:0}.swal2-footer{justify-content:center;margin:1.25em 0 0;padding:1em 0 0;border-top:1px solid #eee;color:#545454;font-size:1em}.swal2-timer-progress-bar-container{position:absolute;right:0;bottom:0;left:0;height:.25em;overflow:hidden;border-bottom-right-radius:.3125em;border-bottom-left-radius:.3125em}.swal2-timer-progress-bar{width:100%;height:.25em;background:rgba(0,0,0,.2)}.swal2-image{max-width:100%;margin:1.25em auto}.swal2-close{position:absolute;z-index:2;top:0;right:0;align-items:center;justify-content:center;width:1.2em;height:1.2em;padding:0;overflow:hidden;transition:color .1s ease-out;border:none;border-radius:0;background:0 0;color:#ccc;font-family:serif;font-size:2.5em;line-height:1.2;cursor:pointer}.swal2-close:hover{transform:none;background:0 0;color:#f27474}.swal2-close::-moz-focus-inner{border:0}.swal2-content{z-index:1;justify-content:center;margin:0;padding:0 1.6em;color:#545454;font-size:1.125em;font-weight:400;line-height:normal;text-align:center;word-wrap:break-word}.swal2-checkbox,.swal2-file,.swal2-input,.swal2-radio,.swal2-select,.swal2-textarea{margin:1em auto}.swal2-file,.swal2-input,.swal2-textarea{box-sizing:border-box;width:100%;transition:border-color .3s,box-shadow .3s;border:1px solid #d9d9d9;border-radius:.1875em;background:inherit;box-shadow:inset 0 1px 1px rgba(0,0,0,.06);color:inherit;font-size:1.125em}.swal2-file.swal2-inputerror,.swal2-input.swal2-inputerror,.swal2-textarea.swal2-inputerror{border-color:#f27474!important;box-shadow:0 0 2px #f27474!important}.swal2-file:focus,.swal2-input:focus,.swal2-textarea:focus{border:1px solid #b4dbed;outline:0;box-shadow:0 0 3px #c4e6f5}.swal2-file::-moz-placeholder,.swal2-input::-moz-placeholder,.swal2-textarea::-moz-placeholder{color:#ccc}.swal2-file:-ms-input-placeholder,.swal2-input:-ms-input-placeholder,.swal2-textarea:-ms-input-placeholder{color:#ccc}.swal2-file::-ms-input-placeholder,.swal2-input::-ms-input-placeholder,.swal2-textarea::-ms-input-placeholder{color:#ccc}.swal2-file::placeholder,.swal2-input::placeholder,.swal2-textarea::placeholder{color:#ccc}.swal2-range{margin:1em auto;background:#fff}.swal2-range input{width:80%}.swal2-range output{width:20%;color:inherit;font-weight:600;text-align:center}.swal2-range input,.swal2-range output{height:2.625em;padding:0;font-size:1.125em;line-height:2.625em}.swal2-input{height:2.625em;padding:0 .75em}.swal2-input[type=number]{max-width:10em}.swal2-file{background:inherit;font-size:1.125em}.swal2-textarea{height:6.75em;padding:.75em}.swal2-select{min-width:50%;max-width:100%;padding:.375em .625em;background:inherit;color:inherit;font-size:1.125em}.swal2-checkbox,.swal2-radio{align-items:center;justify-content:center;background:#fff;color:inherit}.swal2-checkbox label,.swal2-radio label{margin:0 .6em;font-size:1.125em}.swal2-checkbox input,.swal2-radio input{margin:0 .4em}.swal2-validation-message{display:none;align-items:center;justify-content:center;padding:.625em;overflow:hidden;background:#f0f0f0;color:#666;font-size:1em;font-weight:300}.swal2-validation-message::before{content:\"!\";display:inline-block;width:1.5em;min-width:1.5em;height:1.5em;margin:0 .625em;border-radius:50%;background-color:#f27474;color:#fff;font-weight:600;line-height:1.5em;text-align:center}.swal2-icon{position:relative;box-sizing:content-box;justify-content:center;width:5em;height:5em;margin:1.25em auto 1.875em;border:.25em solid transparent;border-radius:50%;font-family:inherit;line-height:5em;cursor:default;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.swal2-icon .swal2-icon-content{display:flex;align-items:center;font-size:3.75em}.swal2-icon.swal2-error{border-color:#f27474;color:#f27474}.swal2-icon.swal2-error .swal2-x-mark{position:relative;flex-grow:1}.swal2-icon.swal2-error [class^=swal2-x-mark-line]{display:block;position:absolute;top:2.3125em;width:2.9375em;height:.3125em;border-radius:.125em;background-color:#f27474}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=left]{left:1.0625em;transform:rotate(45deg)}.swal2-icon.swal2-error [class^=swal2-x-mark-line][class$=right]{right:1em;transform:rotate(-45deg)}.swal2-icon.swal2-error.swal2-icon-show{-webkit-animation:swal2-animate-error-icon .5s;animation:swal2-animate-error-icon .5s}.swal2-icon.swal2-error.swal2-icon-show .swal2-x-mark{-webkit-animation:swal2-animate-error-x-mark .5s;animation:swal2-animate-error-x-mark .5s}.swal2-icon.swal2-warning{border-color:#facea8;color:#f8bb86}.swal2-icon.swal2-info{border-color:#9de0f6;color:#3fc3ee}.swal2-icon.swal2-question{border-color:#c9dae1;color:#87adbd}.swal2-icon.swal2-success{border-color:#a5dc86;color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-circular-line]{position:absolute;width:3.75em;height:7.5em;transform:rotate(45deg);border-radius:50%}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=left]{top:-.4375em;left:-2.0635em;transform:rotate(-45deg);transform-origin:3.75em 3.75em;border-radius:7.5em 0 0 7.5em}.swal2-icon.swal2-success [class^=swal2-success-circular-line][class$=right]{top:-.6875em;left:1.875em;transform:rotate(-45deg);transform-origin:0 3.75em;border-radius:0 7.5em 7.5em 0}.swal2-icon.swal2-success .swal2-success-ring{position:absolute;z-index:2;top:-.25em;left:-.25em;box-sizing:content-box;width:100%;height:100%;border:.25em solid rgba(165,220,134,.3);border-radius:50%}.swal2-icon.swal2-success .swal2-success-fix{position:absolute;z-index:1;top:.5em;left:1.625em;width:.4375em;height:5.625em;transform:rotate(-45deg)}.swal2-icon.swal2-success [class^=swal2-success-line]{display:block;position:absolute;z-index:2;height:.3125em;border-radius:.125em;background-color:#a5dc86}.swal2-icon.swal2-success [class^=swal2-success-line][class$=tip]{top:2.875em;left:.8125em;width:1.5625em;transform:rotate(45deg)}.swal2-icon.swal2-success [class^=swal2-success-line][class$=long]{top:2.375em;right:.5em;width:2.9375em;transform:rotate(-45deg)}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-tip{-webkit-animation:swal2-animate-success-line-tip .75s;animation:swal2-animate-success-line-tip .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-line-long{-webkit-animation:swal2-animate-success-line-long .75s;animation:swal2-animate-success-line-long .75s}.swal2-icon.swal2-success.swal2-icon-show .swal2-success-circular-line-right{-webkit-animation:swal2-rotate-success-circular-line 4.25s ease-in;animation:swal2-rotate-success-circular-line 4.25s ease-in}.swal2-progress-steps{align-items:center;margin:0 0 1.25em;padding:0;background:inherit;font-weight:600}.swal2-progress-steps li{display:inline-block;position:relative}.swal2-progress-steps .swal2-progress-step{z-index:20;width:2em;height:2em;border-radius:2em;background:#3085d6;color:#fff;line-height:2em;text-align:center}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step{background:#3085d6}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step{background:#add8e6;color:#fff}.swal2-progress-steps .swal2-progress-step.swal2-active-progress-step~.swal2-progress-step-line{background:#add8e6}.swal2-progress-steps .swal2-progress-step-line{z-index:10;width:2.5em;height:.4em;margin:0 -1px;background:#3085d6}[class^=swal2]{-webkit-tap-highlight-color:transparent}.swal2-show{-webkit-animation:swal2-show .3s;animation:swal2-show .3s}.swal2-hide{-webkit-animation:swal2-hide .15s forwards;animation:swal2-hide .15s forwards}.swal2-noanimation{transition:none}.swal2-scrollbar-measure{position:absolute;top:-9999px;width:50px;height:50px;overflow:scroll}.swal2-rtl .swal2-close{right:auto;left:0}.swal2-rtl .swal2-timer-progress-bar{right:0;left:auto}@supports (-ms-accelerator:true){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@media all and (-ms-high-contrast:none),(-ms-high-contrast:active){.swal2-range input{width:100%!important}.swal2-range output{display:none}}@-moz-document url-prefix(){.swal2-close:focus{outline:2px solid rgba(50,100,150,.4)}}@-webkit-keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@keyframes swal2-toast-show{0%{transform:translateY(-.625em) rotateZ(2deg)}33%{transform:translateY(0) rotateZ(-2deg)}66%{transform:translateY(.3125em) rotateZ(2deg)}100%{transform:translateY(0) rotateZ(0)}}@-webkit-keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@keyframes swal2-toast-hide{100%{transform:rotateZ(1deg);opacity:0}}@-webkit-keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@keyframes swal2-toast-animate-success-line-tip{0%{top:.5625em;left:.0625em;width:0}54%{top:.125em;left:.125em;width:0}70%{top:.625em;left:-.25em;width:1.625em}84%{top:1.0625em;left:.75em;width:.5em}100%{top:1.125em;left:.1875em;width:.75em}}@-webkit-keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@keyframes swal2-toast-animate-success-line-long{0%{top:1.625em;right:1.375em;width:0}65%{top:1.25em;right:.9375em;width:0}84%{top:.9375em;right:0;width:1.125em}100%{top:.9375em;right:.1875em;width:1.375em}}@-webkit-keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@keyframes swal2-show{0%{transform:scale(.7)}45%{transform:scale(1.05)}80%{transform:scale(.95)}100%{transform:scale(1)}}@-webkit-keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@keyframes swal2-hide{0%{transform:scale(1);opacity:1}100%{transform:scale(.5);opacity:0}}@-webkit-keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@keyframes swal2-animate-success-line-tip{0%{top:1.1875em;left:.0625em;width:0}54%{top:1.0625em;left:.125em;width:0}70%{top:2.1875em;left:-.375em;width:3.125em}84%{top:3em;left:1.3125em;width:1.0625em}100%{top:2.8125em;left:.8125em;width:1.5625em}}@-webkit-keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@keyframes swal2-animate-success-line-long{0%{top:3.375em;right:2.875em;width:0}65%{top:3.375em;right:2.875em;width:0}84%{top:2.1875em;right:0;width:3.4375em}100%{top:2.375em;right:.5em;width:2.9375em}}@-webkit-keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@keyframes swal2-rotate-success-circular-line{0%{transform:rotate(-45deg)}5%{transform:rotate(-45deg)}12%{transform:rotate(-405deg)}100%{transform:rotate(-405deg)}}@-webkit-keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@keyframes swal2-animate-error-x-mark{0%{margin-top:1.625em;transform:scale(.4);opacity:0}50%{margin-top:1.625em;transform:scale(.4);opacity:0}80%{margin-top:-.375em;transform:scale(1.15)}100%{margin-top:0;transform:scale(1);opacity:1}}@-webkit-keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@keyframes swal2-animate-error-icon{0%{transform:rotateX(100deg);opacity:0}100%{transform:rotateX(0);opacity:1}}@-webkit-keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}@keyframes swal2-rotate-loading{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow:hidden}body.swal2-height-auto{height:auto!important}body.swal2-no-backdrop .swal2-container{top:auto;right:auto;bottom:auto;left:auto;max-width:calc(100% - .625em * 2);background-color:transparent!important}body.swal2-no-backdrop .swal2-container>.swal2-modal{box-shadow:0 0 10px rgba(0,0,0,.4)}body.swal2-no-backdrop .swal2-container.swal2-top{top:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-top-left,body.swal2-no-backdrop .swal2-container.swal2-top-start{top:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-top-end,body.swal2-no-backdrop .swal2-container.swal2-top-right{top:0;right:0}body.swal2-no-backdrop .swal2-container.swal2-center{top:50%;left:50%;transform:translate(-50%,-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-left,body.swal2-no-backdrop .swal2-container.swal2-center-start{top:50%;left:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-center-end,body.swal2-no-backdrop .swal2-container.swal2-center-right{top:50%;right:0;transform:translateY(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom{bottom:0;left:50%;transform:translateX(-50%)}body.swal2-no-backdrop .swal2-container.swal2-bottom-left,body.swal2-no-backdrop .swal2-container.swal2-bottom-start{bottom:0;left:0}body.swal2-no-backdrop .swal2-container.swal2-bottom-end,body.swal2-no-backdrop .swal2-container.swal2-bottom-right{right:0;bottom:0}@media print{body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown){overflow-y:scroll!important}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown)>[aria-hidden=true]{display:none}body.swal2-shown:not(.swal2-no-backdrop):not(.swal2-toast-shown) .swal2-container{position:static!important}}body.swal2-toast-shown .swal2-container{background-color:transparent}body.swal2-toast-shown .swal2-container.swal2-top{top:0;right:auto;bottom:auto;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-top-end,body.swal2-toast-shown .swal2-container.swal2-top-right{top:0;right:0;bottom:auto;left:auto}body.swal2-toast-shown .swal2-container.swal2-top-left,body.swal2-toast-shown .swal2-container.swal2-top-start{top:0;right:auto;bottom:auto;left:0}body.swal2-toast-shown .swal2-container.swal2-center-left,body.swal2-toast-shown .swal2-container.swal2-center-start{top:50%;right:auto;bottom:auto;left:0;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-center{top:50%;right:auto;bottom:auto;left:50%;transform:translate(-50%,-50%)}body.swal2-toast-shown .swal2-container.swal2-center-end,body.swal2-toast-shown .swal2-container.swal2-center-right{top:50%;right:0;bottom:auto;left:auto;transform:translateY(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-left,body.swal2-toast-shown .swal2-container.swal2-bottom-start{top:auto;right:auto;bottom:0;left:0}body.swal2-toast-shown .swal2-container.swal2-bottom{top:auto;right:auto;bottom:0;left:50%;transform:translateX(-50%)}body.swal2-toast-shown .swal2-container.swal2-bottom-end,body.swal2-toast-shown .swal2-container.swal2-bottom-right{top:auto;right:0;bottom:0;left:auto}body.swal2-toast-column .swal2-toast{flex-direction:column;align-items:stretch}body.swal2-toast-column .swal2-toast .swal2-actions{flex:1;align-self:stretch;height:2.2em;margin-top:.3125em}body.swal2-toast-column .swal2-toast .swal2-loading{justify-content:center}body.swal2-toast-column .swal2-toast .swal2-input{height:2em;margin:.3125em auto;font-size:1em}body.swal2-toast-column .swal2-toast .swal2-validation-message{font-size:1em}");;