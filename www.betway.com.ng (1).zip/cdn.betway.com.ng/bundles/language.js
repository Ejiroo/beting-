function debounce(n, t) {
    var i;
    return function() {
        var r = this,
            u = arguments,
            f = function() {
                i = null;
                n.apply(r, u)
            };
        clearTimeout(i);
        i = setTimeout(f, t || 200)
    }
}
var languageEnabled, languageOutcomesEnabled, currentLanguage, languageSets, outcomeSets, countryIsoCode, isDebugMode, removeLanguageSetsOlderThan, language = function() {
    var i = {},
        t = {};
    const h = "LanguageSets",
        c = "OutcomeSets",
        l = 864e5,
        e = "Global";
    var r = function(n, t, i, r) {
            isDebugMode && console.warn("[TRANSLATE] undefined: " + JSON.stringify({
                lang: currentLanguage,
                set: t,
                key: i,
                value: r
            }))
        },
        a = function(n) {
            const i = localStorage.getItem(n);
            if (!i) return null;
            const t = JSON.parse(i),
                r = new Date;
            return r.getTime() > t.expiry || t.created < new Date(removeLanguageSetsOlderThan).getTime() ? (localStorage.removeItem(n), null) : t
        },
        u = function() {
            (languageSets === null || languageSets === undefined) && ((languageSets === null || languageSets === undefined) && (languageSetsItem = a(h)), languageOutcomesEnabled && (outcomeSets === null || outcomeSets === undefined) && (outcomeSetsItem = a(c)), languageSetsItem == null || languageSetsItem.language !== currentLanguage ? $.ajax({
                type: "GET",
                url: "/Account/GetResourceSets",
                data: {
                    language: currentLanguage
                },
                async: !1,
                success: function(n) {
                    const r = new Date;
                    i = JSON.parse(n.LanguageSets);
                    const u = {
                        value: n.LanguageSets,
                        language: currentLanguage,
                        created: r.getTime(),
                        expiry: r.getTime() + l
                    };
                    if (localStorage.setItem(h, JSON.stringify(u)), languageOutcomesEnabled) {
                        t = JSON.parse(n.OutcomeSets);
                        const i = {
                            value: n.OutcomeSets,
                            language: currentLanguage,
                            created: r.getTime(),
                            expiry: r.getTime() + l
                        };
                        localStorage.setItem(c, JSON.stringify(i))
                    }
                }
            }) : (languageSets = languageSetsItem.value, i = JSON.parse(languageSets), languageOutcomesEnabled && (outcomeSets = outcomeSetsItem.value, t = JSON.parse(outcomeSets))))
        },
        n = function(n, t) {
            try {
                return i[n][t.toUpperCase()]
            } catch (r) {
                return isDebugMode && console.error(r), undefined
            }
        },
        w = function(t, i, u) {
            n(i, u) === undefined ? r(t, i, u, $(t).attr("href")) : $(t).attr("href", "mailto:" + n(i, u))
        },
        f = function(t, i, u) {
            n(i, u) === undefined ? r(t, i, u, $(t).text()) : $(t).html(n(i, u))
        },
        b = function(n, t) {
            var i = $(n).data("translate-type");
            $(n).find("option").each(function() {
                var n = $(this).attr("data-translate-key");
                return (n === undefined || n === null) && (n = language.generateKey(this.text), $(this).attr("data-translate-key", n)), f($(this), t, n), i === "select-option-label" ? !1 : void 0
            })
        },
        v = function(t, i, u) {
            f(t, i, u);
            n(i, u) !== undefined && [].forEach.call(t.get(0).attributes, function(u) {
                var f, c, h, l;
                if (u.name.indexOf("data-translate-value-") >= 0 && u.value !== undefined && u.value !== "") {
                    var a = $(t).html(),
                        e = u.name.split("data-translate-value-").pop(),
                        o = u.value,
                        s = u.value;
                    $(t).attr("data-translate-replace-value-" + e) === "true" && (f = "", $(t).attr("data-translate-replace-value-" + e + "-tag") !== undefined ? (c = $(t).attr("data-translate-replace-value-" + e + "-tag"), h = y(o, c), f = language.generateKey(h)) : f = language.generateKey(u.value), $(t).attr("data-translate-replace-value-" + e + "-key", f), o = n(i, f) || s, n(i, f) === undefined && r(t, i, f, s), $(t).attr("data-translate-replace-value-" + e + "-tag") !== undefined && (o = s.replace(h, o)));
                    l = a.replace("{" + e + "}", o);
                    $(t).html(l)
                }
            })
        },
        o = function(t, i, u, f) {
            n(u, f) === undefined ? r(t, u, f, $(t).attr(i)) : ($(t).attr(i, n(u, f)), [].forEach.call(t.get(0).attributes, function(f) {
                var e, l, c, a;
                if (f.name.indexOf("data-translate-value-") >= 0 && f.value !== undefined && f.value !== "") {
                    var v = $(t).attr(i),
                        o = f.name.split("data-translate-value-").pop(),
                        s = f.value,
                        h = f.value;
                    $(t).attr("data-translate-replace-value-" + o) === "true" && (e = "", $(t).attr("data-translate-replace-value-" + o + "-tag") !== undefined ? (l = $(t).attr("data-translate-replace-value-" + o + "-tag"), c = y(s, l), e = language.generateKey(c)) : e = language.generateKey(f.value), $(t).attr("data-translate-replace-value-" + o + "-key", e), s = n(u, e) || h, n(u, e) === undefined && r(t, u, e, h), $(t).attr("data-translate-replace-value-" + o + "-tag") !== undefined && (s = h.replace(c, s)));
                    a = v.replace("{" + o + "}", s);
                    $(t).attr(i, a)
                }
            }))
        },
        y = function(n, t) {
            var i = document.createElement(t);
            return i.innerHTML = n, i.textContent || i.innerText
        },
        k = function(t, i) {
            var f = $(t).data("translate-type"),
                u = $(t).attr("data-translate-key"),
                e, s;
            (u === undefined || u === null) && (e = "", e = f === "background-image" ? $(t).css("background-image") : $(t).attr("src"), s = ft(e), u = language.generateKey(s), $(t).attr("data-translate-key", u));
            f === "background-image" ? n(i, u) === undefined ? r(t, i, u, f) : $(t).css("background-image", "url('" + n(i, u) + "')") : (o(t, "src", i, u), o(t, "alt", i, u))
        },
        d = function() {
            const n = "ErrorMessages";
            nt(n);
            it(n);
            g(n);
            tt(n)
        },
        g = function(n) {
            var t = ["data-val-required", "data-val-remote", "data-val-email", "data-val-url", "data-val-date", "data-val-dateISO", "data-val-number", "data-val-creditcard", "data-val-equalTo", "data-val-accept", "data-val-maxlength", "data-val-minlength", "data-val-rangelength", "data-val-range", "data-val-max", "data-val-min", "data-val-regex", "title"];
            $("input[data-val], textarea[data-val], select[data-val]").each(function() {
                var i = $(this);
                [].forEach.call(i.get(0).attributes, function(r) {
                    var e, u, h, s;
                    _.contains(t, r.name) && r.value !== undefined && r.value !== "" && ($(i).attr("data-translate-set", n), e = r.name + "-translate-key", u = $(i).attr(e), (typeof u == typeof undefined || u === !1) && (u = language.generateKey(r.value), $(i).attr(e, u)), o(i, r.name, n, u), h = $(i).attr("name"), s = $("form").find("[data-valmsg-for='" + h + "']"), $(s).is(":empty") || f(s, n, u))
                })
            })
        },
        nt = function(t) {
            var i = $("form");
            i.data("validator", null);
            $.validator.unobtrusive.parse(i);
            $('[name = "MobileNumber"]').rules("add", {
                messages: {
                    maxlength: n(t, "InvalidMobileNumber") || "Invalid mobile number",
                    required: n(t, "EnterAMobileNumber") || "Enter a mobile number"
                }
            })
        },
        tt = function(n) {
            var t = [{
                message: "Mobile number {0} has already been registered",
                regex: /Mobile number (.*) has already been registered/,
                key: "ReferAFriendMobileNumberAlreadyRegistered"
            }, {
                message: "Mobile number {0} has already been referred",
                regex: /Mobile number (.*) has already been referred/,
                key: "ReferAFriendMobileNumberAlreadyReferred"
            }, {
                message: "You have exceeded the number of referrals for mobile number: {0}",
                regex: /You have exceeded the number of referrals for mobile number: (.*)/,
                key: "ReferAFriendExceededMaxReferrals"
            }];
            $(".validation-summary-errors ul li, .number-error-message, .error-message p, .error-message span, .field-validation-error").each(function() {
                var i = $(this);
                $(i).attr("data-translate-set", n);
                [].forEach.call(t, function(t) {
                    var r;
                    const u = t.regex.exec(i.text());
                    if (u !== undefined && u !== null) {
                        u.shift();
                        var o = t.message.replace(/\{0}/g, "%s"),
                            e = 0,
                            s = o.replace(/%s/g, function() {
                                return u.slice(e, ++e)
                            });
                        s === i.text() && ($(i).attr("data-translate-type", "generic-html"), $(i).attr("data-translate-key", t.key), u.forEach(function(n, t) {
                            $(i).attr("data-translate-value-" + t, n)
                        }), v(i, n, t.key))
                    } else r = $(i).attr("data-translate-key"), (r === undefined || r === null) && (r = language.generateKey(i.text())), r !== undefined && r !== null && r !== "" && ($(i).attr("data-translate-key", r), f(i, n, r))
                })
            })
        },
        it = function(t) {
            jQuery.extend(jQuery.validator.messages, {
                required: n(t, "required") || "This field is required.",
                remote: n(t, "remote") || "Please fix this field.",
                email: n(t, "email") || "Please enter a valid email address.",
                url: n(t, "url") || "Please enter a valid URL.",
                date: n(t, "date") || "Please enter a valid date.",
                dateISO: n(t, "dateISO") || "Please enter a valid date (ISO).",
                number: n(t, "number") || "Please enter a valid number.",
                digits: n(t, "digits") || "Please enter only digits.",
                equalTo: n(t, "equalTo") || "Please enter the same value again.",
                maxlength: $.validator.format(n(t, "maxlength") || "Please enter no more than {0} characters."),
                minlength: $.validator.format(n(t, "minlength") || "Please enter at least {0} characters."),
                rangelength: $.validator.format(n(t, "rangelength") || "Please enter a value between {0} and {1} characters long."),
                range: $.validator.format(n(t, "range") || "Please enter a value between {0} and {1}."),
                max: $.validator.format(n(t, "max") || "Please enter a value less than or equal to {0}."),
                min: $.validator.format(n(t, "min") || "Please enter a value greater than or equal to {0}."),
                step: $.validator.format(n(t, "step") || "Please enter a multiple of {0}."),
                ValidSaIdNumber: n(t, "ValidSaIdNumber") || "Please enter a valid SA ID Number.",
                ValidIdentityType: n(t, "ValidIdentityType") || "This field is in incorrect format."
            })
        },
        rt = function(n, i, r, u) {
            var a, h, v, f, s, o, y, k, d, g, nt, w, tt, it, rt, ut, b, c, ft, et, l;
            if (languageOutcomesEnabled === !0) try {
                const ct = p(t[e], n.text());
                if (ct !== null) $(n).html(ct);
                else {
                    r = r.trim();
                    a = t;
                    for (h in a)
                        if (h === i) {
                            v = a[h];
                            for (f in v) {
                                if (f.indexOf("ALIAS=") !== -1 ? (y = f.split(/ALIAS=\s?/), s = y[0], o = y[1]) : s = f, s.indexOf("{0}") !== -1) {
                                    d = s.replace(/[-\/\\^$*+?.()|[\]]/g, "\\$&").replace(/\{0}/g, "(.*)");
                                    g = new RegExp(d, "g");
                                    const n = g.exec(r);
                                    n !== undefined && n !== null && (n.shift(), nt = s.replace(/\{0}/g, "%s"), w = 0, k = nt.replace(/%s/g, function() {
                                        return n.slice(w, ++w)
                                    }))
                                }
                                if (o !== undefined && o !== null && o.indexOf("{0}") !== -1) {
                                    it = o.replace(/[-\/\\^$*+?.()|[\]]/g, "\\$&").replace(/\{0}/g, "(.*)");
                                    rt = new RegExp(it, "g");
                                    const n = rt.exec(r);
                                    n !== undefined && n !== null && (n.shift(), ut = o.replace(/\{0}/g, "%s"), b = 0, tt = ut.replace(/%s/g, function() {
                                        return n.slice(b, ++b)
                                    }))
                                }
                                if (k === r || tt === r || s === r || o === r)
                                    for (c in v[f])
                                        if (c.indexOf("{0}") !== -1) {
                                            ft = c.replace(/[-\/\\^$*+?.()|[\]]/g, "\\$&").replace(/\{0}/g, "(.*)");
                                            et = new RegExp(ft, "g");
                                            const i = et.exec(u);
                                            if (i !== undefined && i !== null) {
                                                i.shift();
                                                var st = c.replace(/\{0}/g, "%s"),
                                                    ot = 0,
                                                    ht = st.replace(/%s/g, function() {
                                                        return i.slice(ot, ++ot)
                                                    });
                                                if (ht === u) {
                                                    i.forEach(function(t, i) {
                                                        $(n).attr("data-translate-value-" + i, t)
                                                    });
                                                    l = t[h][f][c];
                                                    [].forEach.call(n.get(0).attributes, function(n) {
                                                        if (n.name.indexOf("data-translate-value-") >= 0 && n.value !== undefined && n.value !== "") {
                                                            var r = n.name.split("data-translate-value-").pop(),
                                                                i = n.value;
                                                            const u = p(t[e], i);
                                                            u !== null && (i = u);
                                                            l = l.replace("{" + r + "}", i)
                                                        }
                                                    });
                                                    $(n).html(l);
                                                    break
                                                }
                                            }
                                        } else {
                                            $(n).html(t[h][f][u]);
                                            break
                                        }
                            }
                            break
                        }
                }
            } catch (ct) {
                isDebugMode && console.error(ct)
            }
        },
        p = function(n, t) {
            var i, u, r, f;
            try {
                if (n == undefined && n == null) return null;
                const e = Object.keys(n);
                if (e == undefined && e == null) return null;
                if (t = t.trim(), e.findIndex(n => n.toLowerCase() === t.toLowerCase()) > -1) return n[t];
                const o = " or ",
                    s = n[o.trim()];
                return i = t, t.includes(o) || t.includes(s) ? (t.includes(s) ? u = t.split(s) : (u = t.split(o), i = i.replace(o.trim(), n[o.trim()])), r = u[0], f = u[1], e.findIndex(n => n.toLowerCase() === r.toLowerCase()) > -1 && (i = i.replace(r, n[r]))) : e.findIndex(n => n.toLowerCase() === r.toLowerCase()) > -1 && (i = i.replace(r, n[r])), e.findIndex(n => n.toLowerCase() === f.toLowerCase()) > -1 && (i = i.replace(f, n[f])), i
            } catch (e) {
                return null
            }
        },
        ut = function(n) {
            var r, s;
            try {
                if (globalDictionary = t[e], globalDictionary !== undefined && globalDictionary !== null) {
                    const t = Object.keys(globalDictionary);
                    if (r = n.text(), r.includes(" v ")) {
                        var f = r,
                            i = r.split(" v "),
                            u = i[0],
                            o = i[1];
                        u.includes("Id: ") ? (i = u.split(" "), s = i[i.length - 1], t.findIndex(n => n.toLowerCase() === s.toLowerCase()) > -1 && (i[i.length - 1] = globalDictionary[s], f = r.replace(u, i.join(" ")))) : t.findIndex(n => n.toLowerCase() === u.toLowerCase()) > -1 && (f = r.replace(u, globalDictionary[u]));
                        t.findIndex(n => n.toLowerCase() === o.toLowerCase()) > -1 && (f = f.replace(o, globalDictionary[o]));
                        $(n).html(f)
                    }
                }
            } catch (h) {
                isDebugMode && console.error(h)
            }
        },
        ft = function(n) {
            var t = n.lastIndexOf("/") + 1;
            return n.substr(t)
        },
        et = function(n) {
            return n.replace(/(?:^|\s)\w/g, function(n) {
                return n.toUpperCase()
            })
        },
        s = function(n, r, u) {
            var e, s;
            i !== undefined && i !== null && r !== undefined && r !== null && (u === "select" || u === "select-option-label" ? b(n, r) : u === "image" || u === "background-image" ? k(n, r) : (e = n.attr("data-translate-key"), e !== undefined && e !== null && (u === "placeholder" || u === "title" || u === "value" ? o(n, u, r, e) : u === "generic-html" ? v(n, r, e) : u === "outcome" ? t !== undefined && t !== null && (s = n.attr("data-translate-market"), rt(n, r, s, e)) : u === "event" ? t !== undefined && t !== null && ut(n, r, e) : u === "mailto" ? w(n, r, e) : f(n, r, e))))
        };
    return {
        init: function() {
            u();
            language.translate()
        },
        setLanguageAttribute: function() {
            var n = document.querySelector("html");
            n.setAttribute("lang", "en-" + countryIsoCode)
        },
        changeLanguage: function(n) {
            languageEnabled === !0 && $.ajax({
                type: "POST",
                url: "/Account/ChangeLanguage",
                data: {
                    language: n
                },
                success: function() {
                    window.location.reload()
                }
            })
        },
        handleLanguageChange: function(n, t = false) {
            var i, r;
            languageEnabled === !0 && (t ? (n = $('option[value^="' + n.toLowerCase() + '"]').val(), n != null && (r = $("#chooseLanguage").val(), n.toLowerCase() !== r.toLowerCase() && this.changeLanguage(n))) : (i = new URL(location.href), i.searchParams.set("lang", n), history.pushState({}, "newLang", i.href), this.changeLanguage(n)))
        },
        generateKey: function(n) {
            if (languageEnabled === !0) {
                if (n === undefined || n === null) return;
                try {
                    var i = et(n).replace(/\s/g, ""),
                        t = i.replace(/[^a-z0-9\s]/gi, "").replace(/[_\s]/g, "-");
                    return t === undefined || t === null ? void 0 : t
                } catch (r) {
                    return isDebugMode && console.error(r), !1
                }
            }
        },
        removeTranslateAttributes: function(n) {
            if (languageEnabled === !0) try {
                [].forEach.call(n.get(0).attributes, function(t) {
                    t.name.startsWith("data-translate-") && $(n).removeAttr(t.name)
                })
            } catch (t) {
                return isDebugMode && console.error(t), !1
            }
        },
        translateSection: function(n) {
            if (languageEnabled === !0) try {
                u();
                $("#" + n).find("[data-translate-set]").each(function() {
                    var n = $(this),
                        t = n.data("translate-set"),
                        i = n.data("translate-type");
                    s(n, t, i)
                })
            } catch (t) {
                return isDebugMode && console.error(t), !1
            }
        },
        translateWidgetSearchTerm: function(n) {
            if (languageEnabled === !0 && languageOutcomesEnabled === !0) {
                if (u(), t == undefined && t == null) return n;
                try {
                    if (globalDictionary = t[e], globalDictionary !== undefined && globalDictionary !== null && n.trim() !== "") {
                        var i = Object.getOwnPropertyNames(globalDictionary).find(t => globalDictionary[t].toLowerCase().includes(n.toLowerCase()));
                        if (i !== undefined) return i
                    }
                } catch (r) {
                    return isDebugMode && console.error(r), n
                }
            }
            return n
        },
        translateAtRuntime: function(n, t, r) {
            if (languageEnabled === !0) try {
                u();
                $(n).attr("data-translate-set", t);
                $.each(r, function(t, i) {
                    $(n).attr(t, i)
                });
                var f = $(n).data("translate-type");
                i !== undefined && i !== null && s($(n), t, f)
            } catch (e) {
                return isDebugMode && console.error(e), !1
            }
        },
        translate: debounce(function() {
            if (languageEnabled === !0) try {
                u();
                i !== null && i !== undefined && (d(), $("[data-translate-set]").each(function() {
                    var n = $(this),
                        t = n.data("translate-set"),
                        i = n.data("translate-type");
                    s(n, t, i)
                }))
            } catch (n) {
                return isDebugMode && console.error(n), !1
            }
        }, 100)
    }
}();
(function() {
    languageEnabled === !0 && language.init()
})();
window.addEventListener("load", function() {
    language.setLanguageAttribute()
})