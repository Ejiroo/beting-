var currentHistoryFilters, sportFilters, filterOptions;
(function(n) {
    function it(n, t, i) {
        switch (arguments.length) {
            case 2:
                return null != n ? n : t;
            case 3:
                return null != n ? n : null != t ? t : i;
            default:
                throw new Error("Implement me");
        }
    }

    function g(n, t) {
        return kr.call(n, t)
    }

    function yi(n) {
        !1 === t.suppressDeprecationWarnings && "undefined" != typeof console && console.warn && console.warn("Deprecation warning: " + n)
    }

    function o(n, t) {
        var i = !0;
        return nt(function() {
            return i && (yi(n), i = !1), t.apply(this, arguments)
        }, t)
    }

    function pi(n, t) {
        return function(i) {
            return r(n.call(this, i), t)
        }
    }

    function wu(n, t) {
        return function(i) {
            return this.localeData().ordinal(n.call(this, i), t)
        }
    }

    function wi() {}

    function ft(n, i) {
        !1 !== i && fr(n);
        bi(this, n);
        this._d = new Date(+n._d);
        !1 === at && (at = !0, t.updateOffset(this), at = !1)
    }

    function vt(n) {
        var i = tr(n),
            r = i.year || 0,
            u = i.quarter || 0,
            f = i.month || 0,
            e = i.week || 0,
            o = i.day || 0,
            s = i.hour || 0,
            h = i.minute || 0,
            c = i.second || 0,
            l = i.millisecond || 0;
        this._milliseconds = +l + 1e3 * c + 6e4 * h + 36e5 * s;
        this._days = +o + 7 * e;
        this._months = +f + 3 * u + 12 * r;
        this._data = {};
        this._locale = t.localeData();
        this._bubble()
    }

    function nt(n, t) {
        for (var i in t) g(t, i) && (n[i] = t[i]);
        return g(t, "toString") && (n.toString = t.toString), g(t, "valueOf") && (n.valueOf = t.valueOf), n
    }

    function bi(n, t) {
        var i, r, u;
        if (void 0 !== t._isAMomentObject && (n._isAMomentObject = t._isAMomentObject), void 0 !== t._i && (n._i = t._i), void 0 !== t._f && (n._f = t._f), void 0 !== t._l && (n._l = t._l), void 0 !== t._strict && (n._strict = t._strict), void 0 !== t._tzm && (n._tzm = t._tzm), void 0 !== t._isUTC && (n._isUTC = t._isUTC), void 0 !== t._offset && (n._offset = t._offset), void 0 !== t._pf && (n._pf = t._pf), void 0 !== t._locale && (n._locale = t._locale), rt.length > 0)
            for (i in rt) void 0 !== (u = t[r = rt[i]]) && (n[r] = u);
        return n
    }

    function h(n) {
        return n < 0 ? Math.ceil(n) : Math.floor(n)
    }

    function r(n, t, i) {
        for (var r = "" + Math.abs(n), u = n >= 0; r.length < t;) r = "0" + r;
        return (u ? i ? "+" : "" : "-") + r
    }

    function ki(n, t) {
        var i = {
            milliseconds: 0,
            months: 0
        };
        return i.months = t.month() - n.month() + 12 * (t.year() - n.year()), n.clone().add(i.months, "M").isAfter(t) && --i.months, i.milliseconds = +t - +n.clone().add(i.months, "M"), i
    }

    function di(n, i) {
        return function(r, u) {
            var f, e, o;
            return null === u || isNaN(+u) || (o = "moment()." + i + "(period, number) is deprecated. Please use moment()." + i + "(number, period).", ai[e = i] || (yi(o), ai[e] = !0), f = r, r = u, u = f), r = "string" == typeof r ? +r : r, gi(this, t.duration(r, u), n), this
        }
    }

    function gi(n, i, r, u) {
        var o = i._milliseconds,
            f = i._days,
            e = i._months;
        u = null == u || u;
        o && n._d.setTime(+n._d + o * r);
        f && yr(n, "Date", ti(n, "Date") + f * r);
        e && vr(n, ti(n, "Month") + e * r);
        u && t.updateOffset(n, f || e)
    }

    function et(n) {
        return "[object Array]" === Object.prototype.toString.call(n)
    }

    function yt(n) {
        return "[object Date]" === Object.prototype.toString.call(n) || n instanceof Date
    }

    function nr(n, t, r) {
        for (var e = Math.min(n.length, t.length), o = Math.abs(n.length - t.length), f = 0, u = 0; u < e; u++)(r && n[u] !== t[u] || !r && i(n[u]) !== i(t[u])) && f++;
        return f + o
    }

    function e(n) {
        if (n) {
            var t = n.toLowerCase().replace(/(.)s$/, "$1");
            n = yu[n] || pu[t] || t
        }
        return n
    }

    function tr(n) {
        var i, t, r = {};
        for (t in n) g(n, t) && (i = e(t)) && (r[i] = n[t]);
        return r
    }

    function bu(i) {
        var r, u;
        if (0 === i.indexOf("week")) r = 7, u = "day";
        else {
            if (0 !== i.indexOf("month")) return;
            r = 12;
            u = "month"
        }
        t[i] = function(f, e) {
            var o, s, c = t._locale[i],
                h = [];
            if ("number" == typeof f && (e = f, f = n), s = function(n) {
                    var i = t().utc().set(u, n);
                    return c.call(t._locale, i, f || "")
                }, null != e) return s(e);
            for (o = 0; o < r; o++) h.push(s(o));
            return h
        }
    }

    function i(n) {
        var t = +n,
            i = 0;
        return 0 !== t && isFinite(t) && (i = t >= 0 ? Math.floor(t) : Math.ceil(t)), i
    }

    function pt(n, t) {
        return new Date(Date.UTC(n, t + 1, 0)).getUTCDate()
    }

    function ir(n, i, r) {
        return tt(t([n, 11, 31 + i - r]), i, r).week
    }

    function rr(n) {
        return ur(n) ? 366 : 365
    }

    function ur(n) {
        return n % 4 == 0 && n % 100 != 0 || n % 400 == 0
    }

    function fr(n) {
        var t;
        n._a && -2 === n._pf.overflow && (t = n._a[l] < 0 || n._a[l] > 11 ? l : n._a[s] < 1 || n._a[s] > pt(n._a[c], n._a[l]) ? s : n._a[f] < 0 || n._a[f] > 24 || 24 === n._a[f] && (0 !== n._a[w] || 0 !== n._a[b] || 0 !== n._a[k]) ? f : n._a[w] < 0 || n._a[w] > 59 ? w : n._a[b] < 0 || n._a[b] > 59 ? b : n._a[k] < 0 || n._a[k] > 999 ? k : -1, n._pf._overflowDayOfYear && (t < c || t > s) && (t = s), n._pf.overflow = t)
    }

    function er(t) {
        return null == t._isValid && (t._isValid = !isNaN(t._d.getTime()) && t._pf.overflow < 0 && !t._pf.empty && !t._pf.invalidMonth && !t._pf.nullInput && !t._pf.invalidFormat && !t._pf.userInvalidated, t._strict && (t._isValid = t._isValid && 0 === t._pf.charsLeftOver && 0 === t._pf.unusedTokens.length && t._pf.bigHour === n)), t._isValid
    }

    function or(n) {
        return n ? n.toLowerCase().replace("_", "-") : n
    }

    function sr(n) {
        var i = null;
        if (!d[n] && ri) try {
            i = t.locale();
            require("./locale/" + n);
            t.locale(i)
        } catch (n) {}
        return d[n]
    }

    function wt(n, i) {
        var r, u;
        return i._isUTC ? (r = i.clone(), u = (t.isMoment(n) || yt(n) ? +n : +t(n)) - +r, r._d.setTime(+r._d + u), t.updateOffset(r, !1), r) : t(n).local()
    }

    function bt(n, t) {
        return n.isValid() ? (t = hr(t, n.localeData()), lt[t] || (lt[t] = function(n) {
            for (var u, i = n.match(ui), t = 0, r = i.length; t < r; t++) i[t] = a[i[t]] ? a[i[t]] : (u = i[t]).match(/\[[\s\S]/) ? u.replace(/^\[|\]$/g, "") : u.replace(/\\/g, "");
            return function(u) {
                var f = "";
                for (t = 0; t < r; t++) f += i[t] instanceof Function ? i[t].call(u, n) : i[t];
                return f
            }
        }(t)), lt[t](n)) : n.localeData().invalidDate()
    }

    function hr(n, t) {
        function r(n) {
            return t.longDateFormat(n) || n
        }
        var i = 5;
        for (ut.lastIndex = 0; i >= 0 && ut.test(n);) n = n.replace(ut, r), ut.lastIndex = 0, i -= 1;
        return n
    }

    function ku(n, t) {
        var r, i = t._strict;
        switch (n) {
            case "Q":
                return ei;
            case "DDDD":
                return si;
            case "YYYY":
            case "GGGG":
            case "gggg":
                return i ? hu : iu;
            case "Y":
            case "G":
            case "g":
                return lu;
            case "YYYYYY":
            case "YYYYY":
            case "GGGGG":
            case "ggggg":
                return i ? cu : ru;
            case "S":
                if (i) return ei;
            case "SS":
                if (i) return oi;
            case "SSS":
                if (i) return si;
            case "DDD":
                return tu;
            case "MMM":
            case "MMMM":
            case "dd":
            case "ddd":
            case "dddd":
                return fu;
            case "a":
            case "A":
                return t._locale._meridiemParse;
            case "x":
                return ou;
            case "X":
                return su;
            case "Z":
            case "ZZ":
                return st;
            case "T":
                return eu;
            case "SSSS":
                return uu;
            case "MM":
            case "DD":
            case "YY":
            case "GG":
            case "gg":
            case "HH":
            case "hh":
            case "mm":
            case "ss":
            case "ww":
            case "WW":
                return i ? oi : fi;
            case "M":
            case "D":
            case "d":
            case "H":
            case "h":
            case "m":
            case "s":
            case "w":
            case "W":
            case "e":
            case "E":
                return fi;
            case "Do":
                return i ? t._locale._ordinalParse : t._locale._ordinalParseLenient;
            default:
                return new RegExp((r = n.replace("\\", ""), r.replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(n, t, i, r, u) {
                    return t || i || r || u
                }).replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")))
        }
    }

    function kt(n) {
        var r = (n = n || "").match(st) || [],
            t = ((r[r.length - 1] || []) + "").match(vu) || ["-", 0, 0],
            u = 60 * t[1] + i(t[2]);
        return "+" === t[0] ? u : -u
    }

    function du(n, r, u) {
        var o, e = u._a;
        switch (n) {
            case "Q":
                null != r && (e[l] = 3 * (i(r) - 1));
                break;
            case "M":
            case "MM":
                null != r && (e[l] = i(r) - 1);
                break;
            case "MMM":
            case "MMMM":
                null != (o = u._locale.monthsParse(r, n, u._strict)) ? e[l] = o : u._pf.invalidMonth = r;
                break;
            case "D":
            case "DD":
                null != r && (e[s] = i(r));
                break;
            case "Do":
                null != r && (e[s] = i(parseInt(r.match(/\d{1,2}/)[0], 10)));
                break;
            case "DDD":
            case "DDDD":
                null != r && (u._dayOfYear = i(r));
                break;
            case "YY":
                e[c] = t.parseTwoDigitYear(r);
                break;
            case "YYYY":
            case "YYYYY":
            case "YYYYYY":
                e[c] = i(r);
                break;
            case "a":
            case "A":
                u._meridiem = r;
                break;
            case "h":
            case "hh":
                u._pf.bigHour = !0;
            case "H":
            case "HH":
                e[f] = i(r);
                break;
            case "m":
            case "mm":
                e[w] = i(r);
                break;
            case "s":
            case "ss":
                e[b] = i(r);
                break;
            case "S":
            case "SS":
            case "SSS":
            case "SSSS":
                e[k] = i(1e3 * ("0." + r));
                break;
            case "x":
                u._d = new Date(i(r));
                break;
            case "X":
                u._d = new Date(1e3 * parseFloat(r));
                break;
            case "Z":
            case "ZZ":
                u._useUTC = !0;
                u._tzm = kt(r);
                break;
            case "dd":
            case "ddd":
            case "dddd":
                null != (o = u._locale.weekdaysParse(r)) ? (u._w = u._w || {}, u._w.d = o) : u._pf.invalidWeekday = r;
                break;
            case "w":
            case "ww":
            case "W":
            case "WW":
            case "d":
            case "e":
            case "E":
                n = n.substr(0, 1);
            case "gggg":
            case "GGGG":
            case "GGGGG":
                n = n.substr(0, 2);
                r && (u._w = u._w || {}, u._w[n] = i(r));
                break;
            case "gg":
            case "GG":
                u._w = u._w || {};
                u._w[n] = t.parseTwoDigitYear(r)
        }
    }

    function gu(n) {
        var i, v, e, o, r, s, y, h, p, l, w, f, a, u;
        null != (i = n._w).GG || null != i.W || null != i.E ? (r = 1, s = 4, v = it(i.GG, n._a[c], tt(t(), 1, 4).year), e = it(i.W, 1), o = it(i.E, 1)) : (r = n._locale._week.dow, s = n._locale._week.doy, v = it(i.gg, n._a[c], tt(t(), r, s).year), e = it(i.w, 1), null != i.d ? (o = i.d) < r && ++e : o = null != i.e ? i.e + r : r);
        p = e;
        l = o;
        w = s;
        f = r;
        u = 0 === (u = ni(h = v, 0, 1).getUTCDay()) ? 7 : u;
        y = {
            year: (a = 7 * (p - 1) + ((l = null != l ? l : f) - f) + (f - u + (u > w ? 7 : 0) - (u < f ? 7 : 0)) + 1) > 0 ? h : h - 1,
            dayOfYear: a > 0 ? a : rr(h - 1) + a
        };
        n._a[c] = y.year;
        n._dayOfYear = y.dayOfYear
    }

    function dt(n) {
        var t, r, u, e, o = [],
            h, i;
        if (!n._d) {
            for (h = n, i = new Date, u = h._useUTC ? [i.getUTCFullYear(), i.getUTCMonth(), i.getUTCDate()] : [i.getFullYear(), i.getMonth(), i.getDate()], n._w && null == n._a[s] && null == n._a[l] && gu(n), n._dayOfYear && (e = it(n._a[c], u[c]), n._dayOfYear > rr(e) && (n._pf._overflowDayOfYear = !0), r = ni(e, 0, n._dayOfYear), n._a[l] = r.getUTCMonth(), n._a[s] = r.getUTCDate()), t = 0; t < 3 && null == n._a[t]; ++t) n._a[t] = o[t] = u[t];
            for (; t < 7; t++) n._a[t] = o[t] = null == n._a[t] ? 2 === t ? 1 : 0 : n._a[t];
            24 === n._a[f] && 0 === n._a[w] && 0 === n._a[b] && 0 === n._a[k] && (n._nextDay = !0, n._a[f] = 0);
            n._d = (n._useUTC ? ni : function(n, t, i, r, u, f, e) {
                var o = new Date(n, t, i, r, u, f, e);
                return n < 1970 && o.setFullYear(n), o
            }).apply(null, o);
            null != n._tzm && n._d.setUTCMinutes(n._d.getUTCMinutes() - n._tzm);
            n._nextDay && (n._a[f] = 24)
        }
    }

    function gt(i) {
        if (i._f !== t.ISO_8601) {
            i._a = [];
            i._pf.empty = !0;
            for (var e, o, v, s, r, l, y, u = "" + i._i, w = u.length, p = 0, c = hr(i._f, i._locale).match(ui) || [], h = 0; h < c.length; h++) o = c[h], (e = (u.match(ku(o, i)) || [])[0]) && ((v = u.substr(0, u.indexOf(e))).length > 0 && i._pf.unusedInput.push(v), u = u.slice(u.indexOf(e) + e.length), p += e.length), a[o] ? (e ? i._pf.empty = !1 : i._pf.unusedTokens.push(o), du(o, e, i)) : i._strict && !e && i._pf.unusedTokens.push(o);
            i._pf.charsLeftOver = w - p;
            u.length > 0 && i._pf.unusedInput.push(u);
            !0 === i._pf.bigHour && i._a[f] <= 12 && (i._pf.bigHour = n);
            i._a[f] = (s = i._locale, r = i._a[f], null == (l = i._meridiem) ? r : null != s.meridiemHour ? s.meridiemHour(r, l) : null != s.isPM ? ((y = s.isPM(l)) && r < 12 && (r += 12), y || 12 !== r || (r = 0), r) : r);
            dt(i);
            fr(i)
        } else cr(i)
    }

    function cr(n) {
        var t, i, r = n._i,
            u = au.exec(r);
        if (u) {
            for (n._pf.iso = !0, t = 0, i = ht.length; t < i; t++)
                if (ht[t][1].exec(r)) {
                    n._f = ht[t][0] + (u[6] || " ");
                    break
                }
            for (t = 0, i = ct.length; t < i; t++)
                if (ct[t][1].exec(r)) {
                    n._f += ct[t][0];
                    break
                }
            r.match(st) && (n._f += "Z");
            gt(n)
        } else n._isValid = !1
    }

    function nf(i) {
        var o, f, u, e, r = i._i;
        r === n ? i._d = new Date : yt(r) ? i._d = new Date(+r) : null !== (o = dr.exec(r)) ? i._d = new Date(+o[1]) : "string" == typeof r ? (cr(e = i), !1 === e._isValid && (delete e._isValid, t.createFromInputFallback(e))) : et(r) ? (i._a = function(n, t) {
            for (var r = [], i = 0; i < n.length; ++i) r.push(t(n[i], i));
            return r
        }(r.slice(0), function(n) {
            return parseInt(n, 10)
        }), dt(i)) : "object" == typeof r ? (f = i)._d || (u = tr(f._i), f._a = [u.year, u.month, u.day || u.date, u.hour, u.minute, u.second, u.millisecond], dt(f)) : "number" == typeof r ? i._d = new Date(r) : t.createFromInputFallback(i)
    }

    function ni(n) {
        var t = new Date(Date.UTC.apply(null, arguments));
        return n < 1970 && t.setUTCFullYear(n), t
    }

    function tt(n, i, r) {
        var f, e = r - i,
            u = r - n.day();
        return u > e && (u -= 7), u < e - 7 && (u += 7), f = t(n).add(u, "d"), {
            week: Math.ceil(f.dayOfYear() / 7),
            year: f.year()
        }
    }

    function lr(i) {
        var u, r = i._i,
            f = i._f;
        return i._locale = i._locale || t.localeData(i._l), null === r || f === n && "" === r ? t.invalid({
            nullInput: !0
        }) : ("string" == typeof r && (i._i = r = i._locale.preparse(r)), t.isMoment(r) ? new ft(r, !0) : (f ? et(f) ? function(n) {
            var t, f, u, r, i;
            if (0 === n._f.length) return n._pf.invalidFormat = !0, void(n._d = new Date(NaN));
            for (r = 0; r < n._f.length; r++) i = 0, t = bi({}, n), null != n._useUTC && (t._useUTC = n._useUTC), t._pf = {
                empty: !1,
                unusedTokens: [],
                unusedInput: [],
                overflow: -2,
                charsLeftOver: 0,
                nullInput: !1,
                invalidMonth: null,
                invalidFormat: !1,
                userInvalidated: !1,
                iso: !1
            }, t._f = n._f[r], gt(t), er(t) && (i += t._pf.charsLeftOver, i += 10 * t._pf.unusedTokens.length, t._pf.score = i, (null == u || i < u) && (u = i, f = t));
            nt(n, f || t)
        }(i) : gt(i) : nf(i), (u = new ft(i))._nextDay && (u.add(1, "d"), u._nextDay = n), u))
    }

    function ar(n, i) {
        var u, r;
        if (1 === i.length && et(i[0]) && (i = i[0]), !i.length) return t();
        for (u = i[0], r = 1; r < i.length; ++r) i[r][n](u) && (u = i[r]);
        return u
    }

    function vr(n, t) {
        var i;
        return "string" == typeof t && "number" != typeof(t = n.localeData().monthsParse(t)) ? n : (i = Math.min(n.date(), pt(n.year(), t)), n._d["set" + (n._isUTC ? "UTC" : "") + "Month"](t, i), n)
    }

    function ti(n, t) {
        return n._d["get" + (n._isUTC ? "UTC" : "") + t]()
    }

    function yr(n, t, i) {
        return "Month" === t ? vr(n, i) : n._d["set" + (n._isUTC ? "UTC" : "") + t](i)
    }

    function v(n, i) {
        return function(r) {
            return null != r ? (yr(this, n, r), t.updateOffset(this, i), this) : ti(this, n)
        }
    }

    function pr(n) {
        return 400 * n / 146097
    }

    function wr(n) {
        return 146097 * n / 400
    }

    function tf(n) {
        t.duration.fn[n] = function() {
            return this._data[n]
        }
    }

    function br(n) {
        "undefined" == typeof ender && (ii = ot.moment, ot.moment = n ? o("Accessing Moment through the global scope is deprecated, and will be removed in an upcoming release.", t) : t)
    }
    for (var t, ii, u, ot = "undefined" == typeof global || "undefined" != typeof window && window !== global.window ? this : global, p = Math.round, kr = Object.prototype.hasOwnProperty, c = 0, l = 1, s = 2, f = 3, w = 4, b = 5, k = 6, d = {}, rt = [], ri = "undefined" != typeof module && module && module.exports, dr = /^\/?Date\((\-?\d+)/i, gr = /(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/, nu = /^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/, ui = /(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,4}|x|X|zz?|ZZ?|.)/g, ut = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, fi = /\d\d?/, tu = /\d{1,3}/, iu = /\d{1,4}/, ru = /[+\-]?\d{1,6}/, uu = /\d+/, fu = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i, st = /Z|[\+\-]\d\d:?\d\d/gi, eu = /T/i, ou = /[\+\-]?\d+/, su = /[\+\-]?\d+(\.\d{1,3})?/, ei = /\d/, oi = /\d\d/, si = /\d{3}/, hu = /\d{4}/, cu = /[+-]?\d{6}/, lu = /[+-]?\d+/, au = /^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/, ht = [
            ["YYYYYY-MM-DD", /[+-]\d{6}-\d{2}-\d{2}/],
            ["YYYY-MM-DD", /\d{4}-\d{2}-\d{2}/],
            ["GGGG-[W]WW-E", /\d{4}-W\d{2}-\d/],
            ["GGGG-[W]WW", /\d{4}-W\d{2}/],
            ["YYYY-DDD", /\d{4}-\d{3}/]
        ], ct = [
            ["HH:mm:ss.SSSS", /(T| )\d\d:\d\d:\d\d\.\d+/],
            ["HH:mm:ss", /(T| )\d\d:\d\d:\d\d/],
            ["HH:mm", /(T| )\d\d:\d\d/],
            ["HH", /(T| )\d\d/]
        ], vu = /([\+\-]|\d\d)/gi, hi = ("Date|Hours|Minutes|Seconds|Milliseconds".split("|"), {
            Milliseconds: 1,
            Seconds: 1e3,
            Minutes: 6e4,
            Hours: 36e5,
            Days: 864e5,
            Months: 2592e6,
            Years: 31536e6
        }), yu = {
            ms: "millisecond",
            s: "second",
            m: "minute",
            h: "hour",
            d: "day",
            D: "date",
            w: "week",
            W: "isoWeek",
            M: "month",
            Q: "quarter",
            y: "year",
            DDD: "dayOfYear",
            e: "weekday",
            E: "isoWeekday",
            gg: "weekYear",
            GG: "isoWeekYear"
        }, pu = {
            dayofyear: "dayOfYear",
            isoweekday: "isoWeekday",
            isoweek: "isoWeek",
            weekyear: "weekYear",
            isoweekyear: "isoWeekYear"
        }, lt = {}, y = {
            s: 45,
            m: 45,
            h: 22,
            d: 26,
            M: 11
        }, ci = "DDD w W M D d".split(" "), li = "M D H h m s w W".split(" "), a = {
            M: function() {
                return this.month() + 1
            },
            MMM: function(n) {
                return this.localeData().monthsShort(this, n)
            },
            MMMM: function(n) {
                return this.localeData().months(this, n)
            },
            D: function() {
                return this.date()
            },
            DDD: function() {
                return this.dayOfYear()
            },
            d: function() {
                return this.day()
            },
            dd: function(n) {
                return this.localeData().weekdaysMin(this, n)
            },
            ddd: function(n) {
                return this.localeData().weekdaysShort(this, n)
            },
            dddd: function(n) {
                return this.localeData().weekdays(this, n)
            },
            w: function() {
                return this.week()
            },
            W: function() {
                return this.isoWeek()
            },
            YY: function() {
                return r(this.year() % 100, 2)
            },
            YYYY: function() {
                return r(this.year(), 4)
            },
            YYYYY: function() {
                return r(this.year(), 5)
            },
            YYYYYY: function() {
                var n = this.year();
                return (n >= 0 ? "+" : "-") + r(Math.abs(n), 6)
            },
            gg: function() {
                return r(this.weekYear() % 100, 2)
            },
            gggg: function() {
                return r(this.weekYear(), 4)
            },
            ggggg: function() {
                return r(this.weekYear(), 5)
            },
            GG: function() {
                return r(this.isoWeekYear() % 100, 2)
            },
            GGGG: function() {
                return r(this.isoWeekYear(), 4)
            },
            GGGGG: function() {
                return r(this.isoWeekYear(), 5)
            },
            e: function() {
                return this.weekday()
            },
            E: function() {
                return this.isoWeekday()
            },
            a: function() {
                return this.localeData().meridiem(this.hours(), this.minutes(), !0)
            },
            A: function() {
                return this.localeData().meridiem(this.hours(), this.minutes(), !1)
            },
            H: function() {
                return this.hours()
            },
            h: function() {
                return this.hours() % 12 || 12
            },
            m: function() {
                return this.minutes()
            },
            s: function() {
                return this.seconds()
            },
            S: function() {
                return i(this.milliseconds() / 100)
            },
            SS: function() {
                return r(i(this.milliseconds() / 10), 2)
            },
            SSS: function() {
                return r(this.milliseconds(), 3)
            },
            SSSS: function() {
                return r(this.milliseconds(), 3)
            },
            Z: function() {
                var n = this.utcOffset(),
                    t = "+";
                return n < 0 && (n = -n, t = "-"), t + r(i(n / 60), 2) + ":" + r(i(n) % 60, 2)
            },
            ZZ: function() {
                var n = this.utcOffset(),
                    t = "+";
                return n < 0 && (n = -n, t = "-"), t + r(i(n / 60), 2) + r(i(n) % 60, 2)
            },
            z: function() {
                return this.zoneAbbr()
            },
            zz: function() {
                return this.zoneName()
            },
            x: function() {
                return this.valueOf()
            },
            X: function() {
                return this.unix()
            },
            Q: function() {
                return this.quarter()
            }
        }, ai = {}, vi = ["months", "monthsShort", "weekdays", "weekdaysShort", "weekdaysMin"], at = !1; ci.length;) u = ci.pop(), a[u + "o"] = wu(a[u], u);
    for (; li.length;) u = li.pop(), a[u + u] = pi(a[u], 2);
    for (a.DDDD = pi(a.DDD, 3), nt(wi.prototype, {
            set: function(n) {
                var t;
                for (var i in n) "function" == typeof(t = n[i]) ? this[i] = t : this["_" + i] = t;
                this._ordinalParseLenient = new RegExp(this._ordinalParse.source + "|" + /\d{1,2}/.source)
            },
            _months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"),
            months: function(n) {
                return this._months[n.month()]
            },
            _monthsShort: "Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),
            monthsShort: function(n) {
                return this._monthsShort[n.month()]
            },
            monthsParse: function(n, i, r) {
                var u, f, e;
                for (this._monthsParse || (this._monthsParse = [], this._longMonthsParse = [], this._shortMonthsParse = []), u = 0; u < 12; u++)
                    if ((f = t.utc([2e3, u]), r && !this._longMonthsParse[u] && (this._longMonthsParse[u] = new RegExp("^" + this.months(f, "").replace(".", "") + "$", "i"), this._shortMonthsParse[u] = new RegExp("^" + this.monthsShort(f, "").replace(".", "") + "$", "i")), r || this._monthsParse[u] || (e = "^" + this.months(f, "") + "|^" + this.monthsShort(f, ""), this._monthsParse[u] = new RegExp(e.replace(".", ""), "i")), r && "MMMM" === i && this._longMonthsParse[u].test(n)) || r && "MMM" === i && this._shortMonthsParse[u].test(n) || !r && this._monthsParse[u].test(n)) return u
            },
            _weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),
            weekdays: function(n) {
                return this._weekdays[n.day()]
            },
            _weekdaysShort: "Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),
            weekdaysShort: function(n) {
                return this._weekdaysShort[n.day()]
            },
            _weekdaysMin: "Su_Mo_Tu_We_Th_Fr_Sa".split("_"),
            weekdaysMin: function(n) {
                return this._weekdaysMin[n.day()]
            },
            weekdaysParse: function(n) {
                var i, r, u;
                for (this._weekdaysParse || (this._weekdaysParse = []), i = 0; i < 7; i++)
                    if (this._weekdaysParse[i] || (r = t([2e3, 1]).day(i), u = "^" + this.weekdays(r, "") + "|^" + this.weekdaysShort(r, "") + "|^" + this.weekdaysMin(r, ""), this._weekdaysParse[i] = new RegExp(u.replace(".", ""), "i")), this._weekdaysParse[i].test(n)) return i
            },
            _longDateFormat: {
                LTS: "h:mm:ss A",
                LT: "h:mm A",
                L: "MM/DD/YYYY",
                LL: "MMMM D, YYYY",
                LLL: "MMMM D, YYYY LT",
                LLLL: "dddd, MMMM D, YYYY LT"
            },
            longDateFormat: function(n) {
                var t = this._longDateFormat[n];
                return !t && this._longDateFormat[n.toUpperCase()] && (t = this._longDateFormat[n.toUpperCase()].replace(/MMMM|MM|DD|dddd/g, function(n) {
                    return n.slice(1)
                }), this._longDateFormat[n] = t), t
            },
            isPM: function(n) {
                return "p" === (n + "").toLowerCase().charAt(0)
            },
            _meridiemParse: /[ap]\.?m?\.?/i,
            meridiem: function(n, t, i) {
                return n > 11 ? i ? "pm" : "PM" : i ? "am" : "AM"
            },
            _calendar: {
                sameDay: "[Today at] LT",
                nextDay: "[Tomorrow at] LT",
                nextWeek: "dddd [at] LT",
                lastDay: "[Yesterday at] LT",
                lastWeek: "[Last] dddd [at] LT",
                sameElse: "L"
            },
            calendar: function(n, t, i) {
                var r = this._calendar[n];
                return "function" == typeof r ? r.apply(t, [i]) : r
            },
            _relativeTime: {
                future: "in %s",
                past: "%s ago",
                s: "a few seconds",
                m: "a minute",
                mm: "%d minutes",
                h: "an hour",
                hh: "%d hours",
                d: "a day",
                dd: "%d days",
                M: "a month",
                MM: "%d months",
                y: "a year",
                yy: "%d years"
            },
            relativeTime: function(n, t, i, r) {
                var u = this._relativeTime[i];
                return "function" == typeof u ? u(n, t, i, r) : u.replace(/%d/i, n)
            },
            pastFuture: function(n, t) {
                var i = this._relativeTime[n > 0 ? "future" : "past"];
                return "function" == typeof i ? i(t) : i.replace(/%s/i, t)
            },
            ordinal: function(n) {
                return this._ordinal.replace("%d", n)
            },
            _ordinal: "%d",
            _ordinalParse: /\d{1,2}/,
            preparse: function(n) {
                return n
            },
            postformat: function(n) {
                return n
            },
            week: function(n) {
                return tt(n, this._week.dow, this._week.doy).week
            },
            _week: {
                dow: 0,
                doy: 6
            },
            firstDayOfWeek: function() {
                return this._week.dow
            },
            firstDayOfYear: function() {
                return this._week.doy
            },
            _invalidDate: "Invalid date",
            invalidDate: function() {
                return this._invalidDate
            }
        }), (t = function(t, i, r, u) {
            var f;
            return "boolean" == typeof r && (u = r, r = n), (f = {})._isAMomentObject = !0, f._i = t, f._f = i, f._l = r, f._strict = u, f._isUTC = !1, f._pf = {
                empty: !1,
                unusedTokens: [],
                unusedInput: [],
                overflow: -2,
                charsLeftOver: 0,
                nullInput: !1,
                invalidMonth: null,
                invalidFormat: !1,
                userInvalidated: !1,
                iso: !1
            }, lr(f)
        }).suppressDeprecationWarnings = !1, t.createFromInputFallback = o("moment construction falls back to js Date. This is discouraged and will be removed in upcoming major release. Please refer to https://github.com/moment/moment/issues/1407 for more info.", function(n) {
            n._d = new Date(n._i + (n._useUTC ? " UTC" : ""))
        }), t.min = function() {
            return ar("isBefore", [].slice.call(arguments, 0))
        }, t.max = function() {
            return ar("isAfter", [].slice.call(arguments, 0))
        }, t.utc = function(t, i, r, u) {
            var f;
            return "boolean" == typeof r && (u = r, r = n), (f = {})._isAMomentObject = !0, f._useUTC = !0, f._isUTC = !0, f._l = r, f._i = t, f._f = i, f._strict = u, f._pf = {
                empty: !1,
                unusedTokens: [],
                unusedInput: [],
                overflow: -2,
                charsLeftOver: 0,
                nullInput: !1,
                invalidMonth: null,
                invalidFormat: !1,
                userInvalidated: !1,
                iso: !1
            }, lr(f).utc()
        }, t.unix = function(n) {
            return t(1e3 * n)
        }, t.duration = function(n, r) {
            var o, v, h, y, l, a, c, u = n,
                e = null;
            return t.isDuration(n) ? u = {
                ms: n._milliseconds,
                d: n._days,
                M: n._months
            } : "number" == typeof n ? (u = {}, r ? u[r] = n : u.milliseconds = n) : (e = gr.exec(n)) ? (o = "-" === e[1] ? -1 : 1, u = {
                y: 0,
                d: i(e[s]) * o,
                h: i(e[f]) * o,
                m: i(e[w]) * o,
                s: i(e[b]) * o,
                ms: i(e[k]) * o
            }) : (e = nu.exec(n)) ? (o = "-" === e[1] ? -1 : 1, u = {
                y: (h = function(n) {
                    var t = n && parseFloat(n.replace(",", "."));
                    return (isNaN(t) ? 0 : t) * o
                })(e[2]),
                M: h(e[3]),
                d: h(e[4]),
                h: h(e[5]),
                m: h(e[6]),
                s: h(e[7]),
                w: h(e[8])
            }) : null == u ? u = {} : "object" == typeof u && ("from" in u || "to" in u) && (l = t(u.from), a = wt(a = t(u.to), l), l.isBefore(a) ? c = ki(l, a) : ((c = ki(a, l)).milliseconds = -c.milliseconds, c.months = -c.months), (u = {}).ms = (y = c).milliseconds, u.M = y.months), v = new vt(u), t.isDuration(n) && g(n, "_locale") && (v._locale = n._locale), v
        }, t.version = "2.9.0", t.defaultFormat = "YYYY-MM-DDTHH:mm:ssZ", t.ISO_8601 = function() {}, t.momentProperties = rt, t.updateOffset = function() {}, t.relativeTimeThreshold = function(t, i) {
            return y[t] !== n && (i === n ? y[t] : (y[t] = i, !0))
        }, t.lang = o("moment.lang is deprecated. Use moment.locale instead.", function(n, i) {
            return t.locale(n, i)
        }), t.locale = function(n, i) {
            var r;
            return n && (r = void 0 !== i ? t.defineLocale(n, i) : t.localeData(n)) && (t.duration._locale = t._locale = r), t._locale._abbr
        }, t.defineLocale = function(n, i) {
            return null !== i ? (i.abbr = n, d[n] || (d[n] = new wi), d[n].set(i), t.locale(n), d[n]) : (delete d[n], null)
        }, t.langData = o("moment.langData is deprecated. Use moment.localeData instead.", function(n) {
            return t.localeData(n)
        }), t.localeData = function(n) {
            var i;
            if (n && n._locale && n._locale._abbr && (n = n._locale._abbr), !n) return t._locale;
            if (!et(n)) {
                if (i = sr(n)) return i;
                n = [n]
            }
            return function(n) {
                for (var t, i, f, u, r = 0; r < n.length;) {
                    for (t = (u = or(n[r]).split("-")).length, i = (i = or(n[r + 1])) ? i.split("-") : null; t > 0;) {
                        if (f = sr(u.slice(0, t).join("-"))) return f;
                        if (i && i.length >= t && nr(u, i, !0) >= t - 1) break;
                        t--
                    }
                    r++
                }
                return null
            }(n)
        }, t.isMoment = function(n) {
            return n instanceof ft || null != n && g(n, "_isAMomentObject")
        }, t.isDuration = function(n) {
            return n instanceof vt
        }, u = vi.length - 1; u >= 0; --u) bu(vi[u]);
    t.normalizeUnits = function(n) {
        return e(n)
    };
    t.invalid = function(n) {
        var i = t.utc(NaN);
        return null != n ? nt(i._pf, n) : i._pf.userInvalidated = !0, i
    };
    t.parseZone = function() {
        return t.apply(null, arguments).parseZone()
    };
    t.parseTwoDigitYear = function(n) {
        return i(n) + (i(n) > 68 ? 1900 : 2e3)
    };
    t.isDate = yt;
    nt(t.fn = ft.prototype, {
        clone: function() {
            return t(this)
        },
        valueOf: function() {
            return +this._d - 6e4 * (this._offset || 0)
        },
        unix: function() {
            return Math.floor(+this / 1e3)
        },
        toString: function() {
            return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")
        },
        toDate: function() {
            return this._offset ? new Date(+this) : this._d
        },
        toISOString: function() {
            var n = t(this).utc();
            return 0 < n.year() && n.year() <= 9999 ? "function" == typeof Date.prototype.toISOString ? this.toDate().toISOString() : bt(n, "YYYY-MM-DD[T]HH:mm:ss.SSS[Z]") : bt(n, "YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]")
        },
        toArray: function() {
            var n = this;
            return [n.year(), n.month(), n.date(), n.hours(), n.minutes(), n.seconds(), n.milliseconds()]
        },
        isValid: function() {
            return er(this)
        },
        isDSTShifted: function() {
            return !!this._a && this.isValid() && nr(this._a, (this._isUTC ? t.utc(this._a) : t(this._a)).toArray()) > 0
        },
        parsingFlags: function() {
            return nt({}, this._pf)
        },
        invalidAt: function() {
            return this._pf.overflow
        },
        utc: function(n) {
            return this.utcOffset(0, n)
        },
        local: function(n) {
            return this._isUTC && (this.utcOffset(0, n), this._isUTC = !1, n && this.subtract(this._dateUtcOffset(), "m")), this
        },
        format: function(n) {
            var i = bt(this, n || t.defaultFormat);
            return this.localeData().postformat(i)
        },
        add: di(1, "add"),
        subtract: di(-1, "subtract"),
        diff: function(n, t, i) {
            var r, u, f, s, c, o, l = wt(n, this),
                a = 6e4 * (l.utcOffset() - this.utcOffset());
            return "year" === (t = e(t)) || "month" === t || "quarter" === t ? (f = this, c = 12 * ((s = l).year() - f.year()) + (s.month() - f.month()), o = f.clone().add(c, "months"), u = -(c + (s - o < 0 ? (s - o) / (o - f.clone().add(c - 1, "months")) : (s - o) / (f.clone().add(c + 1, "months") - o))), "quarter" === t ? u /= 3 : "year" === t && (u /= 12)) : (r = this - l, u = "second" === t ? r / 1e3 : "minute" === t ? r / 6e4 : "hour" === t ? r / 36e5 : "day" === t ? (r - a) / 864e5 : "week" === t ? (r - a) / 6048e5 : r), i ? u : h(u)
        },
        from: function(n, i) {
            return t.duration({
                to: this,
                from: n
            }).locale(this.locale()).humanize(!i)
        },
        fromNow: function(n) {
            return this.from(t(), n)
        },
        calendar: function(n) {
            var r = n || t(),
                u = wt(r, this).startOf("day"),
                i = this.diff(u, "days", !0),
                f = i < -6 ? "sameElse" : i < -1 ? "lastWeek" : i < 0 ? "lastDay" : i < 1 ? "sameDay" : i < 2 ? "nextDay" : i < 7 ? "nextWeek" : "sameElse";
            return this.format(this.localeData().calendar(f, this, t(r)))
        },
        isLeapYear: function() {
            return ur(this.year())
        },
        isDST: function() {
            return this.utcOffset() > this.clone().month(0).utcOffset() || this.utcOffset() > this.clone().month(5).utcOffset()
        },
        day: function(n) {
            var t = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
            return null != n ? (n = function(n, t) {
                if ("string" == typeof n)
                    if (isNaN(n)) {
                        if ("number" != typeof(n = t.weekdaysParse(n))) return null
                    } else n = parseInt(n, 10);
                return n
            }(n, this.localeData()), this.add(n - t, "d")) : t
        },
        month: v("Month", !0),
        startOf: function(n) {
            switch (n = e(n)) {
                case "year":
                    this.month(0);
                case "quarter":
                case "month":
                    this.date(1);
                case "week":
                case "isoWeek":
                case "day":
                    this.hours(0);
                case "hour":
                    this.minutes(0);
                case "minute":
                    this.seconds(0);
                case "second":
                    this.milliseconds(0)
            }
            return "week" === n ? this.weekday(0) : "isoWeek" === n && this.isoWeekday(1), "quarter" === n && this.month(3 * Math.floor(this.month() / 3)), this
        },
        endOf: function(t) {
            return (t = e(t)) === n || "millisecond" === t ? this : this.startOf(t).add(1, "isoWeek" === t ? "week" : t).subtract(1, "ms")
        },
        isAfter: function(n, i) {
            return "millisecond" === (i = e(void 0 !== i ? i : "millisecond")) ? +this > +(n = t.isMoment(n) ? n : t(n)) : (t.isMoment(n) ? +n : +t(n)) < +this.clone().startOf(i)
        },
        isBefore: function(n, i) {
            var r;
            return "millisecond" === (i = e(void 0 !== i ? i : "millisecond")) ? +this < +(n = t.isMoment(n) ? n : t(n)) : (r = t.isMoment(n) ? +n : +t(n), +this.clone().endOf(i) < r)
        },
        isBetween: function(n, t, i) {
            return this.isAfter(n, i) && this.isBefore(t, i)
        },
        isSame: function(n, i) {
            var r;
            return "millisecond" === (i = e(i || "millisecond")) ? +this == +(n = t.isMoment(n) ? n : t(n)) : (r = +t(n), +this.clone().startOf(i) <= r && r <= +this.clone().endOf(i))
        },
        min: o("moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548", function(n) {
            return (n = t.apply(null, arguments)) < this ? this : n
        }),
        max: o("moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548", function(n) {
            return (n = t.apply(null, arguments)) > this ? this : n
        }),
        zone: o("moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779", function(n, t) {
            return null != n ? ("string" != typeof n && (n = -n), this.utcOffset(n, t), this) : -this.utcOffset()
        }),
        utcOffset: function(n, i) {
            var r, u = this._offset || 0;
            return null != n ? ("string" == typeof n && (n = kt(n)), Math.abs(n) < 16 && (n *= 60), !this._isUTC && i && (r = this._dateUtcOffset()), this._offset = n, this._isUTC = !0, null != r && this.add(r, "m"), u !== n && (!i || this._changeInProgress ? gi(this, t.duration(n - u, "m"), 1, !1) : this._changeInProgress || (this._changeInProgress = !0, t.updateOffset(this, !0), this._changeInProgress = null)), this) : this._isUTC ? u : this._dateUtcOffset()
        },
        isLocal: function() {
            return !this._isUTC
        },
        isUtcOffset: function() {
            return this._isUTC
        },
        isUtc: function() {
            return this._isUTC && 0 === this._offset
        },
        zoneAbbr: function() {
            return this._isUTC ? "UTC" : ""
        },
        zoneName: function() {
            return this._isUTC ? "Coordinated Universal Time" : ""
        },
        parseZone: function() {
            return this._tzm ? this.utcOffset(this._tzm) : "string" == typeof this._i && this.utcOffset(kt(this._i)), this
        },
        hasAlignedHourOffset: function(n) {
            return n = n ? t(n).utcOffset() : 0, (this.utcOffset() - n) % 60 == 0
        },
        daysInMonth: function() {
            return pt(this.year(), this.month())
        },
        dayOfYear: function(n) {
            var i = p((t(this).startOf("day") - t(this).startOf("year")) / 864e5) + 1;
            return null == n ? i : this.add(n - i, "d")
        },
        quarter: function(n) {
            return null == n ? Math.ceil((this.month() + 1) / 3) : this.month(3 * (n - 1) + this.month() % 3)
        },
        weekYear: function(n) {
            var t = tt(this, this.localeData()._week.dow, this.localeData()._week.doy).year;
            return null == n ? t : this.add(n - t, "y")
        },
        isoWeekYear: function(n) {
            var t = tt(this, 1, 4).year;
            return null == n ? t : this.add(n - t, "y")
        },
        week: function(n) {
            var t = this.localeData().week(this);
            return null == n ? t : this.add(7 * (n - t), "d")
        },
        isoWeek: function(n) {
            var t = tt(this, 1, 4).week;
            return null == n ? t : this.add(7 * (n - t), "d")
        },
        weekday: function(n) {
            var t = (this.day() + 7 - this.localeData()._week.dow) % 7;
            return null == n ? t : this.add(n - t, "d")
        },
        isoWeekday: function(n) {
            return null == n ? this.day() || 7 : this.day(this.day() % 7 ? n : n - 7)
        },
        isoWeeksInYear: function() {
            return ir(this.year(), 1, 4)
        },
        weeksInYear: function() {
            var n = this.localeData()._week;
            return ir(this.year(), n.dow, n.doy)
        },
        get: function(n) {
            return this[n = e(n)]()
        },
        set: function(n, t) {
            var i;
            if ("object" == typeof n)
                for (i in n) this.set(i, n[i]);
            else "function" == typeof this[n = e(n)] && this[n](t);
            return this
        },
        locale: function(i) {
            var r;
            return i === n ? this._locale._abbr : (null != (r = t.localeData(i)) && (this._locale = r), this)
        },
        lang: o("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.", function(t) {
            return t === n ? this.localeData() : this.locale(t)
        }),
        localeData: function() {
            return this._locale
        },
        _dateUtcOffset: function() {
            return 15 * -Math.round(this._d.getTimezoneOffset() / 15)
        }
    });
    t.fn.millisecond = t.fn.milliseconds = v("Milliseconds", !1);
    t.fn.second = t.fn.seconds = v("Seconds", !1);
    t.fn.minute = t.fn.minutes = v("Minutes", !1);
    t.fn.hour = t.fn.hours = v("Hours", !0);
    t.fn.date = v("Date", !0);
    t.fn.dates = o("dates accessor is deprecated. Use date instead.", v("Date", !0));
    t.fn.year = v("FullYear", !0);
    t.fn.years = o("years accessor is deprecated. Use year instead.", v("FullYear", !0));
    t.fn.days = t.fn.day;
    t.fn.months = t.fn.month;
    t.fn.weeks = t.fn.week;
    t.fn.isoWeeks = t.fn.isoWeek;
    t.fn.quarters = t.fn.quarter;
    t.fn.toJSON = t.fn.toISOString;
    t.fn.isUTC = t.fn.isUtc;
    nt(t.duration.fn = vt.prototype, {
        _bubble: function() {
            var r, u, f, o = this._milliseconds,
                t = this._days,
                i = this._months,
                n = this._data,
                e = 0;
            n.milliseconds = o % 1e3;
            r = h(o / 1e3);
            n.seconds = r % 60;
            u = h(r / 60);
            n.minutes = u % 60;
            f = h(u / 60);
            n.hours = f % 24;
            t += h(f / 24);
            i += h((t -= h(wr(e = h(pr(t))))) / 30);
            t %= 30;
            e += h(i / 12);
            i %= 12;
            n.days = t;
            n.months = i;
            n.years = e
        },
        abs: function() {
            return this._milliseconds = Math.abs(this._milliseconds), this._days = Math.abs(this._days), this._months = Math.abs(this._months), this._data.milliseconds = Math.abs(this._data.milliseconds), this._data.seconds = Math.abs(this._data.seconds), this._data.minutes = Math.abs(this._data.minutes), this._data.hours = Math.abs(this._data.hours), this._data.months = Math.abs(this._data.months), this._data.years = Math.abs(this._data.years), this
        },
        weeks: function() {
            return h(this.days() / 7)
        },
        valueOf: function() {
            return this._milliseconds + 864e5 * this._days + this._months % 12 * 2592e6 + 31536e6 * i(this._months / 12)
        },
        humanize: function(n) {
            var s, a, v, i, h, r, u, f, e, c, o, l = (s = this, a = !n, v = this.localeData(), i = t.duration(s).abs(), h = p(i.as("s")), r = p(i.as("m")), u = p(i.as("h")), f = p(i.as("d")), e = p(i.as("M")), c = p(i.as("y")), (o = h < y.s && ["s", h] || 1 === r && ["m"] || r < y.m && ["mm", r] || 1 === u && ["h"] || u < y.h && ["hh", u] || 1 === f && ["d"] || f < y.d && ["dd", f] || 1 === e && ["M"] || e < y.M && ["MM", e] || 1 === c && ["y"] || ["yy", c])[2] = a, o[3] = +s > 0, o[4] = v, function(n, t, i, r, u) {
                return u.relativeTime(t || 1, !!i, n, r)
            }.apply({}, o));
            return n && (l = this.localeData().pastFuture(+this, l)), this.localeData().postformat(l)
        },
        add: function(n, i) {
            var r = t.duration(n, i);
            return this._milliseconds += r._milliseconds, this._days += r._days, this._months += r._months, this._bubble(), this
        },
        subtract: function(n, i) {
            var r = t.duration(n, i);
            return this._milliseconds -= r._milliseconds, this._days -= r._days, this._months -= r._months, this._bubble(), this
        },
        get: function(n) {
            return this[(n = e(n)).toLowerCase() + "s"]()
        },
        as: function(n) {
            var t, i;
            if ("month" === (n = e(n)) || "year" === n) return t = this._days + this._milliseconds / 864e5, i = this._months + 12 * pr(t), "month" === n ? i : i / 12;
            switch (t = this._days + Math.round(wr(this._months / 12)), n) {
                case "week":
                    return t / 7 + this._milliseconds / 6048e5;
                case "day":
                    return t + this._milliseconds / 864e5;
                case "hour":
                    return 24 * t + this._milliseconds / 36e5;
                case "minute":
                    return 1440 * t + this._milliseconds / 6e4;
                case "second":
                    return 86400 * t + this._milliseconds / 1e3;
                case "millisecond":
                    return Math.floor(864e5 * t) + this._milliseconds;
                default:
                    throw new Error("Unknown unit " + n);
            }
        },
        lang: t.fn.lang,
        locale: t.fn.locale,
        toIsoString: o("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)", function() {
            return this.toISOString()
        }),
        toISOString: function() {
            var r = Math.abs(this.years()),
                u = Math.abs(this.months()),
                f = Math.abs(this.days()),
                n = Math.abs(this.hours()),
                t = Math.abs(this.minutes()),
                i = Math.abs(this.seconds() + this.milliseconds() / 1e3);
            return this.asSeconds() ? (this.asSeconds() < 0 ? "-" : "") + "P" + (r ? r + "Y" : "") + (u ? u + "M" : "") + (f ? f + "D" : "") + (n || t || i ? "T" : "") + (n ? n + "H" : "") + (t ? t + "M" : "") + (i ? i + "S" : "") : "P0D"
        },
        localeData: function() {
            return this._locale
        },
        toJSON: function() {
            return this.toISOString()
        }
    });
    t.duration.fn.toString = t.duration.fn.toISOString;
    for (u in hi) g(hi, u) && tf(u.toLowerCase());
    t.duration.fn.asMilliseconds = function() {
        return this.as("ms")
    };
    t.duration.fn.asSeconds = function() {
        return this.as("s")
    };
    t.duration.fn.asMinutes = function() {
        return this.as("m")
    };
    t.duration.fn.asHours = function() {
        return this.as("h")
    };
    t.duration.fn.asDays = function() {
        return this.as("d")
    };
    t.duration.fn.asWeeks = function() {
        return this.as("weeks")
    };
    t.duration.fn.asMonths = function() {
        return this.as("M")
    };
    t.duration.fn.asYears = function() {
        return this.as("y")
    };
    t.locale("en", {
        ordinalParse: /\d{1,2}(th|st|nd|rd)/,
        ordinal: function(n) {
            var t = n % 10;
            return n + (1 === i(n % 100 / 10) ? "th" : 1 === t ? "st" : 2 === t ? "nd" : 3 === t ? "rd" : "th")
        }
    });
    ri ? module.exports = t : "function" == typeof define && define.amd ? (define(function(n, i, r) {
        return r.config && r.config() && !0 === r.config().noGlobal && (ot.moment = ii), t
    }), br(!0)) : br()
}).call(this);
! function(n) {
    "use strict";
    if ("function" == typeof define && define.amd) define(["jquery", "moment"], n);
    else if ("object" == typeof exports) module.exports = n(require("jquery"), require("moment"));
    else {
        if ("undefined" == typeof jQuery) throw "bootstrap-datetimepicker requires jQuery to be loaded first";
        if ("undefined" == typeof moment) throw "bootstrap-datetimepicker requires Moment.js to be loaded first";
        n(jQuery, moment)
    }
}(function(n, t) {
    "use strict";
    if (!t) throw new Error("bootstrap-datetimepicker requires Moment.js to be loaded first");
    var i = function(i, r) {
        var e, o, s, k, y, rt, b, u = {},
            d = !0,
            l = !1,
            f = !1,
            nt = 0,
            ot = [{
                clsName: "days",
                navFnc: "M",
                navStep: 1
            }, {
                clsName: "months",
                navFnc: "y",
                navStep: 1
            }, {
                clsName: "years",
                navFnc: "y",
                navStep: 10
            }, {
                clsName: "decades",
                navFnc: "y",
                navStep: 100
            }],
            vt = ["days", "months", "years", "decades"],
            bt = ["top", "bottom", "auto"],
            kt = ["left", "right", "auto"],
            dt = ["default", "top", "bottom"],
            gt = {
                up: 38,
                38: "up",
                down: 40,
                40: "down",
                left: 37,
                37: "left",
                right: 39,
                39: "right",
                tab: 9,
                9: "tab",
                escape: 27,
                27: "escape",
                enter: 13,
                13: "enter",
                pageUp: 33,
                33: "pageUp",
                pageDown: 34,
                34: "pageDown",
                shift: 16,
                16: "shift",
                control: 17,
                17: "control",
                space: 32,
                32: "space",
                t: 84,
                84: "t",
                "delete": 46,
                46: "delete"
            },
            st = {},
            yt = function() {
                return void 0 !== t.tz && void 0 !== r.timeZone && null !== r.timeZone && "" !== r.timeZone
            },
            g = function(n) {
                var i;
                return i = void 0 === n || null === n ? t() : t.isDate(n) || t.isMoment(n) ? t(n) : yt() ? t.tz(n, rt, r.useStrict, r.timeZone) : t(n, rt, r.useStrict), yt() && i.tz(r.timeZone), i
            },
            p = function(n) {
                if ("string" != typeof n || n.length > 1) throw new TypeError("isEnabled expects a single character string parameter");
                switch (n) {
                    case "y":
                        return y.indexOf("Y") !== -1;
                    case "M":
                        return y.indexOf("M") !== -1;
                    case "d":
                        return y.toLowerCase().indexOf("d") !== -1;
                    case "h":
                    case "H":
                        return y.toLowerCase().indexOf("h") !== -1;
                    case "m":
                        return y.indexOf("m") !== -1;
                    case "s":
                        return y.indexOf("s") !== -1;
                    default:
                        return !1
                }
            },
            ht = function() {
                return p("h") || p("m") || p("s")
            },
            ct = function() {
                return p("y") || p("M") || p("d")
            },
            ei = function() {
                var t = n("<thead>").append(n("<tr>").append(n("<th>").addClass("prev").attr("data-action", "previous").append(n("<span>").addClass(r.icons.previous))).append(n("<th>").addClass("picker-switch").attr("data-action", "pickerSwitch").attr("colspan", r.calendarWeeks ? "6" : "5")).append(n("<th>").addClass("next").attr("data-action", "next").append(n("<span>").addClass(r.icons.next)))),
                    i = n("<tbody>").append(n("<tr>").append(n("<td>").attr("colspan", r.calendarWeeks ? "8" : "7")));
                return [n("<div>").addClass("datepicker-days").append(n("<table>").addClass("table-condensed").append(t).append(n("<tbody>"))), n("<div>").addClass("datepicker-months").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone())), n("<div>").addClass("datepicker-years").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone())), n("<div>").addClass("datepicker-decades").append(n("<table>").addClass("table-condensed").append(t.clone()).append(i.clone()))]
            },
            oi = function() {
                var t = n("<tr>"),
                    i = n("<tr>"),
                    u = n("<tr>");
                return p("h") && (t.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.incrementHour
                }).addClass("btn").attr("data-action", "incrementHours").append(n("<span>").addClass(r.icons.up)))), i.append(n("<td>").append(n("<span>").addClass("timepicker-hour").attr({
                    "data-time-component": "hours",
                    title: r.tooltips.pickHour
                }).attr("data-action", "showHours"))), u.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.decrementHour
                }).addClass("btn").attr("data-action", "decrementHours").append(n("<span>").addClass(r.icons.down))))), p("m") && (p("h") && (t.append(n("<td>").addClass("separator")), i.append(n("<td>").addClass("separator").html(":")), u.append(n("<td>").addClass("separator"))), t.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.incrementMinute
                }).addClass("btn").attr("data-action", "incrementMinutes").append(n("<span>").addClass(r.icons.up)))), i.append(n("<td>").append(n("<span>").addClass("timepicker-minute").attr({
                    "data-time-component": "minutes",
                    title: r.tooltips.pickMinute
                }).attr("data-action", "showMinutes"))), u.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.decrementMinute
                }).addClass("btn").attr("data-action", "decrementMinutes").append(n("<span>").addClass(r.icons.down))))), p("s") && (p("m") && (t.append(n("<td>").addClass("separator")), i.append(n("<td>").addClass("separator").html(":")), u.append(n("<td>").addClass("separator"))), t.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.incrementSecond
                }).addClass("btn").attr("data-action", "incrementSeconds").append(n("<span>").addClass(r.icons.up)))), i.append(n("<td>").append(n("<span>").addClass("timepicker-second").attr({
                    "data-time-component": "seconds",
                    title: r.tooltips.pickSecond
                }).attr("data-action", "showSeconds"))), u.append(n("<td>").append(n("<a>").attr({
                    href: "#",
                    tabindex: "-1",
                    title: r.tooltips.decrementSecond
                }).addClass("btn").attr("data-action", "decrementSeconds").append(n("<span>").addClass(r.icons.down))))), k || (t.append(n("<td>").addClass("separator")), i.append(n("<td>").append(n("<button>").addClass("btn btn-primary").attr({
                    "data-action": "togglePeriod",
                    tabindex: "-1",
                    title: r.tooltips.togglePeriod
                }))), u.append(n("<td>").addClass("separator"))), n("<div>").addClass("timepicker-picker").append(n("<table>").addClass("table-condensed").append([t, i, u]))
            },
            si = function() {
                var i = n("<div>").addClass("timepicker-hours").append(n("<table>").addClass("table-condensed")),
                    r = n("<div>").addClass("timepicker-minutes").append(n("<table>").addClass("table-condensed")),
                    u = n("<div>").addClass("timepicker-seconds").append(n("<table>").addClass("table-condensed")),
                    t = [oi()];
                return p("h") && t.push(i), p("m") && t.push(r), p("s") && t.push(u), t
            },
            hi = function() {
                var t = [];
                return r.showTodayButton && t.push(n("<td>").append(n("<a>").attr({
                    "data-action": "today",
                    title: r.tooltips.today
                }).append(n("<span>").addClass(r.icons.today)))), !r.sideBySide && ct() && ht() && t.push(n("<td>").append(n("<a>").attr({
                    "data-action": "togglePicker",
                    title: r.tooltips.selectTime
                }).append(n("<span>").addClass(r.icons.time)))), r.showClear && t.push(n("<td>").append(n("<a>").attr({
                    "data-action": "clear",
                    title: r.tooltips.clear
                }).append(n("<span>").addClass(r.icons.clear)))), r.showClose && t.push(n("<td>").append(n("<a>").attr({
                    "data-action": "close",
                    title: r.tooltips.close
                }).append(n("<span>").addClass(r.icons.close)))), n("<table>").addClass("table-condensed").append(n("<tbody>").append(n("<tr>").append(t)))
            },
            ci = function() {
                var t = n("<div>").addClass("bootstrap-datetimepicker-widget dropdown-menu"),
                    f = n("<div>").addClass("datepicker").append(ei()),
                    e = n("<div>").addClass("timepicker").append(si()),
                    i = n("<ul>").addClass("list-unstyled"),
                    u = n("<li>").addClass("picker-switch" + (r.collapse ? " accordion-toggle" : "")).append(hi());
                return r.inline && t.removeClass("dropdown-menu"), k && t.addClass("usetwentyfour"), p("s") && !k && t.addClass("wider"), r.sideBySide && ct() && ht() ? (t.addClass("timepicker-sbs"), "top" === r.toolbarPlacement && t.append(u), t.append(n("<div>").addClass("row").append(f.addClass("col-md-6")).append(e.addClass("col-md-6"))), "bottom" === r.toolbarPlacement && t.append(u), t) : ("top" === r.toolbarPlacement && i.append(u), ct() && i.append(n("<li>").addClass(r.collapse && ht() ? "collapse in" : "").append(f)), "default" === r.toolbarPlacement && i.append(u), ht() && i.append(n("<li>").addClass(r.collapse && ct() ? "collapse" : "").append(e)), "bottom" === r.toolbarPlacement && i.append(u), t.append(i))
            },
            li = function() {
                var t, u = {};
                return t = i.is("input") || r.inline ? i.data() : i.find("input").data(), t.dateOptions && t.dateOptions instanceof Object && (u = n.extend(!0, u, t.dateOptions)), n.each(r, function(n) {
                    var i = "date" + n.charAt(0).toUpperCase() + n.slice(1);
                    void 0 !== t[i] && (u[n] = t[i])
                }), u
            },
            pt = function() {
                var t, o = (l || i).position(),
                    s = (l || i).offset(),
                    u = r.widgetPositioning.vertical,
                    e = r.widgetPositioning.horizontal;
                if (r.widgetParent) t = r.widgetParent.append(f);
                else if (i.is("input")) t = i.after(f).parent();
                else {
                    if (r.inline) return void(t = i.append(f));
                    t = i;
                    i.children().first().after(f)
                }
                if ("auto" === u && (u = s.top + 1.5 * f.height() >= n(window).height() + n(window).scrollTop() && f.height() + i.outerHeight() < s.top ? "top" : "bottom"), "auto" === e && (e = t.width() < s.left + f.outerWidth() / 2 && s.left + f.outerWidth() > n(window).width() ? "right" : "left"), "top" === u ? f.addClass("top").removeClass("bottom") : f.addClass("bottom").removeClass("top"), "right" === e ? f.addClass("pull-right") : f.removeClass("pull-right"), "static" === t.css("position") && (t = t.parents().filter(function() {
                        return "static" !== n(this).css("position")
                    }).first()), 0 === t.length) throw new Error("datetimepicker component should be placed within a non-static positioned container");
                f.css({
                    top: "top" === u ? "auto" : o.top + i.outerHeight(),
                    bottom: "top" === u ? t.outerHeight() - (t === i ? 0 : o.top) : "auto",
                    left: "left" === e ? t === i ? 0 : o.left : "auto",
                    right: "left" === e ? "auto" : t.outerWidth() - i.outerWidth() - (t === i ? 0 : o.left)
                })
            },
            it = function(n) {
                "dp.change" === n.type && (n.date && n.date.isSame(n.oldDate) || !n.date && !n.oldDate) || i.trigger(n)
            },
            ut = function(n) {
                "y" === n && (n = "YYYY");
                it({
                    type: "dp.update",
                    change: n,
                    viewDate: o.clone()
                })
            },
            ft = function(n) {
                f && (n && (b = Math.max(nt, Math.min(3, b + n))), f.find(".datepicker > div").hide().filter(".datepicker-" + ot[b].clsName).show())
            },
            ai = function() {
                var t = n("<tr>"),
                    i = o.clone().startOf("w").startOf("d");
                for (r.calendarWeeks === !0 && t.append(n("<th>").addClass("cw").text("#")); i.isBefore(o.clone().endOf("w"));) t.append(n("<th>").addClass("dow").text(i.format("dd"))), i.add(1, "d");
                f.find(".datepicker-days thead").append(t)
            },
            vi = function(n) {
                return r.disabledDates[n.format("YYYY-MM-DD")] === !0
            },
            yi = function(n) {
                return r.enabledDates[n.format("YYYY-MM-DD")] === !0
            },
            pi = function(n) {
                return r.disabledHours[n.format("H")] === !0
            },
            wi = function(n) {
                return r.enabledHours[n.format("H")] === !0
            },
            c = function(t, i) {
                if (!t.isValid() || r.disabledDates && "d" === i && vi(t) || r.enabledDates && "d" === i && !yi(t) || r.minDate && t.isBefore(r.minDate, i) || r.maxDate && t.isAfter(r.maxDate, i) || r.daysOfWeekDisabled && "d" === i && r.daysOfWeekDisabled.indexOf(t.day()) !== -1 || r.disabledHours && ("h" === i || "m" === i || "s" === i) && pi(t) || r.enabledHours && ("h" === i || "m" === i || "s" === i) && !wi(t)) return !1;
                if (r.disabledTimeIntervals && ("h" === i || "m" === i || "s" === i)) {
                    var u = !1;
                    if (n.each(r.disabledTimeIntervals, function() {
                            if (t.isBetween(this[0], this[1])) return u = !0, !1
                        }), u) return !1
                }
                return !0
            },
            bi = function() {
                for (var i = [], t = o.clone().startOf("y").startOf("d"); t.isSame(o, "y");) i.push(n("<span>").attr("data-action", "selectMonth").addClass("month").text(t.format("MMM"))), t.add(1, "M");
                f.find(".datepicker-months td").empty().append(i)
            },
            ki = function() {
                var i = f.find(".datepicker-months"),
                    t = i.find("th"),
                    u = i.find("tbody").find("span");
                t.eq(0).find("span").attr("title", r.tooltips.prevYear);
                t.eq(1).attr("title", r.tooltips.selectYear);
                t.eq(2).find("span").attr("title", r.tooltips.nextYear);
                i.find(".disabled").removeClass("disabled");
                c(o.clone().subtract(1, "y"), "y") || t.eq(0).addClass("disabled");
                t.eq(1).text(o.year());
                c(o.clone().add(1, "y"), "y") || t.eq(2).addClass("disabled");
                u.removeClass("active");
                e.isSame(o, "y") && !d && u.eq(e.month()).addClass("active");
                u.each(function(t) {
                    c(o.clone().month(t), "M") || n(this).addClass("disabled")
                })
            },
            di = function() {
                var i = f.find(".datepicker-years"),
                    t = i.find("th"),
                    n = o.clone().subtract(5, "y"),
                    u = o.clone().add(6, "y"),
                    s = "";
                for (t.eq(0).find("span").attr("title", r.tooltips.prevDecade), t.eq(1).attr("title", r.tooltips.selectDecade), t.eq(2).find("span").attr("title", r.tooltips.nextDecade), i.find(".disabled").removeClass("disabled"), r.minDate && r.minDate.isAfter(n, "y") && t.eq(0).addClass("disabled"), t.eq(1).text(n.year() + "-" + u.year()), r.maxDate && r.maxDate.isBefore(u, "y") && t.eq(2).addClass("disabled"); !n.isAfter(u, "y");) s += '<span data-action="selectYear" class="year' + (n.isSame(e, "y") && !d ? " active" : "") + (c(n, "y") ? "" : " disabled") + '">' + n.year() + "<\/span>", n.add(1, "y");
                i.find("td").html(s)
            },
            gi = function() {
                var u, s = f.find(".datepicker-decades"),
                    i = s.find("th"),
                    n = t({
                        y: o.year() - o.year() % 100 - 1
                    }),
                    h = n.clone().add(100, "y"),
                    y = n.clone(),
                    a = !1,
                    v = !1,
                    l = "";
                for (i.eq(0).find("span").attr("title", r.tooltips.prevCentury), i.eq(2).find("span").attr("title", r.tooltips.nextCentury), s.find(".disabled").removeClass("disabled"), (n.isSame(t({
                        y: 1900
                    })) || r.minDate && r.minDate.isAfter(n, "y")) && i.eq(0).addClass("disabled"), i.eq(1).text(n.year() + "-" + h.year()), (n.isSame(t({
                        y: 2e3
                    })) || r.maxDate && r.maxDate.isBefore(h, "y")) && i.eq(2).addClass("disabled"); !n.isAfter(h, "y");) u = n.year() + 12, a = r.minDate && r.minDate.isAfter(n, "y") && r.minDate.year() <= u, v = r.maxDate && r.maxDate.isAfter(n, "y") && r.maxDate.year() <= u, l += '<span data-action="selectDecade" class="decade' + (e.isAfter(n) && e.year() <= u ? " active" : "") + (c(n, "y") || a || v ? "" : " disabled") + '" data-selection="' + (n.year() + 6) + '">' + (n.year() + 1) + " - " + (n.year() + 12) + "<\/span>", n.add(12, "y");
                l += "<span><\/span><span><\/span><span><\/span>";
                s.find("td").html(l);
                i.eq(1).text(y.year() + 1 + "-" + n.year())
            },
            et = function() {
                var t, s, h, l = f.find(".datepicker-days"),
                    u = l.find("th"),
                    a = [],
                    i = [];
                if (ct()) {
                    for (u.eq(0).find("span").attr("title", r.tooltips.prevMonth), u.eq(1).attr("title", r.tooltips.selectMonth), u.eq(2).find("span").attr("title", r.tooltips.nextMonth), l.find(".disabled").removeClass("disabled"), u.eq(1).text(o.format(r.dayViewHeaderFormat)), c(o.clone().subtract(1, "M"), "M") || u.eq(0).addClass("disabled"), c(o.clone().add(1, "M"), "M") || u.eq(2).addClass("disabled"), t = o.clone().startOf("M").startOf("w").startOf("d"), h = 0; h < 42; h++) 0 === t.weekday() && (s = n("<tr>"), r.calendarWeeks && s.append('<td class="cw">' + t.week() + "<\/td>"), a.push(s)), i = ["day"], t.isBefore(o, "M") && i.push("old"), t.isAfter(o, "M") && i.push("new"), t.isSame(e, "d") && !d && i.push("active"), c(t, "d") || i.push("disabled"), t.isSame(g(), "d") && i.push("today"), 0 !== t.day() && 6 !== t.day() || i.push("weekend"), it({
                        type: "dp.classify",
                        date: t,
                        classNames: i
                    }), s.append('<td data-action="selectDay" data-day="' + t.format("L") + '" class="' + i.join(" ") + '">' + t.date() + "<\/td>"), t.add(1, "d");
                    l.find("tbody").empty().append(a);
                    ki();
                    di();
                    gi()
                }
            },
            nr = function() {
                var u = f.find(".timepicker-hours table"),
                    t = o.clone().startOf("d"),
                    r = [],
                    i = n("<tr>");
                for (o.hour() > 11 && !k && t.hour(12); t.isSame(o, "d") && (k || o.hour() < 12 && t.hour() < 12 || o.hour() > 11);) t.hour() % 4 == 0 && (i = n("<tr>"), r.push(i)), i.append('<td data-action="selectHour" class="hour' + (c(t, "h") ? "" : " disabled") + '">' + t.format(k ? "HH" : "hh") + "<\/td>"), t.add(1, "h");
                u.empty().append(r)
            },
            tr = function() {
                for (var s = f.find(".timepicker-minutes table"), t = o.clone().startOf("h"), u = [], i = n("<tr>"), e = 1 === r.stepping ? 5 : r.stepping; o.isSame(t, "h");) t.minute() % (4 * e) == 0 && (i = n("<tr>"), u.push(i)), i.append('<td data-action="selectMinute" class="minute' + (c(t, "m") ? "" : " disabled") + '">' + t.format("mm") + "<\/td>"), t.add(e, "m");
                s.empty().append(u)
            },
            ir = function() {
                for (var u = f.find(".timepicker-seconds table"), t = o.clone().startOf("m"), r = [], i = n("<tr>"); o.isSame(t, "m");) t.second() % 20 == 0 && (i = n("<tr>"), r.push(i)), i.append('<td data-action="selectSecond" class="second' + (c(t, "s") ? "" : " disabled") + '">' + t.format("ss") + "<\/td>"), t.add(5, "s");
                u.empty().append(r)
            },
            rr = function() {
                var n, i, t = f.find(".timepicker span[data-time-component]");
                k || (n = f.find(".timepicker [data-action=togglePeriod]"), i = e.clone().add(e.hours() >= 12 ? -12 : 12, "h"), n.text(e.format("A")), c(i, "h") ? n.removeClass("disabled") : n.addClass("disabled"));
                t.filter("[data-time-component=hours]").text(e.format(k ? "HH" : "hh"));
                t.filter("[data-time-component=minutes]").text(e.format("mm"));
                t.filter("[data-time-component=seconds]").text(e.format("ss"));
                nr();
                tr();
                ir()
            },
            a = function() {
                f && (et(), rr())
            },
            h = function(n) {
                var t = d ? null : e;
                if (!n) return d = !0, s.val(""), i.data("date", ""), it({
                    type: "dp.change",
                    date: !1,
                    oldDate: t
                }), void a();
                if (n = n.clone().locale(r.locale), yt() && n.tz(r.timeZone), 1 !== r.stepping)
                    for (n.minutes(Math.round(n.minutes() / r.stepping) * r.stepping).seconds(0); r.minDate && n.isBefore(r.minDate);) n.add(r.stepping, "minutes");
                c(n) ? (e = n, o = e.clone(), s.val(e.format(y)), i.data("date", e.format(y)), d = !1, a(), it({
                    type: "dp.change",
                    date: e.clone(),
                    oldDate: t
                })) : (r.keepInvalid ? it({
                    type: "dp.change",
                    date: n,
                    oldDate: t
                }) : s.val(d ? "" : e.format(y)), it({
                    type: "dp.error",
                    date: n,
                    oldDate: t
                }))
            },
            v = function() {
                var t = !1;
                return f ? (f.find(".collapse").each(function() {
                    var i = n(this).data("collapse");
                    return !i || !i.transitioning || (t = !0, !1)
                }), t ? u : (l && l.hasClass("btn") && l.toggleClass("active"), f.hide(), n(window).off("resize", pt), f.off("click", "[data-action]"), f.off("mousedown", !1), f.remove(), f = !1, it({
                    type: "dp.hide",
                    date: e.clone()
                }), s.blur(), b = 0, o = e.clone(), u)) : u
            },
            ni = function() {
                h(null)
            },
            tt = function(n) {
                return void 0 === r.parseInputDate ? (!t.isMoment(n) || n instanceof Date) && (n = g(n)) : n = r.parseInputDate(n), n
            },
            lt = {
                next: function() {
                    var n = ot[b].navFnc;
                    o.add(ot[b].navStep, n);
                    et();
                    ut(n)
                },
                previous: function() {
                    var n = ot[b].navFnc;
                    o.subtract(ot[b].navStep, n);
                    et();
                    ut(n)
                },
                pickerSwitch: function() {
                    ft(1)
                },
                selectMonth: function(t) {
                    var i = n(t.target).closest("tbody").find("span").index(n(t.target));
                    o.month(i);
                    b === nt ? (h(e.clone().year(o.year()).month(o.month())), r.inline || v()) : (ft(-1), et());
                    ut("M")
                },
                selectYear: function(t) {
                    var i = parseInt(n(t.target).text(), 10) || 0;
                    o.year(i);
                    b === nt ? (h(e.clone().year(o.year())), r.inline || v()) : (ft(-1), et());
                    ut("YYYY")
                },
                selectDecade: function(t) {
                    var i = parseInt(n(t.target).data("selection"), 10) || 0;
                    o.year(i);
                    b === nt ? (h(e.clone().year(o.year())), r.inline || v()) : (ft(-1), et());
                    ut("YYYY")
                },
                selectDay: function(t) {
                    var i = o.clone();
                    n(t.target).is(".old") && i.subtract(1, "M");
                    n(t.target).is(".new") && i.add(1, "M");
                    h(i.date(parseInt(n(t.target).text(), 10)));
                    ht() || r.keepOpen || r.inline || v()
                },
                incrementHours: function() {
                    var n = e.clone().add(1, "h");
                    c(n, "h") && h(n)
                },
                incrementMinutes: function() {
                    var n = e.clone().add(r.stepping, "m");
                    c(n, "m") && h(n)
                },
                incrementSeconds: function() {
                    var n = e.clone().add(1, "s");
                    c(n, "s") && h(n)
                },
                decrementHours: function() {
                    var n = e.clone().subtract(1, "h");
                    c(n, "h") && h(n)
                },
                decrementMinutes: function() {
                    var n = e.clone().subtract(r.stepping, "m");
                    c(n, "m") && h(n)
                },
                decrementSeconds: function() {
                    var n = e.clone().subtract(1, "s");
                    c(n, "s") && h(n)
                },
                togglePeriod: function() {
                    h(e.clone().add(e.hours() >= 12 ? -12 : 12, "h"))
                },
                togglePicker: function(t) {
                    var f, u = n(t.target),
                        e = u.closest("ul"),
                        i = e.find(".in"),
                        o = e.find(".collapse:not(.in)");
                    if (i && i.length) {
                        if (f = i.data("collapse"), f && f.transitioning) return;
                        i.collapse ? (i.collapse("hide"), o.collapse("show")) : (i.removeClass("in"), o.addClass("in"));
                        u.is("span") ? u.toggleClass(r.icons.time + " " + r.icons.date) : u.find("span").toggleClass(r.icons.time + " " + r.icons.date)
                    }
                },
                showPicker: function() {
                    f.find(".timepicker > div:not(.timepicker-picker)").hide();
                    f.find(".timepicker .timepicker-picker").show()
                },
                showHours: function() {
                    f.find(".timepicker .timepicker-picker").hide();
                    f.find(".timepicker .timepicker-hours").show()
                },
                showMinutes: function() {
                    f.find(".timepicker .timepicker-picker").hide();
                    f.find(".timepicker .timepicker-minutes").show()
                },
                showSeconds: function() {
                    f.find(".timepicker .timepicker-picker").hide();
                    f.find(".timepicker .timepicker-seconds").show()
                },
                selectHour: function(t) {
                    var i = parseInt(n(t.target).text(), 10);
                    k || (e.hours() >= 12 ? 12 !== i && (i += 12) : 12 === i && (i = 0));
                    h(e.clone().hours(i));
                    lt.showPicker.call(u)
                },
                selectMinute: function(t) {
                    h(e.clone().minutes(parseInt(n(t.target).text(), 10)));
                    lt.showPicker.call(u)
                },
                selectSecond: function(t) {
                    h(e.clone().seconds(parseInt(n(t.target).text(), 10)));
                    lt.showPicker.call(u)
                },
                clear: ni,
                today: function() {
                    var n = g();
                    c(n, "d") && h(n)
                },
                close: v
            },
            ur = function(t) {
                return !n(t.currentTarget).is(".disabled") && (lt[n(t.currentTarget).data("action")].apply(u, arguments), !1)
            },
            w = function() {
                var t, i = {
                    year: function(n) {
                        return n.month(0).date(1).hours(0).seconds(0).minutes(0)
                    },
                    month: function(n) {
                        return n.date(1).hours(0).seconds(0).minutes(0)
                    },
                    day: function(n) {
                        return n.hours(0).seconds(0).minutes(0)
                    },
                    hour: function(n) {
                        return n.seconds(0).minutes(0)
                    },
                    minute: function(n) {
                        return n.seconds(0)
                    }
                };
                return s.prop("disabled") || !r.ignoreReadonly && s.prop("readonly") || f ? u : (void 0 !== s.val() && 0 !== s.val().trim().length ? h(tt(s.val().trim())) : d && r.useCurrent && (r.inline || s.is("input") && 0 === s.val().trim().length) && (t = g(), "string" == typeof r.useCurrent && (t = i[r.useCurrent](t)), h(t)), f = ci(), ai(), bi(), f.find(".timepicker-hours").hide(), f.find(".timepicker-minutes").hide(), f.find(".timepicker-seconds").hide(), a(), ft(), n(window).on("resize", pt), f.on("click", "[data-action]", ur), f.on("mousedown", !1), l && l.hasClass("btn") && l.toggleClass("active"), pt(), f.show(), r.focusOnShow && !s.is(":focus") && s.focus(), it({
                    type: "dp.show"
                }), u)
            },
            wt = function() {
                return f ? v() : w()
            },
            ti = function(n) {
                var t, e, i, o, s = null,
                    c = [],
                    l = {},
                    h = n.which,
                    a = "p";
                st[h] = a;
                for (t in st) st.hasOwnProperty(t) && st[t] === a && (c.push(t), parseInt(t, 10) !== h && (l[t] = !0));
                for (t in r.keyBinds)
                    if (r.keyBinds.hasOwnProperty(t) && "function" == typeof r.keyBinds[t] && (i = t.split(" "), i.length === c.length && gt[h] === i[i.length - 1])) {
                        for (o = !0, e = i.length - 2; e >= 0; e--)
                            if (!(gt[i[e]] in l)) {
                                o = !1;
                                break
                            }
                        if (o) {
                            s = r.keyBinds[t];
                            break
                        }
                    }
                s && (s.call(u, f), n.stopPropagation(), n.preventDefault())
            },
            ii = function(n) {
                st[n.which] = "r";
                n.stopPropagation();
                n.preventDefault()
            },
            ri = function(t) {
                var i = n(t.target).val().trim(),
                    r = i ? tt(i) : null;
                return h(r), t.stopImmediatePropagation(), !1
            },
            fr = function() {
                s.on({
                    change: ri,
                    blur: r.debug ? "" : v,
                    keydown: ti,
                    keyup: ii,
                    focus: r.allowInputToggle ? w : ""
                });
                i.is("input") ? s.on({
                    focus: w
                }) : l && (l.on("click", wt), l.on("mousedown", !1))
            },
            er = function() {
                s.off({
                    change: ri,
                    blur: blur,
                    keydown: ti,
                    keyup: ii,
                    focus: r.allowInputToggle ? v : ""
                });
                i.is("input") ? s.off({
                    focus: w
                }) : l && (l.off("click", wt), l.off("mousedown", !1))
            },
            ui = function(t) {
                var i = {};
                return n.each(t, function() {
                    var n = tt(this);
                    n.isValid() && (i[n.format("YYYY-MM-DD")] = !0)
                }), !!Object.keys(i).length && i
            },
            fi = function(t) {
                var i = {};
                return n.each(t, function() {
                    i[this] = !0
                }), !!Object.keys(i).length && i
            },
            at = function() {
                var n = r.format || "L LT";
                y = n.replace(/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, function(n) {
                    var t = e.localeData().longDateFormat(n) || n;
                    return t.replace(/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g, function(n) {
                        return e.localeData().longDateFormat(n) || n
                    })
                });
                rt = r.extraFormats ? r.extraFormats.slice() : [];
                rt.indexOf(n) < 0 && rt.indexOf(y) < 0 && rt.push(y);
                k = y.toLowerCase().indexOf("a") < 1 && y.replace(/\[.*?\]/g, "").indexOf("h") < 1;
                p("y") && (nt = 2);
                p("M") && (nt = 1);
                p("d") && (nt = 0);
                b = Math.max(nt, b);
                d || h(e)
            };
        if (u.destroy = function() {
                v();
                er();
                i.removeData("DateTimePicker");
                i.removeData("date")
            }, u.toggle = wt, u.show = w, u.hide = v, u.disable = function() {
                return v(), l && l.hasClass("btn") && l.addClass("disabled"), s.prop("disabled", !0), u
            }, u.enable = function() {
                return l && l.hasClass("btn") && l.removeClass("disabled"), s.prop("disabled", !1), u
            }, u.ignoreReadonly = function(n) {
                if (0 === arguments.length) return r.ignoreReadonly;
                if ("boolean" != typeof n) throw new TypeError("ignoreReadonly () expects a boolean parameter");
                return r.ignoreReadonly = n, u
            }, u.options = function(t) {
                if (0 === arguments.length) return n.extend(!0, {}, r);
                if (!(t instanceof Object)) throw new TypeError("options() options parameter should be an object");
                return n.extend(!0, r, t), n.each(r, function(n, t) {
                    if (void 0 === u[n]) throw new TypeError("option " + n + " is not recognized!");
                    u[n](t)
                }), u
            }, u.date = function(n) {
                if (0 === arguments.length) return d ? null : e.clone();
                if (!(null === n || "string" == typeof n || t.isMoment(n) || n instanceof Date)) throw new TypeError("date() parameter must be one of [null, string, moment or Date]");
                return h(null === n ? null : tt(n)), u
            }, u.format = function(n) {
                if (0 === arguments.length) return r.format;
                if ("string" != typeof n && ("boolean" != typeof n || n !== !1)) throw new TypeError("format() expects a string or boolean:false parameter " + n);
                return r.format = n, y && at(), u
            }, u.timeZone = function(n) {
                if (0 === arguments.length) return r.timeZone;
                if ("string" != typeof n) throw new TypeError("newZone() expects a string parameter");
                return r.timeZone = n, u
            }, u.dayViewHeaderFormat = function(n) {
                if (0 === arguments.length) return r.dayViewHeaderFormat;
                if ("string" != typeof n) throw new TypeError("dayViewHeaderFormat() expects a string parameter");
                return r.dayViewHeaderFormat = n, u
            }, u.extraFormats = function(n) {
                if (0 === arguments.length) return r.extraFormats;
                if (n !== !1 && !(n instanceof Array)) throw new TypeError("extraFormats() expects an array or false parameter");
                return r.extraFormats = n, rt && at(), u
            }, u.disabledDates = function(t) {
                if (0 === arguments.length) return r.disabledDates ? n.extend({}, r.disabledDates) : r.disabledDates;
                if (!t) return r.disabledDates = !1, a(), u;
                if (!(t instanceof Array)) throw new TypeError("disabledDates() expects an array parameter");
                return r.disabledDates = ui(t), r.enabledDates = !1, a(), u
            }, u.enabledDates = function(t) {
                if (0 === arguments.length) return r.enabledDates ? n.extend({}, r.enabledDates) : r.enabledDates;
                if (!t) return r.enabledDates = !1, a(), u;
                if (!(t instanceof Array)) throw new TypeError("enabledDates() expects an array parameter");
                return r.enabledDates = ui(t), r.disabledDates = !1, a(), u
            }, u.daysOfWeekDisabled = function(n) {
                if (0 === arguments.length) return r.daysOfWeekDisabled.splice(0);
                if ("boolean" == typeof n && !n) return r.daysOfWeekDisabled = !1, a(), u;
                if (!(n instanceof Array)) throw new TypeError("daysOfWeekDisabled() expects an array parameter");
                if (r.daysOfWeekDisabled = n.reduce(function(n, t) {
                        return t = parseInt(t, 10), t > 6 || t < 0 || isNaN(t) ? n : (n.indexOf(t) === -1 && n.push(t), n)
                    }, []).sort(), r.useCurrent && !r.keepInvalid) {
                    for (var t = 0; !c(e, "d");) {
                        if (e.add(1, "d"), 31 === t) throw "Tried 31 times to find a valid date";
                        t++
                    }
                    h(e)
                }
                return a(), u
            }, u.maxDate = function(n) {
                if (0 === arguments.length) return r.maxDate ? r.maxDate.clone() : r.maxDate;
                if ("boolean" == typeof n && n === !1) return r.maxDate = !1, a(), u;
                "string" == typeof n && ("now" !== n && "moment" !== n || (n = g()));
                var t = tt(n);
                if (!t.isValid()) throw new TypeError("maxDate() Could not parse date parameter: " + n);
                if (r.minDate && t.isBefore(r.minDate)) throw new TypeError("maxDate() date parameter is before options.minDate: " + t.format(y));
                return r.maxDate = t, r.useCurrent && !r.keepInvalid && e.isAfter(n) && h(r.maxDate), o.isAfter(t) && (o = t.clone().subtract(r.stepping, "m")), a(), u
            }, u.minDate = function(n) {
                if (0 === arguments.length) return r.minDate ? r.minDate.clone() : r.minDate;
                if ("boolean" == typeof n && n === !1) return r.minDate = !1, a(), u;
                "string" == typeof n && ("now" !== n && "moment" !== n || (n = g()));
                var t = tt(n);
                if (!t.isValid()) throw new TypeError("minDate() Could not parse date parameter: " + n);
                if (r.maxDate && t.isAfter(r.maxDate)) throw new TypeError("minDate() date parameter is after options.maxDate: " + t.format(y));
                return r.minDate = t, r.useCurrent && !r.keepInvalid && e.isBefore(n) && h(r.minDate), o.isBefore(t) && (o = t.clone().add(r.stepping, "m")), a(), u
            }, u.defaultDate = function(n) {
                if (0 === arguments.length) return r.defaultDate ? r.defaultDate.clone() : r.defaultDate;
                if (!n) return r.defaultDate = !1, u;
                "string" == typeof n && (n = "now" === n || "moment" === n ? g() : g(n));
                var t = tt(n);
                if (!t.isValid()) throw new TypeError("defaultDate() Could not parse date parameter: " + n);
                if (!c(t)) throw new TypeError("defaultDate() date passed is invalid according to component setup validations");
                return r.defaultDate = t, (r.defaultDate && r.inline || "" === s.val().trim()) && h(r.defaultDate), u
            }, u.locale = function(n) {
                if (0 === arguments.length) return r.locale;
                if (!t.localeData(n)) throw new TypeError("locale() locale " + n + " is not loaded from moment locales!");
                return r.locale = n, e.locale(r.locale), o.locale(r.locale), y && at(), f && (v(), w()), u
            }, u.stepping = function(n) {
                return 0 === arguments.length ? r.stepping : (n = parseInt(n, 10), (isNaN(n) || n < 1) && (n = 1), r.stepping = n, u)
            }, u.useCurrent = function(n) {
                var t = ["year", "month", "day", "hour", "minute"];
                if (0 === arguments.length) return r.useCurrent;
                if ("boolean" != typeof n && "string" != typeof n) throw new TypeError("useCurrent() expects a boolean or string parameter");
                if ("string" == typeof n && t.indexOf(n.toLowerCase()) === -1) throw new TypeError("useCurrent() expects a string parameter of " + t.join(", "));
                return r.useCurrent = n, u
            }, u.collapse = function(n) {
                if (0 === arguments.length) return r.collapse;
                if ("boolean" != typeof n) throw new TypeError("collapse() expects a boolean parameter");
                return r.collapse === n ? u : (r.collapse = n, f && (v(), w()), u)
            }, u.icons = function(t) {
                if (0 === arguments.length) return n.extend({}, r.icons);
                if (!(t instanceof Object)) throw new TypeError("icons() expects parameter to be an Object");
                return n.extend(r.icons, t), f && (v(), w()), u
            }, u.tooltips = function(t) {
                if (0 === arguments.length) return n.extend({}, r.tooltips);
                if (!(t instanceof Object)) throw new TypeError("tooltips() expects parameter to be an Object");
                return n.extend(r.tooltips, t), f && (v(), w()), u
            }, u.useStrict = function(n) {
                if (0 === arguments.length) return r.useStrict;
                if ("boolean" != typeof n) throw new TypeError("useStrict() expects a boolean parameter");
                return r.useStrict = n, u
            }, u.sideBySide = function(n) {
                if (0 === arguments.length) return r.sideBySide;
                if ("boolean" != typeof n) throw new TypeError("sideBySide() expects a boolean parameter");
                return r.sideBySide = n, f && (v(), w()), u
            }, u.viewMode = function(n) {
                if (0 === arguments.length) return r.viewMode;
                if ("string" != typeof n) throw new TypeError("viewMode() expects a string parameter");
                if (vt.indexOf(n) === -1) throw new TypeError("viewMode() parameter must be one of (" + vt.join(", ") + ") value");
                return r.viewMode = n, b = Math.max(vt.indexOf(n), nt), ft(), u
            }, u.toolbarPlacement = function(n) {
                if (0 === arguments.length) return r.toolbarPlacement;
                if ("string" != typeof n) throw new TypeError("toolbarPlacement() expects a string parameter");
                if (dt.indexOf(n) === -1) throw new TypeError("toolbarPlacement() parameter must be one of (" + dt.join(", ") + ") value");
                return r.toolbarPlacement = n, f && (v(), w()), u
            }, u.widgetPositioning = function(t) {
                if (0 === arguments.length) return n.extend({}, r.widgetPositioning);
                if ("[object Object]" !== {}.toString.call(t)) throw new TypeError("widgetPositioning() expects an object variable");
                if (t.horizontal) {
                    if ("string" != typeof t.horizontal) throw new TypeError("widgetPositioning() horizontal variable must be a string");
                    if (t.horizontal = t.horizontal.toLowerCase(), kt.indexOf(t.horizontal) === -1) throw new TypeError("widgetPositioning() expects horizontal parameter to be one of (" + kt.join(", ") + ")");
                    r.widgetPositioning.horizontal = t.horizontal
                }
                if (t.vertical) {
                    if ("string" != typeof t.vertical) throw new TypeError("widgetPositioning() vertical variable must be a string");
                    if (t.vertical = t.vertical.toLowerCase(), bt.indexOf(t.vertical) === -1) throw new TypeError("widgetPositioning() expects vertical parameter to be one of (" + bt.join(", ") + ")");
                    r.widgetPositioning.vertical = t.vertical
                }
                return a(), u
            }, u.calendarWeeks = function(n) {
                if (0 === arguments.length) return r.calendarWeeks;
                if ("boolean" != typeof n) throw new TypeError("calendarWeeks() expects parameter to be a boolean value");
                return r.calendarWeeks = n, a(), u
            }, u.showTodayButton = function(n) {
                if (0 === arguments.length) return r.showTodayButton;
                if ("boolean" != typeof n) throw new TypeError("showTodayButton() expects a boolean parameter");
                return r.showTodayButton = n, f && (v(), w()), u
            }, u.showClear = function(n) {
                if (0 === arguments.length) return r.showClear;
                if ("boolean" != typeof n) throw new TypeError("showClear() expects a boolean parameter");
                return r.showClear = n, f && (v(), w()), u
            }, u.widgetParent = function(t) {
                if (0 === arguments.length) return r.widgetParent;
                if ("string" == typeof t && (t = n(t)), null !== t && "string" != typeof t && !(t instanceof n)) throw new TypeError("widgetParent() expects a string or a jQuery object parameter");
                return r.widgetParent = t, f && (v(), w()), u
            }, u.keepOpen = function(n) {
                if (0 === arguments.length) return r.keepOpen;
                if ("boolean" != typeof n) throw new TypeError("keepOpen() expects a boolean parameter");
                return r.keepOpen = n, u
            }, u.focusOnShow = function(n) {
                if (0 === arguments.length) return r.focusOnShow;
                if ("boolean" != typeof n) throw new TypeError("focusOnShow() expects a boolean parameter");
                return r.focusOnShow = n, u
            }, u.inline = function(n) {
                if (0 === arguments.length) return r.inline;
                if ("boolean" != typeof n) throw new TypeError("inline() expects a boolean parameter");
                return r.inline = n, u
            }, u.clear = function() {
                return ni(), u
            }, u.keyBinds = function(n) {
                return 0 === arguments.length ? r.keyBinds : (r.keyBinds = n, u)
            }, u.getMoment = function(n) {
                return g(n)
            }, u.debug = function(n) {
                if ("boolean" != typeof n) throw new TypeError("debug() expects a boolean parameter");
                return r.debug = n, u
            }, u.allowInputToggle = function(n) {
                if (0 === arguments.length) return r.allowInputToggle;
                if ("boolean" != typeof n) throw new TypeError("allowInputToggle() expects a boolean parameter");
                return r.allowInputToggle = n, u
            }, u.showClose = function(n) {
                if (0 === arguments.length) return r.showClose;
                if ("boolean" != typeof n) throw new TypeError("showClose() expects a boolean parameter");
                return r.showClose = n, u
            }, u.keepInvalid = function(n) {
                if (0 === arguments.length) return r.keepInvalid;
                if ("boolean" != typeof n) throw new TypeError("keepInvalid() expects a boolean parameter");
                return r.keepInvalid = n, u
            }, u.datepickerInput = function(n) {
                if (0 === arguments.length) return r.datepickerInput;
                if ("string" != typeof n) throw new TypeError("datepickerInput() expects a string parameter");
                return r.datepickerInput = n, u
            }, u.parseInputDate = function(n) {
                if (0 === arguments.length) return r.parseInputDate;
                if ("function" != typeof n) throw new TypeError("parseInputDate() sholud be as function");
                return r.parseInputDate = n, u
            }, u.disabledTimeIntervals = function(t) {
                if (0 === arguments.length) return r.disabledTimeIntervals ? n.extend({}, r.disabledTimeIntervals) : r.disabledTimeIntervals;
                if (!t) return r.disabledTimeIntervals = !1, a(), u;
                if (!(t instanceof Array)) throw new TypeError("disabledTimeIntervals() expects an array parameter");
                return r.disabledTimeIntervals = t, a(), u
            }, u.disabledHours = function(t) {
                if (0 === arguments.length) return r.disabledHours ? n.extend({}, r.disabledHours) : r.disabledHours;
                if (!t) return r.disabledHours = !1, a(), u;
                if (!(t instanceof Array)) throw new TypeError("disabledHours() expects an array parameter");
                if (r.disabledHours = fi(t), r.enabledHours = !1, r.useCurrent && !r.keepInvalid) {
                    for (var i = 0; !c(e, "h");) {
                        if (e.add(1, "h"), 24 === i) throw "Tried 24 times to find a valid date";
                        i++
                    }
                    h(e)
                }
                return a(), u
            }, u.enabledHours = function(t) {
                if (0 === arguments.length) return r.enabledHours ? n.extend({}, r.enabledHours) : r.enabledHours;
                if (!t) return r.enabledHours = !1, a(), u;
                if (!(t instanceof Array)) throw new TypeError("enabledHours() expects an array parameter");
                if (r.enabledHours = fi(t), r.disabledHours = !1, r.useCurrent && !r.keepInvalid) {
                    for (var i = 0; !c(e, "h");) {
                        if (e.add(1, "h"), 24 === i) throw "Tried 24 times to find a valid date";
                        i++
                    }
                    h(e)
                }
                return a(), u
            }, u.viewDate = function(n) {
                if (0 === arguments.length) return o.clone();
                if (!n) return o = e.clone(), u;
                if (!("string" == typeof n || t.isMoment(n) || n instanceof Date)) throw new TypeError("viewDate() parameter must be one of [string, moment or Date]");
                return o = tt(n), ut(), u
            }, i.is("input")) s = i;
        else if (s = i.find(r.datepickerInput), 0 === s.length) s = i.find("input");
        else if (!s.is("input")) throw new Error('CSS class "' + r.datepickerInput + '" cannot be applied to non input element');
        if (i.hasClass("input-group") && (l = 0 === i.find(".datepickerbutton").length ? i.find(".input-group-addon") : i.find(".datepickerbutton")), !r.inline && !s.is("input")) throw new Error("Could not initialize DateTimePicker without an input element");
        return e = g(), o = e.clone(), n.extend(!0, r, li()), u.options(r), at(), fr(), s.prop("disabled") && u.disable(), s.is("input") && 0 !== s.val().trim().length ? h(tt(s.val().trim())) : r.defaultDate && void 0 === s.attr("placeholder") && h(r.defaultDate), r.inline && w(), u
    };
    return n.fn.datetimepicker = function(t) {
        t = t || {};
        var r, f = Array.prototype.slice.call(arguments, 1),
            u = !0;
        if ("object" == typeof t) return this.each(function() {
            var u, r = n(this);
            r.data("DateTimePicker") || (u = n.extend(!0, {}, n.fn.datetimepicker.defaults, t), r.data("DateTimePicker", i(r, u)))
        });
        if ("string" == typeof t) return this.each(function() {
            var e = n(this),
                i = e.data("DateTimePicker");
            if (!i) throw new Error('bootstrap-datetimepicker("' + t + '") method was called on an element that is not using DateTimePicker');
            r = i[t].apply(i, f);
            u = r === i
        }), u || n.inArray(t, ["destroy", "hide", "show", "toggle"]) > -1 ? this : r;
        throw new TypeError("Invalid arguments for DateTimePicker: " + t);
    }, n.fn.datetimepicker.defaults = {
        timeZone: "",
        format: !1,
        dayViewHeaderFormat: "MMMM YYYY",
        extraFormats: !1,
        stepping: 1,
        minDate: !1,
        maxDate: !1,
        useCurrent: !0,
        collapse: !0,
        locale: t.locale(),
        defaultDate: !1,
        disabledDates: !1,
        enabledDates: !1,
        icons: {
            time: "glyphicon glyphicon-time",
            date: "glyphicon glyphicon-calendar",
            up: "glyphicon glyphicon-chevron-up",
            down: "glyphicon glyphicon-chevron-down",
            previous: "glyphicon glyphicon-chevron-left",
            next: "glyphicon glyphicon-chevron-right",
            today: "glyphicon glyphicon-screenshot",
            clear: "glyphicon glyphicon-trash",
            close: "glyphicon glyphicon-remove"
        },
        tooltips: {
            today: "Go to today",
            clear: "Clear selection",
            close: "Close the picker",
            selectMonth: "Select Month",
            prevMonth: "Previous Month",
            nextMonth: "Next Month",
            selectYear: "Select Year",
            prevYear: "Previous Year",
            nextYear: "Next Year",
            selectDecade: "Select Decade",
            prevDecade: "Previous Decade",
            nextDecade: "Next Decade",
            prevCentury: "Previous Century",
            nextCentury: "Next Century",
            pickHour: "Pick Hour",
            incrementHour: "Increment Hour",
            decrementHour: "Decrement Hour",
            pickMinute: "Pick Minute",
            incrementMinute: "Increment Minute",
            decrementMinute: "Decrement Minute",
            pickSecond: "Pick Second",
            incrementSecond: "Increment Second",
            decrementSecond: "Decrement Second",
            togglePeriod: "Toggle Period",
            selectTime: "Select Time"
        },
        useStrict: !1,
        sideBySide: !1,
        daysOfWeekDisabled: !1,
        calendarWeeks: !1,
        viewMode: "days",
        toolbarPlacement: "default",
        showTodayButton: !1,
        showClear: !1,
        showClose: !1,
        widgetPositioning: {
            horizontal: "auto",
            vertical: "auto"
        },
        widgetParent: null,
        ignoreReadonly: !1,
        keepOpen: !1,
        focusOnShow: !0,
        inline: !1,
        keepInvalid: !1,
        datepickerInput: ".datepickerinput",
        keyBinds: {
            up: function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") ? this.date(t.clone().subtract(7, "d")) : this.date(t.clone().add(this.stepping(), "m"))
                }
            },
            down: function(n) {
                if (!n) return void this.show();
                var t = this.date() || this.getMoment();
                n.find(".datepicker").is(":visible") ? this.date(t.clone().add(7, "d")) : this.date(t.clone().subtract(this.stepping(), "m"))
            },
            "control up": function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") ? this.date(t.clone().subtract(1, "y")) : this.date(t.clone().add(1, "h"))
                }
            },
            "control down": function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") ? this.date(t.clone().add(1, "y")) : this.date(t.clone().subtract(1, "h"))
                }
            },
            left: function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") && this.date(t.clone().subtract(1, "d"))
                }
            },
            right: function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") && this.date(t.clone().add(1, "d"))
                }
            },
            pageUp: function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") && this.date(t.clone().subtract(1, "M"))
                }
            },
            pageDown: function(n) {
                if (n) {
                    var t = this.date() || this.getMoment();
                    n.find(".datepicker").is(":visible") && this.date(t.clone().add(1, "M"))
                }
            },
            enter: function() {
                this.hide()
            },
            escape: function() {
                this.hide()
            },
            "control space": function(n) {
                n && n.find(".timepicker").is(":visible") && n.find('.btn[data-action="togglePeriod"]').click()
            },
            t: function() {
                this.date(this.getMoment())
            },
            "delete": function() {
                this.clear()
            }
        },
        debug: !1,
        allowInputToggle: !1,
        disabledTimeIntervals: !1,
        disabledHours: !1,
        enabledHours: !1,
        viewDate: !1
    }, n.fn.datetimepicker
}),
function(n, t) {
    typeof exports == "object" && exports && typeof exports.nodeName != "string" ? t(exports) : typeof define == "function" && define.amd ? define(["exports"], t) : (n.Mustache = {}, t(n.Mustache))
}(this, function(n) {
    function f(n) {
        return typeof n == "function"
    }

    function l(n) {
        return u(n) ? "array" : typeof n
    }

    function o(n) {
        return n.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
    }

    function s(n, t) {
        return n != null && typeof n == "object" && t in n
    }

    function a(n, t) {
        return n != null && typeof n != "object" && n.hasOwnProperty && n.hasOwnProperty(t)
    }

    function y(n, t) {
        return v.call(n, t)
    }

    function w(n) {
        return !y(p, n)
    }

    function k(n) {
        return String(n).replace(/[&<>"'`=\/]/g, function(n) {
            return b[n]
        })
    }

    function it(t, i) {
        function lt() {
            if (ot && !b)
                while (p.length) delete a[p.pop()];
            else p = [];
            ot = !1;
            b = !1
        }

        function vt(n) {
            if (typeof n == "string" && (n = n.split(g, 2)), !u(n) || n.length !== 2) throw new Error("Invalid tags: " + n);
            ht = new RegExp(o(n[0]) + "\\s*");
            v = new RegExp("\\s*" + o(n[1]));
            at = new RegExp("\\s*" + o("}" + n[1]))
        }
        var ht, v, at, f, c, e, s, y, ct, l, it, yt;
        if (!t) return [];
        var ft = !1,
            et = [],
            a = [],
            p = [],
            ot = !1,
            b = !1,
            k = "",
            st = 0;
        for (vt(i || n.tags), f = new r(t); !f.eos();) {
            if (c = f.pos, s = f.scanUntil(ht), s)
                for (it = 0, yt = s.length; it < yt; ++it) y = s.charAt(it), w(y) ? (p.push(a.length), k += y) : (b = !0, ft = !0, k += " "), a.push(["text", y, c, c + 1]), c += 1, y === "\n" && (lt(), k = "", st = 0, ft = !1);
            if (!f.scan(ht)) break;
            if (ot = !0, e = f.scan(tt) || "name", f.scan(d), e === "=" ? (s = f.scanUntil(h), f.scan(h), f.scanUntil(v)) : e === "{" ? (s = f.scanUntil(at), f.scan(nt), f.scanUntil(v), e = "&") : s = f.scanUntil(v), !f.scan(v)) throw new Error("Unclosed tag at " + f.pos);
            if (ct = e == ">" ? [e, s, c, f.pos, k, st, ft] : [e, s, c, f.pos], st++, a.push(ct), e === "#" || e === "^") et.push(ct);
            else if (e === "/") {
                if (l = et.pop(), !l) throw new Error('Unopened section "' + s + '" at ' + c);
                if (l[1] !== s) throw new Error('Unclosed section "' + l[1] + '" at ' + c);
            } else e === "name" || e === "{" || e === "&" ? b = !0 : e === "=" && vt(s)
        }
        if (lt(), l = et.pop(), l) throw new Error('Unclosed section "' + l[1] + '" at ' + f.pos);
        return ut(rt(a))
    }

    function rt(n) {
        for (var u = [], t, i, r = 0, f = n.length; r < f; ++r) t = n[r], t && (t[0] === "text" && i && i[0] === "text" ? (i[1] += t[1], i[3] = t[3]) : (u.push(t), i = t));
        return u
    }

    function ut(n) {
        for (var u = [], r = u, i = [], t, e, f = 0, o = n.length; f < o; ++f) {
            t = n[f];
            switch (t[0]) {
                case "#":
                case "^":
                    r.push(t);
                    i.push(t);
                    r = t[4] = [];
                    break;
                case "/":
                    e = i.pop();
                    e[5] = t[2];
                    r = i.length > 0 ? i[i.length - 1][4] : u;
                    break;
                default:
                    r.push(t)
            }
        }
        return u
    }

    function r(n) {
        this.string = n;
        this.tail = n;
        this.pos = 0
    }

    function i(n, t) {
        this.view = n;
        this.cache = {
            ".": this.view
        };
        this.parent = t
    }

    function t() {
        this.cache = {}
    }
    var c = Object.prototype.toString,
        u = Array.isArray || function(n) {
            return c.call(n) === "[object Array]"
        },
        v = RegExp.prototype.test,
        p = /\S/,
        b = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
            "/": "&#x2F;",
            "`": "&#x60;",
            "=": "&#x3D;"
        },
        d = /\s*/,
        g = /\s+/,
        h = /\s*=/,
        nt = /\s*\}/,
        tt = /#|\^|\/|>|\{|&|=|!/,
        e;
    return r.prototype.eos = function() {
        return this.tail === ""
    }, r.prototype.scan = function(n) {
        var i = this.tail.match(n),
            t;
        return !i || i.index !== 0 ? "" : (t = i[0], this.tail = this.tail.substring(t.length), this.pos += t.length, t)
    }, r.prototype.scanUntil = function(n) {
        var i = this.tail.search(n),
            t;
        switch (i) {
            case -1:
                t = this.tail;
                this.tail = "";
                break;
            case 0:
                t = "";
                break;
            default:
                t = this.tail.substring(0, i);
                this.tail = this.tail.substring(i)
        }
        return this.pos += t.length, t
    }, i.prototype.push = function(n) {
        return new i(n, this)
    }, i.prototype.lookup = function(n) {
        var h = this.cache,
            i, r, t, u, e, o;
        if (h.hasOwnProperty(n)) i = h[n];
        else {
            for (r = this, o = !1; r;) {
                if (n.indexOf(".") > 0)
                    for (t = r.view, u = n.split("."), e = 0; t != null && e < u.length;) e === u.length - 1 && (o = s(t, u[e]) || a(t, u[e])), t = t[u[e++]];
                else t = r.view[n], o = s(r.view, n);
                if (o) {
                    i = t;
                    break
                }
                r = r.parent
            }
            h[n] = i
        }
        return f(i) && (i = i.call(this.view)), i
    }, t.prototype.clearCache = function() {
        this.cache = {}
    }, t.prototype.parse = function(t, i) {
        var u = this.cache,
            f = t + ":" + (i || n.tags).join(":"),
            r = u[f];
        return r == null && (r = u[f] = it(t, i)), r
    }, t.prototype.render = function(n, t, r, u) {
        var f = this.parse(n, u),
            e = t instanceof i ? t : new i(t);
        return this.renderTokens(f, e, r, n, u)
    }, t.prototype.renderTokens = function(n, t, i, r, u) {
        for (var h = "", e, o, f, s = 0, c = n.length; s < c; ++s) f = undefined, e = n[s], o = e[0], o === "#" ? f = this.renderSection(e, t, i, r) : o === "^" ? f = this.renderInverted(e, t, i, r) : o === ">" ? f = this.renderPartial(e, t, i, u) : o === "&" ? f = this.unescapedValue(e, t) : o === "name" ? f = this.escapedValue(e, t) : o === "text" && (f = this.rawValue(e)), f !== undefined && (h += f);
        return h
    }, t.prototype.renderSection = function(n, t, i, r) {
        function l(n) {
            return c.render(n, t, i)
        }
        var c = this,
            o = "",
            e = t.lookup(n[1]),
            s, h;
        if (e) {
            if (u(e))
                for (s = 0, h = e.length; s < h; ++s) o += this.renderTokens(n[4], t.push(e[s]), i, r);
            else if (typeof e == "object" || typeof e == "string" || typeof e == "number") o += this.renderTokens(n[4], t.push(e), i, r);
            else if (f(e)) {
                if (typeof r != "string") throw new Error("Cannot use higher-order sections without the original template");
                e = e.call(t.view, r.slice(n[3], n[5]), l);
                e != null && (o += e)
            } else o += this.renderTokens(n[4], t, i, r);
            return o
        }
    }, t.prototype.renderInverted = function(n, t, i, r) {
        var f = t.lookup(n[1]);
        if (!f || u(f) && f.length === 0) return this.renderTokens(n[4], t, i, r)
    }, t.prototype.indentPartial = function(n, t, i) {
        for (var f = t.replace(/[^ \t]/g, ""), u = n.split("\n"), r = 0; r < u.length; r++) u[r].length && (r > 0 || !i) && (u[r] = f + u[r]);
        return u.join("\n")
    }, t.prototype.renderPartial = function(n, t, i, r) {
        var u;
        if (i && (u = f(i) ? i(n[1]) : i[n[1]], u != null)) {
            var s = n[6],
                h = n[5],
                o = n[4],
                e = u;
            return h == 0 && o && (e = this.indentPartial(u, o, s)), this.renderTokens(this.parse(e, r), t, i, e)
        }
    }, t.prototype.unescapedValue = function(n, t) {
        var i = t.lookup(n[1]);
        if (i != null) return i
    }, t.prototype.escapedValue = function(t, i) {
        var r = i.lookup(t[1]);
        if (r != null) return n.escape(r)
    }, t.prototype.rawValue = function(n) {
        return n[1]
    }, n.name = "mustache.js", n.version = "3.1.0", n.tags = ["{{", "}}"], e = new t, n.clearCache = function() {
        return e.clearCache()
    }, n.parse = function(n, t) {
        return e.parse(n, t)
    }, n.render = function(n, t, i, r) {
        if (typeof n != "string") throw new TypeError('Invalid template! Template should be a "string" but "' + l(n) + '" was given as the first argument for mustache#render(template, view, partials)');
        return e.render(n, t, i, r)
    }, n.to_html = function(t, i, r, u) {
        var e = n.render(t, i, r);
        if (f(u)) u(e);
        else return e
    }, n.escape = k, n.Scanner = r, n.Context = i, n.Writer = t, n
});
sportFilters = {
    Owner: null,
    sportConfigId: "",
    couponTypeId: "",
    FeedDataTypeId: "",
    leagueIds: [],
    DateRange: {
        PredeterminedTime: "None",
        From: null,
        To: null
    },
    OddsRange: {
        From: 1,
        To: 9999
    },
    MarketSet: !1,
    IsFilteredByTrending: !1
};
$(function() {
    var n = localStorage.getItem("fromBack");
    n != null && localStorage.removeItem("fromBack");
    filterOptions.Init(null);
    $(document).mouseup(function(n) {
        var t = $(".new-filters-container");
        t.is(n.target) || t.has(n.target).length !== 0 || ($(".filter-values").hide(), $("body").hasClass("lock") && $("body").removeClass("lock"), $(".backDrop").hide(), $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel").show())
    })
});
filterOptions = {
    Init: function(n) {
        var r, t, u, i;
        if (sportsFilterOptionsEnabled !== "True" || window.location.href.indexOf("inplay=true") > -1 || window.location.href.indexOf("LiveSport") > -1) $(".new-filters-container").hide();
        else if (r = global.getCookie("submenuRef").toLowerCase().indexOf("outrights") > -1, global.getCookie("submenuRef").toLowerCase().indexOf("outrights") > -1 || n === "00000000-0000-0000-da7a-000000580005" || n === "00000000-0000-0000-da7a-000000580006" || n === "00000000-0000-0000-da7a-000000580007" || n === "00000000-0000-0000-0000-000000000000" ? $(".new-filters-container").hide() : $(".new-filters-container").show(), t = this.getAllSportFilters(), t !== null) {
            t.Owner == null && (t.Owner = _hashedSessionId);
            t.Owner !== _hashedSessionId && (t = this.initFiltersBySport());
            u = this.getCurrentSportId();
            i = t[u];
            let n;
            i && (n = this.renderTags(i));
            n && (sportFilters = i, eventsWithFiltersLoaded || this.applyFilters(!1, i), r || setTimeout(function() {
                homePage.synapseNavBarEnabled ? $("#synapseBar_prematchtab").click() : $("#tab_UC").click()
            }, 300))
        }
    },
    renderTags: function(n) {
        var t = !1,
            i;
        if (n != null) {
            if (i = $("li.league-item.isChecked").length, i = i == 0 ? n.leagueIds.length : i, i > 0 ? (t = !0, this.activateFilter("league"), $("#selectedLCount").text(i), language.translateAtRuntime($(".filter-league-label"), "SportContent", {
                    "data-translate-key": "FilterOptionsLeagues",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": $("li.league-item.isChecked").length
                }), $("#cancel-leagues").hide(), $("#reset-leagues").show(), $("li.league-item.isChecked").length > 0 && (n.leagueIds = this.getTickedLeagueIds()), n.leagueIds.forEach(function(n) {
                    $('li[id="' + n + '"]').addClass("isChecked").find("span").removeClass("glyphicon-unchecked").addClass("glyphicon-check")
                })) : this.resetLeagueTicks(), n.OddsRange.From !== 1 && n.OddsRange.To !== 9999) {
                t = !0;
                let i = $("#filterOddsFrom").find('[value="' + n.OddsRange.From + '"]').text() + " - " + $("#filterOddsTo").find('[value="' + n.OddsRange.To + '"]').text();
                this.activateFilter("odds", i);
                setTimeout(function() {
                    $("#filterOddsFrom").val(n.OddsRange.From);
                    $("#filterOddsTo").val(n.OddsRange.To);
                    $("#filterOddsFrom").change();
                    $("#filterOddsTo").change()
                }, 1e3)
            }
            if (n.DateRange.From !== null && n.DateRange.To !== null) {
                t = !0;
                let i = moment(n.DateRange.From).format("DD MMM") + " - " + moment(n.DateRange.To).format("DD MMM");
                this.activateFilter("date", i);
                language.removeTranslateAttributes($(".filter-date-label"));
                language.translateAtRuntime($(".filter-date-label"), "DatePicker", {
                    "data-translate-key": "SportContentFilterDateTag",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": moment(n.DateRange.From).format("DD"),
                    "data-translate-value-1": moment(n.DateRange.From).format("MMM"),
                    "data-translate-replace-value-1": "true",
                    "data-translate-value-2": moment(n.DateRange.To).format("DD"),
                    "data-translate-value-3": moment(n.DateRange.To).format("MMM"),
                    "data-translate-replace-value-3": "true"
                });
                setTimeout(function() {
                    $("#filterFromDate").val(n.DateRange.From);
                    $("#filterToDate").val(n.DateRange.To)
                }, 1e3)
            }
            if (n.DateRange.PredeterminedTime !== "None" && n.DateRange.PredeterminedTime !== "") {
                t = !0;
                let i = $("#dllPredeterminedTime").find('[value="' + n.DateRange.PredeterminedTime + '"]').text();
                this.activateFilter("date", i, $('[value="' + n.DateRange.PredeterminedTime + '"]').val());
                setTimeout(function() {
                    $("#dllPredeterminedTime").val(n.DateRange.PredeterminedTime)
                }, 1e3);
                $("#filterToDate, #filterFromDate").attr("disabled", "disabled")
            }
            if (n.FeedDataTypeId === "" && (n.FeedDataTypeId = "00000000-0000-0000-da7a-000000580001", filterOptions.updateFilterCache(n)), n.couponTypeId !== "" && n.MarketSet === !0) {
                t = !0;
                let i = $('[id="' + n.couponTypeId + '"]').find("a").text();
                i !== "" && this.activateFilter("market", i)
            }
            n.IsFilteredByTrending !== null && n.IsFilteredByTrending === !0 && (t = !0, this.activateFilter("lightning", ""))
        } else this.updateSportFilters(this.getCurrentSportId(), this.initSportFilter());
        return t
    },
    getFilterCache: function() {
        return JSON.parse(localStorage.getItem("sportFilters"))
    },
    updateFilterCache: function(n) {
        localStorage.setItem("sportFilters", JSON.stringify(n))
    },
    toggleFilter: function(n) {
        $(window).width() <= 768 && ($(".top-and-fav-leagues-container").addClass("hidden"), $("#dropFavExpand").text("arrow_drop_down"));
        generateAccountFavoriteLeagueFilters();
        $(".filter-values").not("#" + $(n).next().attr("id")).hide();
        var t = $(n).next();
        t.toggle();
        let i = $(".header-container").outerHeight(),
            r = $("#mobileBetslipFooter").outerHeight();
        $(".leagues-ul").children().length > 9 && $("#league-ul-container").addClass("scroll");
        $(window).width() <= 768 && (t.is(":visible") ? ($("body").addClass("lock"), $(".backDrop").show(), $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel, #mcasinoWidget-container").hide(), $("body, html").animate({
            scrollTop: 20
        }, 300)) : ($("body").removeAttr("class"), $(".backDrop").hide(), $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel, #mcasinoWidget-container").show()))
    },
    scrollTop: function() {
        $("body, html").animate({
            scrollTop: 0
        }, 300)
    },
    closeFilter: function(n) {
        var t = $(n).parents(".filter-values");
        t.toggle();
        $(".backDrop").hide();
        $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel, #mcasinoWidget-container").show();
        $("body").removeAttr("class");
        filterOptions.scrollTop();
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div")
    },
    toggleFooter: function() {
        $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel").show()
    },
    addLeague: function(n) {
        loadFiltersViaAjax && ($("#" + n).hasClass("isChecked") ? ($("#" + n).removeClass("isChecked"), $("#" + n).children("span").removeClass("glyphicon-check"), $("#" + n).children("span").addClass("glyphicon-unchecked")) : ($("#" + n).addClass("isChecked"), $("#" + n).children("span").addClass("glyphicon-check"), $("#" + n).children("span").removeClass("glyphicon-unchecked")));
        setTimeout(function() {
            sportFilters.leagueIds = [];
            counter = 0;
            $("li.league-item.isChecked").each(function() {
                sportFilters.leagueIds.push($(this).attr("id"));
                counter++
            });
            $("#cancel-leagues").hide();
            $("#reset-leagues").show();
            $("#selectedLCount").text(counter);
            $("li.league-item.isChecked").length === 6 ? ($('.league-item[data-checked~="False"]').addClass("unclickable"), $(".league-item.isChecked").removeClass("unclickable"), $("#" + n).removeClass("unclickable")) : ($('.league-item[data-checked~="False"]').removeClass("unclickable"), $(".league-item.isChecked").removeClass("unclickable"), $("#" + n).removeClass("unclickable"));
            $("#leagueGroup").show()
        }, 200)
    },
    confirmLeagues: function(n = null, t = false) {
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div");
        var i = this.getCurrentSportFilters(this.getCurrentSportId());
        this.activateFilter("league");
        $("#selectedLCount").text($("li.league-item.isChecked").length);
        $("#mcasinoWidget-container").show();
        $("li.league-item.isChecked").length > 0 ? $("#clearLFilters").attr("style", "display:flex") : $("#clearLFilters").attr("style", "display:none");
        n != null ? (this.resetLeagueTicks(), i.leagueIds = [], i.leagueIds.push(n)) : i.leagueIds = sportFilters.leagueIds;
        t ? (this.resetLeagueTicks(), i.leagueIds = generateAccountFavoriteLeagueFilters(!0), localStorage.setItem("isFavouriteLeaguesFilter", !0), $("#clearLFilters").attr("style", "display:flex")) : $(".fav-leagues-filter-check").removeClass("glyphicon-check").addClass("glyphicon-unchecked");
        language.translateAtRuntime($(".filter-league-label"), "SportContent", {
            "data-translate-key": "FilterOptionsLeagues",
            "data-translate-type": "generic-html",
            "data-translate-value-0": $("li.league-item.isChecked").length
        });
        $("#leagueGroup").hide();
        $("body").hasClass("lock") && $("body").removeAttr("class");
        filterOptions.scrollTop();
        this.applyFilters(!1, i)
    },
    addOdds: function() {
        var t = this.getCurrentSportFilters(this.getCurrentSportId()),
            n, i;
        sportFilters.OddsRange.From = $("#filterOddsFrom").val();
        sportFilters.OddsRange.To = $("#filterOddsTo").val();
        $("#mcasinoWidget-container").show();
        n = $("#filterOddsTo").children("option:selected")[0].label;
        i = n === "10+" ? "10+" : n;
        $(".oddsGroup-tag").removeClass("disableElement");
        this.activateFilter("odds", $("#filterOddsFrom").find('[value="' + sportFilters.OddsRange.From + '"]').text() + " - " + i);
        $("#oddsGroup").hide();
        $("#filterOddsFrom").find("option").removeAttr("disabled");
        $("#filterOddsTo").find("option").removeAttr("disabled");
        $("body").hasClass("lock") && $("body").removeAttr("class");
        t.OddsRange = sportFilters.OddsRange;
        filterOptions.scrollTop();
        this.applyFilters(!1, t);
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div")
    },
    disableInvalidOddsGroups: function(n) {
        var i = document.getElementById("filterOddsTo"),
            t, r;
        for (this.clearPreviousDisables(i), t = 1; t < i.length; t++)
            if (r = i.options[t].value, parseFloat(r) <= parseFloat(n.value)) i.options[t].disabled = !0;
            else break
    },
    checkForInvalidFromOdds: function() {
        var t = document.getElementById("filterOddsFrom"),
            r = document.getElementById("filterOddsTo"),
            n, i;
        for (this.clearPreviousDisables(t), n = 1; n < t.length; n++) i = t.options[n].value, parseFloat(i) >= parseFloat(r.value) && (t.options[n].disabled = !0)
    },
    clearPreviousDisables: function(n) {
        for (var i, t = 0; t < n.length; t++) i = n.options[t].value, n.options[t].disabled = !1
    },
    addDate: function() {
        var n = this.getCurrentSportFilters(this.getCurrentSportId()),
            t;
        $(".dateGroup-tag").removeClass("disableElement");
        t = $("#dllPredeterminedTime").find("option:selected").text();
        sportFilters.DateRange.PredeterminedTime = $("#dllPredeterminedTime").val();
        $("#mcasinoWidget-container").show();
        sportFilters.DateRange.PredeterminedTime === "None" ? (sportFilters.DateRange.From = $("#filterFromDate").val(), sportFilters.DateRange.To = $("#filterToDate").val()) : (this.activateFilter("date", t, $("#dllPredeterminedTime").find("option:selected").val()), sportFilters.DateRange.From = null, sportFilters.DateRange.To = null);
        sportFilters.DateRange.From !== null && sportFilters.DateRange.To !== null && (sportFilters.DateRange.From = sportFilters.DateRange.From === "" ? new Date : sportFilters.DateRange.From, sportFilters.DateRange.To = sportFilters.DateRange.To === "" ? new Date("12/31/2199") : sportFilters.DateRange.To, this.activateFilter("date", moment(sportFilters.DateRange.From).format("DD MMM") + " - " + moment(sportFilters.DateRange.To).format("DD MMM")), language.removeTranslateAttributes($(".filter-date-label")), language.translateAtRuntime($(".filter-date-label"), "DatePicker", {
            "data-translate-key": "SportContentFilterDateTag",
            "data-translate-value-0": moment(sportFilters.DateRange.From).format("DD"),
            "data-translate-value-1": moment(sportFilters.DateRange.From).format("MMM"),
            "data-translate-replace-value-1": "true",
            "data-translate-value-2": moment(sportFilters.DateRange.To).format("DD"),
            "data-translate-value-3": moment(sportFilters.DateRange.To).format("MMM"),
            "data-translate-replace-value-3": "true"
        }));
        $("#dateGroup").hide();
        $("body").hasClass("lock") && $("body").removeAttr("class");
        n.DateRange = sportFilters.DateRange;
        filterOptions.scrollTop();
        this.applyFilters(!1, n);
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div")
    },
    showBoltFiltered: function() {
        if (!$(".lightning-filter-box").hasClass("disabled")) {
            var n = this.getCurrentSportFilters(this.getCurrentSportId());
            n.IsFilteredByTrending == null || n.IsFilteredByTrending == !1 ? (n.IsFilteredByTrending = !0, $("#boltSpan").removeAttr("disabled"), this.activateFilter("lightning", "")) : (n.IsFilteredByTrending = !1, $("#boltSpan").attr("disabled"), $(".lightning-filter-box").find("h2").removeClass("filterApplied"));
            this.applyFilters(!1, n);
            $(".top-and-fav-leagues-container").removeClass("hidden");
            homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div")
        }
    },
    setActiveMarket: function(n, t, i, r) {
        var u = this.getCurrentSportFilters(this.getCurrentSportId()),
            f, o, e;
        sportFilters.couponTypeId = t;
        sportFilters.FeedDataTypeId = i;
        sportFilters.MarketSet = !0;
        i === "00000000-0000-0000-da7a-000000580001" && homePage.LoadSubMenuBar("#prematchtab", "");
        language.removeTranslateAttributes($(".filter-market-label"));
        language.translateAtRuntime($(".filter-market-label"), "MarketTypes", {
            "data-translate-key": language.generateKey(r)
        });
        f = $('*[data-filtermarket-list-markettypecategory*="' + i + '"]');
        f.find("li").removeClass("isActive");
        f.find(t).addClass("isActive");
        o = $('*[data-filtermarket-button-markettypecategory*="' + i + '"]');
        o.html('<span class="fltrText">' + $(t).text() + '<\/span><span class="glyphicon glyphicon-menu-down fade-a-bit"><\/span>');
        this.activateFilter("market", r);
        $("#marketGroup").hide();
        $("body").hasClass("lock") && $("body").removeAttr("class");
        e = $(".market-mobile").find("span:contains('" + r + "')").attr("data-translate-key");
        e !== undefined && e !== "" && language.translateAtRuntime($("#marketGroup-tag.inline-tag"), "MarketTypes", {
            "data-translate-key": language.generateKey(r)
        });
        u.couponTypeId = t;
        u.FeedDataTypeId = i;
        u.MarketSet = !0;
        this.applyFilters(!1, u);
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div")
    },
    applyFilters: function(n, t) {
        var i, r, u;
        n = n === null ? !1 : n;
        i = global.getCookie("submenuRef").toLowerCase().indexOf("outrights") > -1;
        $("filter-tag").removeClass("disableElement");
        t.IsEsport = filterOptions.isEsport();
        filterOptions.updateSportFilters(this.getCurrentSportId(), t);
        r = this.renderTags(t);
        homePage.showOverlay();
        console.log("APPLYING FILTERS: ", t);
        this.isPrintFilters() ? (pageNumber = 1, getFixturesForPrint(t)) : window.UseGetForFilterEvents != null && window.UseGetForFilterEvents === !0 ? (u = "?sportConfigId=" + t.sportConfigId + "&couponTypeId=" + t.couponTypeId + "&feedDataTypeId=" + t.FeedDataTypeId + "&leagueIds=" + t.leagueIds + "&PredeterminedTime=" + t.DateRange.PredeterminedTime + "&daterangeFrom=" + t.DateRange.From + "&dateRangeTo=" + t.DateRange.To + "&oddsRangeFrom=" + t.OddsRange.From + "&OddsRangeTo=" + t.OddsRange.To + "&isEsport=" + t.isEsport + "&MarketSet=" + t.MarketSet + "&removedFilters=&isFilteredByTrending" + t.IsFilteredByTrending + "&set=" + t.set + "&eventIds=", pat.get("/Event/FilterEventsGet" + u).done(function(u) {
            var f = $('*[data-matchbetting-events-markettypecategory*="' + t.FeedDataTypeId + '"]');
            f.html(u);
            SetOutcomeButtons();
            homePage.closeOverlay();
            n && (eventDisplay.expandCollapseMenu(), filters.bindLeagues(), populateSportSlider());
            homePage.anchorToId("mSportDiv");
            i || t.FeedDataTypeId !== constId.feedDataType_Prematch || r && (homePage.synapseNavBarEnabled ? $("#synapseBar_prematchtab").click() : $("#tab_UC").click());
            filterOptions.checkForDisabledFilters(t);
            setTimeout(function() {
                $("#filterOddsFrom").val(t.OddsRange.From);
                $("#filterOddsTo").val(t.OddsRange.To);
                t.DateRange.PredeterminedTime !== "None" && t.DateRange.PredeterminedTime !== "" ? ($("#dllPredeterminedTime").val(t.DateRange.PredeterminedTime), $("#filterToDate, #filterFromDate").attr("disabled", "disabled")) : $("#filterToDate, #filterFromDate").removeAttr("disabled");
                applyFavorites()
            }, 1e3);
            t.leagueIds.length === 1 && $(".league-group-items").css("display", "block");
            filterOptions.toggleGroupedLeagueArrow()
        })) : pat.post("/Event/FilterEvents", t).done(function(u) {
            var f = $('*[data-matchbetting-events-markettypecategory*="' + t.FeedDataTypeId + '"]');
            f.html(u);
            SetOutcomeButtons();
            homePage.closeOverlay();
            n && (eventDisplay.expandCollapseMenu(), filters.bindLeagues(), populateSportSlider());
            homePage.anchorToId("mSportDiv");
            i || t.FeedDataTypeId !== constId.feedDataType_Prematch || r && (homePage.synapseNavBarEnabled ? $("#synapseBar_prematchtab").click() : $("#tab_UC").click());
            filterOptions.checkForDisabledFilters(t);
            setTimeout(function() {
                $("#filterOddsFrom").val(t.OddsRange.From);
                $("#filterOddsTo").val(t.OddsRange.To);
                t.DateRange.PredeterminedTime !== "None" && t.DateRange.PredeterminedTime !== "" ? ($("#dllPredeterminedTime").val(t.DateRange.PredeterminedTime), $("#filterToDate, #filterFromDate").attr("disabled", "disabled")) : $("#filterToDate, #filterFromDate").removeAttr("disabled");
                applyFavorites()
            }, 1e3);
            t.leagueIds.length === 1 && $(".league-group-items").css("display", "block");
            filterOptions.toggleGroupedLeagueArrow()
        });
        $(".backDrop").hide();
        $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel").show();
        $(".sports-filters").hide();
        $("#filterToDate, #filterFromDate").removeAttr("disabled")
    },
    toggleGroupedLeagueArrow: function() {
        var n = parseInt($("#selectedLCount").text());
        n > 1 && ($('[data-nowloaded="Upcoming"]').find(".eventsByLeagueArrows").text("expand_more"), $('[data-nowloaded="Upcoming"]').find(".league-group-items").addClass("collapse"))
    },
    league: "",
    date: "",
    odds: "",
    marketType: "",
    cancel: function(n) {
        $(".backDrop, #" + n).hide();
        $("body").hasClass("lock") && $("body").removeAttr("class");
        $(".backDrop").hide();
        $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel, #mcasinoWidget-container").show();
        filterOptions.scrollTop();
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div");
        $(".fav-leagues-filter-check").removeClass("glyphicon-check").addClass("glyphicon-unchecked")
    },
    clearFilter: function(n) {
        var t = $("." + n + "-filter-box").find("h2").hasClass("filterApplied");
        $("." + n + "-filter-box").find("h2").removeClass("filterApplied");
        n !== "league" && $(".filter-" + n + "-label").data() !== undefined && ($(".filter-" + n + "-label").text($(".filter-" + n + "-label").data().defaultText), language.translateAtRuntime($(".filter-" + n + "-label"), "SportContent", {
            "data-translate-key": language.generateKey($(".filter-" + n + "-label").data().defaultText)
        }));
        this.removeFilter(null, n + "Group", t);
        $(".backDrop, #" + n + "-Group").hide();
        $("body").hasClass("lock") && $("body").removeAttr("class");
        $(".backDrop").hide();
        $(".mb-footer-container, .mini-betslip-wrapper, #mSportDiv, .transparent, .ragingCarousel, #mcasinoWidget-container").show();
        filterOptions.scrollTop();
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div");
        $(".fav-leagues-filter-check").removeClass("glyphicon-check").addClass("glyphicon-unchecked")
    },
    removeFilter: function(n, t, i) {
        var r = this.getCurrentSportFilters(this.getCurrentSportId());
        $(".filter-values").each(function() {
            $(this).hide()
        });
        $("." + t).hide();
        switch (t) {
            case "leagueGroup":
                r.leagueIds = [];
                $("#selectedLCount").text(0);
                this.league = "";
                break;
            case "oddsGroup":
                r.OddsRange = {
                    From: 1,
                    To: 9999
                };
                this.odds = "";
                $("#filterOddsFrom").val(1);
                $("#filterOddsTo").val(9999);
                filterOptions.clearPreviousDisables(document.getElementById("filterOddsFrom"));
                filterOptions.clearPreviousDisables(document.getElementById("filterOddsTo"));
                break;
            case "dateGroup":
                r.DateRange = {
                    From: null,
                    To: null,
                    PredeterminedTime: "None"
                };
                this.date = "";
                $("#filterFromDate, #filterToDate").val("");
                $("#dllPredeterminedTime").val("None");
                break;
            case "marketGroup":
                r.couponTypeId = "";
                r.MarketSet = !1;
                this.marketType = "";
                break;
            case "eventGroup":
                r.couponTypeId = "";
                break;
            case "lightningGroup":
                r.IsFilteredByTrending = !1
        }
        this.updateSportFilters(r.sportConfigId, r);
        i === !0 && this.applyFilters(!1, r)
    },
    clearFilters: function() {
        this.league = "";
        this.date = "";
        this.odds = "";
        this.marketType = "";
        $("#selectedLCount").text("0");
        $(".filter-radio").removeClass("active").removeClass("fa-circle").addClass("fa-circle-o");
        $("#filterFromDate, #filterToDate").val("");
        $("#mcasinoWidget-container").show();
        sportFilters = {
            sportConfigId: this.getCurrentSportId(),
            couponTypeId: "",
            FeedDataTypeId: "",
            leagueIds: [],
            DateRange: {
                PredeterminedTime: "None",
                From: null,
                To: null
            },
            OddsRange: {
                From: 1,
                To: 9999
            },
            isEsport: !1,
            MarketSet: !1
        };
        sportFilters.FeedDataTypeId = "00000000-0000-0000-da7a-000000580001";
        this.resetLeagues();
        filterOptions.applyFilters();
        $(".filter-tag, .mobile-filter-tags-container, #clearAllFilters, #btn-apply-history").hide()
    },
    activateFilter: function(n, t, i) {
        $("." + n + "-filter-box").find("h2").addClass("filterApplied");
        var r = "",
            u = i != null ? i : t;
        switch (n) {
            case "date":
                r = "SportContent";
                break;
            case "market":
                r = "MarketTypes"
        }
        n !== "league" && (this.renderRunTimeTranslation(n, $(".filter-" + n + "-label"), r, u), $(".filter-" + n + "-label").text(t))
    },
    addRemoveClickEvent: function(n) {
        $("." + n + "-tag.inline-tag").find("i").click(function() {})
    },
    setPredeterminedTime: function(n) {
        var t = $(n).val();
        t !== "None" ? (sportFilters.DateRange.PredeterminedTime = $(n).val(), $("#filterToDate, #filterFromDate").attr("disabled", "disabled")) : $("#filterToDate, #filterFromDate").removeAttr("disabled")
    },
    getCurrentSportId: function() {
        return this.isPrintFilters() ? localStorage.getItem("currentFixturesSportId") : localStorage.getItem("currentSportId")
    },
    getMoreLeagues: function(n, t, i) {
        var r = filterOptions.getFilterCache();
        homePage.showOverlay();
        pat.post("/Home/GetMore", {
            isOperaMini: n,
            moreEvents: t,
            FeedDataTypeId: i
        }).done(function(n) {
            $("#newfiltersContainer").html(n);
            $(".new-filters-container").show();
            t === !0 ? ($("#moreLeagueBtn").addClass("hidden"), $("#lessLeagueBtn").removeClass("hidden"), $("body").addClass("lock")) : t === !1 ? ($("#moreLeagueBtn").removeClass("hidden"), $("#lessLeagueBtn").addClass("hidden"), $("body").addClass("lock")) : ($("#filterleagues-section").removeClass("open"), $("#filterleagues-list.dropdown-menu").css("display", "none"));
            $.cookie("FilterCount") === "10" && $('.league-item[data-checked~="False"]').addClass("unclickable");
            eventDisplay.expandCollapseMenu();
            filters.bindLeagues();
            SetOutcomeButtons();
            homePage.closeOverlay();
            $(".league-filter-box").find("h2").click();
            filterOptions.renderTags(r)
        }).fail(function() {
            homePage.closeOverlay();
            typeof n != "undefined" && n === !0 && location.reload();
            SetOutcomeButtons();
            homePage.closeOverlay()
        })
    },
    resetLeagues: function(n = true) {
        var t = this.getCurrentSportFilters(this.getCurrentSportId());
        filterOptions.resetLeagueTicks();
        t.leagueIds = [];
        $("#leagueGroup").hide();
        $("#cancel-leagues").show();
        $("#reset-leagues").hide();
        $("#mcasinoWidget-container").show();
        this.clearFilter("league");
        $(".league-item:not(.isChecked)").removeClass("unclickable");
        $(".checked-list-box").css("display", "none");
        $(".leagueLink").css("background-color", "transparent");
        $(".leagueLink").css("color", "black");
        homePage.applyLiveInPlayColourScheme();
        $('*[id^="submenu_"]').hide();
        $(".top-and-fav-leagues-container").removeClass("hidden");
        homePage.initTopLeaguesSlick("#top-leagues-div, #fav-leagues-div");
        this.toggleFavLeagueFilterTick(!1);
        n && this.applyFilters(!1, t);
        $("#selectedLCount").text("0") ? ($("#clearLFilters").attr("style", "display:none"), $("#synapseBar_highlights").addClass("active-tab v-btn--active"), $("#synapseBar_prematchtab").removeClass("active-tab v-btn--active"), $("#highlights").addClass("active"), $("#Upcoming").removeClass("active")) : $("#clearLFilters").attr("style", "display:flex")
    },
    resetLeagueTicks: function() {
        var n = $(".leagues-ul");
        n.find("li.league-item").removeClass("isChecked");
        n.find("li.league-item").children("input").prop("checked", !1);
        n.find("li.league-item").children("span").removeClass("glyphicon-check");
        n.find("li.league-item").children("span").addClass("glyphicon-unchecked");
        $("#selectedLCount").text("0");
        $.cookie("FilterCount", 0)
    },
    isEsport: function() {
        return window.location.href.toLowerCase().indexOf("/esports") > -1 || window.location.href.toLowerCase().indexOf("/esport/") > -1
    },
    updateSportTileFilters: function(n, t) {
        localStorage.setItem("currentSportId", n);
        var i = this.getCurrentSportFilters(n);
        i != null ? sportFilters = i : i = {
            sportConfigId: n,
            couponTypeId: "",
            FeedDataTypeId: t,
            leagueIds: [],
            DateRange: {
                PredeterminedTime: "None",
                From: null,
                To: null
            },
            OddsRange: {
                From: 1,
                To: 9999
            },
            isEsport: !1,
            MarketSet: !1
        };
        this.updateSportFilters(n, i)
    },
    renderRunTimeTranslation: function(n, t, i, r) {
        language.removeTranslateAttributes(t);
        n === "odds" ? language.translateAtRuntime($(".filter-odds-label"), "SportContent", {
            "data-translate-key": "FilterOdds",
            "data-translate-value-0": sportFilters.OddsRange.From,
            "data-translate-value-1": sportFilters.OddsRange.To
        }) : language.translateAtRuntime(t, i, {
            "data-translate-key": language.generateKey(r)
        })
    },
    checkForDisabledFilters: function() {
        $(".disabled-filters").each(function() {
            var n = $(this).data().tag;
            $("." + n + "-filter-box").find("h2").removeClass("filterApplied");
            filterOptions.clearFilter(n)
        })
    },
    resetFilters: function() {
        filterOptions.resetLeagueTicks();
        $(".filterApplied").removeClass("filterApplied");
        var n = filterOptions.getFilterCache();
        return n.Owner = _hashedSessionId, n.leagueIds = [], n.couponTypeId = "", n.DateRange = {
            PredeterminedTime: "None",
            From: null,
            To: null
        }, n.OddsRange = {
            From: 1,
            To: 9999
        }, n.MarketSet = !1, filterOptions.updateFilterCache(n), n
    },
    initFiltersBySport: function() {
        var n = {
            Owner: _hashedSessionId
        };
        return n[filterOptions.getCurrentSportId()] = filterOptions.initSportFilter(), localStorage.setItem(this.isPrintFilters() ? "PrintFixturesFilters" : "AllSportFilters", JSON.stringify(n)), n
    },
    getAllSportFilters: function() {
        var n = JSON.parse(localStorage.getItem(this.isPrintFilters() ? "PrintFixturesFilters" : "AllSportFilters"));
        return n != null ? n : this.initFiltersBySport()
    },
    getCurrentSportFilters: function(n) {
        var t = this.getAllSportFilters(),
            i = n == null ? filterOptions.getCurrentSportId() : n;
        return t[i] != null ? t[i] : this.initSportFilter()
    },
    updateSportFilters: function(n, t) {
        var i = this.getAllSportFilters();
        t.sportConfigId = n;
        i[n] = t;
        localStorage.setItem(this.isPrintFilters() ? "PrintFixturesFilters" : "AllSportFilters", JSON.stringify(i))
    },
    getFilterSessionId: function() {
        var n = this.getAllSportFilters();
        return n.Owner
    },
    initSportFilter: function() {
        return sportFilters = {
            sportConfigId: this.getCurrentSportId(),
            couponTypeId: "",
            FeedDataTypeId: "00000000-0000-0000-da7a-000000580001",
            leagueIds: [],
            DateRange: {
                PredeterminedTime: "None",
                From: null,
                To: null
            },
            OddsRange: {
                From: 1,
                To: 9999
            },
            isEsport: !1,
            MarketSet: !1
        }
    },
    resetFilterText: function(n) {
        $(".filter-" + n + "-label").text($(".filter-" + n + "-label").data().defaultText);
        language.translateAtRuntime($(".filter-" + n + "-label"), "SportContent", {
            "data-translate-key": language.generateKey($(".filter-" + n + "-label").data().defaultText)
        })
    },
    getTickedLeagueIds: function() {
        let n = [];
        return $("li.league-item.isChecked").each(function() {
            n.push($(this).attr("id"))
        }), n
    },
    isPrintFilters: function() {
        return $("#hfPrintFixtures").val() != null
    },
    applyFavoritesLeagueFilters: function(n) {
        isAccountFavoriteEnabled && (n = $(n).find("input")[0], n.checked ? (n.checked = !1, this.toggleFavLeagueFilterTick(!1), this.resetLeagues()) : (n.checked = !0, this.toggleFavLeagueFilterTick(!0), this.confirmLeagues(null, !0)))
    },
    toggleFavLeagueFilterTick: function(n) {
        n === !0 ? ($(".fav-leagues-filter-check").removeClass("glyphicon-unchecked").addClass("glyphicon-check"), $("#favoriteLeaguesCheck").prop("checked", !0), localStorage.setItem("isFavouriteLeaguesFilter", !0)) : ($(".fav-leagues-filter-check").removeClass("glyphicon-check").addClass("glyphicon-unchecked"), $("#favoriteLeaguesCheck").prop("checked", !1), localStorage.removeItem("isFavouriteLeaguesFilter"))
    }
}