function SetBetslip(n) {
    var t = "betslipStorage";
    lsTest() === !0 ? localStorage.setItem(t, JSON.stringify(n)) : setCookie(t, JSON.stringify(n), .01)
}

function GetBetslip() {
    var n = "betslipStorage";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "{}" : localStorage.getItem(n) : getCookie(n)
}

function SetBetslipOptions(n) {
    var t = "betslipStorageOptions";
    lsTest() === !0 ? localStorage.setItem(t, JSON.stringify(n)) : setCookie(t, JSON.stringify(n), .01)
}

function GetBetslipOptions() {
    var n = "betslipStorageOptions";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function SetBetslipOption(n, t) {
    var r = GetBetslipOptions(),
        i = {};
    r !== "" && (i = JSON.parse(r));
    i[n] = t;
    SetBetslipOptions(i)
}

function GetBetslipOption(n) {
    var t = GetBetslipOptions(),
        i = {};
    return t !== "" && (i = JSON.parse(t)), i[n]
}

function SetBookingCode(n) {
    var t = "betslipBookingCode";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetBookingCode() {
    var n = "betslipBookingCode";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function SetStretchStorage(n) {
    var t = "stretchStorage";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetStretchStorage() {
    var n = "stretchStorage";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function SetMoneyBackBoostStorage(n) {
    var t = "moneyBackBoostStorage";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetMoneyBackBoostStorage() {
    var n = "moneyBackBoostStorage";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function SetBuildABetStorage(n) {
    var t = "buildABetStorage";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetBuildABetStorage() {
    var n = "buildABetStorage";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function SetBuildABetTmpBetslipStorage(n) {
    var t = "buildABetTmpBetslip";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetBuildABetTmpBetslipStorage() {
    var n = "buildABetTmpBetslip";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function ClearBuildABetTmpForExpiredEvents() {
    var n;
    if (!checkForLite() && (n = GetBuildABetTmpBetslipStorage(), n !== "" && n !== "[]")) {
        var t = [],
            i = new Date,
            r = JSON.parse(n);
        $.each(r, function(n, r) {
            var u = new Date(r.StartDate),
                f = (i.getTime() + timeZoneOffset * 6e4 - u.getTime()) / 6e4;
            f > 0 || t.push(r)
        });
        SetBuildABetTmpBetslipStorage(JSON.stringify(t))
    }
}

function SetBetslipToggle(n) {
    var t = "betslipToggle";
    lsTest() === !0 ? localStorage.setItem(t, n) : setCookie(t, n, .01)
}

function GetBetslipToggle() {
    var n = "betslipToggle";
    return lsTest() === !0 ? localStorage.getItem(n) === null || typeof localStorage.getItem(n) == "undefined" ? "" : localStorage.getItem(n) : getCookie(n)
}

function UpdateSingleMultiBet() {
    var n, t, i;
    if (GetBetslipOption("IsSingleBet") === !0) {
        if (checkForLite() || gax.SetSingleOrMultiBet("MultiBet"), n = !1, t = GetBetslip(), t !== "" && t !== "{}" && (i = JSON.parse(t), n = betslipMultiSelectorEnabled ? !1 : checkDuplicateInObject("EventId", i)), n && !betslipMultiSelectorEnabled) return document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = "You cannot change to multiple bets because there is more than one selection for the same event", language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
            "data-translate-key": "CannotChangeToMultipleBets"
        }), document.getElementById("sb_id").classList.add("active"), document.getElementById("singleb") && (document.getElementById("singleb").checked = GetBetslipOption("IsSingleBet")), n;
        SetBetslipOption("IsSingleBet", !1)
    } else checkForLite() || gax.SetSingleOrMultiBet("SingleBet"), SetBetslipOption("IsSingleBet", !0);
    checkForLite() ? window.location.reload() : (document.getElementById("betslip-single-multi-error").style.display = "none", GetBetslipOption("IsSingleBet") === !0 ? (document.getElementById("sb_id").className.includes("active") || (document.getElementById("sb_id").className += " active"), document.getElementById("mb_id").className = document.getElementById("mb_id").className.replace("active", "")) : (document.getElementById("mb_id").className.includes("active") || (document.getElementById("mb_id").className += " active"), document.getElementById("sb_id").className = document.getElementById("sb_id").className.replace("active", "")))
}

function UpdateBetslipFullVersion(n = false) {
    var e = GetBetslipOption("IsSingleBet") === !0,
        t = JSON.parse(GetBetslip()),
        i = !0,
        o = document.getElementById("bookABetSearch"),
        r, u, f;
    if (t.length === null || t.length === undefined) {
        if (i = !0, document.getElementById("oddsAndRemoveAll") !== null && typeof document.getElementById("oddsAndRemoveAll") != "undefined" && (document.getElementById("oddsAndRemoveAll").style.display = "none"), document.getElementById("betslipFooterEmpty") !== null && typeof document.getElementById("betslipFooterEmpty") != "undefined" && (document.getElementById("betslipFooterEmpty").style.display = ""), document.getElementById("betslipFooter") !== null && typeof document.getElementById("betslipFooter") != "undefined" && (document.getElementById("betslipFooter").style.display = "none"), document.getElementById("sigleBetsCount") !== null && typeof document.getElementById("sigleBetsCount") != "undefined" && (document.getElementById("sigleBetsCount").innerHTML = ""), document.getElementById("multipleBetsCount") !== null && typeof document.getElementById("multipleBetsCount") != "undefined" && (document.getElementById("multipleBetsCount").innerHTML = ""), document.getElementsByClassName("betslipCountBadgeCount").length > 0)
            for (r = 0; r < document.getElementsByClassName("betslipCountBadgeCount").length; r++) document.getElementsByClassName("betslipCountBadgeCount")[r].innerHTML = "0";
        document.getElementById("bookABetContainer").classList.remove("col-xs-7", "col-sm-7", "col-md-7", "col-lg-6");
        document.getElementById("bookABetContainer").classList.add("col-xs-12")
    } else {
        if (i = !1, document.getElementById("oddsAndRemoveAll") !== null && document.getElementById("oddsAndRemoveAll") !== null && (document.getElementById("oddsAndRemoveAll").style.display = ""), document.getElementById("betslipFooterEmpty") !== null && document.getElementById("betslipFooterEmpty") !== null && (document.getElementById("betslipFooterEmpty").style.display = "none"), document.getElementById("betslipFooter") !== null && document.getElementById("betslipFooter") !== null && (document.getElementById("betslipFooter").style.display = ""), document.getElementsByClassName("betslipCountBadgeCount").length > 0) {
            for (u = 0; u < document.getElementsByClassName("betslipCountBadgeCount").length; u++) document.getElementsByClassName("betslipCountBadgeCount")[u].innerHTML = t.length;
            f = document.getElementById("betslipCountBadge");
            f.classList.add("animate__bet");
            setTimeout(function() {
                f.classList.remove("animate__bet")
            }, 1e3)
        }
        e ? (document.getElementById("totalPriceDecimal") !== null && document.getElementById("totalPriceDecimal") !== null && (document.getElementById("totalPriceDecimal").style.display = "none"), document.getElementById("divPotentialWager") !== null && document.getElementById("divPotentialWager") !== null && (document.getElementById("divPotentialWager").style.display = "none"), document.getElementById("divPotentialReturn") !== null && document.getElementById("divPotentialReturn") !== null && (document.getElementById("divPotentialReturn").style.display = "none"), document.getElementById("divPotentialsigleBetsCountReturn") !== null && document.getElementById("divPotentialsigleBetsCountReturn") !== null && (document.getElementById("sigleBetsCount").innerHTML = t.length), document.getElementById("multipleBetsCount") !== null && document.getElementById("multipleBetsCount") !== null && (document.getElementById("multipleBetsCount").innerHTML = ""), document.getElementById("multiFreeBet") !== null && document.getElementById("multiFreeBet") !== null && (document.getElementById("multiFreeBet").style.display = "none"), document.querySelector(".bonus-checkboxes-container-multi-bet") != null && (document.querySelector(".bonus-checkboxes-container-multi-bet").style.display = "none")) : (document.getElementById("totalPriceDecimal") !== null && document.getElementById("totalPriceDecimal") !== null && (document.getElementById("totalPriceDecimal").style.display = ""), document.getElementById("divPotentialWager") !== null && document.getElementById("divPotentialWager") !== null && (document.getElementById("divPotentialWager").style.display = ""), document.getElementById("divPotentialReturn") !== null && document.getElementById("divPotentialReturn") !== null && (document.getElementById("divPotentialReturn").style.display = ""), document.getElementById("sigleBetsCount") !== null && document.getElementById("sigleBetsCount") !== null && (document.getElementById("sigleBetsCount").innerHTML = ""), document.getElementById("multipleBetsCount") !== null && document.getElementById("multipleBetsCount") !== null && (document.getElementById("multipleBetsCount").innerHTML = typeof t.length == "undefined" ? 0 : t.length), document.getElementById("multiFreeBet") !== null && document.getElementById("multiFreeBet") !== null && document.getElementById("hasFreeBetsVar").value === "True" && (document.getElementById("multiFreeBet").style.display = "", document.querySelector(".freeMutliBetContainer").style.display = "flex"), document.querySelector(".bonus-checkboxes-container-multi-bet") != null && (document.querySelector(".bonus-checkboxes-container-multi-bet").style.display = "block"), incrementalPayoutLimitsEnabled && IncrementalPayoutLimits.checkBetSlipSelections(t));
        betslipMultiSelectorEnabled && (document.getElementById("bookABetContainer").classList.remove("col-xs-12"), document.getElementById("bookABetContainer").classList.add("col-xs-7", "col-sm-7", "col-md-7", "col-lg-6"))
    }
    o !== null && typeof o != "undefined" && (document.getElementById("placeCashBetSpan").classList.remove("col-lg-12"), document.getElementById("placeCashBetSpan").classList.add("col-lg-8"), document.getElementById("bookABet").style.display = "", document.getElementById("bookABetSearch").style.display = "");
    isLoggedIn || document.querySelector(".bonus-checkboxes-container-multi-bet") != null && (document.querySelector(".bonus-checkboxes-container-multi-bet").style.display = "none");
    GenerateBetControls(e, t, n);
    isMobileScreen() ? $("#back-to-bets-button-group").show() : $("#back-to-bets-button-group").hide();
    document.getElementById("sigleBetsCount").classList.toggle("betslipBetsCount", t.length > 0);
    document.getElementById("multipleBetsCount").classList.toggle("betslipBetsCount", t.length > 0);
    UpdateVisualElementsOnBetslip();
    i && !homePage.isBigWinnerWidgetShowing ? homePage.toggleBigWinnerWidget() : i || homePage.toggleBigWinnerWidget(!0)
}

function RemoveBet(n) {
    checkForLite() ? (confirm("Are you sure you want to remove this bet?") && (RemoveBetIDOutcomeForGA(n), SendToBetslip(n, "", "", "", "", "", "", "", "", "", "", "", "")), post_to_url("/Bet/Betslip", null, "get")) : (RemoveBetIDOutcomeForGA(n), SendToBetslip(n, "", "", "", "", "", "", "", "", "", "", "", ""))
}

function RemoveBetIDOutcomeForGA(n) {
    var t = 0,
        i = 0,
        r = JSON.parse(GetBetslip());
    r.forEach(function(r) {
        r.OutcomeId === n && (i = t);
        t++
    });
    checkForLite() || gax.RemoveBetSlipPOI(i)
}

function ClearOnlySuccessfulBets(n) {
    var t, i, r, u, f, e;
    if (checkForLite() || gax.ResetBetSlipPOICount(), checkForLite()) SetBetslip({}), post_to_url("/Bet/Betslip", null, "get");
    else {
        if (t = JSON.parse(GetBetslip()), t.length !== null && typeof t.length != "undefined" && t.length > 0) {
            for (i = [], $(".unsuccessfulBet").each(function() {
                    i.push(this.id.replace("SelectedOutcomeForBetslip-", ""))
                }), r = 0; r < t.length; r++) u = t[r], _.contains(i, u.OutcomeId) ? $(".outcomeRow-Info:contains('" + u.EventTitle + "')").closest(".SelectedOutcomeForBetslip").addClass("unsuccessfulBet").find(".outcomeRow-title").css("color", "red") : SendToBetslip(u.OutcomeId, "", "", "", "", "", "", "", "", "", "", "", "", "", "", n);
            for (f = 0; f < i.length; f++) $("#SelectedOutcomeForBetslip-" + i[f]).addClass("unsuccessfulBet").find(".outcomeRow-title").css("color", "red")
        }
        e = GetBetslipOption("MinBetAmount");
        isNaN(parseFloat(e)) || (SetBetslipOption("WagerAmount", e), document.getElementById("wagerAmount").value = parseFloat(e).toFixed(2))
    }
    SetBookingCode("");
    ClearBookABetSearch()
}

function ClearMSSuccessfulBets(n) {
    var t = JSON.parse(GetBetslip()),
        i, r;
    if (t.length !== null && typeof t.length != "undefined" && t.length > 0)
        for (i = 0; i < t.length; i++) r = t[i], r.Ticked && SendToBetslip(r.OutcomeId, "", "", "", "", "", "", "", "", "", "", "", "", "", n);
    SetBookingCode("");
    ClearBookABetSearch();
    ClearAccumulatorsFromBetslip()
}

function ClearBetslip(n) {
    var t, r, u, i;
    if (checkForLite() || gax.ResetBetSlipPOICount(), checkForLite()) SetBetslip({}), post_to_url("/Bet/Betslip", null, "get");
    else {
        if (t = JSON.parse(GetBetslip()), t.length !== null && typeof t.length != "undefined" && t.length > 0)
            for (r = 0; r < t.length; r++) u = t[r], SendToBetslip(u.OutcomeId, "", "", "", "", "", "", "", u.EventId, "", "", "", "", "", "", n, !1, null, null, null);
        i = GetBetslipOption("MinBetAmount");
        isNaN(parseFloat(i)) || enableWagerTax ? enableWagerTax && (SetBetslipOption("InitialStake", parseFloat(i).toFixed(2)), document.getElementById("stakeBeforeWagerTax").value = parseFloat(i).toFixed(2), checkWager()) : (SetBetslipOption("WagerAmount", i), document.getElementById("wagerAmount").value = parseFloat(i).toFixed(2));
        $("#right #betslip-container").css("background-color") == "rgb(238, 238, 238)" && screen.width >= 1200 && ($("#right #betslip-container").css({
            "overflow-y": "initial",
            "background-color": "transparent"
        }), $(".betslip-body").css("flex-shrink", "10"), IsWinboostTableEnabled() && document.getElementById("stretchOfferTable").style.display == "block" && (document.getElementById("stretchOfferTable").style.display = "none", document.getElementById("stretchArrows").innerHTML = "expand_more"))
    }
    ClearAccumulatorsFromBetslip();
    SetBookingCode("");
    ClearBookABetSearch()
}

function ClearBookABetSearch() {
    var n = document.getElementsByClassName("bookingCodeSearch");
    n !== null && n !== undefined && n.length > 0 && n[0] !== null && n[0] !== undefined && (n[0].value = "")
}

function checkDuplicateInObject(n, t) {
    var r = !1,
        i = {};
    return t.map(function(t) {
        var u = t[n];
        u in i ? (i[u].duplicate = !0, t.duplicate = !0, r = !0) : (i[u] = t, delete t.duplicate)
    }), r
}

function checkForLite() {
    return document.getElementById("iAmNotSoLite") ? !1 : !0
}

function isMobileScreen() {
    return window.innerWidth < 1025
}

function ChooseSingleBet(n, t = false) {
    var u = JSON.parse(GetBetslip()),
        r = document.getElementById("BetSingleBet" + n),
        i = r !== null && r !== undefined ? r.checked : !1,
        f;
    i && GetBetslipOption("SingleFreebetId") == n && (i = !1);
    t && (i = !1);
    !checkForLite() && betslipMultiSelectorEnabled && i && (checkMaxSelectedReached() || ($("#SelectedCheckBoxForBetslip-" + n).prop("checked", !0), f = u.findIndex(function(t) {
        return t.OutcomeId === n
    }), u[f].Ticked = !0, SetBetslip(u), updateBetslipCounts(u)), i = document.getElementById("SelectedCheckBoxForBetslip-" + n).checked, r != null && (r.checked = i), disableBetting());
    i ? (SetBetslipOption("SingleFreebetId", n), ChooseSportBonusSingleBet(n, !0)) : (SetBetslipOption("SingleFreebetId", ""), r != null && (r.checked = i));
    toggleSingleFreeBets(i, n);
    checkForLite() || UpdateVisualElementsOnBetslip()
}

function toggleSingleFreeBets(n, t) {
    var u = "",
        e, f, r;
    if (checkForLite() || (u = isThousandSeperatorEnabled ? "label" : ""), e = document.getElementById("BetSingleBet" + t), f = document.getElementsByClassName("SingleFreeBet"), n === !0)
        for (i = 0; i < f.length; i += 1) r = f[i].id.replace("BetSingleBet", ""), u = "", checkForLite() || (u = isThousandSeperatorEnabled ? "label" : ""), f[i].id !== "BetSingleBet" + t ? (bsCheckboxToggle(r, !1), UpdateFreeSingleBet(r, !1), e != null && (e.checked = !1), document.getElementById("wagerAmount" + r + u) != undefined && document.getElementById("wagerAmount" + r + u) != null && (document.getElementById("wagerAmount" + r + u).disabled = !1)) : (document.getElementById("wagerAmount" + r + u) != undefined && document.getElementById("wagerAmount" + r + u) != null && (document.getElementById("wagerAmount" + r + u).disabled = !0), enableWagerTax && (document.getElementById("stakeBeforeWagerTax" + r + u).disabled = !0, document.getElementById("stakeBeforeWagerTax" + r).value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2)), f[i].disabled = !1, bsCheckboxToggle(r, !0), UpdateFreeSingleBet(r, !0), e != null && (e.checked = !0), SetBetslipOption("SingleSportBonusbetId-" + t, ""), UpdateSportBonusSingleBet(t, !1), bsSportBonusCheckboxToggle(t, !1), document.getElementById("accountFreeBetAmount") && document.getElementById("accountFreeBetAmount").innerText !== "" && document.getElementById("accountFreeBetAmount").innerText !== "0.00" ? document.getElementById("wagerAmount" + t).value = parseFloat(document.getElementById("accountFreeBetAmount").innerText).toFixed(2) : getCookie("CurrentFreeBetAmount") && (document.getElementById("wagerAmount" + t).value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2)), document.getElementById("wagerAmount" + t) != undefined && document.getElementById("wagerAmount" + t) != null && (document.getElementById("wagerAmount" + t).disabled = !0), UpdatePotentialSingleReturn(t));
    else {
        for (i = 0; i < f.length; i += 1) r = f[i].id.replace("BetSingleBet", ""), document.getElementById("wagerAmount" + r + u) != undefined && document.getElementById("wagerAmount" + r + u) != null && (document.getElementById("wagerAmount" + r + u).disabled = !1), enableWagerTax && (document.getElementById("stakeBeforeWagerTax" + r + u).disabled = !1), bsCheckboxToggle(r, !1, !1), f[i].disabled ? f[i].disabled = !1 : UpdateFreeSingleBet(r, !1);
        UpdatePotentialSingleReturn(t, !0)
    }
}

function UpdateFreeSingleBet(n, t) {
    var i = JSON.parse(GetBetslip()),
        r;
    bet = i.find(function(t) {
        return t.OutcomeId === n
    });
    r = i.indexOf(bet);
    ~r && (bet.IsSingleFreeBet = t, i[r] = bet, SetBetslip(i))
}

function WriteBet(n, t) {
    t ? (document.write('<div class="betslip-panel spacing-bottom clearfix">'), document.write('  <span href="#" onclick="RemoveBet(\'' + n.OutcomeId + '\')" class="pull-left delete">X<\/span>'), document.write(' <div class="betslip-panel-inner spacing-bottom">'), document.write('<b class="outcome-title pull-left">' + n.Title + "<\/b>"), document.write(' <span class="pull-right"> ' + parseFloat(n.PriceDecimal).toFixed(2) + "<\/span>"), document.write(' <span class="clearfix outcome-result"> ' + n.MarketTitle + "<\/span>"), document.write(' <span class="clearfix outcome-eventTitle" style="width: 65%;overflow: hidden;text-overflow:  ellipsis;white-space: nowrap;"> ' + n.EventTitle + "<\/span>"), document.write('<input type="number" step=".01" style="margin-top:-18px;width:70px;" inputmode="decimal" id="wagerAmount' + n.OutcomeId + '" value="' + parseFloat(n.WagerAmount === null || typeof n.WagerAmount == "undefined" ? GetBetslipOption("MinBetAmount") : n.WagerAmount).toFixed(2) + '" class="betslip-total-input pull-right" onchange="UpdatePotentialSingleReturn(\'' + n.OutcomeId + '\')" /><b style="text-align:right;float:right;margin-top:-9px;">' + sign + "<\/b>"), document.write(' <span id="potentialReturn' + n.OutcomeId + '" class="pull-left p-return-single-lite" onclick="UpdatePotentialSingleReturn(\'' + n.OutcomeId + "');\"><\/span>"), n.IsSingleFreeBet === !0 ? (document.write("<br/><div " + freebetStyle + '><input id="BetSingleBet' + n.OutcomeId + '" class="SingleFreeBet" checked type="checkbox" title="SingleBets" onclick="ChooseSingleBet(\'' + n.OutcomeId + "');\"/>Free Bet<\/div>"), SetBetslipOption("SingleFreebetId", n.OutcomeId)) : document.write("<br/><div " + freebetStyle + '><input id="BetSingleBet' + n.OutcomeId + '" class="SingleFreeBet" type="checkbox" title="SingleBets" onclick="ChooseSingleBet(\'' + n.OutcomeId + "');\"/>Free Bet<\/div>"), n.IsSingleSportBonusBet === !0 ? (document.write("<br/><div " + sportBonusStyle + '><input id="BetSportBonusSingleBet' + n.OutcomeId + '" class="SingleSportBonusBet" checked type="checkbox" title="SingleBets" onclick="ChooseSportBonusSingleBet(\'' + n.OutcomeId + "');\"/>Use Sports Bonus<\/div>"), SetBetslipOption("SingleSportBonusbetId-" + n.OutcomeId + n.OutcomeId, n.OutcomeId)) : document.write("<br/><div " + sportBonusStyle + '><input id="BetSportBonusSingleBet' + n.OutcomeId + '" class="SingleSportBonusBet" type="checkbox" title="SingleBets" onclick="ChooseSportBonusSingleBet(\'' + n.OutcomeId + "');\"/>Use Sports Bonus<\/div>"), document.write(" <\/div>"), document.write(" <\/div>"), UpdatePotentialSingleReturn(n.OutcomeId)) : (document.write('<div class="betslip-panel spacing-bottom clearfix">'), document.write('  <span href="#" onclick="RemoveBet(\'' + n.OutcomeId + '\')" class="pull-left delete">X<\/span>'), document.write(' <div class="betslip-panel-inner spacing-bottom">'), document.write('<b class="outcome-title pull-left">' + n.Title + "<\/b>"), document.write(' <span class="pull-right"> ' + parseFloat(n.PriceDecimal).toFixed(2) + "<\/span>"), document.write(' <span class="clearfix outcome-result"> ' + n.MarketTitle + "<\/span>"), document.write(' <span class="clearfix outcome-eventTitle"> ' + n.EventTitle + "<\/span>"), document.write(" <\/div>"), document.write(" <\/div>"))
}

function addHoursToDate(n, t) {
    return new Date(new Date(n).setHours(n.getHours() + t))
}

function diff_hours(n, t) {
    var r = (n.getTime() - t.getTime()) / 1e3,
        i;
    return r /= 3600, i = Math.abs(r), n > t && (i = i * -1), i
}

function diff_minutes(n, t) {
    var r = t - n,
        i = Math.round(r % 864e5 % 36e5 / 6e4);
    return n > t && (i = i * -1), i
}

function GenerateBetControls(n, t, i = false) {
    var e = parseFloat(0),
        o = parseFloat(0),
        g = parseFloat(0),
        s = Number("0"),
        l = [],
        c = [],
        u, a, nt, w, b, v, tt, f, k, d, y, it, h, r, p, rt;
    if ($("#betslip-list").attr("style", "height:initial"), document.getElementById("betslip-list") !== null && typeof document.getElementById("betslip-list") != "undefined" && document.getElementsByClassName("unsuccessfulBet").length === 0 && (document.getElementById("betslip-list").innerHTML = ""), t.length > 0 && document.getElementById("betslip-list") !== null && typeof document.getElementById("betslip-list") != "undefined") {
        if (betslipMultiSelectorEnabled) {
            if (!checkForLite()) {
                for (document.getElementById("betslip-count").innerText = t.length, $(".ms-select-all").removeClass("hidden"), updateBetslipCounts(t), tt = _.groupBy(t, "EventId"), f = t.filter(function(n) {
                        return n.Ticked === !0
                    }), r = 0; r < f.length; r++) f[r].IsTrendingOutcome && (e == 0 ? e = (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2) : e *= (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2));
                o = parseFloat(_.reduce(_.pluck(f, "PriceDecimal"), function(n, t) {
                    return parseFloat(n * t)
                })).toFixed(2);
                _.each(tt, function(t) {
                    for (var r, f, h, o, s, e, u = 0; u < t.length; u++) {
                        if (r = t[u], removeExpiredSelectionsEnabled && i == !0) {
                            let n = new Date(r.StartDate);
                            f = new Date(utc);
                            f.setMinutes(f.getMinutes() - Number(timeZoneOffsetUtcToBrand));
                            h = diff_hours(n, f);
                            [constId.feedDataType_Prematch, constId.feedDataType_LIP, constId.emptyGuid].includes(r.FeedDataTypeId) && h >= hourDifferenceToRemoveBetsFromBetslip && l.push(r)
                        }
                        r.isAllowBetting = !$("#" + r.OutcomeId).hasClass("disableSelectedElement") && !$("#" + r.OutcomeId).hasClass("disableElement");
                        o = WriteBetFull(r, n);
                        o !== "" && (s = document.createElement("SelectedOutcomeForBetslip-" + r.OutcomeId), s.innerHTML = o, document.getElementById("betslip-list").appendChild(s), r.isAllowBetting || document.getElementById("SelectedOutcomeForBetslip-" + r.OutcomeId) === undefined || document.getElementById("SelectedOutcomeForBetslip-" + r.OutcomeId) === null || (document.getElementById("SelectedOutcomeForBetslip-" + r.OutcomeId).style.color = "#c9c9c9"), language.translateSection("betslip"), r.IsSingleFreeBet && isLoggedIn && (document.getElementById("BetSingleBet" + r.OutcomeId).checked = !0, $("#wagerAmount" + r.OutcomeId).attr("disabled", "disabled")), r.IsSingleSportBonusBet && (document.getElementById("BetSportBonusSingleBet" + r.OutcomeId).checked = !0), r.IsGroupHeader && WriteBetFullGroupChildItems(r, n));
                        n && (g = UpdatePotentialSingleReturn(r.OutcomeId, !1, r.BoostedOddPercentage));
                        GetBetslipOption("SingleSportBonusbetId-" + r.OutcomeId) && GetBetslipOption("SingleSportBonusbetId-" + r.OutcomeId).length > 0 && ChooseSportBonusSingleBet(GetBetslipOption("SingleSportBonusbetId-" + r.OutcomeId));
                        u < t.length - 1 ? $("#SelectedOutcomeForBetslip-" + t[u].OutcomeId).removeClass("ms-divider") : $("#SelectedOutcomeForBetslip-" + t[u].OutcomeId).addClass("ms-divider");
                        t.length > 1 && n ? $("#BetslipItem-" + t[u].OutcomeId).addClass("ms-grouping-border") : $("#BetslipItem-" + t[u].OutcomeId).removeClass("ms-grouping-border");
                        dynamicLIPBetslipCalculationEnabled && document.getElementById(`SelectedOutcomeForBetslip-${t[u].OutcomeId}`) && (e = $(`#SelectedOutcomeForBetslip-${t[u].OutcomeId} #priceDecimal-${t[u].OutcomeId}`).text().replace("%lessPriceDecimal%", "").replace("lock", ""), !t[u].PriceDecimal > 0 && t[u].Ticked && c.push(t[u].OutcomeId), (e == undefined || e == null || e == 0 && t[u].Ticked) && c.push(t[u].OutcomeId), $(`#SelectedOutcomeForBetslip-${t[u].OutcomeId} #priceDecimal-${t[u].OutcomeId}`).text().includes("lock") && (c.push(t[u].OutcomeId), tempLockedOutcomes.includes(t[u].OutcomeId) || tempLockedOutcomes.push(t[u].OutcomeId)))
                    }
                });
                checkForSportBonus(t);
                n ? ($(".alert-conflict").addClass("hidden"), $(".fa-exclamation-circle.conflicted").removeClass("conflicted")) : checkForConflicts(t);
                checkMaxSelectedReached();
                disableBetting();
                $("#chkSelectAll").prop("checked", $(".multiselect-cb input:checkbox:checked").length === t.length)
            }
        } else {
            for (r = 0; r < t.length; r++) {
                if (u = t[r], removeExpiredSelectionsEnabled && i == !0) {
                    let n = new Date(u.StartDate);
                    a = new Date(utc);
                    a.setMinutes(a.getMinutes() - Number(timeZoneOffsetUtcToBrand));
                    nt = diff_hours(n, a);
                    [constId.feedDataType_Prematch, constId.feedDataType_LIP, constId.emptyGuid].includes(u.FeedDataTypeId) && nt >= hourDifferenceToRemoveBetsFromBetslip && l.push(u)
                }
                w = Number(u.BoostedOddPercentage);
                o === 0 ? (o = parseFloat(u.PriceDecimal).toFixed(2), isLessBetslipValuesEnabled && u.IsTrendingOutcome && (e = parseFloat(u.PriceDecimal * ((100 - w) / 100)).toFixed(2), totalTickedBoostedOddPercentage++)) : (o *= parseFloat(u.PriceDecimal).toFixed(2), isLessBetslipValuesEnabled && (e *= u.IsTrendingOutcome ? parseFloat(u.PriceDecimal * ((100 - w) / 100)).toFixed(2) : parseFloat(u.PriceDecimal).toFixed(2)));
                b = WriteBetFull(u, n);
                b !== "" && (v = document.createElement("SelectedOutcomeForBetslip-" + u.OutcomeId), v.innerHTML = b, typeof u.HasError != "undefined" && u.HasError && setInvalidOutcomeStyle(v), document.getElementById("betslip-list").appendChild(v), language.translateSection("betslip"), u.IsSingleFreeBet && (document.getElementById("BetSingleBet" + u.OutcomeId).checked = !0), u.IsSingleSportBonusBet && (document.getElementById("BetSportBonusSingleBet" + u.OutcomeId).checked = !0), u.IsGroupHeader && WriteBetFullGroupChildItems(u, n));
                n && (g = UpdatePotentialSingleReturn(u.OutcomeId));
                GetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId) && GetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId).length > 0 && ChooseSportBonusSingleBet(GetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId))
            }
            isLessBetslipValuesEnabled && (s == 0 ? (e == 0, document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px", hideAllLessPotentialReturn("boostedOdd")) : showAllLessPotentialReturn("boostedOdd"));
            $("#BetExtentionExpandToggle").text().indexOf("expand_more") > -1 ? (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").setAttribute("hidden", !0), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").setAttribute("hidden", !0), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").setAttribute("hidden", !0)) : (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").removeAttribute("hidden"), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").removeAttribute("hidden"), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").removeAttribute("hidden"))
        }
        for (k = document.getElementById("betslip-list").children, d = 0, r = 0; r < k.length; r++) y = k[r].children[0], (y != null || y != undefined) && (it = y.style.color, it == "rgb(201, 201, 201)" && d++);
        if (d <= 0 ? ($("#AlertLockedLIPMarket").addClass("hidden"), isMiniBetslipConflicting = !1) : ($("#AlertLockedLIPMarket").removeClass("hidden"), isMiniBetslipConflicting = !0), miniBetslip(), $("#BetExtentionExpandToggle").text().indexOf("expand_more") > -1 ? (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").setAttribute("hidden", !0), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").setAttribute("hidden", !0), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").setAttribute("hidden", !0)) : (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").removeAttribute("hidden"), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").removeAttribute("hidden"), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").removeAttribute("hidden")), GetBetslipOption("SingleFreebetId") && GetBetslipOption("SingleFreebetId").length > 0, isLessBetslipValuesEnabled) {
            for (h = parseFloat("0"), r = 0; r < f.length; r++) f[r].IsTrendingOutcome && (e == 0 ? (e = (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2), s++) : (s++, e *= (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2)));
            for (r = 0; r < f.length; r++) f[r].IsTrendingOutcome && (h == 0 ? (h = (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2), s++) : (s++, h *= (f[r].PriceDecimal * ((100 - f[r].BoostedOddPercentage) / 100)).toFixed(2)));
            s == 0 ? (e == 0, document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px", hideAllLessPotentialReturn("boostedOdd")) : showAllLessPotentialReturn("boostedOdd");
            p = _.reduce(_.pluck(_.where(f, {
                IsTrendingOutcome: !1
            }), "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            });
            e = p === undefined || p === null ? h : h * p;
            SetBetslipOption("TotalLessPriceDecimal", e === undefined ? 0 : e)
        }
        SetBetslipOption("TotalPriceDecimal", o === undefined ? 0 : o);
        n || UpdatePotentialReturn()
    } else betslipMultiSelectorEnabled && (document.getElementById("betslip-count").innerText = "0", $(".ms-select-all").addClass("hidden"));
    checkForLite() || (n || document.getElementById("isInstantBetsVar") === null || typeof document.getElementById("isInstantBetsVar") == "undefined" || document.getElementById("isInstantBetsVar").value !== "True" ? n || document.getElementById("placeCashBet") === null || typeof document.getElementById("placeCashBet") == "undefined" ? document.getElementById("placeCashBet") !== null && typeof document.getElementById("placeCashBet") != "undefined" && (document.getElementById("placeCashBet").innerText = document.getElementById("buttonContentSingle").value, language.translateAtRuntime(document.getElementById("placeCashBet"), "BetslipWidget", {
        "data-translate-key": language.generateKey(document.getElementById("buttonContentSingle").value)
    })) : (document.getElementById("placeCashBet").innerText = document.getElementById("buttonContentMulti").value, language.translateAtRuntime(document.getElementById("placeCashBet"), "BetslipWidget", {
        "data-translate-key": language.generateKey(document.getElementById("buttonContentMulti").value)
    })) : rt = GetBetslipOption("TotalPriceDecimal") || 1);
    removeExpiredSelectionsEnabled == !0 && l.length > 0 && removeExpiredSelections(l);
    isMiniBetslipEnabled && (miniBetsllipCount = t.length, t.length >= 1 ? miniBetslip() : (document.getElementById("miniBetslip").style.display = "none", moreFeaturesEnabled && document.getElementById("moreOptions").style.display == "block" && (document.getElementById("moreOptions").style.bottom = "55px !important"), document.querySelector(".ngFloatable") != undefined && document.querySelector(".ngFloatable") != null && document.querySelector(".ngFloatable").classList.remove("ngFloatable-minibetslip")));
    c.length > 0 && dynamicLIPBetslipCalculationEnabled && toggleMultiSelectorOutcome(null, null, c);
    applyCurrentBonus();
    $("#betslip-list").attr("style", "height:initial")
}

function GetSmallestTemplateGroupWithError() {
    let n = 100;
    for (let t = 0; t < tabArray.length; t++) $("#TemplateGroup_" + tabArray[t] + " :input").each(function() {
        let i = parseInt(tabArray[t]),
            r = `${$(this).attr("id")}-error`;
        $("#" + r).text().trim().length > 0 && i < n && (n = tabArray[t])
    });
    return n
}

function CreateDisplayIdTemplateField() {
    clonedIdDisplay === null && (clonedIdDisplay = $("#IDNumber_tmpl").clone(), clonedIdTypeDisplay = $("#IDType_tmpl").clone(), $(clonedIdDisplay).val($("#IDNumber_tmpl").val()), $(clonedIdTypeDisplay).val($("#IDType_tmpl").val()), $(clonedIdTypeDisplay).prop("disabled", !0), $(clonedIdTypeDisplay).prop("id", "displayOnlyIdType"), $(clonedIdTypeDisplay).insertBefore($("#CPBName_tmpl").parent()), $(clonedIdDisplay).prop("disabled", !0), $(clonedIdDisplay).prop("id", "displayOnlyId"), $(clonedIdDisplay).prop("type", "text"), $(clonedIdDisplay).insertAfter($(clonedIdTypeDisplay)))
}

function WriteBetFull(n, t) {
    var y = document.activeElement === null || typeof document.activeElement == "undefined" ? "" : document.activeElement.id,
        r = UpdatePotentialSingleReturn(n.OutcomeId),
        e, u, o, s, l, h, c, f;
    if (document.getElementById("SelectedOutcomeForBetslip-" + n.OutcomeId) !== null && typeof document.getElementById("SelectedOutcomeForBetslip-" + n.OutcomeId) != "undefined") {
        for (document.getElementById("priceDecimal-" + n.OutcomeId).innerHTML = !checkForLite() && global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(n.PriceDecimal) : parseFloat(n.PriceDecimal).toFixed(2), y !== "wagerAmount" + n.OutcomeId && (document.getElementById("priceDecimal-" + n.OutcomeId).value = parseFloat(n.WagerAmount === null || typeof n.WagerAmount == "undefined" ? GetBetslipOption("MinBetAmount") : n.WagerAmount).toFixed(2), document.getElementById("potentialReturn" + n.OutcomeId).value = r), e = document.getElementsByClassName("singleMultyToggle"), u = 0; u < e.length; u++) e[u].style.display = e[u].classList.contains("freeSinglebetsContainer") ? t && hasFreeBet() ? "block" : "none" : e[u].classList.contains("sportBonusSinglebetsContainer") ? t && document.getElementById("hasSportBonus").value === "True" ? "block" : "none" : t ? "block" : "none";
        return ""
    }
    if (o = "betslipItemTemplate", document.getElementById(o) !== null && typeof document.getElementById(o) != "undefined") {
        var i = document.getElementById(o).innerHTML,
            p = document.getElementById("currencySymbol").value,
            w = document.getElementById("potentialReturnName").value,
            b = document.getElementById("totalReturnName").value,
            k = 'style="position: relative;margin-bottom:0px;padding-top:4px;z-index:100; justify-content: start; width: 100%; display:' + (t && hasFreeBet() ? "flex" : "none") + '"',
            d = 'style="position: relative;margin-bottom:0px;z-index:100; justify-content: start; width: 100%; display:' + (t && document.getElementById("hasSportBonus").value === "True" ? "flex" : "none") + '"',
            g = 'style="display:' + (t ? "block" : "none") + '"',
            nt = n.IsLiveInPlay === !0 ? '<label data-translate-set="BetslipWidget" data-translate-key="BetslipLiveText" class="lip-title">&nbsp; (Live)<\/label>' : "",
            tt = typeof n.allowEarlyCO == "undefined" || !n.allowEarlyCO || n.allowEarlyCO === "False" ? "none" : "table",
            it = typeof n.IsTrendingOutcome == "undefined" || !n.IsTrendingOutcome || n.IsTrendingOutcome === "false" ? "hidden" : "",
            rt = typeof n.IsTrendingOutcome == "undefined" || !n.IsTrendingOutcome || n.IsTrendingOutcome === "false" ? "" : "margin-top:-15px;",
            ut = typeof n.allowEarlyCO == "undefined" || !n.IsTrendingOutcome || n.IsTrendingOutcome === "false" ? "" : "margin-top:-17px;",
            ft = typeof n.IsTrendingOutcome == "undefined" || !n.IsTrendingOutcome || n.IsTrendingOutcome === "false" ? "" : "margin-top:-5px;";
        n.IsGroupHeader ? (i = i.split("%betItemGroupHeaderDisplay%").join("block"), i = i.split("%betItemHeaderDisplay%").join("none")) : (i = i.split("%betItemGroupHeaderDisplay%").join("none"), i = i.split("%betItemHeaderDisplay%").join("block"));
        i = t ? i.split("%betItemHeaderColumn%").join("col-xs-7 col-sm-8 col-md-8 col-lg-8") : i.split("%betItemHeaderColumn%").join("col-xs-12");
        i = i.split("%outcomeTitle%").join(n.Title);
        i = i.split("%marketTitle%").join(n.MarketTitle);
        i = i.split("%marketTitleTranslateKey%").join(language.generateKey(n.MarketTitle));
        i = i.split("%eventTitle%").join(n.EventTitle);
        i = i.split("%sportTitle%").join(n.Sport);
        s = !checkForLite() && global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(n.PriceDecimal) : parseFloat(n.PriceDecimal).toFixed(2);
        n.isAllowBetting ? (i = i.split("%priceDecimal%").join(s), n.IsTrendingOutcome && isLessBetslipValuesEnabled ? (l = Number(n.BoostedOddPercentage), i = i.split("%lessPriceDecimal%").join(parseFloat(s * ((100 - l) / 100)).toFixed(2)), i = i.split("%lessPriceDecimalDisplay%").join("inline")) : i = i.split("%lessPriceDecimalDisplay%").join("none"), i = i.split("%checkboxDisabled%").join(""), i = i.split("%checked%").join(n.Ticked ? "checked" : "")) : (i = i.split("%lessPriceDecimalDisplay%").join("none"), i = i.split("%priceDecimal%").join('<span class="material-icons-outlined" style="font-size: 15px;">lock<\/span>'), i = i.split("%checkboxDisabled%").join("disabled"), i = i.split("%checked%").join(""));
        i = i.split("%dataPriceDecimal%").join(parseFloat(n.PriceDecimal).toFixed(2));
        i = i.split("%dataLessPriceDecimal%").join(parseFloat(n.PriceDecimal * ((100 - n.BoostedOddPercentage) / 100)).toFixed(2));
        i = i.split("%Sign%").join(p);
        i = i.split("%PotentialReturn%").join(r);
        i = i.split("%potentialReturnName%").join(w);
        enableTax && (h = totalAmountRet = configuredTaxCalculation === TaxCalculation.Winnings ? taxCalc(r, n.WagerAmount) : taxCalc(r, n.WagerAmount), i = i.split("%TotalReturn%").join((r - h * taxPercentage / 100).toFixed(2)), n.IsTrendingOutcome ? isLessBetslipValuesEnabled && (i = i.split("%TotalLessReturn%").join((r * ((100 - boostedOddPercentageGlobal) / 100) - h * taxPercentage / 100).toFixed(2)), i = i.split("%totalReturnStyle%").join("")) : (i = i.split("%totalReturnLabelStyle%").join("margin-top:0"), i = i.split("%totalReturnStyle%").join("display:none")), i = i.split("%totalReturnName%").join(b));
        i = i.split("%outcomeId%").join(n.OutcomeId);
        i = i.split("%eventId%").join(n.EventId);
        i = i.split("%freeBetStyle%").join(k);
        i = i.split("%sportBonusStyle%").join(d);
        enableWagerTax ? (document.getElementById("divPotentialReturn").removeAttribute("hidden"), document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").removeAttribute("hidden"), document.getElementById("divWinningsTax").removeAttribute("hidden"), c = GetBetslipOption("MinBetAmount"), f = 0, f = n.WagerAmount === undefined ? c - c * wagerTaxPercentage / (100 + wagerTaxPercentage) : n.WagerAmount, i = i.split("%stakeBeforeWagerTax%").join(parseFloat(n.InitialStake === null || typeof n.InitialStake == "undefined" ? GetBetslipOption("MinBetAmount") : n.InitialStake).toFixed(2)), i = i.split("%wagerAmount%").join(parseFloat(f !== null || typeof f != "undefined" ? f : n.WagerAmount).toFixed(2))) : i = i.split("%wagerAmount%").join(parseFloat(n.WagerAmount === null || typeof n.WagerAmount == "undefined" ? GetBetslipOption("MinBetAmount") : n.WagerAmount).toFixed(2));
        i = i.split("%singeleBetStyle%").join(g);
        i = i.split("%earlyCashoutIconStyle%").join(tt);
        i = i.split("%isTrendingOutcomeStyle%").join(it);
        isLessBetslipValuesEnabled && (i = i.split("%lessPriceDecimalCOStyle%").join(rt), i = i.split("%lessPriceDecimalTrendingStyle%").join(ut), i = i.split("%dataPriceDecimalWithLessStyle%").join(ft));
        i = i.split("%isLive%").join(nt);
        i = i.split("%groupHeaderId%").join(n.GroupHeaderId);
        n.IsSingleFreeBet === !0 && isLoggedIn && (SetBetslipOption("SingleFreebetId", n.OutcomeId), i = i.replace("glyphicon-unchecked", "glyphicon-check"), i = i.replace("fa-square-o", "fa-check-square-o"));
        n.IsSingleSportBonusBet === !0 && (SetBetslipOption("SingleSportBonusbetId-" + n.OutcomeId, n.OutcomeId), i = i.replace("glyphicon-unchecked", "glyphicon-check"));
        let u, e, st, y = null;
        n.StartDate.indexOf("T") > -1 ? (e = n.StartDate.split("T"), st = e[0], y = e[1], u = new Date(st)) : u = new Date(n.StartDate);
        var et = u.getDate(),
            a = u.toLocaleString("default", {
                month: "short"
            }),
            ot = y !== null ? y.substring(0, 5) : u.toLocaleTimeString("default", {
                hour: "2-digit",
                hourCycle: "h23",
                minute: "2-digit"
            }),
            v = "";
        return [constId.feedDataType_Prematch, constId.feedDataType_LIP, constId.emptyGuid].includes(n.FeedDataTypeId) && (v = `<span class="row"> <label class="ellips PaddingScreen theOtherFont label__league_title" style="margin-top: -4px;"> ${et.toString()} <label data-translate-set="DatePicker" data-translate-key="${a.toString()}" style="font-weight: unset;"> ${a.toString()} </label> ${ot.toString()} </label></span>`), isSportBonusMultiBet() || isSportBonusSingleBet(n) || document.getElementById("configuredTaxPercentage") != null && document.getElementById("configuredTaxPercentageText") != null && (document.getElementById("configuredTaxPercentageText").innerText = `(${document.getElementById("configuredTaxPercentage").value}%)`), i = i.split("%startedDateTimeLayout%").join(v)
    }
}

function WriteBetFullGroupChildItems(n) {
    var t = document.getElementById("betslipGroupItemsTemplate").innerHTML,
        i = document.getElementById("betslip-group-list-" + n.GroupHeaderId);
    return $.each(n.GroupChildItems, function(n, r) {
        var u = t.split("%childOutcomeTitle%").join(r.Title),
            f;
        u = u.split("%childMarketTitle%").join(r.MarketTitle);
        f = document.createElement("SelectedOutcomeForHeader-" + r.OutcomeId);
        f.innerHTML = u;
        i.appendChild(f)
    }), ""
}

function UpdatePotentialSingleReturn(n, t, i = boostedOddPercentageGlobal) {
    var e = JSON.parse(GetBetslip()),
        s, h, f, l, r, u, c, o;
    if ((Object.keys(e).length !== 0 || e.constructor !== Object) && (s = document.activeElement === null || typeof document.activeElement == "undefined" ? "" : document.activeElement.id, bet = e.find(function(t) {
            return t.OutcomeId === n
        }), h = e.indexOf(bet), ~h)) {
        if (document.getElementById("wagerAmount" + n) !== null && typeof document.getElementById("wagerAmount" + n) != "undefined") {
            if (document.getElementById("wagerAmount" + n).value === "")
                if (s !== document.getElementById("wagerAmount" + n).id) document.getElementById("wagerAmount" + n).value = parseFloat(GetBetslipOption("MinBetAmount")).toFixed(2);
                else return;
            bet.WagerAmount = t && !enableWagerTax ? parseFloat(GetBetslipOption("MinBetAmount")).toFixed(2) : parseFloat(document.getElementById("wagerAmount" + n).value).toFixed(2);
            f = document.getElementById("stakeBeforeWagerTax" + n);
            f !== null && f !== undefined && (f.value < .01 && !f.disabled && !$("#stakeBeforeWagerTax" + n).is(":focus") && (f.value = GetBetslipOption("MinBetAmount").toFixed(2), UpdateWageredStake(n)), bet.InitialStake = f.value === "" ? 0 : parseFloat(f.value).toFixed(2), document.getElementById("wagerAmount" + n).style.width = document.getElementById("wagerAmount" + n).value.length * 7 + "px");
            s !== document.getElementById("wagerAmount" + n).id && (document.getElementById("wagerAmount" + n).value = bet.WagerAmount)
        } else(bet.WagerAmount === null || typeof bet.WagerAmount == "undefined") && (enableWagerTax ? (l = precise_round(GetBetslipOption("MinBetAmount") * wagerTaxPercentage / (100 + wagerTaxPercentage), 2), bet.WagerAmount = GetBetslipOption("MinBetAmount") - l) : bet.WagerAmount = GetBetslipOption("MinBetAmount"));
        return e[h] = bet, SetBetslip(e), r = parseFloat(bet.PriceDecimal) * parseFloat(bet.WagerAmount), bet.IsSingleFreeBet = document.getElementById("BetSingleBet" + n) !== null && typeof document.getElementById("BetSingleBet" + n) != "undefined" ? document.getElementById("BetSingleBet" + n).checked : !1, bet.IsSingleFreeBet === !0 && (r = parseFloat(bet.PriceDecimal) * parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), r = r - parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2)), bet.IsSingleSportBonusBet = document.getElementById("BetSportBonusSingleBet" + n) !== null && typeof document.getElementById("BetSportBonusSingleBet" + n) != "undefined" ? document.getElementById("BetSportBonusSingleBet" + n).checked : !1, bet.IsSingleSportBonusBet === !0 && r, u = GetBetslipOption("MaxPayoutSingle"), u = u || 0, r > parseFloat(u) && (r = u), isSportBonusChecked() && (u = GetBetslipOption("SportsBonusMaximumPayout"), u = u || 0, u > 0 && r > parseFloat(u) && (r = u)), document.getElementById("potentialReturn" + n) !== null && typeof document.getElementById("potentialReturn" + n) != "undefined" && (document.getElementById("potentialReturn" + n).textContent = checkForLite() ? "Potential Return: " + sign + r.toFixed(2) : "" + r.toFixed(2), c = enableTax, sportBonusEnabled && enableTax && (bet.IsSportBonusBet || GetBetslipOption("SingleSportBonusbetId-" + bet.OutcomeId) == bet.OutcomeId) ? (c = !1, resetTaxInputs()) : document.getElementById("configuredTaxPercentage") != null && document.getElementById("configuredTaxPercentageText") != null && (document.getElementById("configuredTaxPercentageText").innerText = `(${document.getElementById("configuredTaxPercentage").value}%)`), !checkForLite() && enableTax && (o = configuredTaxCalculation === TaxCalculation.Winnings ? taxCalc(r, bet.WagerAmount) : taxCalc(r, bet.wagerAmount), (bet.IsSingleFreeBet || bet.IsSingleSportBonusBet) && (o = r), document.getElementById("totalReturn" + n) !== undefined && document.getElementById("totalReturn" + n) !== null && (document.getElementById("totalReturn" + n).textContent = c ? "" + (r - o * taxPercentage / 100).toFixed(2) : "" + r.toFixed(2), isLessBetslipValuesEnabled && (document.getElementById("totalLessReturn" + n).textContent = "" + (r * ((100 - i) / 100) - o * taxPercentage / 100).toFixed(2))))), checkForLite() || UpdateVisualElementsOnBetslip(), r.toFixed(2)
    }
}

function UpdatePotentialReturn() {
    var s = document.activeElement === null || typeof document.activeElement == "undefined" ? "" : document.activeElement.id,
        t = 0,
        e = 0,
        i = parseFloat(GetBetslipOption("TotalLessPriceDecimal")).toFixed(4),
        r = parseFloat(GetBetslipOption("TotalPriceDecimal")).toFixed(4),
        o, u, f, n;
    if (isNaN(i) && (i = 0), isNaN(r) && (r = 0), document.getElementById("wagerAmount") !== null && typeof document.getElementById("wagerAmount") != "undefined") {
        if (document.getElementById("wagerAmount").value === "")
            if (s !== document.getElementById("wagerAmount").id) o = GetBetslipOption("MinBetAmount"), GetBetslipOption("WagerAmount") !== null && typeof GetBetslipOption("WagerAmount") != "undefined" && (o = GetBetslipOption("WagerAmount")), document.getElementById("wagerAmount").value = parseFloat(o).toFixed(2);
            else return;
        else s !== document.getElementById("wagerAmount").id && (document.getElementById("wagerAmount").value = parseFloat(document.getElementById("wagerAmount").value).toFixed(2));
        u = document.getElementById("wagerAmount").value;
        SetBetslipOption("WagerAmount", u);
        t = parseFloat(u) * parseFloat(r);
        checkForLite() || (e = isLessBetslipValuesEnabled ? parseFloat(u) * parseFloat(i) : 0);
        GetBetslipOption("IsFreeBet") === !0 && (t = t >= GetBetslipOption("FreeBetMaxPayoutMultiple") ? GetBetslipOption("FreeBetMaxPayoutMultiple") - u : t - u);
        f = JSON.parse(GetBetslip());
        incrementalPayoutLimitsEnabled && IncrementalPayoutLimits.updateMaxPayoutAmount(f.length);
        n = GetBetslipOption("MaxPayoutSingle");
        f !== null && typeof f != "undefined" && Array.isArray(f) && f.length === 1 ? (n = n || 0, t > parseFloat(n) && (t = n)) : (n = GetBetslipOption("MaxPayoutMultiple"), n = n || 0, t > parseFloat(n) && (t = n));
        isSportBonusChecked() && (n = GetBetslipOption("SportsBonusMaximumPayout"), n = n || 0, n > 0 && t > parseFloat(n) && (t = n));
        checkForLite() || (e < .01 ? (document.getElementById("betslip-totallesspricedecimal").innerText = "0", parseFloat(document.getElementById("betslip-totallesspricedecimal").innerText) < .01 && parseFloat(document.getElementById("potentialReturn").value) > 0 && (document.getElementById("potentialLessReturn").textContent = parseFloat(t).toFixed(2)), document.getElementById("potentialLessReturn").style.display = "none") : (document.getElementById("potentialLessReturn").style.display = "block", document.getElementById("potentialLessReturn").textContent = parseFloat(e).toFixed(2)));
        document.getElementById("potentialReturn").value = parseFloat(t).toFixed(2);
        document.getElementById("betslip-totalpricedecimal") !== null && typeof document.getElementById("betslip-totalpricedecimal") != "undefined" && (document.getElementById("betslip-totalpricedecimal").setAttribute("data-pd", parseFloat(r).toFixed(2)), checkForLite() || isLessBetslipValuesEnabled && (document.getElementById("betslip-totallesspricedecimal").setAttribute("data-lpd", parseFloat(i).toFixed(2)), document.getElementById("betslip-totallesspricedecimal").innerHTML = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(i) : parseFloat(i).toFixed(2)), document.getElementById("betslip-totalpricedecimal").innerHTML = global.getCookie("oddsFormat") === "fraction" ? oddsFormatter.convertFromDecimalToFraction(r) : parseFloat(r).toFixed(2), checkForLite() || isLessBetslipValuesEnabled && (document.getElementById("betslip-totallesspricedecimal").innerHTML < .01 ? (document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px") : (document.getElementById("total-odds-text").style.marginTop = "-14px", document.getElementById("betslip-totallesspricedecimal").style.display = "block", document.getElementById("betslip-totalpricedecimal").style.marginTop = "-6px")));
        CalculateStretchOffers(null);
        IsStretchEnabled() || enableTax || document.getElementById("potentialReturn") === null || (document.getElementById("figure").innerText = parseFloat(document.getElementById("potentialReturn").value).toFixed(2))
    }
    return winningsTax(), checkForLite() || UpdateVisualElementsOnBetslip(), miniBetslip(), GetBetslipOption("IsSportBonusBet") ? resetTaxInputs() : document.getElementById("configuredTaxPercentage") != null && document.getElementById("configuredTaxPercentageText") != null && (document.getElementById("configuredTaxPercentageText").innerText = `(${document.getElementById("configuredTaxPercentage").value}%)`), t
}

function roundUp(n, t) {
    var i = Math.pow(10, t);
    return (Math.round(n * i) / i).toFixed(t)
}

function BetExtentionExpandToggle() {
    $("#BetExtentionExpandToggle").text().trim().includes("expand_less") ? ($("#BetExtentionExpandToggle").text("expand_more"), $("#divPotentialReturn").hide(), $("#divPotentialReturn").removeAttr("hidden"), $("#divBoostedAmount").html() != undefined && $("#divBoostedAmount").hide(), $("#divWinningsTax").html() != undefined && $("#divWinningsTax").hide()) : ($("#BetExtentionExpandToggle").text("expand_less"), $("#divPotentialReturn").slideToggle(), $("#divBoostedAmount").html() != undefined && $("#divBoostedAmount").slideToggle(), $("#divWinningsTax").html() != undefined && $("#divWinningsTax").slideToggle())
}

function PlaceBet(n, t, i, r, u, f) {
    var e = completeBetslip(),
        o = document.getElementById("bet-amount-val"),
        it = parseFloat(document.getElementById("potentialReturn").value),
        g = "",
        h, a, c, v, y, p, w, l, s, rt, ut, b, k, d;
    o.className = "error hidden";
    o.innerText = "";
    var ft = document.getElementById("chkAutoAcceptLatestOdds"),
        nt = !1,
        et = document.getElementById("chkKeepBets"),
        tt = !1;
    if (i && !checkForLite()) nt = ft.checked, tt = et.checked;
    else if (!checkForLite()) return homePage.toggleLoginSignup("betnowlogin"), !1;
    if (!e.WagerAmount) return o.innerText = "Bet Amount cannot be empty or 0.", language.translateAtRuntime(o, "ErrorMessages", {
        "data-translate-key": "BetAmountCannotBeEmpty"
    }), o.className = "error", !1;
    if (r && GetBetslipOption("AccountHasFica") === "False" && i) return checkForLite() ? (o.innerText = "Please update your Fica documents before placing a bet.", language.translateAtRuntime(o, "ErrorMessages", {
        "data-translate-key": "UpdateFicaDocumentsToBet"
    }), o.className = "error") : $("#modal-container-ficastatus-confirmation").modal().show(), !1;
    if (h = 0, e.IsSingleBets) {
        for (a = JSON.parse(GetBetslip()), enableWagerTax && (h = t * (wagerTaxPercentage / 100)), c = 0; c < a.length; c++)
            if (a[c].WagerAmount < t && (a[c].OutcomeId !== GetBetslipOption("SingleFreebetId") || a[c].OutcomeId !== GetBetslipOption("SingleSportBonusbetId-" + a[c].OutcomeId))) return o.innerText = "A minimum bet of " + n + "" + roundUp(t + h, 2) + " is required", o.className = "error", language.translateAtRuntime(o, "ErrorMessages", {
                "data-translate-key": "MinimumBetRequired",
                "data-translate-type": "generic-html",
                "data-translate-value-0": n + "" + roundUp(t + h, 2)
            }), !1
    } else if (enableWagerTax && (h = t * (wagerTaxPercentage / 100)), g = GetBookingCode(), e.WagerAmount < t) return o.innerText = "A minimum bet of " + n + "" + roundUp(t + h, 2) + " is required", o.className = "error", language.translateAtRuntime(o, "ErrorMessages", {
        "data-translate-key": "MinimumBetRequired",
        "data-translate-type": "generic-html",
        "data-translate-value-0": n + "" + roundUp(t + h, 2)
    }), !1;
    if (IsStretchEnabled && (v = GetStretchStorage(), v !== "" && v !== "null" && (it = parseFloat(document.getElementById("potentialReturnWithStretchVal").innerText), stretchData = JSON.parse(v), IsStretchOfferExpired(stretchData)))) {
        ClearStretch(!0);
        o.innerText = "The Stretch offer has expired.";
        language.translateAtRuntime(o, "ErrorMessages", {
            "data-translate-key": "StretchOfferExpired"
        });
        o.className = "error";
        document.getElementById("betslip-single-multi-error").style.display = "";
        document.getElementById("betslip-single-multi-error").innerText = "The current Stretch offer has not been used in time and has expired. If available, a new Stretch offer will be loaded.";
        language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
            "data-translate-key": "StretchOfferNotUsedInTime"
        });
        LoadStretch(!0);
        return
    }
    if (IsMoneyBackBoostEnabled()) try {
        if (y = GetMoneyBackBoostStorage(), y !== "" && y !== null) {
            if (moneyBackBoostData = JSON.parse(y), IsMoneyBackBoostOfferExpired(moneyBackBoostData)) {
                ClearMoneyBackBoost(!0);
                betReturned.innerText = "The MoneyBack Boost offer has expired.";
                language.translateAtRuntime(betReturned, "ErrorMessages", {
                    "data-translate-key": "MoneyBackBoostOfferExpired"
                });
                betReturned.className = "error";
                document.getElementById("moneyBackBoostMsg").style.display = "";
                document.getElementById("moneyBackBoostMsg").innerText = "The current MoneyBack Boost offer has not been used in time and has expired. If available, a new Boost offer will be loaded.";
                language.translateAtRuntime(document.getElementById("moneyBackBoostMsg"), "ErrorMessages", {
                    "data-translate-key": "MoneyBackBoostOfferNotUsedInTime"
                });
                LoadMoneyBackBoost(!0);
                return
            }
        } else SetMoneyBackBoostStorage()
    } catch (ot) {
        console.log(ot)
    }
    if (!checkForLite() && (u === undefined || !u) && !GetBetslipOption("IsFreeBet")) {
        if (p = !1, w = !1, e.IsSingleBets && enableTax)
            for (l = JSON.parse(e.Outcomes), s = 0; s < l.length; s++) {
                if (configuredTaxCalculation === TaxCalculation.Payout && l[s].PriceDecimal <= 1 + taxPercentage / 100) {
                    w = !0;
                    break
                }
                if (rt = parseFloat(document.getElementById("totalReturn" + l[s].OutcomeId).innerText), ut = parseFloat(document.getElementById("wagerAmount" + l[s].OutcomeId).value), rt <= ut && (!l[s].IsSingleFreeBet || !l[s].IsSingleSportBonusBet)) {
                    p = !0;
                    break
                }
            } else oddsThresholdEnabled && configuredTaxCalculation === TaxCalculation.Payout && !checkForLite() && enableTax && e.TotalOdds <= 1 + taxPercentage / 100 ? w = !0 : !checkForLite() && enableTax && it <= e.WagerAmount && (p = !0);
        if (w) return $("#modalHeader").html("Odds Too Low"), language.translateAtRuntime($("#modalHeader"), "ErrorMessages", {
            "data-translate-key": "modalHeaderOddsTooLow"
        }), $("#middleContent").html("You cannot place this bet as the odds are too low given the current government taxation requirements."), language.translateAtRuntime($("#middleContent"), "ErrorMessages", {
            "data-translate-key": "modalHeaderLowOddsTaxationGovRequirementsError"
        }), $("#tax-confirm-modal").modal(), $("#btn-AddMoreBets span").text("Ok"), language.translateAtRuntime($("#btn-AddMoreBets span"), "ErrorMessages", {
            "data-translate-key": "btnOk"
        }), $("#btn-AddMoreBets").css({
            float: "none"
        }), $(".back-to-bets").removeClass("col-xs-6").addClass("col-xs-12").css({
            "text-align": "center"
        }), $("#btnTaxConfirm").hide(), $("#betslip-mobile-modal").modal("hide"), !1;
        if (p) return $("#modalHeader").html("Please Note"), language.translateAtRuntime($("#modalHeader"), "BetslipConfirmationDialog", {
            "data-translate-key": "modalHeaderPleaseNote"
        }), $("#middleContent").html("Warning: You have placed a bet at odds that will payout less than your bet amount due to a " + f + "% Winnings Tax taken off your Total Potential Return."), language.translateAtRuntime($("#middleContent"), "BetslipConfirmationDialog", {
            "data-translate-key": "BetWarningPayoutLowerThanWagerAmount",
            "data-translate-type": "generic-html",
            "data-translate-value-0": f
        }), $("#tax-confirm-modal").modal(), $("#btnTaxConfirm").off("click").click(function() {
            homePage.showOverlay();
            PlaceBet(n, t, i, r, !0);
            $("#tax-confirm-modal").modal("hide")
        }), $("#betslip-mobile-modal").modal("hide"), !1
    }
    return b = !1, k = 0, sportBonusEnabled && GetBetslipOption("IsSportBonusBet") && (k = document.getElementById("wagerAmount").value, b = !0), checkForLite() ? (enableWagerTax && (d = e.WagerAmount, e.InitialStake = d, e.WagerAmount = (d - d * wagerTaxPercentage / (100 + wagerTaxPercentage)).toFixed(2)), post_to_url("/Lite/PlaceBetslip", {
        outcomes: e.Outcomes,
        WagerAmount: Number(e.WagerAmount),
        InitialStake: e.InitialStake,
        TotalOdds: e.TotalOdds,
        IsSingleBets: e.IsSingleBets,
        BookingCode: g,
        StretchOfferApplied: e.StretchOfferApplied,
        StretchPotentialReturn: e.StretchPotentialReturn,
        AutoAcceptLatestOdds: nt,
        KeepBets: tt,
        IsTrendingOutcome: e.IsTrendingOutcome,
        IsSportBonusBet: b,
        SportsBonusAmount: k
    }, "post")) : ajax.post("/Lite/PlaceBetslip", {
        outcomes: e.Outcomes,
        WagerAmount: Number(e.WagerAmount),
        InitialStake: e.InitialStake,
        TotalOdds: e.TotalOdds,
        IsSingleBets: e.IsSingleBets,
        BookingCode: g,
        StretchOfferApplied: e.StretchOfferApplied,
        StretchPotentialReturn: e.StretchPotentialReturn,
        AutoAcceptLatestOdds: nt,
        KeepBets: tt,
        IsTrendingOutcome: e.IsTrendingOutcome,
        IsSportBonusBet: b,
        SportsBonusAmount: k
    }, placeFullBetCallBack), !0
}

function useSportBonus(n) {
    if (sportBonusEnabled) {
        var t = GetBetslipOption("MinBetAmount");
        n.checked ? $("#placeFreeBet").prop("disabled", !0).addClass("btn-bettingmatch-more").css("margin-top", 0) : $("#placeFreeBet").prop("disabled", !1).removeClass("btn-bettingmatch-more");
        SetBetslipOption("IsSportBonusBet", !0);
        UpdatePotentialReturn()
    }
}

function checkForSportBonus(n) {
    var t, s;
    if (sportBonusEnabled)
        if (t = GetBetslipOption("IsSingleBet") === !0, t) s = _.groupBy(n, "EventId"), _.each(s, function(n) {
            for (var t = 0; t < n.length; t++) {
                var i = n[t],
                    r = i.PriceDecimal >= minimumOddsForSportBonus,
                    u = n.length >= minimumNumberOfSelectionsForSportsBonus;
                u && i.IsSportBonusAllowed && r && document.getElementById("sportBonusAmountVal") != null && document.getElementById("sportBonusAmountVal").innerText !== "" && document.getElementById("sportBonusAmountVal").innerText !== "0.00" ? $(".sb-" + i.OutcomeId).css({
                    visibility: "visible",
                    display: "flex"
                }) : $(".sb-" + i.OutcomeId).css({
                    visibility: "hidden",
                    display: "none"
                });
                $(".protectedSportsBonus-alert").css({
                    visibility: "hidden",
                    display: "none"
                })
            }
        });
        else {
            var c = _.groupBy(n, "EventId"),
                i = !1,
                r = !1,
                u = parseFloat(0),
                f = localStorage.getItem("sportsBonusExpiryDate"),
                h = f === null ? Date.now() : new Date(+f.replace(/\D/g, "")),
                e = !1,
                o = n.filter(function(n) {
                    return n.Ticked === !0
                });
            u = parseFloat(_.reduce(_.pluck(o, "PriceDecimal"), function(n, t) {
                return parseFloat(n * t)
            })).toFixed(2);
            _.each(n, function(t) {
                for (var s, c, f = 0; f < n.length; f++) s = n[f], c = new Date(s.StartDate), c >= h && (e = !0);
                var y = n.filter(function(n) {
                        return n.Ticked == !0
                    }).length,
                    l = parseFloat(localStorage.getItem("sportsBonusMinOdds")) === 0 ? !1 : parseFloat(u) >= parseFloat(localStorage.getItem("sportsBonusMinOdds")),
                    a = localStorage.getItem("sportsBonusMinSelections") === 0 ? !1 : o.length >= localStorage.getItem("sportsBonusMinSelections"),
                    v = JSON.parse(localStorage.getItem("sportsBonusIsProtected"));
                y > 0 && (i = a && t.IsSportBonusAllowed && l && !v ? !0 : !1, r = l && a && t.IsSportBonusAllowed && v && !e ? !0 : !1)
            });
            i ? (document.getElementById("sportBonusMultiBetCheckbox") !== null && document.getElementById("sportBonusMultiBetCheckbox").classList.remove("SportBonusBetTypeBtnText"), $(".sportBonusMultiBetContainer").removeClass("hidden")) : (document.getElementById("sportBonusMultiBetCheckbox") !== null && document.getElementById("sportBonusMultiBetCheckbox").classList.add("SportBonusBetTypeBtnText"), $(".sportBonusMultiBetContainer").addClass("hidden"));
            r ? ($(".protectedSportsBonus-alert").css({
                visibility: "visible",
                display: "flex"
            }), $(".unprotectedSportsBonus-alert").css({
                visibility: "hidden",
                display: "none"
            })) : ($(".unprotectedSportsBonus-alert").css({
                visibility: "visible",
                display: "flex",
                "background-color": "#d1d1d1"
            }), $(".protectedSportsBonus-alert").css({
                visibility: "hidden",
                display: "none"
            }), JSON.parse(localStorage.getItem("sportsBonusIsProtected")) || ($(".unprotectedSportsBonus-alert").css({
                visibility: "hidden",
                display: "none"
            }), $(".protectedSportsBonus-alert").css({
                visibility: "hidden",
                display: "none"
            })))
        }
}

function ChooseSportBonusSingleBet(n, t = false) {
    var u = JSON.parse(GetBetslip()),
        i = document.getElementById("BetSportBonusSingleBet" + n),
        r = i !== null && i !== undefined ? i.checked : !1,
        f;
    t && (r = !1);
    !checkForLite() && betslipMultiSelectorEnabled && r && (checkMaxSelectedReached() || ($("#SelectedCheckBoxForBetslip-" + n).prop("checked", !0), f = u.findIndex(function(t) {
        return t.OutcomeId === n
    }), u[f].Ticked = !0, SetBetslip(u), updateBetslipCounts(u)), r = document.getElementById("SelectedCheckBoxForBetslip-" + n).checked, i != null && (i.checked = r), disableBetting());
    r ? (SetBetslipOption("SingleSportBonusbetId-" + n, n), GetBetslipOption("SingleFreebetId") == n && ChooseSingleBet(n, !0)) : (i != null && (i.checked = r), SetBetslipOption("SingleSportBonusbetId-" + n, ""));
    toggleSingleSportBonusBets(r, n);
    checkForLite() || UpdateVisualElementsOnBetslip()
}

function toggleSingleSportBonusBets(n, t) {
    if (sportBonusEnabled) {
        var r = GetBetslipOption("MinBetAmount"),
            i = "";
        checkForLite() || (i = isThousandSeperatorEnabled ? "label" : "");
        n ? (UpdateSportBonusSingleBet(t, !0), bsSportBonusCheckboxToggle(t, !0), SetBetslipOption("SingleFreebetId", ""), UpdateFreeSingleBet(t, !1), bsCheckboxToggle(t, !1)) : (UpdateSportBonusSingleBet(t, !1), bsSportBonusCheckboxToggle(t, !1), enableWagerTax && (document.getElementById("stakeBeforeWagerTax" + t).value = parseFloat("0.00").toFixed(2)));
        UpdatePotentialSingleReturn(t)
    }
}

function UpdateSportBonusSingleBet(n, t) {
    var i = JSON.parse(GetBetslip()),
        r;
    bet = i.find(function(t) {
        return t.OutcomeId === n
    });
    r = i.indexOf(bet);
    ~r && (bet.IsSingleSportBonusBet = t, i[r] = bet, SetBetslip(i))
}

function CasinoPlaceForReal(n, t) {
    return ajax.post("/Lite/CasinoPlaceForReal", {
        gameId: n,
        pageNo: t
    }, CasinoPlaceForRealCallBack), !0
}

function PlaceFreeBet(n, t, i) {
    var f = "",
        r, u;
    if (homePage.showOverlay(), !checkForLite() && enableWagerTax) {
        $("#modal-container-bet-confirmation").on("hidden.bs.modal", function() {
            ResetAndBackToBets()
        });
        document.getElementById("stakeBeforeWagerTax").disabled = !0;
        document.getElementById("stakeBeforeWagerTax").value = parseFloat("0.00").toFixed(2)
    }
    if (i && GetBetslipOption("AccountHasFica") === "False" && t) return checkForLite() ? (betAmountVal.innerText = "Please update your Fica documents before placing a bet.", language.translateAtRuntime(betAmountVal, "ErrorMessages", {
        "data-translate-key": "UpdateFicaDocuments"
    }), betAmountVal.className = "error") : $("#modal-container-ficastatus-confirmation").modal().show(), homePage.closeOverlay(), !1;
    if (document.getElementById("accountFreeBetAmount") && document.getElementById("accountFreeBetAmount").innerText !== "" && document.getElementById("accountFreeBetAmount").innerText !== "0.00" ? document.getElementById("wagerAmount").value = parseFloat(document.getElementById("accountFreeBetAmount").innerText).toFixed(2) : getCookie("CurrentFreeBetAmount") && (document.getElementById("wagerAmount").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2)), !checkForLite() && enableWagerTax && (document.getElementById("wagerAmount").style.width = document.getElementById("wagerAmount").value.length * 8 + "px"), SetBetslipOption("IsFreeBet", !0), UpdatePotentialReturn(), r = completeBetslip(), f = GetBookingCode(), r.IsSingleBets) {
        u = JSON.parse(r.Outcomes);
        (u.length === 1 && (!u[0].IsSingleFreeBet || !u[0].IsSingleSportBonusBet) || u.length > 1) && homePage.closeOverlay();
        return
    }
    checkForLite() ? post_to_url("/Lite/PlaceBetslip", {
        outcomes: r.Outcomes,
        InitialStake: r.InitialStake,
        WagerAmount: r.WagerAmount,
        TotalOdds: r.TotalOdds,
        IsFreeBet: !0,
        IsSingleBet: r.IsSingleBets,
        BetslipStretch: null,
        BookingCode: f
    }, "post") : ajax.post("/Lite/PlaceBetslip", {
        outcomes: r.Outcomes,
        InitialStake: r.InitialStake,
        WagerAmount: r.WagerAmount,
        TotalOdds: r.TotalOdds,
        IsFreeBet: !0,
        IsSingleBets: r.IsSingleBets,
        BetslipStretch: null,
        BookingCode: f
    }, placeFullBetCallBack)
}

function bsCheckboxToggle(n, t, i) {
    i = i || !0;
    checkForLite() || (document.getElementById("bsCheckbox" + n).className = document.getElementById("bsCheckbox" + n).className.replace("fa-check-square-o", "").replace("fa-square-o", ""), t ? document.getElementById("bsCheckbox" + n).className += " fa-check-square-o" : (document.getElementById("bsCheckbox" + n).className += " fa-square-o", i && (document.getElementById("bsCheckbox" + n).style = "color: #00A826; font-size: 18px;")))
}

function bsSportBonusCheckboxToggle(n, t, i) {
    i = i || !0;
    checkForLite() || document.getElementById("bsSportBonusCheckbox" + n) && (document.getElementById("bsSportBonusCheckbox" + n).className = document.getElementById("bsSportBonusCheckbox" + n).className.replace("fa-check-square-o", "").replace("fa-square-o", ""), document.getElementById("bsSportBonusCheckbox" + n).className += t ? " fa-check-square-o" : " fa-square-o")
}

function ResetAndBackToBets() {
    var i = JSON.parse(GetBetslip()),
        n, t;
    if (document.getElementsByClassName("successfulBets").length > 0) {
        for (n = 0; n < i.length; n++) t = i[n], GetBetslipOption("IsFreeBet") === !0 || GetBetslipOption("SingleFreebetId") !== "" ? (SetBetslipOption("SingleFreebetId", ""), document.getElementById("freebetBtn") !== null && (document.getElementById("freebetBtn").innerText = "Free Bet: 0.00"), language.translateAtRuntime(document.getElementById("freebetBtn"), "ErrorMessages", {
            "data-translate-key": "FreeBet"
        }), document.getElementById("hasFreeBets").value = !1, document.getElementById("accountFreeBetAmount") != null && (document.getElementById("accountFreeBetAmount").value = 0), document.getElementById("hasFreeBetsVar").value = !1, document.getElementById("freebetBtnMobile").innerText = "0.00", document.getElementById("multiFreeBet") != null && (document.getElementById("multiFreeBet").style.display = "none"), chooseBonusType("freebet", document.getElementById("bsFreeMutliBetCheckbox"))) : (GetBetslipOption("IsSportBonusBet") === !0 || GetBetslipOption("SingleSportBonusbetId-" + t.OutcomeId) !== "" && typeof GetBetslipOption("SingleSportBonusbetId-" + t.OutcomeId) != "undefined") && (SetBetslipOption("SingleSportBonusbetId-" + t.OutcomeId, ""), document.getElementById("sportBonusMultiBetCheckbox") != undefined && document.getElementById("sportBonusMultiBetCheckbox") != null && (document.getElementById("sportBonusMultiBetCheckbox").checked = !1), chooseBonusType("sportbonus", document.getElementById("bsSportBonusMultiBetCheckbox")));
        document.getElementById("chkKeepBets").checked || (document.getElementsByClassName("unsuccessfulBet").length > 0 ? ClearOnlySuccessfulBets() : !checkForLite() && betslipMultiSelectorEnabled ? ClearMSSuccessfulBets() : ClearBetslip())
    } else window.innerWidth <= 1024 && document.getElementById("BetslipBtn").click();
    updateWagerAmountData();
    SetBetslipOption("IsFreeBet", !1);
    checkForLite() && (location.href = "/Lite/Betslip")
}

function updateWagerAmountData() {
    (GetBetslipOption("IsFreeBet") === !0 || GetBetslipOption("IsSportBonusBet") === !0) && (SetBetslipOption("IsFreeBet", !1), SetBetslipOption("IsSportBonusBet", !1), document.getElementById("wagerAmount") !== null && typeof document.getElementById("wagerAmount") != "undefined" && (enableWagerTax ? (document.getElementById("stakeBeforeWagerTax").disabled = !1, document.getElementById("stakeBeforeWagerTax").value = parseFloat(GetBetslipOption("MinBetAmount")).toFixed(2), checkWager()) : document.getElementById("wagerAmount").value = parseFloat(GetBetslipOption("MinBetAmount")).toFixed(2), UpdatePotentialReturn()))
}

function BetslipHasLiveBets() {
    var n = JSON.parse(GetBetslip()),
        t;
    return n !== null && typeof n != "undefined" && Array.isArray(n) ? (t = n.find(IsLiveBet), t !== null && typeof t != "undefined") : !1
}

function IsLiveBet(n) {
    return n.IsLiveInPlay === !0
}

function ToggleBetslip(n) {
    var i, r, t;
    if ($(n).hasClass("active") || (i = UpdateSingleMultiBet()), !i) {
        if (SetBetslipOption("IsSingleBet", n.id === "sb_id"), UpdateBetslipFullVersion(!0), r = betslipMultiSelectorEnabled, n !== null && typeof n != "undefined" && n.id === "sb_id" && ($("#betslip-list").addClass("ms-hide-exclamation").addClass("sb-active"), $("#mb_id").removeClass("active"), $("#mb_id").removeClass("liveInPlayClr"), $("#divWinningsTax").hide(), $("#divPotentialReturnWithStretch").hide(), betslipWagerAmountSuggestionEnabled && (document.getElementById("betslipWagerAmountsContainer").style.display = "none"), ClearStretch(!1), ClearMoneyBackBoost(!1), r && disableBetting()), n !== null && typeof n != "undefined" && n.id === "mb_id") {
            if (BetslipContainsBuildABet()) {
                document.getElementById("betslip-single-multi-error") && (document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = "Cannot move to multi bets with a Build a Bet in your betslip.", language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
                    "data-translate-key": "BuildABetMultiBetsNotAllowed"
                }));
                ToggleBetslip(document.getElementById("sb_id"));
                $("#betslip-single-multi-error").show();
                return
            }
            $("#betslip-single-multi-error").innerHTML === "" && $("#sb_id").removeClass("active");
            $("#sb_id").removeClass("liveInPlayClr");
            CalculateStretchOffers(null);
            document.getElementById("moneyBackBoostInfoAlert") !== null && typeof document.getElementById("moneyBackBoostInfoAlert") != "undefined" && (document.getElementById("moneyBackBoostInfoAlert").style.display = "");
            t = enableTax;
            sportBonusEnabled && enableTax && GetBetslipOption("IsSportBonusBet") && (t = !1);
            t === !0 || IsStretchEnabled() ? ($("#divWinningsTax").show(), $("#divPotentialReturnWithStretch").show()) : ($("#divWinningsTax").hide(), $("#divPotentialReturnWithStretch").hide());
            $("#divBoostedAmount").is(":hidden") && calculateHoldingTax() === 0 && $("#divPotentialReturnWithStretch").hide();
            betslipWagerAmountSuggestionEnabled && (document.getElementById("betslipWagerAmountsContainer").style.display = "block");
            UpdatePotentialReturn()
        }
        global.getCookie("oddsFormat") === "fraction" && ($(".betslipPriceDecimal").each(function() {
            $(this).text(oddsFormatter.convertFromDecimalToFraction($(this).text()))
        }), $("#betslip-totalpricedecimal").text(oddsFormatter.convertFromDecimalToFraction($("#betslip-totalpricedecimal").text())));
        checkMaxSelectedReached();
        UpdateVisualElementsOnBetslip();
        applyCurrentBonus()
    }
}

function IsBuildABet() {
    return buildABetEnabled && typeof buildABet != "undefined" && buildABet.isBuildABetActive() ? !0 : !1
}

function BetslipContainsBuildABet() {
    for (var r = GetBuildABetStorage(), i = GetBetslip(), t = JSON.parse(i), n = 0; n < t.length; n++)
        if (t[n].IsGroupHeader && t[n].GroupTypeId === "00000000-0000-0000-da7a-000000710003") return !0;
    return !1
}

function IsStretchEnabled() {
    var n = !1;
    try {
        n = document.getElementById("enableStretch").value.toLowerCase() === "true"
    } catch (t) {
        console.log("Error occured in the IsStretchEnabled function")
    }
    return n
}

function IsMoneyBackBoostEnabled() {
    var n = !1;
    try {
        n = document.getElementById("moneyBackBoostEnabled").value.toLowerCase() === "true"
    } catch (t) {
        console.log("Error occured in the IsMoneyBackBoostEnabled function")
    }
    return n
}

function IsWinboostTableEnabled() {
    var n = !1;
    try {
        n = document.getElementById("winboostTableEnabled").value.toLowerCase() === "true"
    } catch (t) {
        console.log("Error occured in the IsWinboostTableEnabled function")
    }
    return n
}

function LoadStretch(n) {
    IsStretchEnabled() ? $.get("/Bet/GetStretchOffer", {
        forceReload: n
    }, GetStretchOfferCallBack) : ClearStretch(!0)
}

function LoadMoneyBackBoost(n) {
    IsMoneyBackBoostEnabled() ? $.get("/Ajax/GetMoneyBackBoostOffer", {
        brandId: BrandId,
        forceReload: n
    }, GetMoneyBackBoostOfferCallBack) : ClearMoneyBackBoost(!0)
}

function ClearMoneyBackBoost(n) {
    try {
        n && SetMoneyBackBoostStorage("");
        SetBetslipOption("MoneyBackBoostOfferApplied", "00000000-0000-0000-0000-000000000000");
        var t = "";
        t = "Add 6 or more legs to your Multi Bet betslip and if 1 of your selections lets you down, we’ll refund up to 20x your bet.";
        document.getElementById("moneyBackBoostMsg") != null && (document.getElementById("moneyBackBoostMsg").innerHTML = t);
        document.getElementById("moneyBackBoostInfoAlert") !== null && typeof document.getElementById("moneyBackBoostInfoAlert") != "undefined" && (document.getElementById("moneyBackBoostInfoAlert").style.display = "none")
    } catch (i) {
        console.error(i.message)
    }
}

function ClearStretch(n) {
    n && SetStretchStorage("");
    SetBetslipOption("StretchOfferApplied", "00000000-0000-0000-0000-000000000000");
    document.getElementById("divPotentialReturnWithStretch") !== null && typeof document.getElementById("divPotentialReturnWithStretch") != "undefined" && IsStretchEnabled() && (document.getElementById("divBoostedAmount").style.display = "none");
    document.getElementById("stretchInfoAlert") !== null && typeof document.getElementById("stretchInfoAlert") != "undefined" && (document.getElementById("stretchInfoAlert").style.display = "none")
}

function GetStretchOfferCallBack(n) {
    var t = JSON.parse(n);
    t.StretchDetails !== null && typeof t.StretchDetails != "undefined" ? (stretchDetailsStr = JSON.stringify(t.StretchDetails), SetStretchStorage(stretchDetailsStr), CalculateStretchOffers(t.StretchDetails), tmp_stretchData = t) : SetStretchStorage("")
}

function getWinboostTable() {
    var n = tmp_stretchData,
        t, s, c, h;
    if (!checkForLite() && IsWinboostTableEnabled()) {
        document.getElementById("stretch-offer-table-tbody").innerHTML = null;
        var f = 0,
            o = document.getElementById("stretch-offer-table-tbody"),
            e = 0;
        for (t = 0; t < n.StretchDetails.StretchOffers.length; t++)
            if (e = t + 1, e < n.StretchDetails.StretchOffers.length)
                if (n.StretchDetails.StretchOffers[e].Events - n.StretchDetails.StretchOffers[t].Events > 1) {
                    var i = document.createElement("tr"),
                        u = document.createElement("td"),
                        r = document.createElement("td");
                    u.innerHTML = `${n.StretchDetails.StretchOffers[t].Events}-${n.StretchDetails.StretchOffers[e].Events-1}`;
                    r.innerHTML = `${n.StretchDetails.StretchOffers[t].StretchVal}%`;
                    r.setAttribute("class", "text--bold");
                    i.appendChild(u);
                    i.appendChild(r);
                    o.appendChild(i);
                    f++
                } else {
                    var i = document.createElement("tr"),
                        u = document.createElement("td"),
                        r = document.createElement("td");
                    r.setAttribute("class", "text--bold");
                    u.innerHTML = n.StretchDetails.StretchOffers[t].Events;
                    r.innerHTML = `${n.StretchDetails.StretchOffers[t].StretchVal}%`;
                    i.appendChild(u);
                    i.appendChild(r);
                    o.appendChild(i);
                    f++
                }
        else {
            var i = document.createElement("tr"),
                u = document.createElement("td"),
                r = document.createElement("td");
            r.setAttribute("class", "text--bold");
            u.innerHTML = n.StretchDetails.StretchOffers[t].Events;
            r.innerHTML = `${n.StretchDetails.StretchOffers[t].StretchVal}%`;
            i.appendChild(u);
            i.appendChild(r);
            o.appendChild(i);
            f++
        }
        s = document.getElementById("expand-stretch-btn");
        f > 6 ? s.style.display = "block" : (s.style.display = "none", c = document.getElementById("stretchOfferTable"), h = c.getAttribute("class"), h.includes("stretchOfferCollapsed") && document.getElementById("stretchOfferTable").setAttribute("class", h.replace("stretchOfferCollapsed", "")))
    }
    document.getElementById("stretch-offer-table-tbody").innerText.replace(" ", "").length == 0 && setTimeout(function() {
        getWinboostTable()
    }, 500)
}

function GetMoneyBackBoostOfferCallBack(n) {
    var t = JSON.parse(n);
    t.MoneyBackBoostDetails !== null && typeof t.MoneyBackBoostDetails != "undefined" ? (moneyBackBoostDetailsStr = JSON.stringify(t.MoneyBackBoostDetails), SetMoneyBackBoostStorage(moneyBackBoostDetailsStr), IsMoneyBackBoostEnabled() && processMoneyBackBoostDetails(t.MoneyBackBoostDetails)) : SetMoneyBackBoostStorage("")
}

function getMoneyBackBoostDataFromLocalStorage() {
    var n = GetMoneyBackBoostStorage(),
        t;
    n !== "undefined" && typeof n != "undefined" && n !== null && n.length > 0 ? (t = JSON.parse(n), IsMoneyBackBoostOfferExpired(t) ? LoadMoneyBackBoost(!0) : processMoneyBackBoostDetails(t)) : IsMoneyBackBoostEnabled() && LoadMoneyBackBoost(!0)
}

function processMoneyBackBoostDetails(n) {
    for (var e = document.getElementById("moneyBackBoost-offer-table-tbody"), t = 0; t < n.MoneyBackBoostOffers.length; t++) {
        var i = document.createElement("tr"),
            r = document.createElement("td"),
            u = document.createElement("td"),
            f = document.createElement("td");
        r.innerHTML = `${n.MoneyBackBoostOffers[t].MinimumEvents}-${n.MoneyBackBoostOffers[t].MaximumEvents}`;
        r.innerHTML = r.innerHTML.includes("+") ? `${n.MoneyBackBoostOffers[t].MinimumEvents}${n.MoneyBackBoostOffers[t].MaximumEvents}` : `${n.MoneyBackBoostOffers[t].MinimumEvents}-${n.MoneyBackBoostOffers[t].MaximumEvents}`;
        u.innerHTML = `${n.MoneyBackBoostOffers[t].Odds} per selection`;
        f.innerHTML = `${n.MoneyBackBoostOffers[t].BetReturned}`;
        i.appendChild(r);
        i.appendChild(u);
        i.appendChild(f);
        e.appendChild(i)
    }
}

function expandStretchContainer() {
    var n = document.getElementById("stretchOfferTable").getAttribute("class");
    n.includes("stretchOfferCollapsed") ? document.getElementById("stretchOfferTable").setAttribute("class", n.replace("stretchOfferCollapsed", "")) : document.getElementById("stretchOfferTable").setAttribute("class", `${n} stretchOfferCollapsed`)
}

function expandMoneyBackBoostContainer() {
    var n = document.getElementById("moneyBackBoostOfferTable");
    n.style.display = n.style.display == "none" ? "block" : "none"
}

function toggleStretchArrow(n) {
    var t = document.getElementById(n),
        i = t.innerHTML;
    document.getElementById(n).innerHTML = i.includes("expand_more") ? "expand_less" : "expand_more"
}

function toggleStretchVisibility() {
    var n = document.getElementById("stretchOfferTable");
    n.style.display == "none" ? (document.getElementById("stretchOfferTable").style.display = "block", getWinboostTable(), screen.width >= 1200 && ($("#right #betslip-container").css({
        "overflow-y": "auto",
        "background-color": "#eee"
    }), $(".betslip-body").css("flex-shrink", "0"))) : (document.getElementById("stretchOfferTable").style.display = "none", screen.width >= 1200 && ($("#right #betslip-container").css({
        "overflow-y": "initial",
        "background-color": "transparent"
    }), $(".betslip-body").css("flex-shrink", "10")))
}

function IsStretchOfferExpired(n) {
    if (n !== null && typeof n != "undefined") {
        var t = new Date,
            i = new Date(n.StretchEnd),
            r = (t.getTime() - i.getTime()) / 6e4;
        return expired = r >= 5
    }
    return !1
}

function toggleMoneyBackBoostVisibility() {
    var n = document.getElementById("moneyBackBoostOfferTable");
    document.getElementById("moneyBackBoostOfferTable").style.display = n.style.display == "none" ? "block" : "none"
}

function IsMoneyBackBoostOfferExpired(n) {
    if (n !== null && typeof n != "undefined") {
        var t = new Date,
            i = new Date(n.EndDateTime),
            r = (t.getTime() - i.getTime()) / 6e4;
        return expired = r >= MoneyBackBoostClientCacheTime
    }
    return !1
}

function GetAppliedMoneyBackBoostOfferObj(n) {
    var f = "",
        t, r, u;
    if (IsMoneyBackBoostEnabled() && (t = GetBetslipOption("MoneyBackBoostOfferApplied"), t.length > 30 && t != "00000000-0000-0000-0000-000000000000"))
        for (n == null && (r = GetMoneyBackBoostStorage(), r != "" && (n = JSON.parse(r))), i = 0; i < n.MoneyBackBoostOffers.length; i++)
            if (u = n.MoneyBackBoostOffers[i], u.MoneyBackBoostOfferId == t) {
                f = JSON.stringify(u);
                break
            }
    return f
}

function CalculateStretchOffers(n) {
    var o;
    if (SetBetslipOption("StretchPotentialReturn", 0), IsStretchEnabled()) {
        if (SetBetslipOption("StretchOfferApplied", "00000000-0000-0000-0000-000000000000"), n == null || n == "") {
            var b = GetBetslipOption("IsFreeBet"),
                v = GetStretchStorage(),
                k = GetBetslipOption("IsSingleBet") === !0,
                p = GetBetslipOption("MaxPayoutMultiple"),
                l = parseFloat(document.getElementById("boostedAmount").value).toFixed(2);
            if (v == "" || v == "null") {
                ClearStretch(!0);
                return
            }
            if (b) {
                enableTax ? k ? (document.getElementById("HoldingTaxAmount").value = holdingTax, document.getElementById("potentialReturnWithStretchVal").innerText = parseFloat(document.getElementById("potentialReturn").value - holdingTax).toFixed(2), document.getElementById("figure").innerText = parseFloat(document.getElementById("potentialReturn").value - holdingTax).toFixed(2)) : (holdingTax = document.getElementById("potentialReturn").value + l >= p ? parseFloat(p * taxPercentage / 100) : parseFloat(document.getElementById("potentialReturn").value * taxPercentage / 100), document.getElementById("HoldingTaxAmount").value = holdingTax.toFixed(2), isLessBetslipValuesEnabled && (o = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2), l > 0 ? (showAllLessPotentialReturn("winboost"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = isNaN(o) ? precise_round(parseFloat(document.getElementById("potentialReturn").value) - holdingTax, 2).toFixed(2) : precise_round(parseFloat(o) - parseFloat(holdingTax), 2).toFixed(2)) : hideAllLessPotentialReturn("winboost"), isLessPotentialReturnValid() ? (showAllLessPotentialReturn("boostedOdd"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(o) - parseFloat(holdingTax), 2).toFixed(2)) : hideAllLessPotentialReturn("boostedOdd"), l <= 0 && !isLessPotentialReturnValid() && hideAllLessPotentialReturn()), document.getElementById("figure").innerText = parseFloat(document.getElementById("potentialReturn").value - holdingTax).toFixed(2)) : (holdingTax = 0, isLessBetslipValuesEnabled && (o = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2), l > 0 ? (showAllLessPotentialReturn("winboost"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = isNaN(o) ? precise_round(parseFloat(document.getElementById("potentialReturn").value) - parseFloat(holdingTax), 2).toFixed(2) : precise_round(parseFloat(o) - parseFloat(holdingTax), 2).toFixed(2)) : hideAllLessPotentialReturn("winboost"), isLessPotentialReturnValid() ? (showAllLessPotentialReturn("boostedOdd"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(o) - parseFloat(holdingTax), 2).toFixed(2)) : hideAllLessPotentialReturn("boostedOdd"), l <= 0 && !isLessPotentialReturnValid() && hideAllLessPotentialReturn()), document.getElementById("potentialReturnWithStretchVal").innerText = parseFloat(document.getElementById("potentialReturn").value).toFixed(2), document.getElementById("figure").innerText = parseFloat(document.getElementById("potentialReturn").value).toFixed(2), document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none");
                document.getElementById("boostedAmount").value = parseFloat(0).toFixed(2);
                miniBetslip();
                return
            }
            n = JSON.parse(v)
        }
        var h = document.getElementById("stretchColorCss").classList,
            y = GetBetslip(),
            r = null,
            s = 0,
            u = 0,
            w = 1,
            f = "",
            c = "";
        if (y !== "" && y !== "{}" && (r = JSON.parse(y)), n.StretchOffers !== null && typeof n.StretchOffers != "undefined" && n.StretchOffers.length > 0) {
            if (r !== null && typeof r != "undefined")
                for (i = 0; i < r.length; i++) r[i].AllowStretch === !0 && (w *= r[i].PriceDecimal, (n.StretchType < 3 || n.MinOddsPerEvent > 0 && r[i].PriceDecimal >= n.MinOddsPerEvent) && (u === 0 && (u = 1), u *= r[i].PriceDecimal, s++));
            for (i = 0; i < n.StretchOffers.length; i++) {
                var a = n.StretchOffers[i],
                    e = parseInt(a.Events),
                    t = parseFloat(a.Odds).toFixed(2);
                if (n.StretchType === 1) {
                    if (t > u) {
                        f = a.StretchVal;
                        requiredForNextOffer = parseFloat(t - u).toFixed(2);
                        c = 'For a <b class="' + h + '">' + f + "<\/b>% win boost on this bet, you need a minimum of <b>" + t + "<\/b> odds";
                        break
                    }
                } else if (n.StretchType === 2) {
                    if (t > u || e > s) {
                        f = a.StretchVal;
                        e > s ? requiredForNextOffer = e - s : t > u && (requiredForNextOffer = parseFloat(t - u).toFixed(2));
                        c = 'For a <b class="' + h + '">' + f + "<\/b>% win boost on this bet, you need a minimum of <b>" + e + '<\/b> selections and <b data-pd="' + t + '" class="betslipPriceDecimal">' + t + "<\/b> total odds" + c;
                        break
                    }
                } else if (e > s) {
                    requiredForNextOffer = e - s;
                    f = a.StretchVal;
                    c = 'For a <b class="' + h + '">' + f + "<\/b>% win boost on this bet, you need a minimum of <b>" + e + '<\/b> selections, each at minimum odds of <b data-pd="' + n.MinOddsPerEvent + '" class="betslipPriceDecimal">' + n.MinOddsPerEvent + "<\/b>";
                    break
                }
            }
        }
        document.getElementById("stretchOfferMsg").innerHTML = c;
        n.StretchType === 1 ? language.translateAtRuntime(document.getElementById("stretchOfferWinBoost"), "BetslipWidget", {
            "data-translate-key": "StretchOfferMinimumOdds",
            "data-translate-type": "generic-html",
            "data-translate-value-0": '<b class="' + h + '">' + f + "<\/b>",
            "data-translate-value-1": '<b data-pd="' + t + '" class="betslipPriceDecimal">' + t + "<\/b>"
        }) : n.StretchType === 2 ? language.translateAtRuntime(document.getElementById("stretchOfferWinBoost"), "BetslipWidget", {
            "data-translate-key": "StretchOfferMinimumEventSelectionsAndOdds",
            "data-translate-type": "generic-html",
            "data-translate-value-0": '<b class="' + h + '">' + f + "<\/b>",
            "data-translate-value-1": "<b>" + e + "<\/b>",
            "data-translate-value-2": '<b data-pd="' + t + '" class="betslipPriceDecimal">' + t + "<\/b>"
        }) : language.translateAtRuntime(document.getElementById("stretchOfferWinBoost"), "BetslipWidget", {
            "data-translate-key": "StretchOfferMinimumEventSelectionsAndMinimumOdds",
            "data-translate-type": "generic-html",
            "data-translate-value-0": '<b class="' + h + '">' + f + "<\/b>",
            "data-translate-value-1": "<b>" + e + "<\/b>",
            "data-translate-value-2": '<b data-pd="' + n.MinOddsPerEvent + '" class="betslipPriceDecimal">' + n.MinOddsPerEvent + "<\/b>"
        });
        CalculateStretchOffersApplied(n, r, u, w, s, c);
        global.getCookie("oddsFormat") === "fraction" && oddsFormatter.convertToFraction();
        miniBetslip()
    }
}

function CalculateStretchOffersApplied(n, t, r, u, f, e) {
    var w = "",
        h = 0,
        g = !0,
        ut = GetBetslipOption("IsSingleBet"),
        b = parseFloat(document.getElementById("wagerAmount").value),
        ft = parseFloat(GetBetslipOption("TotalPriceDecimal")),
        a = GetBetslipOption("MaxPayoutMultiple"),
        y = 0,
        v = enableTax,
        nt = r,
        k, s, d, o, rt, l, p;
    if (n.UseTotalOddsForBonusCalc && (nt = u), t !== null && typeof t != "undefined" && n.StretchOffers !== null && typeof n.StretchOffers != "undefined" && n.StretchOffers.length > 0) {
        for (i = n.StretchOffers.length - 1; i >= 0; i--) {
            var c = n.StretchOffers[i],
                tt = parseInt(c.Events),
                it = parseFloat(c.Odds).toFixed(2);
            if (n.StretchType === 1) {
                if (it <= r) {
                    SetBetslipOption("StretchOfferApplied", c.StretchOfferId);
                    h = c.StretchVal;
                    break
                }
            } else if (n.StretchType === 2) {
                if (it <= r && tt <= f) {
                    SetBetslipOption("StretchOfferApplied", c.StretchOfferId);
                    h = c.StretchVal;
                    break
                }
            } else if (tt <= f) {
                SetBetslipOption("StretchOfferApplied", c.StretchOfferId);
                h = c.StretchVal;
                break
            }
        }
        h > 0 && (e !== "" && (e = "<\/br>" + e), k = document.getElementById("stretchColorCss").classList, w = 'You have qualified for a <b class="' + k + '">' + h + "<\/b>% win boost on this bet.")
    }
    document.getElementById("potentialReturnWithStretchVal").innerText = parseFloat(0).toFixed(2);
    document.getElementById("figure").innerText = parseFloat(0).toFixed(2);
    document.getElementById("boostedAmount").value = parseFloat(0).toFixed(2);
    ut ? (document.getElementById("divPotentialReturnWithStretch").style.display = "none", sportBonusEnabled && enableTax && GetBetslipOption("IsSportBonusBet") && (v = !1), !checkForLite() && v && (document.getElementById("divWinningsTax").style.display = "none"), document.getElementById("divBoostedAmount").style.display = "none", document.getElementById("stretchInfoAlert").style.display = "none") : (s = parseFloat(document.getElementById("potentialReturn").value), d = parseFloat(b) * parseFloat(nt), n.StretchOfferAddition === 2 && (d -= b), o = d * h / 100, GetBetslipOption("IsSportBonusBet") && (o = 0), n.MaxBoostAmount > 0 && o > n.MaxBoostAmount && (o = n.MaxBoostAmount, GetBetslipOption("IsSportBonusBet") && (o = 0), g = !1, e = "<\/br>You have reached the maximum Win Boost possible for this bet.", language.translateAtRuntime(document.getElementById("stretchOfferWinBoost"), "BetslipWidget", {
        "data-translate-key": "MaxWinBoostReached"
    })), n.AllowExceedMaxPayout || s + o > a && (o = a - s, GetBetslipOption("IsSportBonusBet") && (o = 0), g = !1, e = "<\/br>You have reached the maximum Total Return possible for this bet.", language.translateAtRuntime(document.getElementById("stretchOfferWinBoost"), "BetslipWidget", {
        "data-translate-key": "MaxWinBoostTotReturnReached"
    })), rt = b * ft, rt >= a ? o = 0 : o > n.MaxBoostAmount && n.MaxBoostAmount !== 0 && (o = n.MaxBoostAmount, GetBetslipOption("IsSportBonusBet") && (o = 0)), w + e !== "" ? (document.getElementById("stretchOfferMsg").innerHTML = w + e, language.translateAtRuntime(document.getElementById("stretchOfferMsg"), "BetslipWidget", {
        "data-translate-key": "stretchOfferYouHaveQualifiedForAWinBoost",
        "data-translate-type": "generic-html",
        "data-translate-value-0": '<b class="' + k + '">' + h + "<\/b>"
    }), document.getElementById("divPotentialReturnWithStretch").style.display = "", document.getElementById("boostedAmount").value = precise_round(o, 2).toFixed(2), sportBonusEnabled && enableTax && GetBetslipOption("IsSportBonusBet") && (v = !1), !checkForLite() && v ? (l = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2), document.getElementById("potentialLessReturn").style.display != "none" ? isNaN(l) || (document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(l) - parseFloat(y), 2).toFixed(2)) : document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(s) * ((100 - boostedOddPercentageGlobal) / 100) - parseFloat(y), 2).toFixed(2), document.getElementById("potentialReturnWithStretchVal").innerText = precise_round(s + o - y, 2).toFixed(2), document.getElementById("figure").innerText = precise_round(s + o - y, 2).toFixed(2), $("#BetExtentionExpandToggle").text().indexOf("expand_more") > -1 ? (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").setAttribute("hidden", !0), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").setAttribute("hidden", !0), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").setAttribute("hidden", !0)) : (document.getElementById("divPotentialReturn") != undefined && document.getElementById("divPotentialReturn") != null && document.getElementById("divPotentialReturn").removeAttribute("hidden"), document.getElementById("divBoostedAmount") != undefined && document.getElementById("divBoostedAmount") != null && document.getElementById("divBoostedAmount").removeAttribute("hidden"), document.getElementById("divWinningsTax") != undefined && document.getElementById("divWinningsTax") != null && document.getElementById("divWinningsTax").removeAttribute("hidden"))) : checkForLite() || (s >= a ? (document.getElementById("potentialReturnWithStretchVal").innerText = precise_round(a, 2).toFixed(2), document.getElementById("figure").innerText = precise_round(a, 2).toFixed(2)) : (l = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2), o > 0 ? (showAllLessPotentialReturn("winboost"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = isNaN(l) ? precise_round(parseFloat(s) * ((100 - boostedOddPercentageGlobal) / 100), 2).toFixed(2) : precise_round(parseFloat(l), 2).toFixed(2)) : hideAllLessPotentialReturn("winboost"), isLessPotentialReturnValid() ? (showAllLessPotentialReturn("boostedOdd"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(l), 2).toFixed(2)) : hideAllLessPotentialReturn("boostedOdd"), GetBetslipOption("IsSportBonusBet") && (o = 0), o <= 0 && !isLessPotentialReturnValid() && hideAllLessPotentialReturn(), document.getElementById("potentialReturnWithStretchVal").innerText = precise_round(s + o, 2).toFixed(2), document.getElementById("figure").innerText = precise_round(s + o, 2).toFixed(2)))) : document.getElementById("stretchOfferMsg").innerHTML = "", checkForLite() || (isLessBetslipValuesEnabled && document.getElementById("lessPotentialReturnWithStretchVal").textContent != document.getElementById("potentialReturnWithStretchVal").value ? document.getElementById("potentialReturnWithStretchValSpan").style.marginTop = "-5px" : (document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none", document.getElementById("potentialReturnWithStretchNowLabel").style.display = "none", document.getElementById("potentialReturnWithStretchValSpan").style.marginTop = "0px"), v && (document.getElementById("divWinningsTax").style.display = "")), document.getElementById("divBoostedAmount").style.display = "", document.getElementById("stretchInfoAlert").style.display = "", GetBetslipOption("IsSportBonusBet") && (o = 0, document.getElementById("boostedAmount") != null && (document.getElementById("boostedAmount").value = parseFloat(0).toFixed(2)), document.getElementById("boostedAmountlabel") != null && (document.getElementById("boostedAmountlabel").value = parseFloat(0).toFixed(2))), SetBetslipOption("StretchPotentialReturn", o), p = document.getElementById("WinBoost"), p && (p.innerHTML = "(" + h + "%)"), GetBetslipOption("IsSportBonusBet") && (p.innerHTML = "(0%)"));
    miniBetslip()
}

function GetAppliedStretchOfferObj(n) {
    var f = "",
        t, r, u;
    if (IsStretchEnabled() && (t = GetBetslipOption("StretchOfferApplied"), t.length > 30 && t != "00000000-0000-0000-0000-000000000000"))
        for (n == null && (r = GetStretchStorage(), r != "" && (n = JSON.parse(r))), i = 0; i < n.StretchOffers.length; i++)
            if (u = n.StretchOffers[i], u.StretchOfferId == t) {
                f = JSON.stringify(u);
                break
            }
    return f
}

function setInvalidOutcome(n) {
    var t = document.getElementById("SelectedOutcomeForBetslip-" + n);
    setInvalidOutcomeStyle(t);
    updateLocalStorageItem("betslipStorage", n, !0)
}

function setInvalidOutcomeStyle(n) {
    for (var r, i = n.getElementsByClassName("theOtherFont"), t = 0; t < i.length; t++) r = i[t].className, r.includes("theOtherFont red") || (i[t].className = r.replace("theOtherFont", "theOtherFont red"))
}

function updateLocalStorageItem(n, t, i) {
    var u = !1,
        r = JSON.parse(safeGetStorageData(n));
    for (index = 0; index < r.length; index++)
        if (r[index].OutcomeId === t) {
            r[index].HasError = i;
            u = !0;
            break
        }
    safeSetStorageData(n, r, u)
}

function resetBetslipStorageHasError() {
    var t = !1,
        n = JSON.parse(safeGetStorageData("betslipStorage"));
    for (index = 0; index < n.length; index++) n[index].HasError && (n[index].HasError = !1, t = !0);
    safeSetStorageData("betslipStorage", n, t)
}

function safeGetStorageData(n) {
    if (lsTest() === !0) {
        var t = localStorage.getItem(n);
        return t === null || typeof t == "undefined" ? "{}" : t
    }
    return getCookie(n)
}

function safeSetStorageData(n, t, i) {
    t !== null && t.length > 0 && i && (lsTest() === !0 ? localStorage.setItem(n, JSON.stringify(t)) : setCookie(n, JSON.stringify(t), .01))
}

function UpdateBetOutcomeOddsIfStretchApplied(n) {
    var o = GetBetslipOption("StretchOfferApplied"),
        r, t, e, u, f, i;
    if (!(o.length < 30) && o != "00000000-0000-0000-0000-000000000000" && typeof n != "undefined" && n != null && n.length > 0 && (r = GetBetslip(), r != "" && r != "{}")) {
        for (t = JSON.parse(r), e = 0, u = 0; u < n.length; u++)
            for (f = n[u], i = 0; i < t.length; i++)
                if (t[i].OutcomeId === f.OutcomeId) {
                    t[i].PriceDecimal = f.PriceDecimal;
                    t[i].IsLiveInPlay = f.IsLiveInPlay;
                    e++;
                    break
                }
        e > 0 && (SetBetslip(t), checkForLite() || UpdateBetslipFullVersion())
    }
}

function UpdateBetOutcomesForBuildAbet(n) {
    var r, t, f, u, e, i;
    if (typeof n != "undefined" && n != null && n.length > 0 && (r = GetBetslip(), r != "" && r != "{}")) {
        for (t = JSON.parse(r), f = 0, u = 0; u < n.length; u++)
            for (e = n[u], i = 0; i < t.length; i++)
                if (t[i].IsGroupHeader && t[i].GroupTypeId === "00000000-0000-0000-da7a-000000710003" && t[i].OutcomeId === e.OutcomeId) {
                    t[i].PriceDecimal = e.PriceDecimal;
                    f++;
                    break
                }
        f > 0 && (SetBetslip(t), checkForLite() || UpdateBetslipFullVersion())
    }
}

function precise_round(n, t) {
    if (typeof n != "number" || typeof t != "number") return !1;
    var i = n >= 0 ? 1 : -1;
    return Math.round(n * Math.pow(10, t) + i * .0001) / Math.pow(10, t)
}

function GetBookingCodeBetslip() {
    var n = "",
        t;
    checkForLite() ? (n = document.getElementById("txtBookingCodeSrch").value, post_to_url("/Bet/BookABet", {
        bookingCode: n
    }, "post")) : (n = $(".bookingCodeSearch")[0].value, n === "" && (n = $(".bookingCodeSearch")[1].value), n.startsWith("X") || n.startsWith("U") ? (homePage.showOverlay(), ajax.get("/BookABet/internal/GetClientSideBetslipForBookingCode", {
        bookingCode: n
    }, GetBetslipForBookingCodeCallBack)) : synapseBookingCodeRedirectEnabled ? (t = `The booking code can only be used on our new site - Click <a href="//${synapseWebsiteUrl}/?bookingCode=${n}"> here </a> to be redirected`, mybets.showAlert("Booking Code", t, !1, !0)) : mybets.showAlert("Booking Code", "Invalid booking code", !1, !0))
}

function GetBookingCodeAccumulator(n, t) {
    homePage.showOverlay();
    t.classList.contains("isSelectedAccumulator") ? (t.classList.remove("isSelectedAccumulator"), ClearBetslip(), homePage.closeOverlay()) : (t.classList.add("isSelectedAccumulator"), ajax.get("/BookABet/internal/GetClientSideBetslipForBookingCode", {
        bookingCode: n
    }, GetBetslipForBookingCodeCallBack))
}

function ClearAccumulatorsFromBetslip() {
    checkForLite() || $(".accumulatorOutcomeBtn").removeClass("isSelectedAccumulator")
}

function setAccumulatorTimeTillClose(n, t) {
    var r = Date.parse($("#footer-realtime-clock").data().date + " " + $("#footer-realtime-clock").text()),
        u = new Date(t),
        f = u - r,
        i = f / 1e3,
        e = Math.floor(i / 3600),
        o = Math.floor(i % 3600 / 60),
        s = i % 60;
    f != null && r < u ? $("#timeTillClose-" + n).text(` ${pad(e,2)}:${pad(o,2)}:${pad(s.toFixed(0),2)} remaining`) : ($("#accumulator-" + n).addClass("disableAccumulatorElement"), $("#timeTillClose-" + n).text("Coupon Expired"), $("#coupon-odds-" + n).addClass("hidden"))
}

function GenerateBookingCode() {
    var e = completeBetslip(),
        n = JSON.parse(e.Outcomes),
        u = !1,
        o = e.IsSingleBets,
        f, r, s;
    checkForLite() || (f = _.findWhere(n, {
        Title: ""
    }), f && (n = f.GroupChildItems, u = !0));
    var t = getCookie("AccountId") !== null && typeof getCookie("AccountId") !== undefined ? getCookie("AccountId") : "",
        h = document.getElementById("bookingCodeForceLogin").value === "true",
        i = "";
    t === undefined && (t = "00000000-0000-0000-0000-000000000000");
    t === "" && h ? checkForLite() || (s = document.getElementById("showLoginContent").innerHTML, $("#modal-container-bet-confirmation").html(s), $("#modal-container-bet-confirmation").modal("show").find(".modal-body").css({
        "-webkit-transform": "translate(-50%, -50%)",
        padding: "15px"
    }), $("#modal-container-bet-confirmation").off("hidden.bs.modal"), homePage.closeOverlay()) : n !== null && typeof n != "undefined" && n.length > 0 ? (r = n.reduce(function(n, t) {
        return n.push(t.OutcomeId), n
    }, []), r.length > 0 ? checkForLite() ? post_to_url("/Bet/BookingCode", {
        outcomeIds: r.join(","),
        accountId: t,
        isSingleBet: o && !u
    }, "post") : ajax.post("/BookABet/internal/GetBookingCodeAndShare", {
        outcomeIds: r.join(","),
        accountId: t,
        isSingleBet: o && !u
    }, GetBookingCodeCallBack) : i = "No valid selections found in your betslip.") : i = "There are no bets in your betslip. You need to first add some bets before it can be shared.";
    i !== "" && (document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = i)
}

function AddBookingCodeItemsToBetslip(n) {
    var s = checkForLite(),
        f, h, u, t, e;
    if (n === null || typeof n == "undefined" || n === "") homePage.closeOverlay(), document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = "This code is expired or invalid. Please enter a new code.", language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
        "data-translate-key": "CodeIsExpiredOrInvalid"
    });
    else {
        var l = JSON.parse(n),
            i = JSON.parse(l),
            r = i.Betslip;
        if (r.length > 0) {
            if (s) {
                for (f = [], a = 0; a < r.length; a++) t = r[a], h = buildBet(t.OutcomeId, t.Title, t.PriceDecimal, t.Sport, t.MarketTitle, t.EventTitle, t.StartDate, t.EventId, t.IsLiveInPlay, t.FeedDataTypeId, t.AllowEarlyCashout, !1, null), f.push(h);
                SetBetslip(f);
                window.location.href = "/Bet/Betslip"
            } else {
                for (ClearBetslip("bookabet"), (i.BookingCode !== null || i.BookingCode !== "undefined" || i.BookingCode !== "") && $("#accumulator-" + i.BookingCode).addClass("isSelectedAccumulator"), homePage.closeOverlay(), i.IsBuildABet && (u = JSON.parse("[]")), a = 0; a < r.length; a++) {
                    if (t = r[a], e = null, i.IsBuildABet) {
                        var o = t.OutcomeFeedId.split("~"),
                            c = t.EventFeedId,
                            v = o[2],
                            y = o[0].replace(c, ""),
                            p = o[1];
                        e = {
                            EventId: c,
                            MarketId: y,
                            Specifiers: p,
                            OutcomeId: v
                        }
                    }
                    SendToBetslip(t.OutcomeId, t.Title, t.PriceDecimal, t.Sport, t.MarketTitle, "None", t.EventTitle, t.StartDate, t.EventId, t.IsLiveInPlay, t.FeedDataTypeId, t.AllowEarlyCashout, t.AllowStretch, t.leagueFriendlyName, t.IsTrendingOutcome, null, i.IsBuildABet, e, u, null, null, t.IsSportBonusAllowed)
                }
                i.IsBuildABet ? (u[0].OutcomeId = i.BuildABetDetails.ResultGuid, u[0].PriceDecimal = i.BuildABetDetails.CalcResult.Odds, buildABet.addTempSelectionToBetslip(i.IsBuildABet, u)) : i.IsSingleBet ? (ToggleBetslip(document.getElementById("sb_id")), mybets.toggleToBetslip("betslipHeader")) : (ToggleBetslip(document.getElementById("mb_id")), mybets.toggleToBetslip("betslipHeader"))
            }
            SetBookingCode(i.BookingCode)
        } else s ? document.getElementById("betslip-bookingCodeNotFound-error") ? document.getElementById("betslip-bookingCodeNotFound-error").style.display = "" : window.location.href = "/Bet/Betslip?bookingCodeNotFound=true" : (homePage.closeOverlay(), document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = "This code is expired or invalid. Please enter a new code.", language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
            "data-translate-key": "CodeIsExpiredOrInvalid"
        }))
    }
}

function ShowMyBetsShareOptionsLite(n) {
    var t = "bookABetShareLink_" + n,
        i = "bookABetShareContent_" + n;
    document.getElementById(t).style.display = "none";
    document.getElementById(i).style.display = ""
}

function SendToBetslip(n, t, i, r, u, f, e, o, s, h, c, l, a, v, y, p, w, b, k, d, g, nt) {
    var lt, ot, ut, ct, it, st;
    (typeof a == "undefined" || a === "") && (a = !1);
    lt = (new Date).toLocaleString();
    SetBookingCode("");
    var rt = GetBetslip(),
        tt = rt !== undefined && rt.length > 0 ? JSON.parse(rt) : "",
        ft = !1,
        ht = "",
        et = checkForLite();
    if (et ? incrementalPayoutLimitsEnabled && IncrementalPayoutLimits.updateMaxPayoutAmount(tt.length) : homePage.isBigWinnerWidgetShowing && homePage.toggleBigWinnerWidget(), checkForLite() || d != undefined && d != null && d != 0 || (d = boostedOddPercentageGlobal), ClearBookABetSearch(), (IsBuildABet() || w) && (ft = !0, ht = s, t == "" && tt && tt.length > 0 && (ft = !1)), document.getElementById("wagerAmount") !== null && typeof document.getElementById("wagerAmount") != "undefined" && (ot = GetBetslipOption("MinBetAmount"), ot > parseFloat(document.getElementById("wagerAmount").value) ? document.getElementById("wagerAmount").value = parseFloat(ot).toFixed(2) : tt.length == 1 && (document.getElementById("wagerAmount").value = parseFloat(ot).toFixed(2))), et || (ut = $('div.outcome-pricedecimal[data-lip-value="' + n + '"]')[0], ut !== null && $(ut).data("lip-pricedecimal") !== undefined && $(ut).data("lip-pricedecimal") !== null && (i = $(ut).attr("data-lip-pricedecimal"))), ct = /[!@#$%^&*_+\-=\[\]{};'"\\|,.<>\/?]/, f === "None" || f.includes("pre:playerprops") || ct.test(f) || (u = u + " " + f), h = h || "False", it = buildBet(n, t, i, r, u, e, o, s, h, c, l, a, ht, y, d, g, nt), document.getElementById("betslip-single-multi-error") != null && (document.getElementById("betslip-single-multi-error").innerText = ""), document.getElementById("bet-amount-val") != null && (st = document.getElementById("bet-amount-val"), st.innerText = "", st.classList.add("hidden")), ft) buildABet.addToTempBetslip(it, s, b, k);
    else {
        if (rt === "" || rt === "{}") tt = [it];
        else if (tt = JSON.parse(rt), RemoveSelected(tt, "OutcomeId", n)) document.getElementById("SelectedOutcomeForBetslip-" + n) != null && ($("SelectedOutcomeForBetslip-" + n).hasClass("unsuccessfulBet") || document.getElementById("SelectedOutcomeForBetslip-" + n).parentNode.removeChild(document.getElementById("SelectedOutcomeForBetslip-" + n)));
        else if (!(GetBetslipOption("IsSingleBet") === !1 && RemoveOtherOutcomesForEvent(tt, "EventId", it.EventId, it.OutcomeId))) {
            if (enableBetslipLimitError(tt.length)) return;
            tt.push(it)
        }
        et || outcomeAddedToBetslip_BetBooster(it.OutcomeId);
        SendToBetslip_Continued(et, it, tt, !0, v, p, r, l)
    }
    checkMaxSelectedReached();
    incrementalPayoutLimitsEnabled && !ft && IncrementalPayoutLimits.checkBetSlipSelections(tt)
}

function SendToBetslip_Continued(n, t, i, r, u, f, e) {
    var h, o, s;
    if (i.length > -1) {
        for (h = i.length, o = 0; o < slips.length; o++) document.getElementsByClassName("slip-counter")[o].innerHTML = h;
        n || typeof mybets != "undefined" && mybets.toggleToBetslip()
    }
    i.length === 0 ? (n || f === "bookabet" || (mybets.toggleToBetslip("betslipHeader"), enableWagerTax && (SetBetslipOption("InitialStake", parseFloat(minBetAmount).toFixed(2)), document.getElementById("stakeBeforeWagerTax").value = parseFloat(minBetAmount).toFixed(2), checkWager())), SetBetslip({}), SetBookingCode(""), ClearAccumulatorsFromBetslip()) : SetBetslip(i);
    r && SetOutcomeButtons(i);
    n || (UpdateBetslipFullVersion(), buildABet.toggleBookABetButton(i));
    typeof useGoogleAnalytics == "undefined" && (useGoogleAnalytics = !1);
    useGoogleAnalytics === !0 && t.Title !== "" && gax.AddToBetslip_EventTracking(t.Title, t.MarketTitle, t.EventTitle, t.PriceDecimal, u, e, t.EventId);
    typeof $ != "undefined" && ($("#sb_id").hasClass("active") ? $("#betslip-list").addClass("ms-hide-exclamation").addClass("sb-active") : $("#mb_id").hasClass("active") && $("#betslip-list").removeClass("ms-hide-exclamation").removeClass("sb-active"));
    n || CalculateStretchOffers(null);
    n || $('[id="' + t.OutcomeId + '"]').hasClass("disableSelectedElement") && $('[id="' + t.OutcomeId + '"]').removeClass("disableSelectedElement").addClass("disableElement");
    n || global.getCookie("oddsFormat") !== "fraction" || ($("#oddsFormat").val("fraction"), $(".betslipPriceDecimal").each(function() {
        $(this).text(oddsFormatter.convertFromDecimalToFraction($(this).text()))
    }), $("#betslip-totalpricedecimal").text(oddsFormatter.convertFromDecimalToFraction($("#betslip-totalpricedecimal").text())));
    removeElements && (s = '{ "message" : "BetslipCount", "data" : { "Count" :' + i.length + "} }", global.getCookie("isIosApp") === "true" ? webkit.messageHandlers.PostData.postMessage(s) : window.Data.postData(s));
    n || (winningsTax(), $("#BetExtentionExpandToggle").text().trim().includes("expand_less") && BetExtentionExpandToggle());
    miniBetsllipCount = i.length;
    miniBetslip(!0)
}

function toggleMultimixmarket(n) {
    document.getElementById(n).style.display = document.getElementById(n).style.display === "none" ? "block" : "none"
}

function OMtoggleAllMarkets() {
    var n = document.getElementsByClassName("multimixtable"),
        t, i;
    if (document.getElementsByClassName("toggleMarketBtnText")[0].textContent.toLowerCase() === "expand all") {
        for (t = 0; t < n.length; t++) n[t].style.display = "block";
        document.getElementsByClassName("toggleMarketBtnText")[0].textContent = "Collapse All"
    } else {
        for (i = 0; i < n.length; i++) n[i].style.display = "none";
        document.getElementsByClassName("toggleMarketBtnText")[0].textContent = "Expand All"
    }
}

function UpdateBetCount(n) {
    var i = "",
        r, t, u;
    if (n !== null && typeof n != "undefined" || (i = GetBetslip(), i !== ""))
        if (n = i, r = JSON.parse(n), r.length > 0)
            for (u = r.length, t = 0; t < slips.length; t++) document.getElementsByClassName("slip-counter")[t].innerHTML = u;
        else
            for (t = 0; t < slips.length; t++) document.getElementsByClassName("slip-counter")[t].innerHTML = 0
}

function SetOutcomeButtons(n) {
    if (!n) {
        var t = GetBetslip();
        n = t === "" || t === "{}" ? JSON.parse(t) : JSON.parse(t)
    }
    IsBuildABet() || SetOutcomeButtonsFromBSItems(n)
}

function SetOutcomeButtonsFromBSItems(n) {
    var f = !1,
        u, t, r, e, i;
    if ((window.location.pathname.toLowerCase() === "/event/inplay" || window.location.pathname.toLowerCase() === "/event/livesport" || window.location.search.toLowerCase().indexOf("inplay=true") > -1 || window.location.pathname.toLowerCase() === "/bet/eventmultimarket" && document.getElementById("multi-head").classList.contains("inPlayBg")) && (f = !0), u = checkForLite(), t = "selected", u || (t = f ? "isSelectedInPlay" : "isSelected"), u ? (removeClassEverywhere(" " + t), DistributeChildWidths("bettingtr"), DistributeChildWidths("bettingdiv")) : (removeClassEverywhere(" " + t), removeClassEverywhereForSelects()), n && n.length)
        for (r = 0; r < n.length; r++) e = n[r].MarketTitle == null ? "" : n[r].MarketTitle, u ? (i = document.getElementById(n[r].OutcomeId), i == null || hasClass(i, t) || (i.className += " " + t, i.tagName === "OPTION" && (i.parentElement.className += " isSelected", i.parentElement.selectedIndex = i.index))) : e.toLowerCase() !== "build a bet" && $("[id='" + n[r].OutcomeId + "']").each(function() {
            hasClass(this, t) || (this.className += " " + t, this.tagName === "OPTION" && (this.parentElement.className += " isSelected", this.parentElement.selectedIndex = this.index))
        });
    else return
}

function removeClassEverywhere(n) {
    for (var i = document.getElementsByClassName(n), t = i.length - 1; t > -1; t--) i[t] != null && (i[t].className = i[t].className.replace(n, ""))
}

function removeClassEverywhereForSelects() {
    for (var r, i, t = document.getElementsByTagName("select"), n = 0; n < t.length; n++)
        if (r = t[n].classList.contains("no-reset"), r || (r = t[n].classList.contains("DOBDropDown") || t[n].classList.contains("valid")), !r)
            for (t[n].selectedIndex = 0, t[n].className = t[n].className.replace("isSelected", ""), i = 0; i < t[n].options.length; i++) t[n].options[i].className = t[n].options[i].className.replace("selected", "").replace("isSelected", "")
}

function hasClass(n, t) {
    return (" " + n.className + " ").indexOf(" " + t) > -1
}

function buildBet(n, t, i, r, u, f, e, o, s, h, c, l, a, v, y, p, w) {
    typeof l == "undefined" && (l = !1);
    var b = {};
    return b.Title = t, b.OutcomeId = n, b.PriceDecimal = i, b.Sport = r, b.MarketTitle = u, b.EventTitle = f, b.StartDate = e, b.EventId = o, b.IsSingleFreeBet = !1, b.IsSingleSportBonusBet = !1, b.IsLiveInPlay = s === "True", b.FeedDataTypeId = h, b.allowEarlyCO = typeof c == "undefined" ? !1 : c, b.IsTrendingOutcome = typeof v == "undefined" ? !1 : v, b.IsSportBonusAllowed = typeof w == "undefined" ? !1 : w, b.BoostedOddPercentage = y, b.AllowStretch = l, b.HasError = !1, b.LeagueId = p, b.Ticked = !checkMaxSelectedReached(), b.IsGroupHeader = !1, b.GroupHeaderId = a, b.GroupTypeId = null, b.GroupChildItems = null, b
}

function buildBetGroupHeader(n, t, i, r, u, f, e, o, s, h, c, l, a, v, y) {
    typeof l == "undefined" && (l = !1);
    var p = buildBet(n, t, i, r, u, f, e, o, s, h, !1, l, v);
    return p.IsGroupHeader = !0, p.GroupHeaderId = v, p.GroupTypeId = a, p.GroupChildItems = [], y && p.GroupChildItems.push(y), p
}

function RemoveSelected(n, t, i) {
    var u, r, f;
    for (ClearBookABetSearch(), u = !1, r = 0; r < n.length; r++)
        if (n[r][t] === i) {
            u = !0;
            f = document.getElementById(n[r][t]);
            f != null && removeSelected(f);
            removeFromArray(n, r);
            SetOutcomeButtons();
            break
        }
    return u
}

function GetIndexOfBetByOutcomeId(n) {
    return n.OutcomeId === this.toString()
}

function RemoveAllOutcomesForEventId(n) {
    var r = GetBetslip(),
        t, i;
    if (r !== "" && r !== "{}") {
        for (t = JSON.parse(r), i = 0; i < t.length; i++) t[i].EventId === n && removeFromArray(t, i);
        SetBetslip(t);
        UpdateBetCount()
    }
}

function RemoveOtherOutcomesForEvent(n, t, i, r) {
    for (var f, u = 0; u < n.length; u++) n[u][t] === i && (n[u].IsGroupHeader || n[u].OutcomeId === r || (f = document.getElementById(n[u].OutcomeId), f == null || betslipMultiSelectorEnabled || removeSelected(f), document.getElementById("SelectedOutcomeForBetslip-" + n[u].OutcomeId) != null && document.getElementById("SelectedOutcomeForBetslip-" + n[u].OutcomeId).parentNode.removeChild(document.getElementById("SelectedOutcomeForBetslip-" + n[u].OutcomeId)), betslipMultiSelectorEnabled || removeFromArray(n, u)))
}

function removeSelected(n) {
    n.className = n.className.replace(/(?:^|\s)selected(?!\S)/g, "")
}

function removeFromArray(n, t) {
    t !== -1 && n.splice(t, 1)
}

function setCookie(n, t, i) {
    var r = new Date,
        u;
    r.setTime(r.getTime() + i * 864e5);
    u = "expires=" + r.toUTCString();
    try {
        document.cookie = n + "=" + t.replace(/"/g, "'") + ";" + u + ";path=/"
    } catch (f) {
        document.cookie = n + "=" + t + ";" + u + ";path=/"
    }
}

function getCookie(n) {
    for (var t, r = n + "=", u = document.cookie.split(";"), i = 0; i < u.length; i++) {
        for (t = u[i]; t.charAt(0) === " ";) t = t.substring(1);
        if (t.indexOf(r) === 0) return t.substring(r.length, t.length).replace(/'/g, '"')
    }
    return ""
}

function lsTest() {
    var n = "test";
    try {
        return localStorage.setItem(n, n), localStorage.removeItem(n), !0
    } catch (t) {
        return !1
    }
}

function post_to_url(n, t, i) {
    var r, f, u;
    i = i || "post";
    r = document.createElement("form");
    r.setAttribute("method", i);
    r.setAttribute("action", n);
    for (f in t) t.hasOwnProperty(f) && (u = document.createElement("input"), u.setAttribute("type", "hidden"), u.setAttribute("name", f), u.setAttribute("value", t[f]), r.appendChild(u));
    document.body.appendChild(r);
    r.submit()
}

function cacheOrCall(n, t, i, r, u, f) {
    var e = n + t,
        o = findCacheItem(e);
    if (o != null) r(o);
    else return i.toLowerCase() === "post" ? ajax.post(n, t, r, u) : ajax.get(n, t, r, u), setCacheValue(e, window.LastResponse, f), window.LastResponse;
    return window.LastResponse
}

function setCacheValue(n, t, i) {
    var r = new Date,
        u;
    (i === null || typeof i == "undefined") && (i = 10);
    r.setSeconds(r.getSeconds() + i);
    u = {
        key: n,
        value: t,
        expiry: r
    };
    cache.push(u);
    cache.length > MAX_CACHE_SIZE && cache.shift()
}

function findCacheItem(n) {
    purgeExpiredItems();
    for (var t = 0, i = cache.length; t < i; t++)
        if (cache[t].key === n) return cache[t].value;
    return null
}

function purgeExpiredItems() {
    for (var t = new Date, n = 0, i = cache.length; n < i; n++) cache[n].expiry < t && cache.splice(n, 1)
}

function GetAccountOption(n) {
    window.location.href = n
}

function getMenuContentOpera() {
    var n = document.getElementById("hamb-menu");
    n != null && (removeOptions(n), cacheOrCall("/Lite/SideMenuOperaMini", null, "GET", function(t) {
        var i = JSON.parse(t);
        Object.keys(i).forEach(function(t) {
            addSelectOption(n, t, i[t])
        })
    }, !0, 300), n.onchange = function() {}, n.onclick = function() {})
}

function addSelectOption(n, t, i) {
    var r = document.createElement("option");
    r.text = t;
    i === "/" && (i = "/Home");
    r.value = i;
    n.add(r)
}

function removeOptions(n) {
    for (var t = n.options.length - 2; t >= 0; t--) n.remove(t)
}

function filterSportsLite(n, t, i, r) {
    return window.runningAjax != null && window.runningAjax === !0 ? !1 : (n.toUpperCase() === "00000000-0000-0000-DA7A-000000550031" ? window.location = "/Casino" : n.toUpperCase() === "00000000-0000-0000-DA7A-000000550032" ? window.location = "/Jackpots/Index" : n.toUpperCase() === "00000000-0000-0000-DA7A-000000550071" ? window.location.pathname = r : n.toUpperCase() === "00000000-0000-0000-DA7A-000000550064" ? window.location = "/Esports" : (window.runningAjax = !0, ajax.get("/Event/GetEventsBySportIdLite", {
        sportConfigId: n,
        FeedDataTypeId: t
    }, function() {
        i === null || typeof i == "undefined" || i === "" ? window.location.reload() : window.location.href = i
    })), !1)
}

function resetFilter(n, t) {
    return window.runningAjax != null && window.runningAjax === !0 ? !1 : (window.runningAjax = !0, n === "League" ? ajax.post("/Lite/FilterEventsLite", {
        reset: n
    }, function() {
        t ? window.location.href = t : location.reload()
    }) : n === "MarketType" && ajax.post("/Lite/FilterEventsLite", {
        reset: n
    }, function() {
        t ? window.location.href = t : location.reload()
    }), !1)
}

function filterLeaguesByRegionId(n, t, i) {
    ajax.post("/Event/FilterEventsByRegionId", {
        regionId: n,
        FeedDataTypeId: i
    }, function() {
        window.location.href = i === "00000000-0000-0000-da7a-000000580003" ? "/Event/LiveSport" : "/"
    }, !0)
}

function filterLeaguesLite(n, t, i, r) {
    var u, f, e;
    return window.runningAjax != null && window.runningAjax === !0 ? !1 : (window.runningAjax = !0, u = document.getElementById("filtermarket-button"), f = [], u != null && (e = u.selectedIndex, f.push(u.options[e].id)), t !== undefined && t != null && (f = t), ajax.post("/Lite/FilterEventsLite", {
        leagueIds: JSON.stringify(n),
        couponTypeId: f,
        reset: r
    }, function() {
        i ? window.location.href = i : location.reload()
    }), !1)
}

function genderChanged(n) {
    for (var i = document.getElementsByName(n.name), t = 0; t < i.length; t++) i[t].checked = i[t].value === n.value ? n.checked : !n.checked
}

function filterBetTypeLite(n, t) {
    return window.runningAjax != null && window.runningAjax === !0 ? !1 : (window.runningAjax = !0, ajax.post("/Lite/FilterEventsLite", {
        couponTypeIds: JSON.stringify(n)
    }, function() {
        t ? window.location.href = t : location.reload()
    }), !1)
}

function onUpdate() {
    var n = document.getElementById("leagueFilterOptions"),
        r = [],
        i, t;
    if (n != null) {
        if (i = n.selectedIndex, n.options[i].getAttribute("data-isRegion") != null && n.options[i].getAttribute("data-isRegion") === "true")
            for (t = i + 1; t < n.options.length; t++) {
                if (n.options[t].getAttribute("data-isRegion") != null && n.options[t].getAttribute("data-isRegion") === "true") break;
                r.push(n.options[t].value)
            } else r.push(n.options[i].value);
        filterLeaguesLite(r)
    }
}

function SetInlineOptions() {
    var n = document.getElementById("guests"),
        t, i;
    getCookie("AccountId") != null && getCookie("AccountId") !== "" && (n = document.getElementById("authed"), getCookie("CurrentBalance") === null || typeof getCookie("CurrentBalance") == "undefined" || getCookie("CurrentBalance") === "" ? RefreshCashBalanceLite() : (t = document.getElementById("accountCashBalance"), i = document.getElementById("accountFreeBetAmount"), t != null && (t.innerText = getCookie("CurrentBalance")), i != null && (i.innerText = getCookie("CurrentFreeBetAmount"))));
    n !== null && (n.style.display = "block")
}

function RefreshCashBalanceLite() {
    ajax.get("/Account/_GetCashBalanceOnly?_=" + (new Date).getTime(), "", function(n) {
        var t = document.getElementById("accountCashBalance");
        t != null && (t.innerText = n);
        setCookie("CurrentBalance", n, .001)
    }, !0);
    ajax.get("/Account/_FreeBetBalanceOnly?_=" + (new Date).getTime(), "", function(n) {
        var t = document.getElementById("accountFreeBetAmount");
        t != null && (t.innerText = n);
        setCookie("CurrentFreeBetAmount", n, 2)
    }, !0)
}

function ValidateSearch() {
    var n = document.getElementById("txtSearchKeyword");
    return n != null ? n.value.length > 3 : !1
}

function DistributeChildWidths(n) {
    for (var r, i = document.getElementsByClassName(n), t = 0; t < i.length; t++) {
        var u = i[t].children.length,
            f = i[t].clientWidth,
            e = f / u;
        for (r = 0; r < i[t].children.length; r++) i[t].children[r].style.width = e + "px"
    }
}

function GetWithdrawalOptionLite(n, t) {
    ajax.post("/Lite/_WithdrawalOption", {
        withdrawalOption: n
    }, function(n) {
        document.getElementById(t).innerHTML = n
    });
    var i = document.querySelectorAll(".wd-buttons button");
    [].forEach.call(i, function(n) {
        n.className = n.className.replace(/\bselected\b/, "")
    })
}

function onWithdrawClick(n, t) {
    var i = document.getElementById("Confirmed");
    i.value = "true";
    ajax.post(n, t).done(function(n) {
        document.getElementById("withdrawalType").innerHTML = n
    })
}

function RedirectifChanged(n) {
    var t = n.value;
    if (t != null) {
        if (window.location.href != null && window.location.pathname != null && window.location.href.toLowerCase() === t.toLowerCase() || window.location.pathname.toLowerCase() === t.toLowerCase()) return;
        setTimeout(function() {
            window.location.href = t
        }, 0)
    }
}

function AddSelectedItemToBetslip(theDropdown) {
    var selectedElement, jsToRun, betslipOutcomes;
    theDropdown !== null && typeof theDropdown != "undefined" && (selectedElement = theDropdown.options[theDropdown.selectedIndex], selectedElement != null && (selectedElement.value !== "EMPTY" ? (jsToRun = selectedElement.getAttribute("data-js"), eval(jsToRun), theDropdown.value = selectedElement.value) : (betslipOutcomes = JSON.parse(GetBetslip()), betslipOutcomes !== undefined && betslipOutcomes !== null && betslipOutcomes.length > 0 && (removeAllOutcomesForEvent(theDropdown, betslipOutcomes), theDropdown.classList.remove("isSelected")))))
}

function removeOutcomeForEventId(n) {
    RemoveAllOutcomesForEventId(n)
}

function removeAllOutcomesForEvent(n, t) {
    for (var r, i = 0; i < n.length; i++) r = t.findIndex(function(t) {
        return t.OutcomeId == n[i].id
    }), r > -1 && RemoveBet(t[r].OutcomeId)
}

function ConfirmWithdrawal(n) {
    n.preventDefault();
    $("#Confirmed").val(!0);
    $("form").submit()
}

function setAmountLite(n, t, i) {
    var r = document.getElementById(t + i);
    r != null && (r.value = n)
}

function setAmountLiteSafariCom(n, t, i, r) {
    var u = document.getElementById(t + r);
    u != null && (u.value = n);
    i != null && ($(".isSelected").removeClass("isSelected"), i.className += " isSelected")
}

function onBetConfirmationModalClick(n, t, i, r, u, f) {
    var o, s, h, e;
    n.preventDefault();
    n != null && (n.currentTarget.disabled = !0, n.currentTarget.innerText = "Loading", language.translateAtRuntime(n.currentTarget, "BetslipConfirmationDialog", {
        "data-translate-key": "Loading"
    }));
    o = !1;
    u === null || typeof u == "undefined" ? u = !1 : u && (o = !0, t = t + "?NewOddsAccepted=true", IsStretchEnabled() && (s = GetBetslipOption("StretchOfferApplied"), s.length > 30 && s != "00000000-0000-0000-0000-000000000000" && (h = GetAppliedStretchOfferObj(null), t = t + "&stretchOfferApplied=" + h)), checkForLite() || (e = $(".SelectedOutcomeForBetslip.unsuccessfulBet").find(".outcomeRow-title"), e !== undefined && e !== null && e.length > 0 && e.css("color", "#333"), $(".SelectedOutcomeForBetslip").removeClass("unsuccessfulBet")));
    f !== null && typeof f != "undefined" && (o ? t = t + "&OverwriteWagerAmtAccepted=true" : (o = !0, t = t + "?OverwriteWagerAmtAccepted=true"));
    checkForLite() ? post_to_url(t, i, "post") : (homePage.showOverlay(), pat.post(t, i).done(function(n) {
        $("#confirmOddsChangeDialog").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#confirmOddsChangeDialog").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        $("#modal-container-bet-confirmation").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#modal-container-bet-confirmation").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        if (r && ($("#modal-container-bet-confirmation").modal(), $("#confirmOddsChangeDialog").modal()), homePage.RefreshCashBalance(), homePage.closeOverlay(), homePage.anchorToTop(), $("#footerMobile").is(":visible") && $("#modal-container-bet-confirmation").find(".error-message").length === 0) {
            $("#mobileBetslipCount").html("(0)");
            $("#mobileBetslipCount").length > 0 ? $("#mobileBetslipCount").html("(0)") : $("#betslipCountBadge").length > 0 && $(".betslipCountBadgeCount").html("0");
            $("#modal-container-bet-confirmation").on("hide.bs.modal", function() {
                window.location = "/"
            })
        }
    }))
}

function ValidateWithdraw(n, t, i, r) {
    var u = document.getElementById("Amount").value;
    document.getElementById("SelectedGhanaWithdrawalType").value = r;
    u < n ? (document.getElementById("errorMobile").innerHTML = "<p id='AmountLessThanMinimumWithdrawalAmount'>Amount less than minimum withdrawal amount<\/p>", language.translateAtRuntime(document.getElementById("AmountLessThanMinimumWithdrawalAmount"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawalAmount"
    }), event.preventDefault()) : u > i && (document.getElementById("errorMobile").innerHTML = "<p id='AmountGreaterThanDaily'>Amount is greater than daily remaining enter valid amount <\/p>", language.translateAtRuntime(document.getElementById("AmountGreaterThanDaily"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanDaily"
    }), event.preventDefault())
}

function ValidatePaymentMTNZambia(n, t, i) {
    var u = t,
        e;
    u === 0 && (u = 10);
    var o = i,
        r = document.getElementById("MMerrorMTN"),
        f = document.getElementById(n + "MTNZambiaPaymentRequest_Amount").value;
    return f.match(/^\d+$/) ? parseFloat(f).toPrecision(21) > o ? (r.innerHTML = "This amount is greater than the maximum limit allowed", language.translateAtRuntime(r, "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), !1) : typeof document.getElementById(n + "MTNZambiaPaymentRequest_Amount") != "undefined" ? (u > 0 && f < u && (r.innerHTML = "This amount is below the minimum limit of ZMW" + u + ".", language.translateAtRuntime(r, "ErrorMessages", {
        "data-translate-key": "AmountBelowMinimumLimitOfZMW",
        "data-translate-type": "generic-html",
        "data-translate-value-0": u
    })), !1) : (e = document.getElementById("MMerrorMTN"), e.innerHTML = "Please enter an amount", language.translateAtRuntime(r, "ErrorMessages", {
        "data-translate-key": "EnterAmount"
    }), !1) : (r.innerHTML = "This amount is invalid. Please provide a valid amount", language.translateAtRuntime(r, "ErrorMessages", {
        "data-translate-key": "AmountInvalid"
    }), !1)
}

function InitMTNZambia(n) {
    ajax.post("/account/Init_MTNZambia?PaymentMethod=" + n, $("#" + n + "_paymentInitZambia").serializeArray()).done(function(t) {
        $("#" + n + "MTNZambiaContainer")[0].innerHTML = t
    }).done(function() {
        document.getElementById("frmPayDetails") != null && document.getElementById("frmPayDetails").submit();
        homePage.closeOverlay()
    })
}

function GetInputValueZambia(n, t, i, r) {
    var u = $("#Amount").val();
    r.toString() === "00000000-0000-0000-da7a-000000400039" ? u.indexOf(".") > -1 ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitWholeNumberOnly'>Please enter whole numbers only<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitWholeNumberOnly"), "ErrorMessages", {
        "data-translate-key": "withdrawalLimitWholeNumberOnly"
    }), document.getElementById("Withdraw").disabled = !0, event.preventDefault()) : (document.getElementById("Withdraw").disabled = !1, u > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : u < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : u > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1)) : u > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : u < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : u > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1)
}

function fnAllowNumeric() {
    if ((event.keyCode < 48 || event.keyCode > 57) && event.keyCode !== 8) return event.keyCode = 0, alert("Accept only Integer..!"), !1
}

function GetInputValue(n, t, i) {
    var r = $("#Amount").val(),
        u = /^[0-9.]*$/.test(r);
    if (u) r > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : r < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : r > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : r > remainingBalance ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1);
    else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), e.preventDefault(), !1
}

function GetInputValueNigeria(n, t, i, r, u) {
    var f = $("#Amount").val();
    document.getElementById("SelectedNigeriaWithdrawalType").value = "Bank Account";
    var o = document.getElementById("AccountNumberId"),
        e = document.getElementById("BankId"),
        s = e.options[e.selectedIndex].text;
    f > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : o === "" ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAccountNumber'>Please enter account number<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAccountNumber"), "ErrorMessages", {
        "data-translate-key": "EnterAccountNumber"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : s === "Select bank" ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitSelectBank'>Please select a bank<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitSelectBank"), "ErrorMessages", {
        "data-translate-key": "SelectBank"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : f < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : f > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : f > u ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("WithdrawEFTNigeria").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("WithdrawEFTNigeria").disabled = !1)
}

function GetInputValueNigeriaCardLess(n, t, i, r, u, f) {
    var e = $("#NigeriaCardlessAmount").val(),
        o;
    document.getElementById("SelectedNigeriaWithdrawalType").value = "Cardless";
    o = document.getElementById("NigeriaCardlessAccountNumber");
    e > f ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorDailyLimit'>Daily Limit Exceeded cannot withdraw from account<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorDailyLimit"), "ErrorMessages", {
        "data-translate-key": "LimitExceededCannotWithdraw"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : e > t ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorLimitReminBalanace'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorReminBalanace"), "ErrorMessages", {
        "data-translate-key": "LimitExceededCannotWithdraw"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : o === "" ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorAccountNumber'>Please enter account number<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorAccountNumber"), "ErrorMessages", {
        "data-translate-key": "EnterAccountNumber"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : e < n ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : e > i ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorAmountGreat'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorAmountGreat"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : e > u ? (document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorReminBalance'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorReminBalance"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("WithdrawPaycode").disabled = !0) : (document.getElementById("cardLessError").innerHTML = "<p><\/p>", document.getElementById("WithdrawPaycode").disabled = !1)
}

function GetInputValueGhana(n, t, i, r, u) {
    var f = $("#Amount").val();
    f > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p  id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : f > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f > u ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1)
}

function GetInputValueKenya(n, t, i, r, u) {
    var f = $("#Amount").val();
    f > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : f > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f > u ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1)
}

function GetInputValueSouthAfrica(n, t, i, r, u) {
    var f = $("#Amount").val();
    f > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : f > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater '>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater "), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit "
    }), document.getElementById("Withdraw").disabled = !0) : f > u ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1)
}

function GetInputValueUganda(n, t, i, r, u) {
    var f = $("#Amount").val(),
        o = /^[0-9.]*$/.test(f);
    if (o) f > t ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f < n ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
        "data-translate-key": "AmountLessThanMinimumWithdrawal"
    }), document.getElementById("Withdraw").disabled = !0) : f > i ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanLimit"
    }), document.getElementById("Withdraw").disabled = !0) : f > u ? (document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanRemainingBalance"
    }), document.getElementById("Withdraw").disabled = !0) : (document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>", document.getElementById("Withdraw").disabled = !1);
    else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), e.preventDefault(), !1
}

function SetEFTNigeriaPaymentTrue(n, t, i, r, u, f) {
    var e = $("#Amount").val(),
        h = /^[0-9.]*$/.test(e);
    if (h) {
        document.getElementById("SelectedNigeriaWithdrawalType").value = f;
        var o = document.getElementById("AccountNumberId"),
            s = document.getElementById("BankId"),
            c = s.options[s.selectedIndex].text,
            l = /^[0-9.]*$/.test(o.value);
        if (e > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater '>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (o.value !== "" && l) {
            if (c === "Select bank") return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitSelectBank'>Please select a bank<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitSelectBank"), "ErrorMessages", {
                "data-translate-key": "SelectBank"
            }), n.preventDefault(), !1;
            if (e < t) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
                "data-translate-key": "AmountLessThanMinimumWithdrawal"
            }), n.preventDefault(), !1;
            if (e > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater '>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanLimit"
            }), n.preventDefault(), !1;
            if (e > u) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanRemainingBalance"
            }), n.preventDefault(), !1;
            document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
            document.getElementById("WithdrawEFTNigeria").disabled = !1
        } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Please enter account number<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "EnterAccountNumber"
        }), n.preventDefault(), !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetEFTSouthAfricaPaymentTrue(n, t, i, r, u, f) {
    var e = $("#Amount").val(),
        h = /^[0-9.]*$/.test(e);
    if (h) {
        document.getElementById("SelectedSouthAfricanWithdrawalType").value = f;
        var c = document.getElementById("BankAccountName"),
            s = document.getElementById("BankAccountNumber"),
            o = document.getElementById("BankIdSA"),
            l = o.options[o.selectedIndex].text,
            a = document.getElementById("BankAccountType"),
            v = o.options[a.selectedIndex].text,
            y = document.getElementById("BranchCodeInput"),
            p = /^[0-9.]*$/.test(s.value);
        if (e > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (s.value !== "" && p) {
            if (y.value === "") return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitBranchCode'>Please enter branch code<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitBranchCode"), "ErrorMessages", {
                "data-translate-key": "PleaseEnterBranchCode"
            }), n.preventDefault(), !1;
            if (c.value === "") return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAccountHolder'>Please enter account holder name<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAccountHolder"), "ErrorMessages", {
                "data-translate-key": "PleaseEnterAccountHolderName"
            }), n.preventDefault(), !1;
            if (l === "Select bank") return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitSelectBank'>Please select a bank<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitSelectBank"), "ErrorMessages", {
                "data-translate-key": "SelectBank"
            }), n.preventDefault(), !1;
            if (v === "Select bank") return document.getElementById("withdrawalLimit").innerHTML = "<p id='SelectBankAccountType'>Please select a bank account type<\/p>", language.translateAtRuntime(document.getElementById("SelectBankAccountType"), "ErrorMessages", {
                "data-translate-key": "SelectBankAccountType"
            }), n.preventDefault(), !1;
            if (e < t) return document.getElementById("withdrawalLimit").innerHTML = "<p  id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
                "data-translate-key": "AmountLessThanMinimumWithdrawal"
            }), n.preventDefault(), !1;
            if (e > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanLimit"
            }), n.preventDefault(), !1;
            if (e > u) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
                "data-translate-key": "AmountGreaterThanRemainingBalance"
            }), n.preventDefault(), !1;
            document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
            document.getElementById("withdrawEft").disabled = !1
        } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAccount'>Please enter account number<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAccount"), "ErrorMessages", {
            "data-translate-key": "EnterAccountNumber"
        }), n.preventDefault(), !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetGhanaPaymentTrue(n, t, i, r, u) {
    var f = $("#Amount").val(),
        e = /^[0-9.]*$/.test(f);
    if (e) {
        if (f > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (f < t) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
            "data-translate-key": "AmountLessThanMinimumWithdrawal"
        }), n.preventDefault(), !1;
        if (f > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanLimit"
        }), n.preventDefault(), !1;
        if (f > u) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanRemainingBalance"
        }), n.preventDefault(), !1;
        document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
        document.getElementById("Withdraw").disabled = !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetKenyaPaymentTrue(n, t, i, r, u) {
    var f = $("#Amount").val(),
        e = /^[0-9.]*$/.test(f);
    if (e) {
        if (f > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (f < t) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
            "data-translate-key": "AmountLessThanMinimumWithdrawal"
        }), n.preventDefault(), !1;
        if (f > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanLimit"
        }), n.preventDefault(), !1;
        if (f > u) return document.getElementById("withdrawalLimit").innerHTML = "<pid='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanRemainingBalance"
        }), n.preventDefault(), !1;
        document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
        document.getElementById("Withdraw").disabled = !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetZambiaPaymentTrue(n, t, i, r, u) {
    var f = $("#Amount").val(),
        e = /^[0-9.]*$/.test(f);
    if (e) {
        if (f > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (f < t) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
            "data-translate-key": "AmountLessThanMinimumWithdrawal"
        }), n.preventDefault(), !1;
        if (f > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanLimit"
        }), n.preventDefault(), !1;
        if (f > u) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanRemainingBalance"
        }), n.preventDefault(), !1;
        document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
        document.getElementById("Withdraw").disabled = !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetUgandaPaymentTrue(n, t, i, r, u) {
    var f = $("#Amount").val(),
        e = /^[0-9.]*$/.test(f);
    if (e) {
        if (f > i) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountGreater"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
        }), n.preventDefault(), !1;
        if (f < t) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
            "data-translate-key": "AmountLessThanMinimumWithdrawal"
        }), n.preventDefault(), !1;
        if (f > r) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanLimit"
        }), n.preventDefault(), !1;
        if (f > u) return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanRemainingBalance"
        }), n.preventDefault(), !1;
        document.getElementById("withdrawalLimit").innerHTML = "<p><\/p>";
        document.getElementById("Withdraw").disabled = !1
    } else return document.getElementById("withdrawalLimit").innerHTML = "<p id='withdrawalLimitVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function SetEFTCardlessNigeriaPaymentTrue(n, t, i, r, u, f, e) {
    var o = $("#NigeriaCardlessAmount").val(),
        h = /^[0-9.]*$/.test(o),
        s;
    if (h) s = "", o.length.toString() === "4" ? (s = o.slice(1, o.length), /^0*$/.test(s) ? CheckNigeriaPayCode(o, n, t, i, r, u, f, e) : ($("#cardLessError").html("<p id='EnterWholeNumbersOnly'>Please enter whole numbers only like: 1000, 2000, 12000<\/p>"), language.translateAtRuntime($("#EnterWholeNumbersOnly"), "ErrorMessages", {
        "data-translate-key": "EnterWholeNumbersOnly"
    }), $("#WithdrawPaycode").prop("disabled", !0), n.preventDefault())) : o.length.toString() === "5" && (s = o.slice(2, o.length), /^0*$/.test(s) ? CheckNigeriaPayCode(o, n, t, i, r, u, f, e) : ($("#cardLessError").html("<p id='EnterWholeNumbersOnly'>Please enter whole numbers only like: 1000, 2000, 12000<\/p>"), language.translateAtRuntime($("#EnterWholeNumbersOnly"), "ErrorMessages", {
        "data-translate-key": "EnterWholeNumbersOnly"
    }), $("#WithdrawPaycode").prop("disabled", !0), n.preventDefault()));
    else return document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorVaildAmount'>Please enter a valid amount<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorVaildAmount"), "ErrorMessages", {
        "data-translate-key": "EnterAValidAmount"
    }), n.preventDefault(), !1
}

function CheckNigeriaPayCode(n, t, i, r, u, f, e, o) {
    var s, h, c;
    if (document.getElementById("SelectedNigeriaWithdrawalType").value = o, s = document.getElementById("NigeriaCardlessAccountNumber"), h = /^[0-9.]*$/.test(s.value), i === "0000" && (document.getElementById("cardLessError").innerHTML = "<p>Daily limit exceeded, can't withdraw from this account<\/p>", c = document.getElementById("WithdrawPaycode"), c.disabled = !0, t.preventDefault()), n > u) return document.getElementById("cardLessError").innerHTML = "<p id='cardLessErrorLimitAmountGreater'>Amount greater than allowed daily limit<\/p>", language.translateAtRuntime(document.getElementById("cardLessErrorLimitAmountGreater"), "ErrorMessages", {
        "data-translate-key": "AmountGreaterThanAllowedDailyLimit"
    }), t.preventDefault(), !1;
    if (s.value !== "" && h) {
        if (n < r) return document.getElementById("cardLessError").innerHTML = "<p id='withdrawalLimitAmountLess'>Amount less than minimum daily withdrawal<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAmountLess"), "ErrorMessages", {
            "data-translate-key": "AmountLessThanMinimumWithdrawal"
        }), t.preventDefault(), !1;
        if (n > f) return document.getElementById("cardLessError").innerHTML = "<p id='withdrawalLimitReminLimit'>Amount Greater than remaining limit<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminLimit"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanLimit"
        }), t.preventDefault(), !1;
        if (n > e) return document.getElementById("cardLessError").innerHTML = "<p id='withdrawalLimitReminBalanace'>Amount Greater than remaining balance<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitReminBalanace"), "ErrorMessages", {
            "data-translate-key": "AmountGreaterThanRemainingBalance"
        }), t.preventDefault(), !1;
        document.getElementById("cardLessError").innerHTML = "<p><\/p>";
        document.getElementById("WithdrawPaycode").disabled = !1
    } else return document.getElementById("cardLessError").innerHTML = "<p id='withdrawalLimitAccount'>Please enter account number<\/p>", language.translateAtRuntime(document.getElementById("withdrawalLimitAccount"), "ErrorMessages", {
        "data-translate-key": "EnterAccountNumber"
    }), t.preventDefault(), !1
}

function isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n)
}

function PrepopulateBranchCodeNg(n) {
    document.getElementById("BranchCode").value = n.value
}

function PrepopulateBranchCode(n) {
    typeof n != "undefined" && ($("#BranchCodeInput").prop("readOnly", !0), document.getElementById("BranchCodeInput").value = n)
}

function PrepopulateBankAccount() {
    var n = $("#bankAccountNumberdId option:selected").val();
    n === "Select New Account" || n === "" ? (document.getElementById("accountNumberSectiontId").style.display = "block", document.getElementById("AccountNumberId").value = "", account.ResetListOfBanks()) : (document.getElementById("accountNumberSectiontId").style.display = "none", account.FilterBankByAccount(n), document.getElementById("AccountNumberId").value = n)
}

function iOSVersion() {
    var i = navigator.platform,
        t, n;
    return /iP(hone|od|ad)/.test(i) ? (t = navigator.appVersion, n = t.match(/OS (\d+)_(\d+)_?(\d+)?/), [parseInt(n[1], 10), parseInt(n[2], 10), parseInt(n[3] || 0, 10)]) : []
}

function calculateHoldingTax(n, t, i, r, u, f, e, o) {
    var h, c, s, l;
    if (n = parseFloat(n), t = parseInt(t), r = r === null ? parseFloat(GetBetslipOption("TotalPriceDecimal")) : parseFloat(r), i = i === null ? parseFloat(document.getElementById("wagerAmount").value) : parseFloat(i), amount = parseFloat(parseFloat(i) * parseFloat(r)), GetBetslipOption("IsFreeBet") ? (h = GetBetslipOption("IsSingleBet") ? parseFloat(GetBetslipOption("MaxPayoutSingle")) : parseFloat(GetBetslipOption("FreeBetMaxPayoutMultiple")), amount > h && (amount = h)) : (c = o == null ? GetBetslipOption("IsSingleBet") ? parseFloat(GetBetslipOption("MaxPayoutSingle")) : parseFloat(GetBetslipOption("MaxPayoutMultiple")) : o, amount > c && (amount = c)), u = parseFloat(u), typeof f == "string" && (f = f.toLowerCase === "true"), !checkForLite() && n > 0) {
        if (s = 0, t > 0) switch (t) {
            case TaxCalculation.Payout:
                s = amount;
                break;
            case TaxCalculation.Winnings:
                s = amount - i
        }
        return s > 0 && f && (s += u), l = s * (n / 100), l.toFixed(2) <= 0 ? 0 : l.toFixed(2)
    }
    return 0
}

function taxCalc(n, t) {
    var i = 0;
    if (enableTax) {
        if (configuredTaxCalculation > 0) switch (configuredTaxCalculation) {
            case TaxCalculation.Payout:
                i = n;
                break;
            case TaxCalculation.Winnings:
                i = n - t
        }
    } else i = n;
    return i
}

function winningsTax() {
    var i;
    if (enableTax) {
        if (GetBetslipOption("IsSingleBet") || (checkForLite() || (document.getElementById("divWinningsTax").style.display = ""), document.getElementById("divPotentialReturnWithStretch") !== null && (document.getElementById("divPotentialReturnWithStretch").style.display = "")), document.getElementById("betslip-totalpricedecimal").innerHTML === "0.00") checkForLite() || $("#HoldingTaxAmount, #potentialReturnWithStretchVal").val("0.00");
        else {
            var r = document.getElementById("wagerAmount").value,
                u = parseFloat(GetBetslipOption("TotalPriceDecimal")),
                t = IsStretchEnabled() ? parseFloat(document.getElementById("boostedAmount").value) : 0,
                n = calculateHoldingTax(taxPercentage, configuredTaxCalculation, r, u, t, stretchTaxable, GetBetslipOption("InitialStake"));
            document.getElementById("HoldingTaxAmount") !== null && (GetBetslipOption("IsSportBonusBet") ? (document.getElementById("HoldingTaxAmount").value = "0.00", n = 0) : document.getElementById("HoldingTaxAmount").value = parseFloat(n).toFixed(2));
            document.getElementById("potentialReturnWithStretchVal").innerText = parseFloat(parseFloat(document.getElementById("potentialReturn").value) + parseFloat(t) - parseFloat(n)).toFixed(2);
            checkForLite() || isLessBetslipValuesEnabled && (i = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2), t > 0 ? (showAllLessPotentialReturn("winboost"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = isNaN(i) ? precise_round(parseFloat(document.getElementById("potentialReturn").value) - parseFloat(n), 2).toFixed(2) : precise_round(parseFloat(i) - parseFloat(n), 2).toFixed(2)) : hideAllLessPotentialReturn("winboost"), isLessPotentialReturnValid() ? (showAllLessPotentialReturn("boostedOdd"), document.getElementById("lessPotentialReturnWithStretchVal").textContent = precise_round(parseFloat(i) - parseFloat(n), 2).toFixed(2)) : hideAllLessPotentialReturn("boostedOdd"), t <= 0 && !isLessPotentialReturnValid() && hideAllLessPotentialReturn());
            document.getElementById("figure").innerText = parseFloat(document.getElementById("potentialReturnWithStretchVal").innerText).toFixed(2)
        }
        checkForLite() || (UpdateVisualElementsOnBetslip(), miniBetslip())
    }
}

function UpdateWageredStake(n) {
    setTimeout(function() {
        var i = document.getElementById("stakeBeforeWagerTax").value,
            t = document.getElementById("wagerAmount"),
            r;
        GetBetslipOption("IsSingleBet") === !0 && (n === null || n === undefined || document.getElementById("stakeBeforeWagerTax" + n).disabled || (i = document.getElementById("stakeBeforeWagerTax" + n).value, t = document.getElementById("wagerAmount" + n)));
        r = precise_round(i * wagerTaxPercentage / (100 + wagerTaxPercentage), 2).toFixed(2);
        GetBetslipOption("IsSingleBet") || (document.getElementById("wagerTaxAmount").innerHTML = r, SetBetslipOption("InitialStake", document.getElementById("stakeBeforeWagerTax").value));
        GetBetslipOption("IsFreeBet") ? document.getElementById("wagerTaxAmount").innerHTML = parseFloat("0.00").toFixed(2) : t.value = parseFloat(precise_round(i - r, 2)).toFixed(2);
        GetBetslipOption("IsSingleBet") === !0 && n !== null ? UpdatePotentialSingleReturn(n) : GetBetslipOption("IsFreeBet") || UpdatePotentialReturn();
        t.style.width = t.value.length * 8 + "px"
    }, 100)
}

function checkWager(n) {
    var i, t;
    n === null || n === undefined ? document.getElementById("stakeBeforeWagerTax") !== null && typeof document.getElementById("stakeBeforeWagerTax") != "undefined" ? (document.getElementById("stakeBeforeWagerTax").value === "" && (i = GetBetslipOption("MinBetAmount"), GetBetslipOption("InitialStake") !== null && typeof GetBetslipOption("InitialStake") != "undefined" && GetBetslipOption("InitialStake") !== "" && (i = GetBetslipOption("InitialStake")), document.getElementById("stakeBeforeWagerTax").value = parseFloat(i).toFixed(2)), t = GetBetslipOption("MinBetAmount"), document.getElementById("stakeBeforeWagerTax").value = parseFloat(document.getElementById("stakeBeforeWagerTax").value).toFixed(2), UpdateWageredStake()) : isNaN(parseFloat(t)) || (SetBetslipOption("WagerAmount", t), document.getElementById("stakeBeforeWagerTax").value = parseFloat(t).toFixed(2)) : document.getElementById("stakeBeforeWagerTax" + n).value = parseFloat(document.getElementById("stakeBeforeWagerTax" + n).value).toFixed(2)
}

function isEmpty(n) {
    return !$.trim(n.html())
}

function IDTypeChanged(n) {
    var t;
    enableMultiStepRegistration && enableCPBNameMultiStepRegistration && (isMobileScreen() ? $("#nxtBtn").css({
        "margin-top": "10px",
        "margin-bottom": "0px",
        "min-width": "100px"
    }) : $("#nxtBtn").css({
        "margin-top": "10px",
        "margin-bottom": "15px",
        "min-width": "100px"
    }), clonedIdDisplay === null && CreateDisplayIdTemplateField(), clonedIdDisplay !== null && ($(clonedIdDisplay).val($("#IDNumber_tmpl").val()), $(clonedIdTypeDisplay).val($("#IDType_tmpl").val())), $(n).val() === "South African ID" ? ($(".DOBDropDown").rules("remove", "totalCheck"), $("#FirstName_tmpl").prop("readonly", !0), $("#LastName_tmpl").prop("readonly", !0), (isMultiNameSelectCallSuccessfull === !1 || $("IDNumber_tmpl").val() !== lastValidatedIdNumber) && $("#nxtBtn").prop("disabled", !0), $("#CPBName_tmpl").show(), $(".date-of-birth").parent().hide(), $("#DateOfBirth_tmpl").parent().hide(), TemplateFieldInsertAfterElement($("#FirstName_tmpl"), $("#Password_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#FirstName_tmpl-error"), $("#FirstName_tmpl").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl"), $("#FirstName_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl-error"), $("#LastName_tmpl").parent().parent()), t = $("#CPBName_tmpl ~ div input").attr("name"), $(`[name='${t}']`).each(function() {
        $(this).parent().show()
    }), $("#IDNumber_tmpl").val() !== "" && ValidateIdNumber($("#IDNumber_tmpl").val())) : $(n).val() === "Passport" && ($.validator.addClassRules({
        DOBDropDown: {
            totalCheck: !0
        }
    }), $("#nxtBtn").prop("disabled", !1), $("#FirstName_tmpl").prop("readonly", !1), $("#LastName_tmpl").prop("readonly", !1), $("#CPBName_tmpl").hide(), $(".date-of-birth").parent().show(), $("#DateOfBirth_tmpl").parent().show(), TemplateFieldInsertAfterElement($("#FirstName_tmpl"), clonedIdDisplay.parent()), TemplateFieldInsertAfterElement($("#FirstName_tmpl-error"), $("#FirstName_tmpl").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl"), $("#FirstName_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl-error"), $("#LastName_tmpl").parent().parent()), TemplateFieldInsertAfterElement($(".date-of-birth"), $("#LastName_tmpl-error").parent().parent()), t = $("#CPBName_tmpl ~ div input").attr("name"), $(clonedIdDisplay).val($("#IDNumber_tmpl").val()), $(`[name='${t}']`).each(function() {
        $(this).parent().hide()
    })));
    homePage.changeItemPlaceHolder(n, "#IDNumber_tmpl", "@Request.Browser.IsMobileDevice");
    $(".DOBDropDown").css("pointer-events", "auto");
    $(n).val() == "South African ID" ? ($("#IDNumber_tmpl").rules("add", {
        ValidSaIdNumber: !0
    }), $("#IDNumber_tmpl").rules("remove", "ValidIdentityType")) : ($("#IDNumber_tmpl").rules("add", {
        ValidIdentityType: !0
    }), $("#IDNumber_tmpl").rules("remove", "ValidSaIdNumber"))
}

function AppendTemplateFieldToElement(n, t) {
    var i = $(n).parent().parent(),
        r = $(i).next();
    $(i).appendTo($(t));
    $(r).appendTo($(i))
}

function TemplateFieldInsertAfterElement(n, t) {
    var i = $(n).parent().parent();
    $(i).insertAfter($(t))
}

function AssignOptions() {}

function ValidIdentityType(n, t) {
    var f, i, r, u;
    return $("#IDType_tmpl").find(":selected").length > 0 && (f = $("#IDType_tmpl").find(":selected")[0], i = f.attributes.regexpression, i && i.value !== "" && IsValidRegEx(i.value) && (r = new RegExp(i.value), r)) ? (u = r.test(t), u || console.log("Valid Regex {" + i.value + "}, invalid input."), u) : !0
}

function IsValidRegEx(n) {
    var t = !0;
    try {
        new RegExp(n)
    } catch (i) {
        t = !1;
        console.log("Invalid regex: " + n)
    }
    return t
}

function hideIdValMessage(n) {
    let t = $('[data-translate-key="PleaseEnterAValidIDOrPassportNumber"]');
    n.length > 0 && (t.hide(), t.next().hide())
}

function checkLeapYear(n) {
    return 0 == n % 4 && 0 != n % 100 || 0 == n % 400 ? !0 : !1
}

function ValidateIdNumber(n) {
    var t, p, e, o, w, b, s, l, a, i;
    if (enableMultiStepRegistration && enableCPBNameMultiStepRegistration && ($("#IDType_tmpl").val() === "South African ID" ? ($("#FirstName_tmpl").prop("readonly", !0), $("#LastName_tmpl").prop("readonly", !0), isMultiNameSelectCallSuccessfull === !1 && $("#nxtBtn").prop("disabled", !0), $("#CPBName_tmpl").show(), TemplateFieldInsertAfterElement($("#FirstName_tmpl"), $("#Password_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#FirstName_tmpl-error"), $("#FirstName_tmpl").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl"), $("#FirstName_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl-error"), $("#LastName_tmpl").parent().parent()), i = $("#CPBName_tmpl ~ div input").attr("name"), $(`[name='${i}']`).change(function() {
            $(this).parent().show()
        })) : $("#IDType_tmpl").val() === "Passport" && ($("#nxtBtn").prop("disabled", !1), $("#FirstName_tmpl").prop("readonly", !1), $("#LastName_tmpl").prop("readonly", !1), $("#CPBName_tmpl").hide(), TemplateFieldInsertAfterElement($("#FirstName_tmpl"), clonedIdDisplay.parent()), TemplateFieldInsertAfterElement($("#FirstName_tmpl-error"), $("#FirstName_tmpl").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl"), $("#FirstName_tmpl-error").parent().parent()), TemplateFieldInsertAfterElement($("#LastName_tmpl-error"), $("#LastName_tmpl").parent().parent()), i = $("#CPBName_tmpl ~ div input").attr("name"), $(`[name='${i}']`).change(function() {
            $(this).parent().hide()
        }))), t = !0, n.length !== 13 || !isNumber(n)) return $("#IDType_tmpl").val() === "South African ID" ? $("#IDNumber_tmpl").rules("add", {
        ValidSaIdNumber: !0
    }) : $("#IDNumber_tmpl").rules("remove", "ValidSaIdNumber"), t = !1, enableMultiStepRegistration && enableCPBNameMultiStepRegistration && $("#nxtBtn").prop("disabled", !0), t;
    e = "";
    n.substring(0, 1) == "0" ? (p = n.substring(0, 2), o = (new Date).getFullYear().toString(), e = o.substring(0, 2) + p) : e = n.substring(0, 2);
    var r = new Date(e, n.substring(2, 4) - 1, n.substring(4, 6)),
        h = r.getDate(),
        c = r.getMonth(),
        f = r.getFullYear();
    if (!(f.toString().substring(2, 4) == n.substring(0, 2) && c == n.substring(2, 4) - 1 && h == n.substring(4, 6))) return t = !1, enableMultiStepRegistration && enableCPBNameMultiStepRegistration && $("#nxtBtn").prop("disabled", !0), t;
    if (o = (new Date).getFullYear(), w = o - r.getFullYear(), parseInt(w) > 100 && (f = f + 100, r = new Date(f, c, h)), b = dateDiffInYears(r), b < 18) return enableMultiStepRegistration && enableCPBNameMultiStepRegistration && $("#nxtBtn").prop("disabled", !0), !1;
    var k = $(".DOBDropDownDay"),
        l = $(".DOBDropDownMonth"),
        a = $(".DOBDropDownYear");
    k.length !== 0 && l.length !== 0 && a.length !== 0 && ($(k[0]).val(h), $(l[0]).val(c + 1), $(a[0]).val(f));
    var d = n.substring(6, 10),
        g = parseInt(d) < 5e3 ? "Female" : "Male",
        nt = parseInt(n.substring(10, 11)) === 0 ? "Yes" : "No",
        u = 0,
        v = 0,
        y = 1;
    for (s = 0; s < 13; ++s) u = parseInt(n.charAt(s)) * y, u > 9 && (u = parseInt(u.toString().charAt(0)) + parseInt(u.toString().charAt(1))), v = v + u, y = y % 2 == 0 ? 1 : 2;
    if (v % 10 != 0 && (t = !1), !t || enableMultiStepRegistration || enableCPBNameMultiStepRegistration || ($(".DOBDropDown").css("pointer-events", "none"), l = $(".DOBDropDownMonth"), a = $(".DOBDropDownYear"), setTimeout(function() {
            $(".DOBDropDownDay")[0].blur();
            $(".DOBDropDownMonth")[0].blur();
            $(".DOBDropDownYear")[0].blur()
        }, 1)), enableMultiStepRegistration && enableCPBNameMultiStepRegistration) {
        if (t) {
            if (lastValidatedIdNumber != n) {
                lastValidatedIdNumber = n;
                isMultiNameSelectCallSuccessfull = !1;
                let t = document.getElementById("registerForm"),
                    i = new FormData(t);
                $.ajax({
                    url: "/Account/GetNamesToVerifyModal",
                    type: "POST",
                    processData: !1,
                    contentType: !1,
                    dataType: "html",
                    data: i,
                    complete: function(n) {
                        var t = $("#alreadyHaveAnAccount").clone(),
                            i = $("#ClickHereToLogin").clone();
                        location.hash.includes("TemplateGroup") && (location.hash = "");
                        $("#desktopReg").html(n.responseText);
                        $(".DodgyHackForSignup").hide();
                        $(t).insertAfter($("#registerForm"));
                        $(i).insertAfter($(t));
                        $("#bckBtn").insertBefore($("#nxtBtn"));
                        isMultiNameSelectCallSuccessfull = !0;
                        $("#nxtBtn").prop("disabled", !1);
                        $(clonedIdTypeDisplay).insertBefore($("#CPBName_tmpl").parent());
                        $(clonedIdDisplay).insertAfter($(clonedIdTypeDisplay));
                        $(clonedIdDisplay).val($("#IDNumber_tmpl").val());
                        setTimeout(function() {
                            var n = $("#CPBName_tmpl ~ div input")[0].value,
                                t = n.trimEnd().lastIndexOf(" ");
                            $("#FirstName_tmpl").val(n.substring(0, t));
                            $("#LastName_tmpl").val(n.substring(t + 1, n.length))
                        }, 750)
                    }
                })
            }
            lastValidatedIdNumber === n && isMultiNameSelectCallSuccessfull && $("#nxtBtn").prop("disabled", !1);
            i = $("#CPBName_tmpl ~ div input").attr("name");
            $(`[name='${i}']`).change(function() {
                var n = this.value.trimEnd().lastIndexOf(" ");
                $("#FirstName_tmpl").val(this.value.substring(0, n));
                $("#LastName_tmpl").val(this.value.substring(n + 1, this.value.length))
            })
        }
        t || $("#nxtBtn").prop("disabled", !0)
    }
    return t
}

function redirectToEventMoreBets(n) {
    var t = window.location.origin;
    homePage.showOverlay();
    pat.get("/Event/GetMoreBetsLinkForEvent", {
        eventId: n
    }, {
        dataType: "json"
    }).done(function(n) {
        if (n && n.Success && n.Url.length > 0) {
            var i = t + n.Url;
            window.location = i
        }
    })
}

function dateDiffInYears(n) {
    var t = new Date,
        f = t.getFullYear(),
        r = t.getMonth(),
        e = t.getDate(),
        o = n.getFullYear(),
        u = n.getMonth(),
        s = n.getDate(),
        i = f - o;
    return u > r ? i-- : u === r && s > e && i--, i
}

function AdvancedFilterUpdate(n, t) {
    for (var u = [], r = document.querySelectorAll("input[type='checkbox']"), i = 0; i < r.length; i++) r[i].checked === !0 && u.push(r[i].value);
    filterLeaguesLite(u, n, "/Home", t)
}

function toggleMultiSelectorOutcome(n, t, i = null) {
    var r, h, u, f, s;
    if (n == null && t == null && dynamicLIPBetslipCalculationEnabled) {
        if (r = JSON.parse(GetBetslip()), i != undefined && i != null && i.length > 0) {
            for (h = 0; h < i.length; h++) u = r.findIndex(function(n) {
                return n.OutcomeId === i[h]
            }), u != undefined && u != null && (r[u] != undefined && r[u] != null && tempLockedOutcomes.length > 0 && tempLockedOutcomes.includes(r[u].OutcomeId) ? document.getElementById(`SelectedOutcomeForBetslip-${r[u].OutcomeId}`).style.color != "rgb(201, 201, 201)" ? (r[u].Ticked = !0, $("#SelectedCheckBoxForBetslip-" + r[u].OutcomeId).prop("checked", !0), tempLockedOutcomes.pop(r[u].OutcomeId)) : (r[u].Ticked = !1, $("#SelectedCheckBoxForBetslip-" + r[u].OutcomeId).prop("checked", !1)) : r[u] != undefined && r[u] != null && (r[u].Ticked = !1, $("#SelectedCheckBoxForBetslip-" + r[u].OutcomeId).prop("checked", !1)));
            f = r.filter(function(n) {
                return n.Ticked == !0
            });
            incrementalPayoutLimitsEnabled && IncrementalPayoutLimits.updateMaxPayoutAmount(f.length);
            var c = _.reduce(_.pluck(_.where(f, {
                    IsTrendingOutcome: !0
                }), "PriceDecimal"), function(n, t) {
                    return parseFloat(n * t).toFixed(2)
                }) * .97,
                o = _.reduce(_.pluck(_.where(f, {
                    IsTrendingOutcome: !1
                }), "PriceDecimal"), function(n, t) {
                    return parseFloat(n * t).toFixed(2)
                }),
                l = o === undefined || o === null ? c : c * o;
            SetBetslipOption("TotalLessPriceDecimal", l === undefined ? 0 : l);
            s = _.reduce(_.pluck(f, "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            });
            SetBetslipOption("TotalPriceDecimal", s === undefined ? 0 : s);
            y || UpdatePotentialReturn();
            document.getElementById("BetSingleBet" + t).checked && mybetslip.chooseMe(document.getElementById("bsCheckbox" + t));
            document.getElementById("BetSportBonusSingleBet" + t) != undefined && document.getElementById("BetSportBonusSingleBet" + t) != null && document.getElementById("BetSportBonusSingleBet" + t).checked && mybetslip.chooseMe(document.getElementById("bsSportBonusCheckbox" + t));
            SetBetslip(r);
            updateBetslipCounts(r);
            checkMaxSelectedReached();
            disableBetting();
            checkForSportBonus(r);
            checkForConflicts(r);
            $("#chkSelectAll").prop("checked", $(".multiselect-cb input:checkbox:checked").length === r.length);
            SetBookingCode("")
        }
    } else {
        n.checked || $("#conflicted-" + t).removeClass("conflicted");
        var e = JSON.parse(GetBetslip()),
            v = e.findIndex(function(n) {
                return n.OutcomeId === t
            }),
            a = $(".multiselect-cb input:checkbox:checked").length > parseInt(maxBetsPerBetslips),
            y = GetBetslipOption("IsSingleBet") === !0;
        e[v].Ticked = a ? !1 : n.checked;
        e[v].AllowStretch = a ? !1 : n.checked;
        f = e.filter(function(n) {
            return n.Ticked == !0
        });
        incrementalPayoutLimitsEnabled && IncrementalPayoutLimits.updateMaxPayoutAmount(f.length);
        var c = _.reduce(_.pluck(_.where(f, {
                IsTrendingOutcome: !0
            }), "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            }) * .97,
            o = _.reduce(_.pluck(_.where(f, {
                IsTrendingOutcome: !1
            }), "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            }),
            l = o === undefined || o === null ? c : c * o;
        SetBetslipOption("TotalLessPriceDecimal", l === undefined ? 0 : l);
        s = _.reduce(_.pluck(f, "PriceDecimal"), function(n, t) {
            return parseFloat(n * t).toFixed(2)
        });
        SetBetslipOption("TotalPriceDecimal", s === undefined ? 0 : s);
        y || UpdatePotentialReturn();
        document.getElementById("BetSingleBet" + t).checked && mybetslip.chooseMe(document.getElementById("bsCheckbox" + t));
        document.getElementById("BetSportBonusSingleBet" + t) != undefined && document.getElementById("BetSportBonusSingleBet" + t) != null && document.getElementById("BetSportBonusSingleBet" + t).checked && mybetslip.chooseMe(document.getElementById("bsSportBonusCheckbox" + t));
        SetBetslip(e);
        updateBetslipCounts(e);
        checkMaxSelectedReached();
        disableBetting();
        checkForSportBonus(e);
        checkForConflicts(e);
        a && $("#SelectedCheckBoxForBetslip-" + t).prop("checked", !1);
        $("#chkSelectAll").prop("checked", $(".multiselect-cb input:checkbox:checked").length === e.length);
        SetBookingCode("")
    }
}

function redirectToEventMoreBets(n) {
    var t = window.location.origin;
    homePage.showOverlay();
    pat.get("/Event/GetMoreBetsLinkForEvent", {
        eventId: n
    }, {
        dataType: "json"
    }).done(function(n) {
        if (n && n.Success && n.Url.length > 0) {
            var i = t + n.Url;
            window.location = i
        }
    })
}

function updateBetslipCounts(n) {
    var t = n.filter(function(n) {
        return n.Ticked == !0
    }).length;
    document.getElementById("sigleBetsCount").innerText = betslipMultiSelectorEnabled ? t : "";
    document.getElementById("multipleBetsCount").innerText = betslipMultiSelectorEnabled ? t : ""
}

function checkForConflicts(n) {
    var y = GetBetslipOption("IsSingleBet") === !0,
        i, a, e, c, v, u;
    if (!y) {
        var p = _.groupBy(n, "EventId"),
            r = !1,
            o = !1,
            t = !1,
            w = n.filter(function(n) {
                return n.Ticked == !0
            }),
            l = _.reduce(_.pluck(w, "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            });
        if (SetBetslipOption("TotalPriceDecimal", l === undefined ? 0 : l), UpdatePotentialReturn(), _.each(p, function(n) {
                var u = n.filter(function(n) {
                        return n.Ticked == !0
                    }).length,
                    i;
                for (t = t ? t : u > 0, i = 0; i < n.length; i++) n.length > 1 ? u > 1 ? n[i].Ticked ? ($("#conflicted-" + n[i].OutcomeId).addClass("conflicted"), r = !0) : $("#conflicted-" + n[i].OutcomeId).removeClass("conflicted") : $("#conflicted-" + n[i].OutcomeId).removeClass("conflicted") : $("#conflicted-" + n[i].OutcomeId).removeClass("conflicted")
            }), outrightRelatedContingenciesEnabled) {
            var s = _.where(n, {
                    FeedDataTypeId: "00000000-0000-0000-da7a-000000580006"
                }),
                h = _.where(n, {
                    FeedDataTypeId: "00000000-0000-0000-da7a-000000580005"
                }),
                f = [];
            if (s.length > 0)
                for (i = 0; i < s.length; i++) f.push(s[i]);
            if (h.length > 0)
                for (i = 0; i < h.length; i++) f.push(h[i]);
            f = _.reject(f, function(n) {
                return n.Sport == "Golf"
            });
            a = _.groupBy(f, "LeagueId");
            _.each(a, function(n) {
                var r = n.filter(function(n) {
                        return n.Ticked == !0
                    }).length,
                    i;
                for (t = t ? t : r > 0, i = 0; i < n.length; i++) n.length > 1 && r > 1 && n[i].Ticked && (o = !0, $("#conflicted-" + n[i].OutcomeId).addClass("conflicted"))
            })
        }
        e = n.filter(function(n) {
            return n.IsGroupHeader && n.Ticked
        });
        e.length > 0 && (c = n.filter(function(n) {
            return !n.IsGroupHeader && n.Ticked
        }), v = c.length > 0 && e.length > 0 || e.length > 1, v && (_.each(e, function(n) {
            $("#conflicted-" + n.OutcomeId).addClass("conflicted")
        }), _.each(c, function(n) {
            $("#conflicted-" + n.OutcomeId).addClass("conflicted")
        }), r = !0));
        $(".liveoutrighthead").length > 0 && (u = n.filter(function(n) {
            return n.Ticked
        }), u.length > 1 ? $(".liveoutrighthead").each(function() {
            var n = 0,
                t = $(this).siblings(".sto-container")[0],
                i;
            t != null && (i = $(t).find("button"), _.each(i, function(t) {
                _.each(u, function(i) {
                    i.OutcomeId == $(t).attr("id") && n++
                })
            }));
            n > 1 ? (_.each(u, function(n) {
                $("#conflicted-" + n.OutcomeId).addClass("conflicted")
            }), r = !0) : _.each(u, function(n) {
                $("#conflicted-" + n.OutcomeId).removeClass("conflicted")
            })
        }) : _.each(u, function(n) {
            $("#conflicted-" + n.OutcomeId).removeClass("conflicted")
        }));
        r || o || !t ? (r || o ? $(".alert-conflict").removeClass("hidden") : $(".alert-conflict").addClass("hidden"), (r || o) && typeof $(".potReturn") != null || !t && typeof $(".potReturn") != null ? $(".potReturn").hide() : $(".potReturn").show(), enableTax && !t && $("#HoldingTaxAmount, #potentialReturnWithStretchVal").text("0.00"), isMiniBetslipConflicting = !0) : ($(".alert-conflict").addClass("hidden"), isMiniBetslipConflicting = !1);
        disableBetting();
        checkMaxSelectedReached();
        miniBetslip()
    }
}

function checkMaxSelectedReached() {
    try {
        if (!checkForLite() && betslipMultiSelectorEnabled == !0) {
            var n = $(".multiselect-cb input:checkbox:checked").length;
            if (n >= parseInt(maxBetsPerBetslips)) return n > parseInt(maxBetsPerBetslips) && ($("#betslip-single-multi-error").show(), $("#betslip-single-multi-error").text("Maximum selectable outcomes reached, please tick outcomes you wish to bet on.")), !0;
            if (n <= parseInt(maxBetsPerBetslips) && $("#betslip-totalpricedecimal").text() !== "0.00") return $("#betslip-single-multi-error").hide(), !1;
            disableBetting()
        }
        return !1
    } catch (t) {}
}

function tickAllOutcomes(n) {
    var t = JSON.parse(GetBetslip());
    if (t.length > 0) {
        var i = parseInt(maxBetsPerBetslips),
            u = GetBetslipOption("IsSingleBet") === !0,
            f = t.filter(function(n) {
                return n.Ticked == !0
            }),
            r = _.reduce(_.pluck(f, "PriceDecimal"), function(n, t) {
                return parseFloat(n * t).toFixed(2)
            });
        n.checked ? t.length > i ? (handleMsCheckBoxForBetslip(t, i, t.length, !1), handleMsCheckBoxForBetslip(t, 0, i, !0)) : handleMsCheckBoxForBetslip(t, 0, t.length, !0) : handleMsCheckBoxForBetslip(t, 0, t.length, !1);
        SetBetslipOption("TotalPriceDecimal", r === undefined ? 0 : r);
        u || UpdatePotentialReturn();
        SetBetslip(t);
        updateBetslipCounts(t);
        checkForSportBonus(t);
        checkForConflicts(t);
        disableBetting();
        SetBookingCode("")
    }
}

function handleMsCheckBoxForBetslip(n, t, i, r) {
    for (var u = t; u < i; u++) n[u].Ticked = r, n[u].AllowStretch = r, $("#SelectedCheckBoxForBetslip-" + n[u].OutcomeId).prop("checked", r)
}

function disableBetting() {
    var n = JSON.parse(GetBetslip());
    if (n.length !== null && typeof n.length != "undefined" && n.length > 0) {
        var i = parseInt(maxBetsPerBetslips),
            t = n.filter(function(n) {
                return n.Ticked === !0
            }),
            r = $(".fa-exclamation-circle.conflicted").length > 0,
            u = t.length > 0,
            f = t.length > i;
        r || !u || f ? ($("#placeCashBet, #placeFreeBet").prop("disabled", !0).addClass("btn-bettingmatch-more").css("margin-top", 0), $(".freeMutliBetContainer ").css("display", "none")) : ($("#placeCashBet, #placeFreeBet").prop("disabled", !1).removeClass("btn-bettingmatch-more"), parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2) <= 0 ? $(".freeMutliBetContainer ").css("display", "none") : $(".freeMutliBetContainer ").css("display", "flex"), document.getElementById("sportBonusAmountVal") != null && parseFloat(document.getElementById("sportBonusAmountVal").innerText) <= 0 || document.querySelector(".sports-bonus") != null && parseFloat(document.querySelector(".sports-bonus").innerText) <= 0 ? $(".sportBonusMultiBetContainer ").css("display", "none") : sportBonusEnabled && $(".sportBonusMultiBetContainer ").css("display", "flex"))
    }
}

function updateFreeBetContent(n) {
    var u = JSON.parse(GetBetslip()),
        r, t, i, f;
    if (u.length !== null && u.length !== undefined && u.length > 0 && n < minimumFreeBet && (GetBetslipOption("IsFreeBet") === !0 || GetBetslipOption("SingleFreebetId") !== "")) {
        if (r = document.getElementById("multiFreeBet"), r !== undefined && r !== null && (r.style.display = "none", document.querySelector(".freeMutliBetContainer").style.display = "none"), GetBetslipOption("SingleFreebetId") !== "" && (SetBetslipOption("SingleFreebetId", ""), t = document.getElementsByClassName("freeSinglebetsContainer"), t !== undefined && t !== null && t.length > 0))
            for (i = 0; i < t.length; i++) t[i].style.display = "none", f = t[i].querySelector("input:checked"), f !== null && mybetslip.chooseMe(f.parentElement);
        document.getElementById("hasFreeBets").value = !1;
        document.getElementById("hasFreeBetsVar").value = !1;
        document.getElementById("accountFreeBetAmount") != null && (document.getElementById("accountFreeBetAmount").value = n);
        document.getElementById("freebetBtnMobile").innerText = n.toFixed(2);
        document.getElementById("freeBetAmountVal").innerHTML = n.toFixed(2);
        document.getElementsByClassName("mobile-freebet").innerText = n.toFixed(2);
        global.setCookie("CurrentFreeBetAmount", n.toString(), .001);
        updateWagerAmountData()
    }
}

function updateSportBonusBetContent(n) {
    for (var u, f, i, e, r = JSON.parse(GetBetslip()), o = GetBetslipOption("MinBetAmount"), t = 0; t < r.length; t++)
        if (u = r[t], r.length !== null && r.length !== undefined && r.length > 0 && n < o && (GetBetslipOption("IsSportBonusBet") === !0 || GetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId) !== "")) {
            if (f = document.getElementById("divUseSportBonus"), f !== undefined && f !== null && (f.style.display = "none"), $(".sportBonusSinglebetsContainer").css({
                    visibility: "hidden",
                    display: "none"
                }), GetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId) !== "" && (SetBetslipOption("SingleSportBonusbetId-" + u.OutcomeId, ""), i = document.getElementsByClassName("sportBonusSinglebetsContainer"), i !== undefined && i !== null && i.length > 0))
                for (t = 0; t < i.length; t++) i[t].style.display = "none", e = i[t].querySelector("input:checked"), e !== null && mybetslip.chooseMe(e.parentElement);
            document.getElementById("sportBonusBtnMobile").innerText = n.toFixed(2);
            document.getElementById("sportBonusAmountVal").innerHTML = n.toFixed(2);
            document.getElementsByClassName("sports-bonus").innerText = n.toFixed(2);
            updateWagerAmountData()
        }
}

function enableBetslipLimitError(n) {
    var t = parseInt(GetBetslipOption("maxBetsPerBetslips")),
        i = betslipMultiSelectorEnabled ? n >= parseInt(maxSelectableOutcomes) : n >= t;
    return i && (document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = document.getElementById("maxBetsPerBetslipsError").value, language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
        "data-translate-key": "MaxBetsInBetslipError",
        "data-translate-type": "generic-html",
        "data-translate-value-0": betslipMultiSelectorEnabled ? maxSelectableOutcomes : t
    })), i
}

function myBetsSearchClick() {
    if ($(".mg-search").toggleClass("search-expanded"), $("#searchIcon").toggleClass("search-icon-expanded"), $("#searchIcon").toggleClass("md-toggle-search md-toggle-times"), $(this).hasClass("md-toggle-times")) $(".md-toggle-times").on("click", function() {
        $("#mtSearch").blur()
    });
    else $("#mtSearch").focusout(), $("#mtSearch").val(""), $("#mtSearch").trigger("keyup"), fasearch = !1
}

function OnDialingCodeFieldChanged(n) {
    if (isFreePlayWebsite != null && isFreePlayWebsite && dialingCodeCountrySyncCount < 1) {
        var t = $("#DialingCode_" + n.replace("+", "")).val();
        $("#CountryList_tmpl").val(t);
        dialingCodeCountrySyncCount++
    }
}

function OnCountryFieldChanged(n) {
    if (isFreePlayWebsite != null && isFreePlayWebsite && dialingCodeCountrySyncCount < 1) {
        var t = $("#Country_" + n).val();
        $("#SignUpModal").find("#DialingCode").val(t);
        dialingCodeCountrySyncCount++
    }
}

function addToBetslip(n) {
    n && n.length > 0 && pat.post("/Event/GetEventsByOutcomeIds", JSON.stringify({
        outcomeIds: n
    }), {
        dataType: "json",
        contentType: "application/json; charset=utf-8"
    }).done(function(n) {
        var r, t, i;
        if (n.Events && n.Events.length > 0) {
            r = [constId.feedDataType_LIP, constId.feedDataType_Prematch];
            for (t of n.Events) {
                let n = $.inArray(t.FeedDataTypeId, r) >= 0;
                i = sportBonusEnabled && t.IsSportBonusAllowedSport && t.IsSportBonusAllowedMarketType;
                n ? SendToBetslip(t.OutcomeId, t.OutcomeTitle, t.PriceDecimal, t.SportTitle, t.MarketTypeTitle, t.SpecialBetValue, t.Title, t.StartDate, t.EventId, t.IsInPlay, t.FeedDataTypeId, t.AllowEarlyCashout, t.AllowStretch, t.LeagueTitle, undefined, undefined, undefined, undefined, undefined, undefined, undefined, i) : SendToBetslip(t.OutcomeId, t.OutcomeTitle, t.PriceDecimal, t.SportTitle, t.Title, t.SpecialBetValue, "", t.StartDate, t.EventId, t.IsInPlay, t.FeedDataTypeId, !1, t.AllowStretch, t.LeagueTitle, undefined, undefined, undefined, undefined, undefined, undefined, undefined, i)
            }
        }
    })
}

function onMaxPayoutRebetConfirmClick(n, t) {
    n.preventDefault();
    var i = document.getElementById("isInstantBetsVar") !== null && typeof document.getElementById("isInstantBetsVar") != "undefined" && document.getElementById("isInstantBetsVar").value === "True";
    n != null && (n.currentTarget.disabled = !0, n.currentTarget.innerText = "Loading", language.translateAtRuntime(n.currentTarget, "BetslipConfirmationDialog", {
        "data-translate-key": "Loading"
    }));
    checkForLite() ? post_to_url(t, {
        OverwriteWagerAmtAccepted: !0
    }, "GET") : (homePage.showOverlay(), pat.get(t + "?OverwriteWagerAmtAccepted=true", null).done(function(n) {
        $("#confirmOddsChangeDialog").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#confirmOddsChangeDialog").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        $("#modal-container-bet-confirmation").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#modal-container-bet-confirmation").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        if (homePage.closeOverlay(), homePage.anchorToTop(), i && ($("#modal-container-bet-confirmation").modal(), $("#confirmOddsChangeDialog").modal()), $("#footerMobile").is(":visible") && $("#modal-container-bet-confirmation").find(".error-message").length === 0) {
            $("#mobileBetslipCount").html("(0)");
            $("#mobileBetslipCount").length > 0 ? $("#mobileBetslipCount").html("(0)") : $("#betslipCountBadge").length > 0 && $(".betslipCountBadgeCount").html("0");
            $("#modal-container-bet-confirmation").on("hide.bs.modal", function() {
                window.location = "/"
            })
        }
    }))
}

function onMaxWagerForSportsBonusRebetConfirmClick(n, t) {
    n.preventDefault();
    var i = document.getElementById("isInstantBetsVar") !== null && typeof document.getElementById("isInstantBetsVar") != "undefined" && document.getElementById("isInstantBetsVar").value === "True";
    n != null && (n.currentTarget.disabled = !0, n.currentTarget.innerText = "Loading", language.translateAtRuntime(n.currentTarget, "BetslipConfirmationDialog", {
        "data-translate-key": "Loading"
    }));
    checkForLite() ? post_to_url(t, {
        OverwriteWagerAmtAccepted: !0
    }, "GET") : (homePage.showOverlay(), pat.get(t + "?ShowWagerEqualsToTargetRemaining=true", null).done(function(n) {
        $("#confirmOddsChangeDialog").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#confirmOddsChangeDialog").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        $("#modal-container-bet-confirmation").html(n).find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        });
        $("#modal-container-bet-confirmation").on("hidden.bs.modal", function() {
            $("html").removeClass("modal-open")
        });
        if (homePage.closeOverlay(), homePage.anchorToTop(), i && ($("#modal-container-bet-confirmation").modal(), $("#confirmOddsChangeDialog").modal()), $("#footerMobile").is(":visible") && $("#modal-container-bet-confirmation").find(".error-message").length === 0) {
            $("#mobileBetslipCount").html("(0)");
            $("#mobileBetslipCount").length > 0 ? $("#mobileBetslipCount").html("(0)") : $("#betslipCountBadge").length > 0 && $(".betslipCountBadgeCount").html("0");
            $("#modal-container-bet-confirmation").on("hide.bs.modal", function() {
                window.location = "/"
            })
        }
    }))
}

function toggleAllCheckBox(n) {
    var i, t;
    if (n !== undefined)
        for (i = document.querySelectorAll('input[class~="toggleAgreeToAll"]'), t = 0; t < i.length; t++) i[t].checked = n.checked, checkForLite() || $(i[t]).valid()
}

function selectAllChildren(n) {
    for (var r = $(n).attr("id"), u = $("#" + r).is(":checked"), f = r.replace("_tmpl", "") + "Children", i = document.getElementById(f).getElementsByTagName("input"), t = 0; t < i.length; t++) i[t].setAttribute("checked", u), i[t].checked = u, i[t].disabled = !1, i[t].readOnly = !1
}

function validateParentCheckBox(n, t) {
    var u = document.getElementById(t + "_tmpl"),
        e = t + "Children",
        r = document.getElementById(e).getElementsByTagName("input"),
        f = 0,
        i;
    if (r != undefined && r != null)
        for (i = 0; i < r.length; i++)
            if ($(r[i]).is(":checked") == !0 && f++, f > 1 ? u != undefined && u != null && (u.checked = !0, u.setAttribute("checked")) : f == 0 && u != undefined && u != null && (u.checked = !1, u.removeAttribute("checked")), f == 0)
                for (i = 0; i < r.length; i++) $(r[i]).attr("readOnly", !0), $(r[i]).attr("disabled", !0);
            else
                for (i = 0; i < r.length; i++) $(r[i]).removeAttr("readOnly"), $(r[i]).removeAttr("disabled")
}

function toggleExpandArrow(n) {
    var t = document.getElementById(n),
        i = t.innerHTML;
    document.getElementById(n).innerHTML = i.includes("expand_more") ? "expand_less" : "expand_more"
}

function toggleGroupBoxChild(n) {
    var t = document.getElementById(n);
    document.getElementById(n).style.display = t.style.display == "none" ? "block" : "none"
}

function removeParentWithNoChildren() {
    for (var u, r, t, f, i = document.getElementsByClassName("cs-checkbox-group"), n = 0; n < i.length; n++)
        for (u = i[n].getElementsByClassName("cs-checkbox-group-parent"), r = u[0].getElementsByTagName("input"), t = 0; t < r.length; t++)(r[t].getAttribute("id") != null || r[t].getAttribute("id") == "") && (f = i[n].children, f[1].getElementsByTagName("input").length == 0 && (i[n].style.display = "none"))
}

function toggleCheckBox() {
    var n = checkForLite() ? document.getElementById("AgreeToAll") : document.getElementById("AgreeToAll_tmpl"),
        t;
    n !== undefined && n !== null && (t = document.querySelector('input[class~="toggleAgreeToAll"]:not(:checked)'), n.checked = t !== null ? t.checked : !0)
}

function onRegistrationSubmit() {
    document.getElementById("signUpFormLite").submit()
}

function setPageAsPreferred(n) {
    localStorage.setItem("preferredPage", n)
}

function getPreferredPage() {
    return localStorage.getItem("preferredPage")
}

function removePreferredPage() {
    localStorage.removeItem("preferredPage")
}

function getUserIsBrowsingCheck() {
    return sessionStorage.getItem("isUserBrowsing_PreferredPage")
}

function setUserIsBrowsingCheck(n) {
    sessionStorage.setItem("isUserBrowsing_PreferredPage", n)
}

function isUrlInPreferredWhiteList(n) {
    var t = PreferredPageWhiteList.filter(t => RegexMatchPartialStringExtension(t, n));
    return t.length > 0
}

function RegexMatchPartialStringExtension(n, t) {
    var i = n.replace(/[?+^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`^${i.replace(/\*/g,".*")}$`, "i").test(t)
}

function pad(n, t) {
    var n = n + "";
    return n.length >= t ? n : new Array(t - n.length + 1).join("0") + n
}

function saveUserRecentSearchTerm(n, t) {
    var i, u, f, e, r;
    try {
        if (enableRecentSearchTerm)
            if (n) {
                t = decodeURIComponent(t);
                i = JSON.parse(localStorage.getItem("recentSearchTerms"));
                u = document.querySelectorAll(".prematch.col-xs-12").length / 2;
                i == null && (i = []);
                u == null && (u = 0);
                let n = [];
                for (r = 0; r < i.length; r++) i[r].term.localeCompare(t) == 0 && n.push(r);
                let o = 0;
                if (n.forEach(n => {
                        i.splice(n - o, 1), o++
                    }), i.push(new RecentUserSearchObj(t, Date.now(), u)), i.length > recentSearchTermMaxLimitToSave) {
                    for (f = 0, e = 0, r = 0; r < i.Length; r++) i[r].searchDate > e && (f = r, e = i[r].searchDate);
                    i.splice(f, 1)
                }
                localStorage.setItem("recentSearchTerms", JSON.stringify(i))
            } else {
                t = decodeURIComponent(t);
                i = JSON.parse(localStorage.getItem("recentSearchTerms"));
                u = document.querySelectorAll(".widget-flyout-content > div").length;
                i == null && (i = []);
                u == null && (u = 0);
                let n = [];
                for (r = 0; r < i.length; r++) i[r].term.localeCompare(t) == 0 && n.push(r);
                let o = 0;
                if (n.forEach(n => {
                        i.splice(n - o, 1), o++
                    }), i.push(new RecentUserSearchObj(t, Date.now(), u)), i.length > recentSearchTermMaxLimitToSave) {
                    for (f = 0, e = 0, r = 0; r < i.Length; r++) i[r].searchDate > e && (f = r, e = i[r].searchDate);
                    i.splice(f, 1)
                }
                localStorage.setItem("recentSearchTerms", JSON.stringify(i))
            }
    } catch (o) {
        console.error(o)
    }
}

function RecentUserSearchObj(n, t, i) {
    this.term = n;
    this.searchDate = t;
    this.resultCount = i
}

function showRecentSearches(n) {
    widgetContainer.openRecentSearchResults(getHtmlForRecentSearches(n), n);
    n == !1 && setTimeout(() => {
        isSearchWidgetOpen = !0
    }, 200)
}

function getHtmlForRecentSearches(n) {
    var t = JSON.parse(localStorage.getItem("recentSearchTerms")),
        r = "",
        i, u, f;
    if (t == null || t.length == 0) r = '<div data-translate-set="SearchEventsWidget" data-translate-key="NoPreviousSearches">No Previous Searches...<\/div>';
    else
        for (i = t.length - 1; i >= 0; i--) u = new Date(t[i].searchDate).toLocaleString(), f = n ? `widgetContainer.widgetModalSearch('Search','${encodeURIComponent(t[i].term)}')` : `widgetContainer.widgetSearch('Search','${encodeURIComponent(t[i].term)}')`, r += `<div class="prematch col-xs-12 padding--none padding--y" style="border-bottom:solid rgba(0,0,0,0.3) 1px;cursor:pointer" onclick=${f}>

            <div class="col-xs-11 padding--none-left">
                <label class="ellips theOtherFont label__league_title display--block margin--none" style="cursor:pointer">${t[i].term}</label>
                <label class="ellips theOtherFont label-search__event_title display--block margin--none" style="cursor:pointer">${u} ${t[i].resultCount==null?0:t[i].resultCount} 
                 <label data-translate-set="SearchEventsWidget" data-translate-key="ResultsCountText">Result(s)</label>
                </label>
            </div>
             <div class="col-xs-1 padding--x" style="margin-top:7px;">
             <i style="font-size:20px;" class="fa fa-chevron-circle-right"></i>
            </div>
    </div>`;
    return r
}

function toggleTopAndFavLeagues(n) {
    $("#topLeagues, #accFavs").removeClass("active");
    n == "fav" ? ($("#accFavs,.parent-fav-leagues").addClass("active"), $(".parent-top-leagues").removeClass("active"), homePage.initTopLeaguesSlick("#fav-leagues-div"), AddSlickWidth($('[data-favorite-league-type="fav"]').length, "#fav-leagues-div")) : n == "top" && ($("#topLeagues,.parent-top-leagues").addClass("active"), $(".parent-fav-leagues").removeClass("active"))
}

function isSignUpTemplatesVisible(n, t) {
    var i = 0;
    for (var r of n) {
        if (t.includes(r)) return console.error("Exclude green, return false"), !1;
        let n = "#TemplateGroup_" + r;
        $(`${n}`).is(":visible") && i++
    }
    return i > 0
}

function isLessPotentialReturnValid() {
    var n = parseFloat(document.getElementById("potentialLessReturn").innerText).toFixed(2);
    return n == undefined || n == 0 ? !1 : n > 0 && parseFloat(document.getElementById("betslip-totallesspricedecimal").innerText) == 0 && document.getElementById("boostedAmount") !== null && parseFloat(document.getElementById("boostedAmount").value) == 0 ? !1 : document.getElementById("potentialLessReturn").style.display == "none" ? !1 : isNaN(n) ? !1 : !0
}

function hideAllLessPotentialReturn(n) {
    n == "boostedOdd" ? (document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px", typeof document.getElementById("boostedAmount") != "undefined" && document.getElementById("boostedAmount") == null && parseFloat(document.getElementById("boostedAmount").value).toFixed(2) == 0 && (typeof document.getElementById("potentialLessReturn") != "undefined" && document.getElementById("potentialLessReturn") !== null && document.getElementById("potentialLessReturn").style.display == "none", typeof document.getElementById("lessPotentialReturnWithStretchValSpan") != "undefined" && document.getElementById("lessPotentialReturnWithStretchValSpan") !== null && (document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none"), typeof document.getElementById("potentialReturnWithStretchNowLabel") != "undefined" && document.getElementById("potentialReturnWithStretchNowLabel") !== null && (document.getElementById("potentialReturnWithStretchNowLabel").style.display = "none")), parseFloat(document.getElementById("betslip-totallesspricedecimal").innerText) < .01 && document.getElementById("boostedAmount") !== null && parseFloat(document.getElementById("boostedAmount").value) > 0 && (document.getElementById("potentialLessReturn").style.display = "none")) : n == "winboost" ? isLessPotentialReturnValid() || (document.getElementById("potentialLessReturn").style.display == "none", document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none", document.getElementById("potentialReturnWithStretchNowLabel").style.display = "none") : (document.getElementById("potentialReturnWithStretchNowLabel").style.display == "none", document.getElementById("potentialLessReturn").style.display == "none", document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px");
    parseFloat(document.getElementById("potentialLessReturn").innerText) == parseFloat(document.getElementById("potentialReturn").value) && (document.getElementById("potentialLessReturn").style.display = "none");
    isLessBetslipValuesEnabled || (document.getElementById("potentialReturnWithStretchNowLabel").style.display == "none", document.getElementById("potentialLessReturn").style.display == "none", document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px")
}

function showAllLessPotentialReturn(n) {
    n == "boostedOdd" ? (document.getElementById("total-odds-text").style.marginTop = "-14px", document.getElementById("betslip-totallesspricedecimal").style.display = "block", document.getElementById("betslip-totalpricedecimal").style.marginTop = "-6px") : n == "winboost" || (document.getElementById("betslip-totallesspricedecimal").style.display = "block", document.getElementById("potentialLessReturn").style.display = "block", document.getElementById("total-odds-text").style.marginTop = "-14px", document.getElementById("betslip-totallesspricedecimal").style.display = "block", document.getElementById("betslip-totalpricedecimal").style.marginTop = "-6px");
    document.getElementById("potentialLessReturn").style.display = "block";
    document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "block";
    document.getElementById("potentialReturnWithStretchNowLabel").style.display = "inline";
    parseFloat(document.getElementById("betslip-totallesspricedecimal").innerText) == 0 && (document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px");
    parseFloat(document.getElementById("potentialLessReturn").innerText) == parseFloat(document.getElementById("potentialReturn").value) && (document.getElementById("potentialLessReturn").style.display = "none");
    parseFloat(document.getElementById("betslip-totallesspricedecimal").innerText) < .01 && parseFloat(document.getElementById("boostedAmount").value) > 0 && (document.getElementById("potentialLessReturn").style.display = "none");
    isLessBetslipValuesEnabled || (document.getElementById("potentialReturnWithStretchNowLabel").style.display == "none", document.getElementById("potentialLessReturn").style.display == "none", document.getElementById("lessPotentialReturnWithStretchValSpan").style.display = "none", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("total-odds-text").style.marginTop = "0px", document.getElementById("betslip-totallesspricedecimal").style.display = "none", document.getElementById("betslip-totalpricedecimal").style.marginTop = "0px")
}

function miniBetslip(n = false) {
    if (!checkForLite() && isMiniBetslipEnabled) {
        if ((window.location.pathname.toLowerCase().includes("lobby") || window.location.pathname.toLowerCase().includes("horseracing")) && document.getElementById("miniBetslip") != undefined && document.getElementById("miniBetslip") != null) {
            document.getElementById("miniBetslip").style.display = "none";
            document.getElementById("scroll").setAttribute("class", "");
            return
        }
        window.innerWidth < 768 && miniBetsllipCount >= 1 && document.getElementById("betslipBtn").style.display != "none" ? (document.getElementById("miniBetslip").style.display = "block", isMiniBetslipConflicting ? (document.getElementById("miniBetslipConflicting").style.display = "block", document.getElementById("miniBetslipContent").style.display = "none", document.getElementById("scroll").setAttribute("class", "")) : (document.getElementById("miniBetslipConflicting").style.display = "none", document.getElementById("miniBetslipContent").style.display = "flex", document.getElementById("scroll").setAttribute("class", "miniBetslipActive"), moreFeaturesEnabled && document.getElementById("moreOptions").style.display == "block" && (document.getElementById("moreOptions").style.bottom = "105px"), n && ToggleBetslip(document.getElementById("mb_id")), document.querySelector(".ngFloatable") != undefined && document.querySelector(".ngFloatable") != null && document.querySelector(".ngFloatable").classList.add("ngFloatable-minibetslip"), (document.getElementById("wagerAmount") != undefined || document.getElementById("wagerAmount") != null) && (document.getElementById("miniBetslipWagerAmount").innerText = document.getElementById("wagerAmount").value), (document.getElementById("betslip-totalpricedecimal") != undefined || document.getElementById("betslip-totalpricedecimal") != null) && (parseFloat(document.getElementById("betslip-totalpricedecimal").innerText) == 0 ? (document.getElementById("miniBetslipConflicting").style.display = "block", document.getElementById("miniBetslipContent").style.display = "none") : document.getElementById("miniBetslipTotalOdds").innerText = document.getElementById("betslip-totalpricedecimal").innerText), isLessBetslipValuesEnabled ? document.getElementById("lessPotentialReturnWithStretchVal") != undefined && document.getElementById("lessPotentialReturnWithStretchVal") != null && (document.getElementById("lessPotentialReturnWithStretchVal").innerText != "" && document.getElementById("lessPotentialReturnWithStretchValSpan").style.display != "none" ? (document.getElementById("miniBetslipWasContainer").style.display = "block", document.getElementById("miniBetslipWasAmount").innerText = document.getElementById("lessPotentialReturnWithStretchVal").innerText) : document.getElementById("miniBetslipWasContainer").style.display = "none") : document.getElementById("miniBetslipWasContainer").style.display = "none", isLessBetslipValuesEnabled ? document.getElementById("potentialReturnWithStretchVal") != undefined && document.getElementById("potentialReturnWithStretchVal") != null && (document.getElementById("miniBetslipBetwayReturnAmount").innerText = document.getElementById("potentialReturnWithStretchVallabel") != undefined && document.getElementById("potentialReturnWithStretchVallabel") != null && parseFloat(document.getElementById("potentialReturnWithStretchVallabel").innerText) != 0 ? document.getElementById("potentialReturnWithStretchVallabel").innerText : document.getElementById("potentialReturnWithStretchVal").innerText) : document.getElementById("miniBetslipBetwayReturnAmount").innerText = document.getElementById("potentialReturn").value, $("#AlertLockedLIPMarket").hasClass("hidden") && $(".alert-conflict").hasClass("hidden") || (document.getElementById("miniBetslipConflicting").style.display = "block", document.getElementById("miniBetslipContent").style.display = "none", document.getElementById("scroll").setAttribute("class", "")))) : document.getElementById("miniBetslip") != undefined && document.getElementById("miniBetslip") != null && (document.getElementById("scroll").setAttribute("class", ""), document.getElementById("miniBetslip").style.display = "none", moreFeaturesEnabled && document.getElementById("moreOptions").style.display == "block" && (document.getElementById("moreOptions").style.bottom = "105px"))
    }
}

function toggleMoreFeatures(n) {
    moreFeaturesEnabled && (n == "none" ? (document.getElementById("moreOptions").style.display = "none", document.querySelector("html").style.overflow = "scroll", document.querySelector("html").removeAttribute("style"), document.getElementById("miniBetslip").style.position = "fixed") : n == "block" ? (document.getElementById("moreOptions").style.display = "block", document.querySelector("html").style.overflow = "hidden", isMiniBetslipEnabled && document.getElementById("miniBetslip").style.display == "block" ? (document.getElementById("moreOptions").style.bottom = "105px", document.getElementById("miniBetslip").style.position = "fixed") : (document.getElementById("moreOptions").style.bottom = "55px", isMiniBetslipEnabled && (document.getElementById("miniBetslip").style.position = "fixed"))) : (document.getElementById("moreOptions").style.display = "none", document.querySelector("html").style.overflow = "scroll", document.querySelector("html").removeAttribute("style"), isMiniBetslipEnabled && (document.getElementById("miniBetslip").style.position = "fixed")))
}

function getMoreFeatures() {
    if (moreFeaturesEnabled) {
        var n = document.getElementById("moreOptionsContent");
        homePage.showOverlay();
        n.innerHTML == null || n.innerHTML == "" ? pat.get("/SideMenu/GetMoreFeaturesMenu", null).done(function(t) {
            n.innerHTML = t;
            toggleMoreFeatures("block")
        }) : toggleMoreFeatures("block");
        homePage.closeOverlay()
    }
}

function removeExpiredSelections(n) {
    for (var r, i = JSON.parse(GetBetslip()), t = 0; t < n.length; t++) RemoveSelected(i, "OutcomeId", n[t].OutcomeId) && document.getElementById("SelectedOutcomeForBetslip-" + n[t].OutcomeId) != null && ($("SelectedOutcomeForBetslip-" + n[t].OutcomeId).hasClass("unsuccessfulBet") || document.getElementById("SelectedOutcomeForBetslip-" + n[t].OutcomeId).parentNode.removeChild(document.getElementById("SelectedOutcomeForBetslip-" + n[t].OutcomeId)), document.getElementById(n[t].OutcomeId) != null && document.getElementById(n[t].OutcomeId).classList.contains("isSelected") && document.getElementById(n[t].OutcomeId).classList.remove("isSelected")), RemoveBetIDOutcomeForGA(n[t].OutcomeId);
    i.length === 0 ? (SetBetslip({}), SetBookingCode(""), SetBetslipOption("TotalLessPriceDecimal", 0), SetBetslipOption("TotalPriceDecimal", 0), checkForLite() || (r = GetBetslipOption("MinBetAmount"), mybets.toggleToBetslip("betslipHeader"), enableWagerTax && (SetBetslipOption("InitialStake", parseFloat(r)), document.getElementById("stakeBeforeWagerTax").value = parseFloat(r), checkWager())), UpdatePotentialReturn(), ClearAccumulatorsFromBetslip()) : (SetOutcomeButtonsFromBSItems(i), SetBetslip(i));
    UpdateBetslipFullVersion()
}

function editBetslipWagerAmount(n) {
    var t, i;
    if (n == "reset") t = GetBetslipOption("MinBetAmount"), t != 0 && t != "" ? (document.getElementById("wagerAmount") && (document.getElementById("wagerAmount").value = t.toFixed(2)), document.getElementById("wagerAmountlabel") && (document.getElementById("wagerAmountlabel").value = t.toFixed(2))) : (document.getElementById("wagerAmount") != null && (document.getElementById("wagerAmount").value = 0), document.getElementById("wagerAmountlabel") != null && (document.getElementById("wagerAmountlabel").value = 0)), UpdatePotentialReturn();
    else if (GetBetslipOption("IsFreeBet") == !1) {
        if (isNaN(n)) return;
        i = (parseFloat(document.getElementById("wagerAmount").value) + parseFloat(n)).toFixed(2);
        document.getElementById("wagerAmount") != null && (document.getElementById("wagerAmount").value = i);
        document.getElementById("wagerAmountlabel") != null && (document.getElementById("wagerAmountlabel").value = i);
        UpdatePotentialReturn()
    }
}

function GetBetslipWagerSuggestion() {
    var o, u, i, s, f;
    if (betslipWagerAmountSuggestionEnabled && document.getElementById("betslipWagerAmounts") && document.getElementById("betslipWagerAmounts") != "") {
        document.getElementById("betslipWagerAmounts").innerHTML = "";
        var t = [],
            r = "[]",
            n = localStorage.getItem("betslipWagerSuggestion"),
            e = !1;
        if (n !== null && typeof n != "undefined" && n.length > 0 && (o = JSON.parse(n), diff_minutes(new Date, new Date(o.LastFetchedDateTime)) >= 10 && (e = !0), e || (r = o.data)), n !== null && typeof n != "undefined" && n.length > 0 && !e || $.get("/Account/GetAccountBetslipWagerSuggestion?AccountId=" + PlayerAccountID, function(n) {
                if (n != null) {
                    n = n;
                    var t = {};
                    t.LastFetchedDateTime = new Date;
                    t.data = n;
                    localStorage.setItem("betslipWagerSuggestion", JSON.stringify(t))
                }
            }), r !== null && typeof r != "undefined" && r.length > 0) {
            if (t = r, t == undefined || t == null || t.length != 5) return;
            for (u = 0; u < t.length; u++) i = document.createElement("div"), i.setAttribute("id", "betslipWagerAmount_" + u), i.classList.add("betslip-wager-amount"), s = t[u], i.setAttribute("onclick", `editBetslipWagerAmount(${s})`), i.innerHTML = `<span class="material-icons-outlined" style="font-size: 8px; font-weight: 900; color: #439539">add</span>${s}`, document.getElementById("betslipWagerAmounts").appendChild(i);
            f = document.createElement("div");
            f.classList.add("betslip-wager-amount");
            f.onclick = function() {
                editBetslipWagerAmount(`reset`)
            };
            f.innerHTML = `reset`;
            document.getElementById("betslipWagerAmounts").appendChild(f);
            isGetBetslipWagerSuggesionLoaded = !0
        }
        $("#mb_id").hasClass("active") || (document.getElementById("betslipWagerAmountsContainer").style.display = "none")
    }
}

function viewPassword(n) {
    var t = document.getElementById("Password"),
        i = document.getElementById("menuPassword"),
        r = document.getElementById("pass-status"),
        u = document.getElementById("menu-pass-status");
    n == "pass-status" ? t.type == "password" ? (t.type = "text", r.className = "fa fa-eye-slash passwordIcon") : (t.type = "password", r.className = "fa fa-eye passwordIcon") : n == "menu-pass-status" && (i.type == "password" ? (i.type = "text", u.className = "fa fa-eye-slash passwordIcon") : (i.type = "password", u.className = "fa fa-eye passwordIcon"))
}

function chooseBonusType(n, t) {
    if (t != undefined && t != null) {
        var f = t.children[0],
            o = GetBetslipOption("MinBetAmount"),
            r = document.getElementById("sportBonusMultiBetCheckbox") != null,
            u = document.getElementById("freeMutliBetCheckbox") != null,
            i = document.getElementById("cashMutliBetCheckbox") != null,
            e = JSON.parse(GetBetslip());
        n == "freebet" && u ? (r && document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-check-square-o"), r && (document.getElementById("sportBonusMultiBetCheckbox").checked = !1), SetBetslipOption("IsSportBonusBet", !1), $("#bsSportBonusMultiBetCheckbox").css({
            color: "#000000 !important"
        }), $(".sportBonusMultiBetContainer").css({
            color: "#000000"
        }), i && document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-check-square-o"), i && (document.getElementById("cashMutliBetCheckbox").checked = !1), $("#bsCashMutliBetCheckbox").css({
            color: "#000000 !important"
        }), $(".cashMutliBetContainer").css({
            color: "#000000"
        }), f.checked ? (removeMultiBonus("freebet", !0), i && document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-check-square-o")) : (f.checked = !0, document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-check-square-o"), document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-square-o"), $(".unprotectedSportsBonus-alert").css({
            visibility: "hidden",
            display: "none"
        }), $(".protectedSportsBonus-alert").css({
            visibility: "hidden",
            display: "none"
        }), $("#bsFreeMutliBetCheckbox").css({
            color: "rgb(67, 149, 57)"
        }), $(".freeMutliBetContainer").css({
            color: "rgb(67, 149, 57)"
        }), document.getElementById("wagerAmount").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("wagerAmount").classList.add("bonus-disable-wager"), document.getElementById("stakeBeforeWagerTax") != null && (document.getElementById("stakeBeforeWagerTax").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("stakeBeforeWagerTax").classList.add("bonus-disable-wager")), document.getElementById("wagerAmountlabel") != null && (document.getElementById("wagerAmountlabel").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("wagerAmountlabel").classList.add("bonus-disable-wager")), SetBetslipOption("IsFreeBet", !0), $("#mb_id").hasClass("active") ? $("#placeCashBet").text("Use Free Bet") : $("#placeCashBet").text("Bet Now"), i && document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-square-o")), r && document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-square-o")) : n == "sportbonus" && r ? (u && document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-check-square-o"), u && (document.getElementById("freeMutliBetCheckbox").checked = !1), $("#bsFreeMutliBetCheckbox").css({
            color: "#000000 !important"
        }), $(".freeMutliBetContainer").css({
            color: "#000000"
        }), i && document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-check-square-o"), i && (document.getElementById("cashMutliBetCheckbox").checked = !1), $("#bsCashMutliBetCheckbox").css({
            color: "#000000 !important"
        }), $(".cashMutliBetContainer").css({
            color: "#000000"
        }), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager"), document.getElementById("stakeBeforeWagerTax") != null && document.getElementById("stakeBeforeWagerTax").classList.remove("bonus-disable-wager"), SetBetslipOption("IsFreeBet", !1), f.checked ? (removeMultiBonus("sportbonus"), i && document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-check-square-o")) : (f.checked = !0, document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-check-square-o"), document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-square-o"), $("#bsSportBonusMultiBetCheckbox").css({
            color: "rgb(67, 149, 57)"
        }), $(".sportBonusMultiBetContainer").css({
            color: "rgb(67, 149, 57)"
        }), SetBetslipOption("IsSportBonusBet", !0), $("#mb_id").hasClass("active") ? $("#placeCashBet").text("Use Sport Bonus Bet") : $("#placeCashBet").text("Bet Now"), i && document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-square-o")), u && document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-square-o")) : n == "cash" && i && (r && document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-check-square-o"), r && (document.getElementById("sportBonusMultiBetCheckbox").checked = !1), SetBetslipOption("IsSportBonusBet", !1), $("#bsSportBonusMultiBetCheckbox").css({
            color: "#000000 !important"
        }), $(".sportBonusMultiBetContainer").css({
            color: "#000000"
        }), r && checkForSportBonus(e), u && document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-check-square-o"), u && (document.getElementById("freeMutliBetCheckbox").checked = !1), SetBetslipOption("IsFreeBet", !1), $("#bsFreeMutliBetCheckbox").css({
            color: "#000000 !important"
        }), $(".freeMutliBetContainer").css({
            color: "#000000"
        }), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager"), document.getElementById("stakeBeforeWagerTax") != null && document.getElementById("stakeBeforeWagerTax").classList.remove("bonus-disable-wager"), SetBetslipOption("IsFreeBet", !1), f.checked = !0, document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-check-square-o"), document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-square-o"), $("#bsCashMutliBetCheckbox").css({
            color: "rgb(67, 149, 57)"
        }), $(".cashMutliBetContainer").css({
            color: "rgb(67, 149, 57)"
        }), r && document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-square-o"), u && document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-square-o"));
        GetBetslipOption("IsSportBonusBet") == !1 && GetBetslipOption("IsFreeBet") == !1 && $("#placeCashBet").text("Bet Now");
        isLoggedIn || ($("#placeCashBet").text("Bet Now"), SetBetslipOption("IsSportBonusBet", !1), SetBetslipOption("IsFreeBet", !1));
        UpdatePotentialReturn()
    }
}

function removeMultiBonus(n) {
    var t = document.getElementById("sportBonusMultiBetCheckbox") != null,
        o = document.getElementById("freeMutliBetCheckbox") != null,
        i = document.getElementById("cashMutliBetCheckbox") != null,
        s = JSON.parse(GetBetslip()),
        r, u, f, e;
    n == "freebet" && o ? (r = document.getElementById("bsFreeMutliBetCheckbox"), u = r.children[0], u.checked = !1, document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-check-square-o"), document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-square-o"), $("#bsFreeMutliBetCheckbox").css({
        color: "#000000 !important"
    }), $(".freeMutliBetContainer").css({
        color: "#000000"
    }), i && (document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-check-square-o"), document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-square-o"), $("#bsCashMutliBetCheckbox").css({
        color: "rgb(67, 149, 57)"
    }), $(".cashMutliBetContainer").css({
        color: "rgb(67, 149, 57)"
    })), t && checkForSportBonus(s), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("stakeBeforeWagerTax") != null && document.getElementById("stakeBeforeWagerTax").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager"), SetBetslipOption("IsFreeBet", !1)) : n == "sportbonus" && t && (f = document.getElementById("bsSportBonusMultiBetCheckbox"), e = f.children[0], e.checked = !1, document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-check-square-o"), document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-square-o"), $("#bsSportBonusMultiBetCheckbox").css({
        color: "#000000 !important"
    }), $(".sportBonusMultiBetContainer").css({
        color: "#000000"
    }), i && (document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-check-square-o"), document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-square-o"), $("#bsCashMutliBetCheckbox").css({
        color: "rgb(67, 149, 57)"
    }), $(".cashMutliBetContainer").css({
        color: "rgb(67, 149, 57)"
    })), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager"), SetBetslipOption("IsSportBonusBet", !1))
}

function clearBonusSelection() {
    var n = document.getElementById("sportBonusMultiBetCheckbox") != null,
        t = document.getElementById("freeMutliBetCheckbox") != null;
    n && sportBonusEnabled && removeMultiBonus("sportbonus");
    t && removeMultiBonus("freebet", !0);
    $("#placeCashBet").text("Bet Now")
}

function applyCurrentBonus() {
    var r = document.getElementById("sportBonusMultiBetCheckbox") != null,
        u = document.getElementById("freeMutliBetCheckbox") != null,
        o = document.getElementById("cashMutliBetCheckbox") != null,
        s = document.getElementById("sportBonusMultiBetCheckbox") != null && document.getElementById("sportBonusMultiBetCheckbox").classList.contains("SportBonusBetTypeBtnText"),
        f, n, e, t, i;
    GetBetslipOption("IsSportBonusBet") && r && sportBonusEnabled && isLoggedIn && !s ? (n = document.getElementById("bsSportBonusMultiBetCheckbox"), f = n.children[0], f.checked = !0, document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-square-o"), document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-check-square-o"), $("#bsSportBonusMultiBetCheckbox").css({
        color: "rgb(67, 149, 57)"
    }), $(".sportBonusMultiBetContainer").css({
        color: "rgb(67, 149, 57)"
    }), o && (document.getElementById("bsCashMutliBetCheckbox").classList.remove("fa-check-square-o"), document.getElementById("bsCashMutliBetCheckbox").classList.add("fa-square-o"), $("#bsCashMutliBetCheckbox").css({
        color: "#000000 !important"
    }), $(".cashMutliBetContainer").css({
        color: "#000000"
    })), $("#mb_id").hasClass("active") ? $("#placeCashBet").text("Use Sport Bonus Bet") : $("#placeCashBet").text("Bet Now")) : (sportBonusEnabled && r && (n = document.getElementById("bsSportBonusMultiBetCheckbox"), e = n.children[0], e.checked = !1, document.getElementById("bsSportBonusMultiBetCheckbox").classList.remove("fa-check-square-o"), document.getElementById("bsSportBonusMultiBetCheckbox").classList.add("fa-square-o"), $("#bsSportBonusMultiBetCheckbox").css({
        color: "#000000 !important"
    }), $(".sportBonusMultiBetContainer").css({
        color: "#000000"
    }), document.getElementById("stakeBeforeWagerTax") != null && document.getElementById("stakeBeforeWagerTax").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager")), SetBetslipOption("IsSportBonusBet", !1));
    GetBetslipOption("IsFreeBet") && u && isLoggedIn ? (t = document.getElementById("bsFreeMutliBetCheckbox"), i = t.children[0], i.checked = !0, document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-square-o"), document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-check-square-o"), $("#bsFreeMutliBetCheckbox").css({
        color: "rgb(67, 149, 57)"
    }), $(".freeMutliBetContainer").css({
        color: "rgb(67, 149, 57)"
    }), $(".unprotectedSportsBonus-alert").css({
        visibility: "hidden",
        display: "none"
    }), $(".protectedSportsBonus-alert").css({
        visibility: "hidden",
        display: "none"
    }), document.getElementById("wagerAmount").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("stakeBeforeWagerTax") != null && (document.getElementById("stakeBeforeWagerTax").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("stakeBeforeWagerTax").classList.add("bonus-disable-wager")), document.getElementById("wagerAmount").classList.add("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && (document.getElementById("wagerAmountlabel").value = parseFloat(getCookie("CurrentFreeBetAmount")).toFixed(2), document.getElementById("wagerAmountlabel").classList.add("bonus-disable-wager")), $("#mb_id").hasClass("active") ? $("#placeCashBet").text("Use Free Bet") : $("#placeCashBet").text("Bet Now")) : (u && (t = document.getElementById("bsFreeMutliBetCheckbox"), i = t.children[0], i.checked = !1, document.getElementById("bsFreeMutliBetCheckbox").classList.remove("fa-check-square-o"), document.getElementById("bsFreeMutliBetCheckbox").classList.add("fa-square-o"), document.getElementById("wagerAmount").classList.remove("bonus-disable-wager"), document.getElementById("stakeBeforeWagerTax") != null && document.getElementById("stakeBeforeWagerTax").classList.remove("bonus-disable-wager"), document.getElementById("wagerAmountlabel") != null && document.getElementById("wagerAmountlabel").classList.remove("bonus-disable-wager")), SetBetslipOption("IsFreeBet", !1));
    GetBetslipOption("IsSportBonusBet") == !1 && GetBetslipOption("IsFreeBet") == !1 && $("#placeCashBet").text("Bet Now")
}

function resetTaxInputs() {
    document.getElementById("HoldingTaxAmount") != null && (document.getElementById("HoldingTaxAmount").value = "0.00");
    document.getElementById("wagerTaxAmount") != null && (document.getElementById("wagerTaxAmount").innerText = "0.00");
    document.getElementById("configuredTaxPercentage") != null && document.getElementById("configuredTaxPercentageText") != null && (document.getElementById("configuredTaxPercentageText").innerText = "(0%)")
}

function isSportBonusMultiBet() {
    return sportBonusEnabled && enableTax && GetBetslipOption("IsSportBonusBet") && isLoggedIn ? (resetTaxInputs(), !0) : !1
}

function isSportBonusSingleBet(n) {
    if (sportBonusEnabled && enableTax && isLoggedIn && GetBetslipOption("SingleSportBonusbetId-" + n.OutcomeId) != undefined || GetBetslipOption("SingleSportBonusbetId-" + n.OutcomeId) != "") return resetTaxInputs(), !0
}

function isSportBonusChecked() {
    return sportBonusEnabled && GetBetslipOption("IsSportBonusBet") && isLoggedIn ? !0 : !1
}

function addToFavorites(n, t, i = null, r = "") {
    var h, o, a, c, u, e;
    if (isAccountFavoriteEnabled) {
        var l = n == "league" ? 0 : 1,
            s = localStorage.getItem("accountFavorites"),
            f = {
                AccountFavoriteType: l,
                Value: t
            };
        if (s == null || s == "" || s == "[object Object]") h = [], h.push(f), localStorage.setItem("accountFavorites", JSON.stringify(createNewFavObject(h)));
        else if (o = JSON.parse(s).AccountFavorites, a = o.filter(n => n.AccountFavoriteType == l), a.find(n => n.Value == t) != undefined) {
            if (i != null) {
                if (n == "league") {
                    if (document.getElementById("TopLeagues") != null && (document.querySelector(`#TopLeagues .material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"]`) != null && (document.querySelector(`#TopLeagues .material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"]`).style.color = "#eee"), r == "topleague" && (u = document.querySelectorAll(`.material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"][data-favorite-type="groupedleague"]`), u != undefined && u.length > 0)))
                        for (e = 0; e < u.length; e++) u[e].setAttribute("data-is-favorite", "false"), u[e].style.color = "#eee";
                    i.setAttribute("data-is-favorite", "false");
                    i.style.color = "#eee"
                }
                n == "markettype" && (i.style.color = "#eee", i.setAttribute("data-is-favorite", "false"), document.querySelector(`#_AllOutcomes .search-link[data-markettype-favorite-parent='${t}']`) != null && document.querySelector(`#_AllOutcomes .search-link[data-markettype-favorite-parent='${t}']`).setAttribute("data-is-markettype-favorite", "false"))
            }
            c = o.indexOf(o.find(n => n.Value == f.Value && n.AccountFavoriteType == f.AccountFavoriteType));
            c != -1 && o.splice(c, 1);
            localStorage.setItem("accountFavorites", JSON.stringify(createNewFavObject(o)));
            f.AccountFavoriteType == 0 ? updateAccountFavorites(JSON.stringify(f), !0, !0) : updateAccountFavorites(JSON.stringify(f), !0)
        } else {
            if (i != null) {
                if (n == "league") {
                    if (document.getElementById("TopLeagues") != null && (document.querySelector(`#TopLeagues .material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"]`) != null && (document.querySelector(`#TopLeagues .material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"]`).style.display = "none"), r == "topleague" && (u = document.querySelectorAll(`.material-icons-outlined.acc-fav-heart[data-favorite-league="${t}"][data-favorite-type="groupedleague"]`), u != undefined && u.length > 0)))
                        for (e = 0; e < u.length; e++) u[e].setAttribute("data-is-favorite", "true"), u[e].style.color = "#439539";
                    i.style.color = "#439539";
                    i.setAttribute("data-is-favorite", "true")
                }
                n == "markettype" && (i.style.color = "#439539", i.setAttribute("data-is-favorite", "true"), document.querySelector(`#_AllOutcomes .search-link[data-markettype-favorite-parent='${t}']`) != null && document.querySelector(`#_AllOutcomes .search-link[data-markettype-favorite-parent='${t}']`).setAttribute("data-is-markettype-favorite", "true"))
            }
            o.push(f);
            localStorage.setItem("accountFavorites", JSON.stringify(createNewFavObject(o)));
            f.AccountFavoriteType == 0 ? updateAccountFavorites(JSON.stringify(f), !0, !0) : updateAccountFavorites(JSON.stringify(f), !0)
        }
        n == "league" ? applyFavorites(!0) : applyFavorites()
    }
}

function updatefavLeagueItems() {
    var n = JSON.parse(localStorage.getItem("accountFavorites"));
    $(".fav-league-item").each(function() {
        var t = $(this).data("id"),
            i = n.AccountFavorites.filter(n => n.Value == t);
        i.length === 0 && $("#favLeagueIdDiv_" + t).remove()
    })
}

function createNewFavObject(n) {
    var t = {};
    return t.LastFetchedDateTimeUtc = new Date, t.LastFetchedDateTimeSAST = new Date, t.LastFetchedDateTime = new Date, t.AccountFavorites = n, t
}

function applyFavorites(n = false) {
    var i, r, u, e, t;
    if (isAccountFavoriteEnabled && (i = document.querySelectorAll("span.material-icons-outlined.acc-fav-heart"), r = localStorage.getItem("accountFavorites"), r != null && r != "" && r != "[object Object]")) {
        var o = JSON.parse(r).AccountFavorites,
            f = o.filter(n => n.AccountFavoriteType == 0),
            s = [];
        if (f != null && f != undefined && f.length > 0 && f.forEach(n => {
                s.push(n.Value)
            }), i.length > 0)
            for (t = 0; t < i.length; t++) s.includes(i[t].getAttribute("data-favorite-league")) ? (i[t].style.color = "#439539", i[t].setAttribute("data-is-favorite", "true")) : (i[t].style.color = "#ffffff", i[t].setAttribute("data-is-favorite", "false"));
        if (homePage.initTopLeaguesSlick("#fav-leagues-div"), n) return;
        if (u = o.filter(n => n.AccountFavoriteType == 1), e = [], u != null && u != undefined && u.length > 0 && u.forEach(n => {
                e.push(n.Value)
            }), i.length > 0)
            for (t = 0; t < i.length; t++) i[t].getAttribute("data-favorite-type") == "markettype" && (e.includes(i[t].getAttribute("data-favorite-markettype")) ? (i[t].style.color = "#439539", i[t].setAttribute("data-is-favorite", "true"), document.querySelector(`div.row.search-link[data-markettype-favorite-parent="${i[t].getAttribute("data-favorite-markettype")}"]`).setAttribute("data-is-markettype-favorite", !0)) : (i[t].style.color = "#ffffff", i[t].setAttribute("data-is-favorite", "false"), document.querySelector(`div.row.search-link[data-markettype-favorite-parent="${i[t].getAttribute("data-favorite-markettype")}"]`).setAttribute("data-is-markettype-favorite", !1)));
        isFavouriteTypeMax("league") ? disableOrEnableFavouritesForType("league", "disable") : disableOrEnableFavouritesForType("league", "enable");
        isFavouriteTypeMax("markettype") ? disableOrEnableFavouritesForType("markettype", "disable") : disableOrEnableFavouritesForType("markettype", "enable")
    }
}

function toggleTopFavList() {
    $(".league-items").length > 0 ? ($(".top-Fav-Btns").show(), $("#TopLeaguesAccordion").removeAttr("style")) : ($(".top-Fav-Btns").hide(), $("#TopLeaguesAccordion").attr("style", "display:none !important"));
    $('[data-is-favorite="true"]').length > 0 ? ($("#accFavs").show(), $(".parent-top-leagues").removeClass("active"), $("#accFavs").addClass("active"), $("#topLeagues").removeClass("active"), $(".parent-fav-leagues").addClass("active"), AddSlickWidth($('[data-favorite-league-type="fav"]').length, "#fav-leagues-div")) : ($("#accFavs").hide(), $("#topLeagues").removeClass("active"), $(".parent-top-leagues").addClass("active"))
}

function GetAccountFavorites() {
    var i;
    if (isAccountFavoriteEnabled) try {
        var u = localStorage.getItem("fetchAccountFavorites"),
            n = localStorage.getItem("accountFavorites"),
            t = !1;
        n !== null && typeof n != "undefined" && n.length > 0 && (i = JSON.parse(n), diff_minutes(new Date, new Date(i.LastFetchedDateTimeUtc)) >= 20 && (t = !0));
        n !== null && typeof n != "undefined" && n.length > 0 && !t ? applyFavorites() : $.get("/Account/GetAccountFavorite?accountId=" + PlayerAccountID, null, function(n) {
            if (n !== null && typeof n != "undefined" && n) {
                var t = n;
                t.LastFetchedDateTimeUtc = new Date;
                t.LastFetchedDateTimeSAST = new Date;
                t.LastFetchedDateTime = new Date;
                localStorage.setItem("fetchAccountFavorites", "true");
                localStorage.setItem("accountFavorites", JSON.stringify(t))
            } else localStorage.setItem("accountFavorites", ""), localStorage.setItem("fetchAccountFavorites", "true");
            applyFavorites()
        })
    } catch (r) {
        localStorage.setItem("accountFavorites", "");
        localStorage.setItem("fetchAccountFavorites", "");
        console.log(r)
    }
}

function updateAccountFavorites(n, t = false, i = false) {
    if (isAccountFavoriteEnabled) {
        homePage.showOverlay();
        var r = localStorage.getItem("currentSportId");
        i || (r = "00000000-0000-0000-0000-000000000000");
        ajax.post("/Account/UpdateAccountFavorite", {
            newfavorite: n,
            sportConfigId: r
        }, function(n) {
            localStorage.setItem("accountFavorites", n);
            r != "00000000-0000-0000-0000-000000000000" && homePage.getTopLeagues(r);
            t ? setTimeout(function() {
                homePage.closeOverlay();
                applyFavorites()
            }, 500) : homePage.closeOverlay()
        })
    }
}

function generateAccountFavoriteLeagueFilters(n = false) {
    var t, r, i;
    if (isFavoritesTabEnabled) {
        if (t = document.querySelectorAll('[data-favorite-league-type="fav"]'), r = [], t.length > 0) {
            if (n)
                for (i = 0; i < t.length; i++) r.push(t[i].getAttribute("data-favorite-league"));
            $(".dropdown-submenu-favorite").show();
            document.getElementById("dropMenuFavoriteCount").innerText = `Favourite ${t.length} Leagues`;
            t.length === 1 && $(".league-group-items").removeClass("collapse");
            AddSlickWidth(t.length, "#fav-leagues-div")
        } else $(".dropdown-submenu-favorite").hide(), document.getElementById("dropMenuFavoriteCount") != null && (document.getElementById("dropMenuFavoriteCount").innerText = `Favourite Leagues`);
        if (n) return r
    }
}

function AddSlickWidth(n, t) {
    n <= 5 && (window.innerWidth < 480 || $(t).addClass("width-100"))
}

function toggleExpandArrowById(n) {
    var t = document.getElementById(n);
    t != null && t != undefined && (t.innerHTML = t.innerHTML.includes("expand_more") ? "expand_less" : "expand_more")
}

function isFavouriteTypeMax(n) {
    var t, r, i;
    if (isAccountFavoriteEnabled) {
        if (t = localStorage.getItem("accountFavorites"), r = n == "league" ? 0 : 1, t != null && t != "")
            if (i = JSON.parse(t).AccountFavorites.filter(n => n.AccountFavoriteType == r), n == "league") {
                if (i.length >= accountFavouriteLeagueMax) return !0
            } else if (n == "markettype" && i.length >= accountFavouriteMarketMax) return !0;
        return !1
    }
    return !1
}

function disableOrEnableFavouritesForType(n, t) {
    var r, u, i;
    if (isAccountFavoriteEnabled && (r = document.querySelectorAll("span.material-icons-outlined.acc-fav-heart"), u = localStorage.getItem("accountFavorites"), u != null && u != "" && u != "[object Object]"))
        if (n == "league")
            if (r.length > 0)
                for (i = 0; i < r.length; i++) t == "disable" ? (r[i].getAttribute("data-favorite-type") == "groupedleague" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.add("disable-fav-acc-heart"), r[i].getAttribute("data-favorite-type") == "topleague" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.add("disable-fav-acc-heart")) : t == "enable" && (r[i].getAttribute("data-favorite-type") == "groupedleague" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.remove("disable-fav-acc-heart"), r[i].getAttribute("data-favorite-type") == "topleague" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.remove("disable-fav-acc-heart"));
            else $("#accFavs").hide();
    else if (n == "markettype" && r.length > 0)
        for (i = 0; i < r.length; i++) t == "disable" ? r[i].getAttribute("data-favorite-type") == "markettype" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.add("disable-fav-acc-heart") : t == "enable" && r[i].getAttribute("data-favorite-type") == "markettype" && r[i].getAttribute("data-is-favorite") == "false" && r[i].classList.remove("disable-fav-acc-heart")
}

function isTopLeagueHeartClick(n) {
    return n != undefined && n != undefined && n.target.classList.contains("acc-fav-heart-top-league") ? !0 : !1
}

function OpenOsirisNotificationPanel() {
    $("notifications-panel").attr("opened", "true")
}

function handleNotificationAction(n) {
    const t = n.detail.action,
        i = n.detail.actionValue;
    $("notifications-panel").removeAttr("opened");
    OnNotificationPanelActionReceived(t, i)
}

function OnNotificationPanelActionReceived(n, t) {
    switch (n.toLocaleLowerCase().replace(/\s/g, "")) {
        case "navigateto":
            window.location.assign(t);
            break;
        case "navigatenewtab":
            window.open(t);
            break;
        case "launch":
            OnLaunchContentReceived(t);
            break;
        case "account":
            window.launchInboxMessages();
            break;
        case "moreinfo":
            mybets.showAlert("More Info", t);
            break;
        default:
            console.error(`OnNotificationPanelActionReceived: Default entered with action: ${n} value: ${t}`)
    }
}

function OnLaunchContentReceived(n) {
    switch (n.toLocaleLowerCase().replace(/\s/g, "")) {
        case "chat":
            window.__CONNEXONE_LIVECHAT__.openWidget();
            break;
        case "registration":
            $("#SignUpModal").modal();
            break;
        case "login":
            sideMenu.getMenuContent("_MenuLogin", "MyAccount");
            break;
        case "deposit":
            depositModal();
            break;
        case "withdrawals":
            location.href = "/Account/WithdrawFunds";
            break;
        case "inbox":
            window.launchInboxMessages();
            break;
        case "personaldetails":
            window.launchUpdateDetails();
            break;
        case "documentverification":
            window.launchDocumentUpload();
            break;
        default:
            console.error(`OnLaunchContentReceived: Default entered with value: ${n}`)
    }
}

function updateNotificationsCount(n) {
    let t = n.detail.unread;
    t !== undefined && t !== 0 ? ($("#UnreadNotificationCount").text(t), $("#UnreadNotificationCount").show(), isMobile && $("#UnreadNotificationCount").parent().css("position", "relative")) : ($("#UnreadNotificationCount").hide(), isMobile && $("#UnreadNotificationCount").parent().css("position", "static"))
}

function hasFreeBet() {
    var n, t;
    if (isLoggedIn) {
        n = document.getElementById("hasFreeBets").value === "True";
        try {
            t = JSON.parse(localStorage.getItem("balanceState"));
            typeof t != "undefined" && (n = t.balance.BonusBalance > 0)
        } catch (i) {
            console.log(i)
        }
        return n
    }
    return !1
}

function hasFreeBet() {
    var n, t;
    if (isLoggedIn) {
        n = document.getElementById("hasFreeBets").value === "True";
        try {
            t = JSON.parse(localStorage.getItem("balanceState"));
            typeof t != "undefined" && (n = t.balance.BonusBalance > 0)
        } catch (i) {
            console.log(i)
        }
        return n
    }
    return !1
}

function getParameterByName(n, t) {
    t || (t = window.location.href);
    n = n.replace(/[\[\]]/g, "\\$&");
    var r = new RegExp("[?&]" + n + "(=([^&#]*)|&|#|$)"),
        i = r.exec(t);
    return i ? i[2] ? decodeURIComponent(i[2].replace(/\+/g, " ")) : "" : null
}

function isPlayerIdValid() {
    return PlayerAccountID != "" && PlayerAccountID != null && PlayerAccountID != constId.emptyGuid
}

function syntaxHighlightForJson(n) {
    return typeof n != "string" && (n = JSON.stringify(n, undefined, 2)), n = n.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"), n.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(n) {
        var t = "number";
        return /^"/.test(n) ? t = /:$/.test(n) ? "key" : "string" : /true|false/.test(n) ? t = "boolean" : /null/.test(n) && (t = "null"), '<span class="' + t + '">' + n + "<\/span>"
    })
}

function ficaUploadFormDisplayCallBack(n) {
    document.getElementById("ficaStatusDiv").outerHTML = n;
    fica.BindFileUploads()
}

function requestOTP(n = false) {
    var t, i;
    for (homePage.showOverlay(), t = $("#DocumentUploadLoggedOutModel_MobileNumber").val(), i = !1, n && (i = !0); t.charAt(0) === "0";) t = t.substr(1);
    var f = t.startsWith(BrandDialingCode),
        r = !1,
        u = 9;
    if (Brand == "F8A8D16A-D619-4B49-AA8C-F21211403C92" && (u = 10), f ? r = !1 : (r = t.length === u, t = BrandDialingCode + t), r) $("#docUploadErrors").text("");
    else {
        errorMessage = "Please Enter a Valid Mobile Number";
        $("#docUploadErrors").text(errorMessage);
        homePage.closeOverlay();
        return
    }
    pat.post("/DocumentUpload/_RequestLoggedOutDocumentUpload", {
        mobileNumber: t,
        isOTPSuccessful: i
    }).done(function(n) {
        $("#myOTP").html(n);
        n.includes("successfulOtp") && (document.getElementById("btnRequestOtp").style.display = "none");
        homePage.closeOverlay()
    })
}

function docReady(n) {
    document.readyState === "complete" || document.readyState === "interactive" ? setTimeout(n, 1) : document.addEventListener("DOMContentLoaded", n)
}
var tmp_stretchData, slips, ajax, cache, MAX_CACHE_SIZE, lastValidatedIdNumber, isMultiNameSelectCallSuccessfull, IncrementalPayoutLimits, SportsBonus, previousUrl, isUserBrowsing, isSearchWidgetOpen, constId, swiftEndVerificationType, global, TaxCalculation, EmailValidator, fica;
CasinoPlaceForRealCallBack = function(n) {
    $("#modal-container-casino-confirmation").html(n);
    $("#modal-container-casino-confirmation").modal("show").find(".modal-body").css({
        "-webkit-transform": "translate(-50%, -50%)",
        padding: "15px"
    });
    homePage.applyLiveInPlayColourScheme();
    homePage.closeOverlay()
};
tmp_stretchData = null;
GetBookingCodeCallBack = function(n) {
    homePage.closeOverlay();
    n != null && n.length > 0 ? ($("#modal-container-bet-confirmation").html('<div class="modal-body">' + n + "<\/div"), $("#modal-container-bet-confirmation").modal("show").find(".modal-body").css({
        "-webkit-transform": "translate(-50%, -50%)",
        padding: "15px",
        "z-index": "999999999"
    }), $("#modal-container-bet-confirmation").parent().css({
        "z-index": "999999999"
    }), $("#modal-container-bet-confirmation").off("hidden.bs.modal"), document.getElementById("modal-container-bet-confirmation") != null && (document.getElementById("modal-container-bet-confirmation").style.zIndex = "999999999")) : (document.getElementById("betslip-single-multi-error").style.display = "", document.getElementById("betslip-single-multi-error").innerText = "Unable to generate a booking code at this time. Please try again later.", language.translateAtRuntime(document.getElementById("betslip-single-multi-error"), "ErrorMessages", {
        "data-translate-key": "UnableToGeneratABookingCode"
    }))
};
GetBetslipForBookingCodeCallBack = function(n) {
    AddBookingCodeItemsToBetslip(n)
};
placeFullBetCallBack = function(n) {
    if ($("#betslip-mobile-modal").modal("hide"), $("#modal-container-bet-confirmation").html(n), $("#modal-container-bet-confirmation").modal("show").find(".modal-body").css({
            "-webkit-transform": "translate(-50%, -50%)",
            padding: "15px"
        }), clearBonusSelection(), document.getElementById("chkKeepBets").checked === !1) $("#modal-container-bet-confirmation").on("hidden.bs.modal", function() {
        ResetAndBackToBets()
    });
    homePage.applyLiveInPlayColourScheme();
    homePage.closeOverlay()
};
completeBetslip = function() {
    var n = {},
        t, i, r, u;
    return n.Outcomes = GetBetslip(), t = JSON.parse(n.Outcomes), i = GetBetslipOption("IsSingleBet"), i === !0 ? (wagerAmount = t.reduce(function(n, t) {
        return t.WagerAmount === null || typeof t.WagerAmount == "undefined" ? n : n + parseFloat(t.WagerAmount)
    }, 0), n.WagerAmount = parseFloat(wagerAmount).toFixed(2), enableWagerTax && (initialStake = t.reduce(function(n, t) {
        return t.InitialStake === null || typeof t.InitialStake == "undefined" ? n : n + parseFloat(t.InitialStake)
    }, 0), n.InitialStake = parseFloat(initialStake).toFixed(2))) : (n.WagerAmount = document.getElementById("wagerAmount").value, enableWagerTax && !checkForLite() && (n.InitialStake = document.getElementById("stakeBeforeWagerTax").value)), n.TotalOdds = parseFloat(GetBetslipOption("TotalPriceDecimal")).toFixed(4), n.IsSingleBets = i, n.StretchPotentialReturn = 0, IsStretchEnabled() && (r = GetStretchStorage(), r != "" && (u = JSON.parse(r), n.StretchPotentialReturn = GetBetslipOption("StretchPotentialReturn"), n.StretchOfferApplied = GetAppliedStretchOfferObj(u), n.StretchOfferApplied = GetAppliedStretchOfferObj(u))), n
};
getTotalPriceDecimalFromBetslip = function() {
    return parseFloat(GetBetslipOption("TotalPriceDecimal")).toFixed(4)
};
slips = document.getElementsByClassName("slip-counter");
ajax = {};
ajax.x = function() {
    var t, i, n;
    if (typeof XMLHttpRequest != "undefined") return new XMLHttpRequest;
    for (t = ["MSXML2.XmlHttp.6.0", "MSXML2.XmlHttp.5.0", "MSXML2.XmlHttp.4.0", "MSXML2.XmlHttp.3.0", "MSXML2.XmlHttp.2.0", "Microsoft.XmlHttp"], i = null, n = 0; n < t.length; n++) try {
        i = new ActiveXObject(t[n]);
        break
    } catch (r) {
        console.log("Error has orrcured: " + r)
    }
    return i
};
ajax.send = function(n, t, i, r, u) {
    u === undefined && (u = !0);
    n = n + (/\?/.test(n) ? "&" : "?") + (new Date).getTime();
    var f = ajax.x();
    f.open(i, n, u);
    f.onreadystatechange = function() {
        f.readyState === 4 && t(f.responseText)
    };
    i === "POST" && f.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    f.send(r);
    window.LastResponse = f.responseText
};
ajax.get = function(n, t, i, r) {
    var u = [];
    for (var f in t) t.hasOwnProperty(f) && u.push(encodeURIComponent(f) + "=" + encodeURIComponent(t[f]));
    ajax.send(n + (u.length ? "?" + u.join("&") : ""), i, "GET", null, r)
};
ajax.post = function(n, t, i, r) {
    var f = [];
    for (var u in t) t.hasOwnProperty(u) && f.push(encodeURIComponent(u) + "=" + encodeURIComponent(t[u]));
    ajax.send(n, i, "POST", f.join("&"), r)
};
cache = [];
MAX_CACHE_SIZE = 10;
checkForLite() || (isEmpty($(".validation-summary-errors ul li")) ? $(".alert-box").hide() : ($(".alert-box").show(), $("#validationSummarySignUp").hide(), $("#MobileNumber_tmpl-error").html($(".validation-summary-errors ul li").html()), $("#MobileNumber_tmpl-error").append("<span class='glyphicon glyphicon-info-sign'><\/span>")));
var clonedIdTypeDisplay = null,
    clonedIdDisplay = null,
    hasRegisterButtonBeenPressed = !1;
if (lastValidatedIdNumber = "", isMultiNameSelectCallSuccessfull = !1, document.addEventListener("DOMContentLoaded", function() {
        if (checkForLite()) {
            const n = document.getElementById("FirstName"),
                t = document.getElementById("LastName");
            t != null && n != null && (n.addEventListener("keyup", function() {
                n.value.trim().length < 2 && (n.value = n.value.trim())
            }), t.addEventListener("keyup", function() {
                t.value.trim().length < 2 && (t.value = t.value.trim())
            }))
        }
    }), IncrementalPayoutLimits = {
        updateMaxPayoutAmount: function(n) {
            var t = JSON.parse(localStorage.getItem("IncrementalPayoutLimits")),
                i;
            t !== null && t.length > 0 && n > 1 && (i = t.filter(t => n >= t.RangeFrom && n <= t.RangeTo), i.length === 0 && i.push(t[t.length - 1]), SetBetslipOption("MaxPayoutMultiple", i[0].PayoutLimit))
        },
        checkBetSlipSelections: function(n) {
            var t = n.filter(n => n.Ticked === !0).length;
            t > 1 && this.updateMaxPayoutAmount(t)
        },
        setIncrementalPayoutLimits: function(n) {
            localStorage.setItem("IncrementalPayoutLimits", JSON.stringify(n))
        }
    }, SportsBonus = {
        setSportsBonusMaximumPayout: function(n) {
            SetBetslipOption("SportsBonusMaximumPayout", n)
        }
    }, isFreePlayWebsite != null && isFreePlayWebsite) $(window).on("load", function() {
    setTimeout(function() {
        $("#NotLoggedInPartial").find("#partialLogin").find("#inlineLoginMobileNumberInput").find("#DialingCode").val(freeplayDefaultDialingCode);
        $("#SignUpModal").find("#DialingCode").val(freeplayDefaultDialingCode);
        $("#ResetPassword").find("#CountryCode").val(freeplayDefaultDialingCode)
    }, 1e3)
});
if (isPreferredPageEnabled) {
    previousUrl = "";
    isUserBrowsing = null;

    function n() {
        var n, t, i;
        isUserBrowsing || (n = getPreferredPage(), n !== null && window.location.pathname.length < 2 && (isUrlInPreferredWhiteList(n) ? (isUserLoggedIn || (t = new URLSearchParams(window.location.search), t.has("btag") && (i = new URL(n), i.searchParams.set("btag", t.get("btag")), n = i.href)), window.location.replace(n)) : removePreferredPage()), setUserIsBrowsingCheck(!0))
    }

    function t() {
        isUserBrowsing = getUserIsBrowsingCheck();
        isUserBrowsing === null && (isUserBrowsing = !1);
        n()
    }
    t();
    const i = new MutationObserver(function() {
        if (location.href !== previousUrl) {
            previousUrl = location.href;
            var n = getPreferredPage();
            previousUrl !== n && r()
        }
    });

    function r() {
        isUrlInPreferredWhiteList(location.href) && (isPreferredPageFirstURLEnabled ? preferredPage == null && setPageAsPreferred(location.href) : setPageAsPreferred(location.href))
    }
    i.observe(document, {
        subtree: !0,
        childList: !0
    })
}
if (renderKenticoHomePage) {
    var hasSeenLandingHomepage = localStorage.getItem("HasSeenLandingHomePage"),
        hasObserverForKenticoPageBeenDisconnectedOnce = sessionStorage.getItem("hasObserverForKenticoPageBeenDisconnectedOnce"),
        observerForDynamicContent = undefined,
        observerForMyPageElement = undefined;
    const n = new MutationObserver(function() {
        var i = document.getElementById("Kentico-HomePage"),
            r = document.getElementById("dynamicContent");
        i ? (n.disconnect(), hasSeenLandingHomepage === !1 ? (localStorage.setItem("HasSeenLandingHomePage", !0), i.style.display = "block", document.getElementById("my-page").append(document.getElementById("Kentico-HomePage")), document.getElementById("mainBody").style.display = "none", document.getElementById("ragingCarouselParent").style.display = "none", isShowingKenticoHomePage = !0) : (i.remove(), document.getElementById("mainBody").style.display = "block", document.getElementById("ragingCarouselParent").style.display = "block", isShowingKenticoHomePage = !1, t(document.getElementById("my-page"))), sessionStorage.setItem("hasObserverForKenticoPageBeenDisconnectedOnce", !0)) : hasObserverForKenticoPageBeenDisconnectedOnce && r && (n.disconnect(), t(document.getElementById("my-page")), isShowingKenticoHomePage = !1)
    });

    function i() {
        return observerForMyPageElement !== undefined ? observerForMyPageElement : observerForMyPageElement = new MutationObserver(function() {
            var n = document.getElementById("my-page");
            n && (t(n), observerForMyPageElement.disconnect())
        })
    }

    function r() {
        return observerForDynamicContent !== undefined ? observerForDynamicContent : observerForDynamicContent = new MutationObserver(function() {
            var n = document.getElementById("dynamicContent");
            n && !removeElements && u(n)
        })
    }
    hasSeenLandingHomepage == null && (hasSeenLandingHomepage = window.location.pathname.length > 2);

    function u(n) {
        var t = null;
        if (t = n === null || n === undefined ? document.getElementById("dynamicContent") : n, t && !removeElements) {
            t.classList.remove("hidden");
            try {
                observerForDynamicContent !== null && observerForDynamicContent !== undefined && observerForDynamicContent.disconnect()
            } catch (i) {
                console.error(i)
            }
        }
    }

    function t(n) {
        if (n === undefined || n === null) {
            i().observe(document, {
                attributes: !1,
                childList: !0,
                characterData: !1,
                subtree: !0
            });
            return
        }
        r().observe(n, {
            attributes: !1,
            childList: !0,
            characterData: !1,
            subtree: !0
        })
    }
    addEventListener("DOMContentLoaded", () => {
        localStorage.setItem("HasSeenLandingHomePage", !0), n !== null && n.disconnect()
    });
    n.observe(document, {
        attributes: !1,
        childList: !0,
        characterData: !1,
        subtree: !0
    })
}
isSearchWidgetOpen = !1;
window.addEventListener("click", function(n) {
    isSearchWidgetOpen && (document.getElementsByClassName("widget-flyout")[0].contains(n.target) || widgetContainer.closeWidgetFlyout())
});
$(window).resize(function() {
    checkForLite() || isMiniBetslipEnabled && (window.innerWidth > 767 ? (document.getElementById("miniBetslip") != undefined && document.getElementById("miniBetslip") != null && (document.getElementById("scroll").setAttribute("class", ""), document.getElementById("miniBetslip").style.display = "none"), document.querySelector(".ngFloatable") != undefined && document.querySelector(".ngFloatable") != null && document.querySelector(".ngFloatable").classList.remove("ngFloatable-minibetslip")) : document.getElementById("miniBetslip") != undefined && document.getElementById("miniBetslip") != null && miniBetslip())
});
document.addEventListener("click", function(n) {
    document.getElementById("moreOptions") != undefined && document.getElementById("moreOptions") != null && document.getElementById("moreOptions").style.display == "block" && (n.target.id == "moreOptions" || $(n.target).parents("#moreOptions").length ? toggleMoreFeatures("block") : n.target.id == "btnMoreFeatures" || $(n.target).parents("#btnMoreFeatures").length ? toggleMoreFeatures("block") : toggleMoreFeatures("none"))
});
window.addEventListener("handleNotificationActions", this.handleNotificationAction);
window.addEventListener("updateNotificationsCount", this.updateNotificationsCount);
$(document).ready(function() {
    var n = getParameterByName("action"),
        t = getParameterByName("actionValue");
    n !== null && t !== null && OnNotificationPanelActionReceived(n, t)
});
var SelectedTransactionTypeSourceId = "00000000-0000-0000-0000-000000000000",
    AdminSecret = undefined,
    useInternalCaptchaForAccountDetailsPopUp = undefined,
    noFileSelectedText = "No file selected.",
    proofIdSize = !0,
    proofResidenceSize = !0,
    proofIdMobileSize = !0,
    fileTypeValid = !1,
    proofResidenceMobileSize = !0;
window.promptFICANotification = !1;
CASHOUTBETS = [];
CASHOUTBETS_INITIALIZED = !1;
CASHOUT_MARGIN = .9;
MIN_CASHOUT_LIMIT = .2;
MAX_CASHOUT_LIMIT = .8;
constId = {};
constId.emptyGuid = "00000000-0000-0000-0000-000000000000";
constId.feedDataType_LIP = "00000000-0000-0000-da7a-000000580003";
constId.feedDataType_Prematch = "00000000-0000-0000-da7a-000000580001";
constId.feedDataType_LiveOutrights = "00000000-0000-0000-da7a-000000580008";
constId.BrandIdZA = "BD66EBE1-080B-4455-9094-BF0464D4ADBF";
constId.soccerId = "00000000-0000-0000-DA7A-000000550001";
constId.BetYourWay = "00000000-0000-0000-da7a-000000550072";
constId.FormulaOne = "00000000-0000-0000-da7a-000000550100";
constId.Golf = "00000000-0000-0000-da7a-000000550007";
constId.MotorSport = "00000000-0000-0000-da7a-000000550009";
constId.esportId = "00000000-0000-0000-da7a-000000550064";
constId.Trending = "00000000-0000-0000-da7a-000000550101";
constId.Accumulators = "00000000-0000-0000-da7a-000000550102";
constId.BuildABet = "00000000-0000-0000-da7a-000000710003";
constId.ResultingStatus_NotResulted = 0;
constId.ResultingStatus_Win = 1;
constId.ResultingStatus_Loss = 2;
constId.ResultingStatus_Void = 3;
constId.ResultingStatus_EarlySettlement = 6;
constId.ResultingStatus_ManualResultingRequired = 7;
constId.ResultingStatus_EarlyCashout = 9;
constId.ResultingStatus_WinWithDeadHeatFactor = 10;
constId.LiveOutrightSports = [constId.Golf.toLowerCase(), constId.MotorSport.toLowerCase(), constId.FormulaOne.toLowerCase()];
window.promptForCompleteProfile = !1;
constId.OutcomeDisplaySorting_Default = 0;
constId.OutcomeDisplaySorting_Title = 1;
constId.OutcomeDisplaySorting_TitleDesc = 2;
constId.OutcomeDisplaySorting_PriceDecimal = 3;
constId.OutcomeDisplaySorting_PriceDecimalDesc = 4;
constId.OutcomeDisplaySorting_SBV = 5;
constId.OutcomeDisplaySorting_SBVDesc = 6;
constId.OutcomeDisplaySorting_FeedId = 7;
constId.OutcomeDisplaySorting_FeedIdDesc = 8;
swiftEndVerificationType = {};
swiftEndVerificationType.PHONE_NUMBER = "Phone Number";
swiftEndVerificationType.NATIONAL_IDENTITY_NUMBER = "National Identity Number";
swiftEndVerificationType.BABK_VERIFICATION_NUMBER = "Bank Verification Number";
constId.BrandId_Nigeria = "F8A8D16A-D619-4B49-AA8C-F21211403C92";
global = {
    setCookie: function(n, t, i) {
        var r = new Date,
            u;
        r.setTime(r.getTime() + i * 864e5);
        u = "expires=" + r.toUTCString();
        document.cookie = n + "=" + t.replace(/"/g, "'") + ";" + u + ";path=/"
    },
    setCookieWithAllSubDomain: function(n, t, i) {
        var r = new Date,
            u;
        r.setTime(r.getTime() + i * 864e5);
        u = "expires=" + r.toUTCString();
        document.cookie = n + "=" + t.replace(/"/g, "'") + ";" + u + ";path=/; hostOnly=false; domain=" + `.${window.location.host.toString()}`
    },
    getCookie: function(n) {
        for (var t, r = n + "=", u = document.cookie.split(";"), i = 0; i < u.length; i++) {
            for (t = u[i]; t.charAt(0) === " ";) t = t.substring(1);
            if (t.indexOf(r) === 0) return t.substring(r.length, t.length).replace(/'/g, '"')
        }
        return ""
    },
    eraseCookie: function(n) {
        global.setCookie(n, "", -1)
    },
    isMobile: function() {
        var n = $(window).width();
        return n > 768 ? !1 : !0
    },
    PostAppMessage: function(n) {
        removeElements && (this.getCookie("isIosApp") === "true" ? webkit.messageHandlers.PostData.postMessage(n) : window.Data.postData(n))
    }
};
TaxCalculation = {};
TaxCalculation.Winnings = 2;
TaxCalculation.Payout = 3;
EmailValidator = {
    validateEmail: function() {
        var n = document.querySelector(".email-input").value;
        return n === "" || /(.+)@(.+){2,}\.(.+){3,}/.test(n) ? !0 : !1
    }
};
fica = {
    toggleFICAUploadActive: function(n, t) {
        var i = !1,
            r = document.getElementById("proofIdFile").innerHTML,
            u = document.getElementById("proofIdFileMobile").innerHTML;
        r !== "" && r !== noFileSelectedText ? i = !0 : "";
        u !== "" && u !== noFileSelectedText ? i = !0 : "";
        i && proofIdMobileSize && n && t ? (document.getElementById("fica-submission-button-mobile").disabled = !1, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button-mobile").disabled = !0, document.getElementById("fileuploads").className = "fica-subheading-disabled");
        i && proofIdSize && n && t ? (document.getElementById("fica-submission-button").disabled = !1, document.getElementById("fileuploads").className = "fica-subheading") : (document.getElementById("fica-submission-button").disabled = !0, document.getElementById("fileuploads").className = "fica-subheading-disabled")
    },
    toggleDocumentUploadActive: function(n, t, i, r) {
        var u = document.getElementById(r).innerHTML,
            f = u !== "" && u !== noFileSelectedText;
        document.getElementById(i).disabled = !(f && n && t)
    },
    setDisplay: function(n, t) {
        var i = t.split("\\");
        t.length === 0 ? document.getElementById(n).innerHTML = noFileSelectedText : i.length > 0 && i.constructor === Array ? (t = i[i.length - 1], document.getElementById(n).innerHTML = t) : "";
        fica.toggleFICAUploadActive()
    },
    closeOverlay: function() {
        jQuery(".loading").hide();
        jQuery("#modalloading").hide()
    },
    showFICAPopup: function() {
        fica.BindFileUploads();
        $("#fica-popup-modal").modal({
            backdrop: "static",
            keyboard: !1
        })
    },
    VerifyFicaDetails: function() {
        pat.get("/Account/VerifyFicaDetails").done(function(n) {
            window.promptFICANotification = n.toLowerCase() === "true"
        })
    },
    showFICAStatusConfirmation: function() {
        window.promptFICANotification && !checkForLite() && $("#modal-container-ficastatus-confirmation").modal().show()
    },
    FicaUploadFormDisplay: function(n) {
        checkForLite() ? docUploadEnabled ? location.href = "/DocumentUpload" : ajax.post("/Account/SubmitFICADetails", null, ficaUploadFormDisplayCallBack) : pat.post("/Account/SubmitFICADetails", null, {
            dataType: "html"
        }).done(function(t) {
            typeof n != "undefined" && n.toLowerCase() === "true" ? ($("#OperaminiModalHolderContent").html(t), $("#OperaminiModalHolderContent").find("#fica-modal,#fica-popup-modal").attr("id", "").removeClass("modal"), $("html,body").removeClass("modal-open"), $("#main").css("margin-top", "0px"), $("#OperaminiModalHolder").show(), $("#ficaModal").hide()) : docUploadEnabled === "True" ? location.href = "/DocumentUpload" : $("#modal-container-ficastatus-upload").html(t).modal()
        })
    },
    DelayFicaNotification: function(n) {
        typeof n != "undefined" && n.toLowerCase() === "true" ? window.location.href = "/" : pat.post("/Account/DelayFICANotification", null, {
            dataType: "html"
        }).done(function() {
            window.promptFICANotification = !1
        })
    },
    ficaButtonBack: function() {
        $("#OperaminiModalHolder").hide();
        $("#ficaModal").show()
    },
    submitFicaDetailsAsync: function(n, t) {
        var r, i, e, u, f;
        t.toLowerCase() === "false" && (r = null, i = n === "true" ? $("#ficaProofMobile") : $("#ficaProof"), e = i.attr("action"), homePage.showOverlay(), u = "", f = "", i.attr("enctype") === "multipart/form-data" ? (r = new FormData(i.get(0)), u = !1, f = !1) : "", $.ajax({
            type: "POST",
            url: e,
            data: r,
            dataType: "html",
            contentType: u,
            processData: f,
            success: function(n) {
                t.toLowerCase() === "true" ? window.location.href = "/Account/MyAccount" : ($(".modal-backdrop.fade.in").remove(), $("#fica-modal-upload-items").html(n), $("#fica-modal-upload-items").hide(), $("#modal-container-ficauploadresult").show(), fica.closeOverlay())
            },
            error: function(n, t, i) {
                $("#subsection").innerHTML = i;
                $("#subsection").show();
                homePage.closeOverlay()
            }
        }))
    },
    submitFicaDetailsKICAsync: function(n, t) {
        var u = null,
            f, e, i, r;
        f = n === "true" ? $("#ficaProofMobile") : $("#ficaProof");
        e = "/account/SubmitFICADetailsKIC";
        homePage.showOverlay();
        i = "";
        r = "";
        u = new FormData(f.get(0));
        i = !1;
        r = !1;
        $.ajax({
            type: "POST",
            url: e,
            data: u,
            dataType: "html",
            contentType: i,
            processData: r,
            success: function(n) {
                if (homePage.closeOverlay(), t.toLowerCase() === "true") window.location.reload();
                else {
                    $("#confirmModalContent").html(n);
                    $("#confirmModal").modal("show");
                    $("#confirmModal").on("hidden.bs.modal", function() {
                        window.location.reload()
                    })
                }
            },
            error: function(n, t, i) {
                $("#subsection").innerHTML = i;
                $("#subsection").show();
                homePage.closeOverlay()
            }
        })
    },
    showFicaComplete: function() {
        checkForLite() || ($("#modal-container-ficauploadresult").modal(), $("#modal-container-ficauploadresult").show(), $("#modal-container-ficastatus-upload").hide())
    },
    clearFICAValidationError: function(n) {
        var t, u, i, r, f;
        n !== null ? (t = document.getElementById(n), t !== null && t.remove(), u = document.querySelectorAll("#fica-errors ul li").length, u === 0 && (i = document.querySelector("#fica-errors div"), i.parentNode.removeChild(i), document.querySelector("#fica-errors div").append("validation-summary-valid"), r = document.querySelector("#fica-errors div"), r.classList.remove("validation-summary-errors"), r.classList.add("validation-summary-valid"))) : (document.querySelectorAll("#fica-errors ul>li").forEach(n => n.remove()), f = document.querySelector("#fica-errors div"), f.classList.remove("validation-summary-errors"), document.querySelector("#fica-errors div").classList.add("validation-summary-valid"))
    },
    setFICAValidationError: function(n, t) {
        var r = document.querySelector("#fica-errors div");
        r.classList.remove("validation-summary-valid");
        r.classList.add("validation-summary-errors");
        let i = document.createElement("li");
        i.setAttribute("id", t);
        i.innerHTML = n;
        document.querySelector("#fica-errors ul").appendChild(i)
    },
    BindFileUploads: function() {
        var n = document.getElementById("proofId"),
            t = document.getElementById("proofIdMobile");
        n.addEventListener("change", function() {
            fica.validateUpload("proofId", this)
        });
        t.addEventListener("change", function() {
            fica.validateUpload("proofIdMobile", this)
        })
    },
    validateUpload: function(n, t) {
        fica.validateDocument(n, t, "proof-of-id-error", "The ID proof document is too large.", !1)
    },
    validateDocument: function(n, t, i, r, u, f, e) {
        var o = !0,
            s = !0,
            h, c;
        if (fica.clearFICAValidationError(i), fica.clearFICAValidationError("file-type-error"), t.files !== null && t.files.length > 0) {
            let n = t.files[0].size / 1024,
                u = minDocumentUploadFileSize == null || minDocumentUploadFileSize == undefined ? 0 : minDocumentUploadFileSize;
            this.between(n, u, 4096) || (s = !1, fica.setFICAValidationError(r, i), checkForLite() || language.translateAtRuntime($(i), "SubmitFICADetailsDialog", {
                "data-translate-key": "IDProofdocumentTooLarge"
            }));
            h = t.getAttribute("accept").toLowerCase().split(",");
            c = "." + t.files[0].name.toLowerCase().split(".").pop();
            h === null || h.includes(c) || (o = !1, fica.setFICAValidationError("The selected document format/file-type is not supported. Please see below for acceptable file types", "file-type-error"), checkForLite() || language.translateAtRuntime($("#file-type-error"), "SubmitFICADetailsDialog", {
                "data-translate-key": "SelectedFormatNotSupported"
            }))
        }
        u ? fica.toggleDocumentUploadActive(o, s, f, e) : fica.toggleFICAUploadActive(o, s)
    },
    submitDocumentUploadDetailsAsync: function(n, t = "uploadSection") {
        var r = document.getElementById(n),
            f = document.getElementById("DocumentUploadLoggedOutModel_OTPVerificationCode"),
            o = null,
            u, e, i;
        f != undefined && f != null && (o = f.cloneNode(!0), r.appendChild(o));
        u = document.getElementById("DocumentUploadLoggedOutModel_MobileNumber");
        e = null;
        u != undefined && u != null && (e = u.cloneNode(!0), r.appendChild(e));
        r.getAttribute("enctype") === "multipart/form-data" && (i = new XMLHttpRequest, i.open(r.method, r.action, !0), i.onreadystatechange = function() {
            i.readyState == 4 && i.status == 200 && i.responseText !== null && i.responseText.trim() !== "" && (checkForLite() || homePage.closeOverlay(), document.getElementById(t).innerHTML = i.responseText, i.responseText.includes("documentForceReload") && (i.responseText.includes("documentFinChatResponseText") || i.responseText.includes("documentResponseText") ? setTimeout(function() {
                fica.SwitchToViewStatusOnUploadSuccess()
            }, 4e3) : location.reload()))
        }, i.send(new FormData(r)));
        u != undefined && u != null && e.remove();
        f != undefined && f != null && o.remove()
    },
    SwitchToViewStatusOnUploadSuccess: function() {
        document.getElementById("uploadSectionTab").classList.contains("active") ? (document.getElementById("statusSectionTab").classList.add("active"), document.getElementById("uploadSectionTab").classList.remove("active"), document.getElementById("uploadSection").classList.remove("active"), document.getElementById("statusSection").classList.add("active"), document.getElementById("statusSection").classList.add("in"), document.getElementById("uploadSection").classList.remove("in"), fica.getDocumentsInfoForAccount(1)) : (document.getElementById("uploadSectionTab").classList.add("active"), document.getElementById("statusSectionTab").classList.remove("active"), document.getElementById("uploadSection").classList.add("active"), document.getElementById("statusSection").classList.add("hidden"), document.getElementById("statusSection").classList.remove("in"), document.getElementById("uploadSection").classList.add("in"), document.getElementsByClassName("documentStatus")[0].style.display = "none", document.getElementById("documentResponseText") !== null && document.getElementById("documentResponseText").classList.add("hidden"))
    },
    reloadUploadSection: function() {
        checkForLite() || homePage.showOverlay();
        $.get("/DocumentUpload/GetUploadSectionView", function(n) {
            checkForLite() ? fica.toggleSectionTabs(!1) : homePage.closeOverlay();
            document.getElementById("uploadSection").innerHTML = n
        })
    },
    BindFileUpload: function(n, t, i, r) {
        n !== null && typeof n != "undefined" && (fica.setFileNameDisplay(r, n.value), fica.validateDocument(n.id, n, "proof-of-document-error", t, !0, i, r))
    },
    setFileNameDisplay: function(n, t) {
        var i = t.split("\\");
        t.length === 0 ? document.getElementById(n).innerHTML = noFileSelectedText : i.length > 0 && i.constructor === Array && (t = i[i.length - 1], document.getElementById(n).innerHTML = t);
        document.getElementById("documentResponseText") !== null && document.getElementById("documentResponseText").classList.add("hidden")
    },
    getDocumentsInfoForAccount: function(n = 1) {
        checkForLite() || homePage.showOverlay();
        ajax.get("/DocumentUpload/GetDocumentsInfoForAccount", {
            pageNo: n
        }, function(n) {
            checkForLite() ? fica.toggleSectionTabs(!1) : homePage.closeOverlay();
            document.getElementById("statusSection").innerHTML = n;
            var t = document.getElementById("CurrentPage") !== null ? parseInt(document.getElementById("CurrentPage").value) : null,
                i = document.getElementById("PageSize") !== null ? parseInt(document.getElementById("PageSize").value) : 0,
                r = document.getElementById("RecordTotal") !== null ? parseInt(document.getElementById("RecordTotal").value) : 0;
            r > i ? document.getElementById("showMoreDiv").classList.remove("hidden") : document.getElementById("showMoreDiv").classList.add("hidden");
            t !== null && (document.getElementById("showPrevious").disabled = t == 1, account.isShowMoreVisible(t, i, r))
        }, !0)
    },
    toggleSectionTabs: function(n) {
        n ? (document.getElementById("btnStatusToggle").classList.remove("active"), document.getElementById("btnUploadToggle").classList.add("active"), document.getElementById("uploadSection").classList.remove("hidden"), document.getElementById("statusSection").classList.add("hidden")) : (document.getElementById("btnUploadToggle").classList.remove("active"), document.getElementById("btnStatusToggle").classList.add("active"), document.getElementById("uploadSection").classList.add("hidden"), document.getElementById("statusSection").classList.remove("hidden"))
    },
    viewDocumentFile: function(n) {
        checkForLite() || homePage.showOverlay();
        ajax.get("/DocumentUpload/GetDocumentFile", {
            documentId: n
        }, function(n) {
            checkForLite() || ($("#document-file-modal").html(n), $("#document-file-modal").modal(), homePage.closeOverlay())
        }, !0)
    },
    getNextPage: function() {
        var n = parseInt(document.getElementById("CurrentPage").value);
        n++;
        document.getElementById("CurrentPage").value = n;
        this.getDocumentsInfoForAccount(n)
    },
    getPreviousPage: function() {
        var n = parseInt(document.getElementById("CurrentPage").value);
        n--;
        document.getElementById("CurrentPage").value = n < 1 ? 1 : n;
        this.getDocumentsInfoForAccount(n)
    },
    showFicaModalContainer: function() {
        $("#modal-container-ficastatus-confirmation").modal().show();
        sideMenu.closeMenu()
    },
    between: function(n, t, i) {
        return n >= t && n <= i
    }
};
var activeRGTimePeriodButtonDictionary = {},
    rgCurrentLimitValuesDictionary = {},
    resultHtml = {},
    limitInputFieldMaxValueByInterval = {},
    responsibleGamingManager = {
        setIntervalComponent: function(n, t, i, r, u, f, e, o, s, h, c) {
            var y, l, a, v;
            document.getElementById(i).value = n;
            y = i in activeRGTimePeriodButtonDictionary;
            y ? (document.getElementById(activeRGTimePeriodButtonDictionary[i]).classList.remove("rg-active-period-button"), this.setActiveTimePeriodButton(t, i)) : this.setActiveTimePeriodButton(t, i);
            r && u && f && this.synchronizeLimitTextData(r, u, f);
            e && o && document.getElementById(o) != null ? (l = document.getElementById(o).value, l = l ? ToThousandSeparator(l) : "0.00", document.getElementById(e).innerText = l) : e && (document.getElementById(e).innerText = "0.00");
            s && h && (a = document.getElementById(s).value.toLowerCase() == "true", v = document.getElementById(h).value.toLowerCase() == "true", a ? a && !v ? (document.getElementById(f).disable = !0, document.getElementById(c).disable = !0) : v ? (document.getElementById(f).disable = !1, document.getElementById(c).disable = !1) : console.warn("not supposed to reach this...") : (document.getElementById(f).disable = !1, document.getElementById(c).disable = !1))
        },
        synchronizeLimitTextData: function(n, t, i) {
            if (t && n) {
                var r = document.getElementById(n) == null ? 0 : document.getElementById(n).value;
                r = r ? ToThousandSeparator(r) : "0.00";
                document.getElementById(t).innerText = r;
                document.contains(document.getElementById(i)) && (document.getElementById(i).value = r.toLocaleString().replace(/,/g, ""))
            } else t && (document.getElementById(t).innerText = "0.00")
        },
        setActiveTimePeriodButton: function(n, t) {
            document.getElementById(n).classList.add("rg-active-period-button");
            activeRGTimePeriodButtonDictionary[t] = n
        },
        onResponsibleGamingBtnClick: function(n, t, i) {
            var u = !1,
                f, r;
            u = checkForLite() ? this.setLiteValidations(n) : $(`#${n}`).valid();
            u && (checkForLite() || homePage.showOverlay(), f = document.getElementById(n), data = Array.from(new FormData(f), n => n.map(encodeURIComponent).join("=")).join("&"), r = new XMLHttpRequest, r.open("POST", "/ResponsibleGaming/" + t, !0), r.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), r.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    if (checkForLite()) {
                        this.response.includes("exclusionLogoutRedirect") && (window.location.href = "/Account/LogOut");
                        document.getElementById(i).innerHTML = this.response;
                        ["DepositLimitTimeIntervalId", "LossLimitTimeIntervalId", "WagerLimitTimeIntervalId", "IntervalComponent"].forEach(n => {
                            var t = activeRGTimePeriodButtonDictionary[n];
                            document.getElementById(t).classList.add("rg-active-period-button")
                        })
                    } else $(`#${i}`).html(this.response), homePage.closeOverlay();
                    this.response.includes("sessionLimitSuccess") && (localStorage.removeItem("totalSeconds"), location.reload())
                }
            }, r.send(data))
        },
        setCurrentLimitValue: function(n, t) {
            rgCurrentLimitValuesDictionary[n] = t
        },
        onConfirmBtnClick: function(n, t, i, r, u, f, e) {
            var h = !1,
                o, s, c;
            return h = checkForLite() ? this.setLiteValidations(n) : $(`#${n}`).valid(), h && (typeof e != "undefined" && e !== "" ? o = "<strong>" + e + "<\/strong>" : (s = document.getElementById(n).getElementsByClassName("periodValue")[0].value, s = Number(s).toLocaleString(), c = document.getElementById(n).getElementsByClassName("rg-active-period-button")[0].textContent, o = "<strong>" + s + " " + c + "?<\/strong>"), checkForLite() ? (document.getElementById(n).getElementsByClassName("ConfirmExclusion")[0].innerHTML = u + o + "<br/>" + f, document.getElementById(n).getElementsByClassName("LiteExclusionConfirm")[0].classList.remove("hidden")) : ($("#genericModalHeader").html(r), $("#genericMiddleContent").html(u + o).append("<br/>" + f), t === "SetSelfExclusion" && (language.translateAtRuntime($("#selfExclusionHeaderPopup"), "ResponsibleGamingContent", {
                "data-translate-key": "SelfExclusionHeaderPopup"
            }), language.translateAtRuntime($("#exclusionConfirmPopupContent"), "ResponsibleGamingContent", {
                "data-translate-key": "ExclusionConfirmPopupContent"
            }), language.translateAtRuntime($("#exclusionContentPleaseNote"), "ResponsibleGamingContent", {
                "data-translate-key": "ExclusionContentPleaseNote"
            })), t === "SetCoolingOffPeriod" && (language.translateAtRuntime($("#coolOffHeaderPopup"), "ResponsibleGamingContent", {
                "data-translate-key": "CoolOffHeaderPopup"
            }), language.translateAtRuntime($("#exclusionConfirmPopupContent"), "ResponsibleGamingContent", {
                "data-translate-key": "ExclusionConfirmPopupContent"
            }), language.translateAtRuntime($("#exclusionContentPleaseNote"), "ResponsibleGamingContent", {
                "data-translate-key": "ExclusionContentPleaseNote"
            })), $("#genericConfirmBtns").show(), $("#btnConfirm").text("Confirm"), language.translateAtRuntime($("#btnConfirm"), "ResponsibleGamingContent", {
                "data-translate-key": "ConfirmText"
            }), $("#btn-back").text("Cancel"), language.translateAtRuntime($("#btn-back"), "ResponsibleGamingContent", {
                "data-translate-key": "CancelText"
            }), $("#generic-modal").modal(), $("#btnConfirm").off("click").click(function() {
                responsibleGamingManager.onResponsibleGamingBtnClick(n, t, i);
                $("#generic-modal").modal("hide")
            }))), !1
        },
        setLiteValidations: function(n) {
            var t = document.getElementById(n).getElementsByClassName("ValueValidation")[0],
                r = document.getElementById(n).getElementsByClassName("error-message")[0],
                i = t.value !== "" && t.value !== undefined;
            return r.innerHTML = i ? "" : t.getAttribute("data-val-required"), i
        },
        executeSessionTimer: function(n) {
            var t, i;
            if (n > 0) {
                t = localStorage.getItem("totalSeconds") ? localStorage.getItem("totalSeconds") : (n * 60 - 60).toString();

                function u() {
                    var e, o, u, f;
                    if (t <= 0) {
                        if (localStorage.removeItem("totalSeconds"), clearInterval(i), e = localStorage.getItem("ageVerificationEnabled") == "true", o = localStorage.getItem("showAgeVerification") == "true", sessionTimerEnabled && n > 0)
                            if (e && o) r();
                            else if (checkForLite()) f = document.getElementById("realityCheckModal"), document.getElementById("realityCheckPartial").classList.remove("hidden"), f.classList.replace("overlay-hidden", "overlay-visible"), document.getElementById("btnKeepPlaying").addEventListener("click", function() {
                            r();
                            responsibleGamingManager.hideModalDisplay(f)
                        }), document.getElementById("closePopup").addEventListener("click", function() {
                            r();
                            responsibleGamingManager.hideModalDisplay(f)
                        });
                        else {
                            $("#rgGamingLimitReached-modal").modal();
                            $("#rgGamingLimitReachedModalHeader").html("Reality Check");
                            $("#rgInfoModalMiddleContent").html($("#realityCheckPartial").html());
                            $("#rgConfirmBtns").hide();
                            $("#rgGamingLimitReached-modal").modal("show");
                            u = $("#rgGamingLimitReached-modal").data("bs.modal").options;
                            typeof u != "undefined" && u !== null && (u.backdrop = "static");
                            $("#btnKeepPlaying").click(function() {
                                r();
                                $("#realityCheckPartial").hide()
                            });
                            $("#rgGamingLimitReached-modal").on("hidden.bs.modal", function() {
                                r();
                                $("#realityCheckPartial").hide()
                            })
                        }
                    } else t = t - 60, localStorage.setItem("totalSeconds", t)
                }

                function r() {
                    clearInterval(i);
                    sessionTimerEnabled && n > 0 && (t = localStorage.getItem("totalSeconds") ? localStorage.getItem("totalSeconds") : (n * 60 - 60).toString(), i = setInterval(u, 6e4))
                }
                i = setInterval(u, 6e4)
            }
        },
        onVerifyAgeBtnClick: function(n) {
            var u, f;
            n.preventDefault();
            var t = document.getElementsByClassName("DOBDropDownDay")[0].value,
                i = document.getElementsByClassName("DOBDropDownMonth")[0].value,
                r = document.getElementsByClassName("DOBDropDownYear")[0].value;
            return this.isNullOrEmptyArray(t, i, r) ? (document.getElementById("dob-error").classList.remove("hidden"), document.getElementById("dob-error").innerText = "Date of Birth field cannot be empty.", language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                "data-translate-key": "EmptyDoB"
            })) : (u = isValid(t, i, r), u ? (f = r + "-" + i + "-" + t + " 00:00", document.getElementById("btnProceed").disabled = !0, ajax.post("/ResponsibleGaming/VerifyAgeForAccount", {
                dateOfBirth: f
            }, function(n) {
                var t = JSON.parse(n),
                    i, r;
                t.Success ? (i = t.NumberOfAttempts, r = t.MaxNumberOfAttempts, t.IsValidAge ? (localStorage.setItem("showAgeVerification", !1), checkForLite() ? location.reload() : $("#generic-modal").modal("hide")) : t.MaxNumberOfAttemptsExceeded || t.IsAccountLocked ? location.href = "Account/Logout" : t.MaxNumberOfAttemptsExceeded || t.IsValidAge || (document.getElementById("dob-error").classList.remove("hidden"), document.getElementById("dob-error").innerText = " You have entered an incorrect Date of Birth, your account will be locked after " + r + " attempts. You are on attempt " + i, language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                    "data-translate-key": "IncorrectDoB",
                    "data-translate-type": "generic-html",
                    "data-translate-value-0": r,
                    "data-translate-value-1": i
                }))) : (document.getElementById("dob-error").classList.remove("hidden"), document.getElementById("dob-error").innerText = t.ErrorMessage, language.translateAtRuntime(document.getElementById("dob-error"), "ErrorMessages", {
                    "data-translate-key": "AgeVerificationError"
                }));
                document.getElementById("btnProceed").disabled = !1
            })) : checkForLite() && (document.getElementById("dob-error").classList.remove("hidden"), document.getElementById("dob-error").innerText = "Please enter a valid date of birth.")), !1
        },
        onChangedInterval: function(n, t, i) {
            limitInputFieldMaxValueByInterval[n] = t;
            this.OnChangeEvent(n, i, document.getElementById(n).value)
        },
        OnChangeEvent: function(n, t, i) {
            var r = limitInputFieldMaxValueByInterval[n];
            r && t && i && (document.getElementById(t).disabled = i > r ? !0 : !1)
        },
        logOut: function() {
            checkForLite() || homePage.logout();
            window.location.href = "/Account/LogOut"
        },
        isNullOrEmpty: function(n) {
            return n === null || n.trim() === ""
        },
        isNullOrEmptyArray: function(...n) {
            return n !== null ? n.includes(null) || n.includes("") : !0
        },
        hideModalDisplay: function(n) {
            n.classList.replace("overlay-visible", "overlay-hidden");
            document.getElementById("realityCheckPartial").classList.add("hidden")
        }
    };
docReady(function() {
    isUserLoggedIn && checkForLite() && ageVerificationEnabled && global.getCookie("showAgeVerification") === "true" && document.location.pathname.indexOf("ThankYou") == -1 && (document.getElementById("main").textContent = "", document.getElementById("ageVerificationContent").classList.remove("hidden"), document.getElementsByClassName("main-header")[0].classList.add("disable-section"))
})