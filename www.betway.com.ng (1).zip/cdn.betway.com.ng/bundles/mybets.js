var accordionFilter, mybets = {
    currentJSON: [],
    jsGridMybetSettings: function() {
        $("#jsGrid").jsGrid({
            width: "100%",
            pageSize: 10,
            inserting: !1,
            editing: !1,
            sorting: !0,
            paging: !0
        })
    },
    linkToBetInfoForBetslipSequenceId: function(n, t) {
        homePage.showOverlay();
        pat.get("/MyBets/GetBetInfoLinkForBetslipSequenceId", {
            betslipSequenceId: n,
            settlementStatus: t
        }).done(function(n) {
            $("#BetslipInfoFromSummary").html(n);
            $("#BetslipSummaryPopUp").css("display", "block");
            homePage.closeOverlay()
        })
    },
    closeBetslip: function() {
        $("#BetslipSummaryPopUp").css("display", "none")
    },
    loadBets: function(n, t) {
        n === "open" ? mybets.getOpenSports(t) : mybets.getSettledSports(t)
    },
    getOpenSports: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = JSON.parse(n);
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetslipSequenceId",
                type: "number",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wager Amount",
                width: 200,
                align: "center"
            }, {
                name: "PotentialReturnAmount",
                type: "number",
                title: "Potential Return",
                width: 200,
                align: "center"
            }, {
                name: "CreatedDateTime",
                type: "date",
                myCustomProperty: "bar",
                title: "Date Placed",
                width: 250,
                align: "center"
            }, {
                name: "BetslipSequenceId",
                type: "button",
                width: 150,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    getSettledSports: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = n;
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetslipSequenceId",
                type: "number",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wager Amount",
                width: 200,
                align: "center"
            }, {
                name: "ActualReturnAmount",
                type: "number",
                title: "Actual Return",
                width: 200,
                align: "center"
            }, {
                name: "SettlementDateTime",
                type: "date",
                myCustomProperty: "bar",
                title: "Date Settled",
                width: 250,
                align: "center"
            }, {
                type: "control",
                width: 150,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    getOpenBetgames: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = n;
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetId",
                type: "text",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "BetDescription",
                type: "text",
                title: "Bet Description",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "BetOdds",
                type: "text",
                title: "Odds",
                width: 150,
                align: "center",
                validate: "required"
            }, {
                name: "DrawTime",
                type: "date",
                title: "Draw Time",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wagered Amount",
                width: 200,
                align: "center"
            }, {
                name: "PotentialReturnAmount",
                type: "number",
                title: "Potential Return",
                width: 200,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    getSettledBetgames: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = n;
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetId",
                type: "text",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "BetDescription",
                type: "text",
                title: "Bet Description",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "BetOdds",
                type: "text",
                title: "Odds",
                width: 150,
                align: "center",
                validate: "required"
            }, {
                name: "DrawTime",
                type: "date",
                title: "Draw Time",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wagered Amount",
                width: 200,
                align: "center"
            }, {
                name: "ActualReturnAmount",
                type: "number",
                title: "Actual Return",
                width: 200,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    getOpenVirtuals: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = n;
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetslipSequenceId",
                type: "number",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wager Amount",
                width: 200,
                align: "center"
            }, {
                name: "PotentialReturnAmount",
                type: "number",
                title: "Potential Return",
                width: 200,
                align: "center"
            }, {
                name: "CreatedDateTime",
                type: "date",
                myCustomProperty: "bar",
                title: "Date Placed",
                width: 250,
                align: "center"
            }, {
                type: "control",
                width: 150,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    getSettledVirtuals: function(n) {
        mybets.jsGridMybetSettings();
        mybets.currentJSON = n;
        $("#jsGrid").jsGrid({
            data: JSON.parse(n),
            fields: [{
                name: "BetslipSequenceId",
                type: "number",
                title: "Bet ID",
                width: 200,
                align: "center",
                validate: "required"
            }, {
                name: "WagerAmount",
                type: "number",
                title: "Wager Amount",
                width: 200,
                align: "center"
            }, {
                name: "ActualReturnAmount",
                type: "number",
                title: "Actual Return",
                width: 200,
                align: "center"
            }, {
                name: "SettlementDateTime",
                type: "date",
                myCustomProperty: "bar",
                title: "Date Settled",
                width: 250,
                align: "center"
            }, {
                type: "control",
                width: 150,
                align: "center"
            }]
        });
        $("#jsGrid").jsGrid("refresh")
    },
    testing: function(n) {
        var t = _.findWhere(mybets.currentJSON, {
            BetslipSequenceId: n
        });
        $("#details-" + n).parent().parent().after("<tr id='subGrid-" + n + "'><\/tr>");
        $("#subGrid-" + n).jsGrid({
            width: "100%",
            pageSize: 10,
            inserting: !1,
            editing: !1,
            sorting: !0,
            paging: !0,
            data: t.Bets,
            fields: [{
                name: "SportTitle",
                type: "text",
                title: "Sport",
                width: 100,
                align: "center",
                validate: "required"
            }, {
                name: "EventTitle",
                type: "text",
                title: "Event",
                width: 100,
                align: "center"
            }, {
                name: "LeagueTitle",
                type: "text",
                title: "League",
                width: 100,
                align: "center"
            }, {
                name: "MarketTitle",
                type: "text",
                title: "Market Type",
                width: 150,
                align: "center"
            }, {
                name: "MarketTypeCategory",
                type: "text",
                title: "Live/Prematch",
                width: 150,
                align: "center"
            }, {
                name: "SelectOutcome",
                type: "text",
                title: "Selection",
                width: 150,
                align: "center"
            }, {
                name: "ActualWinner",
                type: "text",
                title: "Winning Selection",
                width: 150,
                align: "center"
            }, {
                name: "PriceDecimal",
                type: "number",
                title: "Odds",
                width: 150,
                align: "center"
            }]
        })
    },
    getBetslipsToContent: function(n) {
        homePage.showOverlay();
        var t = "open";
        if ($("#openTab").hasClass("active") || (t = "settled"), n === "Sport" && newMyBetsEnabled && isPlayerIdValid()) {
            mybets.getBetslipsForMyBetsView(t, "All", null, !0, n);
            return
        }
        pat.get("/MyBets/GetBetslipsForContent", {
            category: n,
            state: t
        }).done(function(n) {
            homePage.closeOverlay();
            $(".default-bets").html(n);
            screen.width <= 786 ? homePage.anchorToId("#accountOptions") : homePage.anchorToTop()
        })
    },
    getBetslipsToContentByState: function(n, t, i, r) {
        homePage.showOverlay();
        i = typeof i != "undefined" && i !== null ? i.replace(" ", "") : "";
        var u = "Sport";
        if ($("#cat_Betgames").hasClass("active") || $("#cat_Betgames").hasClass("selected") ? u = "Betgames" : $("#cat_VirtualBets").hasClass("active") || $("#cat_VirtualBets").hasClass("selected") ? u = "Virtual Bets" : $("#cat_Jackpot").hasClass("active") || $("#cat_Jackpot").hasClass("selected") ? u = "Jackpot" : $("#cat_Bitville").hasClass("active") || $("#cat_Bitville").hasClass("selected") ? u = "Lucky Numbers" : $("#cat_GoldenRace").hasClass("active") || $("#cat_GoldenRace").hasClass("selected") ? u = "GoldenRace" : $("#cat_TvBet").hasClass("active") || $("#cat_TvBet").hasClass("selected") ? u = "TvBet" : $("#cat_RRJackpot").hasClass("active") || $("#cat_RRJackpot").hasClass("selected") ? u = "Betway Jackpots" : $("#cat_FreeJackpots").hasClass("active") || $("#cat_FreeJackpots").hasClass("selected") ? u = "Free Jackpots" : $("#cat_RRFOC").hasClass("active") || $("#cat_RRFOC").hasClass("selected") ? u = "Fixed Odds Contingencies" : ($("#cat_HorseRacing").hasClass("active") || $("#cat_HorseRacing").hasClass("selected")) && (u = "Horse Racing"), $(".mg-tab2").removeClass("active"), $("#out_" + i).addClass("active"), u === "Sport" && newMyBetsEnabled && isPlayerIdValid()) {
            mybets.getBetslipsForMyBetsView(n, i, r, !0, u);
            return
        }
        pat.get("/MyBets/GetBetslipsForContent", {
            category: u,
            state: n,
            pageNo: t,
            outcomeCategory: i,
            searchTerm: r
        }).done(function(t) {
            var i, r;
            if (homePage.closeOverlay(), $(".default-bets").html(t), accountOptionsPopUpEnabled === !1 && (screen.width <= 786 ? homePage.anchorToId("#accountOptions") : homePage.anchorToTop()), n == "settled" && (i = document.getElementsByClassName("marketTypeCategoryBet"), i.length > 0))
                for (r = 0; r < i.length; r++) i[r].innerHTML = ""
        })
    },
    getBetslipsToContentByStateForBetslip: function(n, t, i, r) {
        if (mybets.shouldRedirectCallToNewMyBets()) {
            mybets.getBetslipsForMyBetsView(n, i, r, !0);
            return
        }
        homePage.showOverlay();
        var u = PlayerAccountID,
            f = Brand,
            e = currentTimeZone;
        pat.get("/MyBets/GetBetslipsForContentBetslip", {
            AccountId: u,
            BrandId: f,
            timeZone: e,
            state: n,
            pageNo: t,
            outcomeCategory: i,
            searchTerm: r
        }).done(function(t) {
            var r, u;
            if (homePage.closeOverlay(), $(".default-bets").html(t), $("#openTab").hasClass("active") && i === "All" && ($(".mg-tabs1").show(), $("#myBetsModelSearchContainer").hide(), $(".mg-search").show()), n == "settled" && (r = document.getElementsByClassName("marketTypeCategoryBet"), r.length > 0))
                for (u = 0; u < r.length; u++) r[u].innerHTML = ""
        })
    },
    shouldRedirectCallToNewMyBets: function() {
        return ($("#cat_Sports").hasClass("active") || $("#cat_Sports").hasClass("selected")) && newMyBetsEnabled && isPlayerIdValid()
    },
    getBetslipsForMyBetsView: function(n, t, i, r, u) {
        if (homePage.showOverlay(), !isCurrentlyRetrievingMyBets) {
            var o = PlayerAccountID,
                s = Brand,
                h = currentTimeZone,
                f = r === !0 && r !== undefined ? 0 : $("#MyBets_BetslipCount").data("value"),
                e = localStorage.getItem("lastMyBetsChangeAction");
            f !== undefined && f != null || r || (f = $(".betSrcCont.betTableContainer").length);
            (t === undefined || t === null || t === "") && (t = "All");
            (e === undefined || e == null || e === "") && mybets.updateMyBetsLastActionDelta();
            (hideLosses === undefined || hideLosses === null) && (hideLosses = !1);
            (u === undefined || u === null) && (u = "sport");
            isCurrentlyRetrievingMyBets = !0;
            try {
                pat.get("/Ajax/GetBetslipsForAccount", {
                    AccountId: o,
                    BrandId: s,
                    timeZone: h,
                    page: n,
                    alreadyLoadedCount: f,
                    filterStatus: t,
                    searchTerm: i,
                    hideLosses,
                    lastMyBetsChangeAction: e,
                    isMobile,
                    currencySign: currency,
                    betslipCategory: u
                }).done(function(n) {
                    var i, r;
                    if (homePage.closeOverlay(), $("#loadMore_MyBets").remove(), $("#MyBets_BetslipCount").remove(), $(".default-bets").html(n), $("#openTab").hasClass("active") && t === "All" && ($(".mg-tabs1").show(), $("#myBetsModelSearchContainer").hide(), $(".mg-search").show()), state === "settled" && (i = document.getElementsByClassName("marketTypeCategoryBet"), i.length > 0))
                        for (r = 0; r < i.length; r++) i[r].innerHTML = ""
                })
            } catch (c) {
                console.error(c)
            } finally {
                isCurrentlyRetrievingMyBets = !1
            }
        }
    },
    initializeNewMyBetsView: function() {
        accordionFilter === undefined && (accordionFilter = {});
        accordionFilter.filterTo === undefined && (accordionFilter.filterTo = function(n) {
            accordionFilter.filterSearch(n)
        });
        accordionFilter.filterSearch === undefined && (accordionFilter.filterSearch = function(n) {
            n != null && n.toLowerCase() === "all" && (n = "");
            var t = "betslipFilterable",
                u = $("#mybetsContainer:first"),
                i = $("#mtSearch").val(),
                r = !1;
            n != null && (i = n);
            t.length === 0 && (t = ".theFont:first");
            $(".srcError").hide();
            u.children().each(function() {
                $(this).find(t) != null && $(this).find(t).length > 0 ? $(this).find(t).text().toUpperCase().indexOf(i.toUpperCase()) !== -1 ? ($(this).show(), r = !0) : $(this).hide() : $(this).text().trim() !== "" && i != null && ($(this).text().toUpperCase().indexOf(i.toUpperCase()) !== -1 ? ($(this).show(), r = !0) : $(this).hide())
            });
            r || $(".srcError").show()
        });
        accordionFilter.filterClick === undefined && (accordionFilter.filterClick = function() {
            if ($(".mg-search").toggleClass("search-expanded"), $("#searchIcon").toggleClass("search-icon-expanded"), $("#searchIcon").toggleClass("md-toggle-search md-toggle-times"), $(this).hasClass("md-toggle-times")) $(".md-toggle-times").on("click", function() {
                $("#mtSearch").blur()
            });
            else $("#mtSearch").focusout(), $("#mtSearch").val(""), $("#mtSearch").trigger("keyup"), fasearch = !1
        })
    },
    updateMyBetsLastActionDelta: function() {
        localStorage.setItem("lastMyBetsChangeAction", JSON.stringify((new Date).getTime()))
    },
    updateMyBetsLastActionDelta: function() {
        localStorage.setItem("lastMyBetsChangeAction", JSON.stringify((new Date).getTime()))
    },
    getBetslipsToContentForBetslip: function(n, t) {
        var i = "settled";
        if ($("#openTab").hasClass("active") && (i = "open"), mybets.shouldRedirectCallToNewMyBets()) {
            mybets.getBetslipsForMyBetsView(i, t, null, !0);
            return
        }
        homePage.showOverlay();
        var r = $("#headerBtnMyBets"),
            u = $(".betslip-overlay-container"),
            f = PlayerAccountID,
            e = Brand,
            o = currentTimeZone;
        pat.get("/MyBets/GetBetslipsForContentBetslip", {
            AccountId: f,
            BrandId: e,
            timeZone: o,
            state: i,
            pageNo: n,
            outcomeCategory: t
        }).done(function(n) {
            var t, f;
            if (global.isMobile() || mybets.toggleBetslipElement(u, r, "betslipHeader"), homePage.closeOverlay(), $(".betslip-mybets").removeClass("hidden"), $(".betslipHeaderBtn").removeClass("active"), $(".betslip-mybetsBtn").addClass("active"), $(".default-bets").html(n).removeClass("hidden"), $(".betslip-body, .betslip-footer").hide(), $(".betsNav").show(), $("#BetPlacementDisabledMsg").hide(), i == "settled" && (t = document.getElementsByClassName("marketTypeCategoryBet"), t.length > 0))
                for (f = 0; f < t.length; f++) t[f].innerHTML = ""
        });
        global.setCookie("ActivateCashoutPolling", "true")
    },
    toggleToBetslip: function(n) {
        var t = $("#headerBtnBetslip"),
            i = $(".betslip-overlay-container"),
            r = n ? n : "outcomes";
        global.isMobile() || mybets.toggleBetslipElement(i, t, r);
        $(".betslip-betslipBtn").hasClass("active") || ($(".betslipHeaderBtn").removeClass("active"), $(".betslip-betslipBtn").addClass("active"), $(".default-bets").addClass("hidden"), $(".betslip-body, .betslip-footer").show(), $("#BetPlacementDisabledMsg").show(), screen.width > 1024 && $("#betslip-container").css({
            "max-height": "80vh",
            position: "fixed"
        }), $(".betsNav").hide(), global.setCookie("ActivateCashoutPolling", "false"))
    },
    elementVisible: function(n) {
        return !n.hasClass("hidden")
    },
    hideElement: function(n) {
        n.addClass("hidden")
    },
    showElement: function(n) {
        n.removeClass("hidden")
    },
    toggleBetslipElement: function(n, t, i) {
        var r = t.hasClass("active"),
            u = mybets.elementVisible(n);
        SetBetslipToggle(!u);
        switch (i) {
            case "betslipHeader":
                r && u ? (mybets.hideElement(n), mybets.toggleBetslipBanner(!0)) : (!r || u) && (r || u) ? !r && u && ($(".betslip-betslipBtn").hasClass("active") ? mybets.toggleBetslipBanner(!1) : $(".betslip-mybetsBtn").hasClass("active") && mybets.toggleBetslipBanner(!0)) : (mybets.showElement(n), (!r && $(".betslip-betslipBtn").hasClass("active") || r && $(".betslip-mybetsBtn").hasClass("active")) && !u && mybets.toggleBetslipBanner(!1));
                break;
            case "outcomes":
                (!r || u) && (r || u) || mybets.showElement(n);
                break;
            default:
                console.log("event trigger not set")
        }
    },
    toggleBetslipBanner: function(n) {
        n ? ($("#betslip-container").css({
            position: "fixed"
        }), $(".banner-row").removeClass("hidden")) : ($("#betslip-container").css({
            position: "relative"
        }), $(".banner-row").addClass("hidden"))
    },
    goToPage: function(n, t, i) {
        var u = "open",
            r = "All";
        $("#openTab").hasClass("active") || (u = "settled");
        $("#out_Loss").hasClass("active") || $("#out_Loss").hasClass("selected") || $("#out_Loss").attr("checked") == "checked" ? r = "Loss" : $("#out_Win").hasClass("active") || $("#out_Win").hasClass("selected") || $("#out_Win").attr("checked") == "checked" ? r = "Win" : $("#out_CashOut").hasClass("active") || $("#out_CashOut").hasClass("selected") || $("#out_CashOut").attr("checked") == "checked" ? r = "CashOut" : ($("#out_CancelBet").hasClass("active") || $("#out_CancelBet").hasClass("selected") || $("#out_CashOut").attr("checked") == "checked") && (r = "CancelBet");
        i ? mybets.getBetslipsToContentByStateForBetslip(u, n, r, t) : mybets.getBetslipsToContentByState(u, n, r, t)
    },
    filterByOutcomeCategory: function(n, t) {
        var i = "open";
        if ($("#openTab").hasClass("active") || (i = "settled"), console.log(" state : " + i + " , outcome :" + n), mybets.shouldRedirectCallToNewMyBets()) {
            mybets.getBetslipsForMyBetsView(i, n, null, !0);
            return
        }
        t ? mybets.getBetslipsToContentByStateForBetslip(i, 1, n) : mybets.getBetslipsToContentByState(i, 1, n)
    },
    toggleHideLosses: function(n, t) {
        if (homePage.showOverlay(), hideLosses = !hideLosses, mybets.shouldRedirectCallToNewMyBets()) {
            mybets.getBetslipsForMyBetsView("settled", "All", null, !0);
            return
        }
        pat.get("/MyBets/SetHideLosingBetsOption", {
            hideLosses: n.checked
        }).done(function() {
            homePage.showOverlay();
            t ? mybets.getBetslipsToContentByStateForBetslip("settled", 1, "All") : mybets.getBetslipsToContentByState("settled", 1, "All")
        })
    },
    confirmEarlyCashout: function(n, t, i, r, u, f = "") {
        var e = u,
            o, s;
        (e === 0 || e === null) && (e = f == "CancelBet" ? $(".cancelBetAmount-" + t + ":first").text() : $(".cashOutAmount-" + t + ":first").text());
        $(".btn-confirmCO-" + t).prop("disabled", !0).html("Loading");
        $(".btn-closeECO-" + t).prop("disabled", !0);
        o = "";
        s = null;
        f == "CancelBet" ? (o = "/Account/AcceptCancelBet", s = {
            betslipId: n,
            betslipSequenceId: t,
            cancelBetAmount: e,
            wagerAmount: i,
            potentialReturnAmount: r
        }) : (o = "/Account/AcceptCashout", s = {
            betslipId: n,
            betslipSequenceId: t,
            cashoutAmount: e,
            wagerAmount: i,
            potentialReturnAmount: r
        }, homePage.showOverlay());
        pat.post(o, s).done(function(u) {
            var f, e, s, o;
            homePage.closeOverlay();
            f = u.Success ? "Success" : "Unsuccessful";
            $(".cashout-confirmation-header-text").html(f);
            language.translateAtRuntime($(".cashout-confirmation-header-text"), "BetslipWidget", {
                "data-translate-key": language.generateKey(f)
            });
            $(".cashout-body").html(u.Message);
            language.translateAtRuntime($(".cashout-body"), "BetslipWidget", {
                "data-translate-key": language.generateKey(u.Message)
            });
            u.Success ? ($(".cashout-confirmation-header-text").html(f), language.translateAtRuntime($(".cashout-confirmation-header-text"), "BetslipWidget", {
                "data-translate-key": language.generateKey(f)
            }), $(".eco-continueBtn").removeClass("hidden"), $(".eco-reoffer-confirmBtn").addClass("hidden"), $(".eco-reoffer-backToBetSlip").addClass("hidden"), homePage.RefreshCashBalance(!0), mybets.updateMyBetsLastActionDelta(), $("#mybetsContainer").children().length < 1 ? ($("#mybetsContainer").html('<div class="message-nobetslips"><div id="CashoutBody" class="alert-box notice">There are no sport bets for this account. <a href="/">Bet Now<\/a><\/div><\/div>'), language.translateAtRuntime($("#CashoutBody"), "BetslipWidget", {
                "data-translate-key": "NoSportsBetsText",
                "data-translate-value-0": '<a href="/">Bet Now<\/a><\/div><\/div>'
            }), $(".pagination").hide()) : location.pathname.toLowerCase().indexOf("mybets") < 0 && (accountOptionsPopUpEnabled || mybets.getBetslipsToContentByStateForBetslip("open"))) : (f = "Unsuccessful", $(".cashout-confirmation-header-text").html(f), language.translateAtRuntime($(".cashout-confirmation-header-text"), "BetslipWidget", {
                "data-translate-key": language.generateKey(f)
            }), typeof u.Message == "undefined" || u.Message === null || u.Message.toLowerCase().indexOf("undefined") > -1 ? ($(".cashout-body").html("<br/>Could not complete this action."), language.translateAtRuntime($(".cashout-body"), "BetslipWidget", {
                "data-translate-key": "CompleteActionFailedText"
            })) : ($(".cashout-body").html("<br/>" + u.Message), language.translateAtRuntime($(".cashout-body"), "BetslipWidget", {
                "data-translate-key": language.generateKey(u.message)
            })), u.Code === 1 ? (f = "Confirm Cash Out Offer", $(".cashout-body").append("<br><br>Old Offer: <b>" + u.CashoutAmounts.Currency + " " + ToThousandSeparator(u.CashoutAmounts.OldAmount) + "<\/b>"), $(".cashout-body").append("<br>New Offer: <b>" + u.CashoutAmounts.Currency + " " + ToThousandSeparator(u.CashoutAmounts.NewAmount) + "<\/b>"), language.translateAtRuntime($(".cashout-body"), "BetslipWidget", {
                "data-translate-key": "CashoutOfferText",
                "data-translate-type": "generic-html",
                "data-translate-value-0": u.CashoutAmounts.Currency + " " + ToThousandSeparator(u.CashoutAmounts.OldAmount),
                "data-translate-value-1": u.CashoutAmounts.Currency + " " + ToThousandSeparator(u.CashoutAmounts.NewAmount)
            }), $(".eco-continueBtn").addClass("hidden"), $(".eco-reoffer-backToBetSlip").removeClass("hidden"), $(".eco-reoffer-confirmBtn").removeClass("hidden"), $(".eco-reoffer-confirmBtn").click(function() {
                mybets.confirmEarlyCashout(n, t, i, r, u.CashoutAmounts.NewAmount)
            }), homePage.closeOverlay(), $(".eco-reoffer-backToBetSlip").click(function() {
                $("#cashout-confirmation-modal").modal("hide")
            })) : u.Code === 3 ? (e = (u.EarlyCashoutAmount / u.PotentialReturnAmount * 100).toFixed(2), s = e < 20 ? "red" : e >= 20 && e < 50 ? "orange" : "green", $(".co-bar-" + t).css({
                width: e + "%",
                "background-color": s
            }), ($(".cancelBetAmount-" + t) != undefined || $(".cancelBetAmount-" + t) != null) && $(".cancelBetAmount-" + t).html(u.EarlyCashoutAmount.toFixed(2)), $(".cashOutAmount-" + t).html(u.EarlyCashoutAmount.toFixed(2)), $(".cashoutBtn-" + t).prop("disabled", !1), o = '<strong data-translate-set="MyBetsContent" data-translate-key="Cashout">Cash Out<\/strong>', !$(".betslip-mybetsBtn")[0] || window.location.pathname.toLowerCase().indexOf("/mybets") > -1 || (o = "Cash Out"), $(".cashoutBtn-" + t).html(o), $(".cashout-text-" + t).html("Cash Out Offer:"), $(".btn-confirmCO-" + t).removeAttr("onclick"), $(".btn-confirmCO-" + t).click(function() {
                mybets.confirmEarlyCashout(u.BetslipId, t, u.WagerAmount, u.PotentialReturnAmount, u.EarlyCashoutAmount, "")
            }), $(".btn-confirmCO-" + t).attr("data-eco-value", u.EarlyCashoutAmount.toFixed(2)), language.translateAtRuntime($(".cashoutBtn-" + t), "MyBetsContent", {
                "data-translate-key": language.generateKey(u.message)
            })) : u.Code === 4 ? ($(".co-bar-" + t).css({
                width: "0%"
            }), ($(".cancelBetAmount-" + t) != undefined || $(".cancelBetAmount-" + t) != null) && $(".cancelBetAmount-" + t).html('<span class="fa fa-lock"><\/span>'), $(".cashoutBtn-" + t).html('<strong data-translate-set="MyBetsContent" data-translate-key="Cashout">Cash Out<\/strong>'), $(".cashoutBtn-" + t).html('<span class="fa fa-lock"><\/span>'), $(".cashoutBtn-" + t).prop("disabled", !0), language.translateAtRuntime($(".cashoutBtn-" + t), "MyBetsContent", {
                "data-translate-key": language.generateKey(u.message)
            })) : ($(".eco-continueBtn").removeClass("hidden"), $(".eco-reoffer-backToBetSlip").addClass("hidden"), $(".eco-reoffer-confirmBtn").addClass("hidden")), $(".btn-confirmCO-" + t).prop("disabled", !1).html("Confirm"), $(".btn-closeECO-" + t).prop("disabled", !1), console.log("Waiting for input"), $(".confirmEcoBtns").hide(), $(".cashoutBtn-" + t).removeClass("hidden"));
            u.Success && (mybets.setSuccessfulCashoutMessage(t), mybets.addSuccessfulCashoutToLocalStorage(t));
            $("#cashout-confirmation-modal").modal("show")
        })
    },
    addSuccessfulCashoutToLocalStorage: function(n) {
        if (enableCashoutCacheCorrection) {
            var t = JSON.parse(localStorage.getItem("successfulCashouts"));
            t === null && (t = []);
            t.push({
                addedTime: (new Date).getTime(),
                betslipSequenceId: n
            });
            localStorage.setItem("successfulCashouts", JSON.stringify(t))
        }
    },
    getSuccessfulCashoutToLocalStorage: function() {
        var n = JSON.parse(localStorage.getItem("successfulCashouts"));
        return n === null && (n = []), n
    },
    setSuccessfulCashoutMessage: function(n) {
        if ($(".bet-cashout-id-" + n).addClass("hidden"), console.error("done"), enableCashoutCacheCorrection) {
            $(`.bet-id-${n}`).text("Cashed Out");
            $(`.bet-id-${n}`).removeClass("cashout-hidden");
            var t = language.translateAtRuntime($(`.bet-id-${n}`), "MyBetsContent", {
                "data-translate-key": "CashedOut"
            })
        }
    },
    initializeSuccessfulCashouts: function() {
        var t, n, u;
        if (enableCashoutCacheCorrection) {
            var i = mybets.getSuccessfulCashoutToLocalStorage(),
                r = [],
                f = (new Date).getTime() + minTimeToExpireSuccessfulCashout * 1e3;
            for (t = 0; t < i.length; t++) n = i[t], u = $(`.${n.betslipSequenceId}`), u.length > 0 ? mybets.setSuccessfulCashoutMessage(n.betslipSequenceId) : n.addedTime < f && r.push(n.betslipSequenceId);
            mybets.cleanupSuccessfulBetsLocalStorage(i, r)
        }
    },
    cleanupSuccessfulBetsLocalStorage: function(n, t) {
        var r = n.filter(function(n) {
            for (i = 0; i < t.length; i++)
                if (t[i] == n.betslipSequenceId) return !1;
            return !0
        });
        localStorage.setItem("successfulCashouts", JSON.stringify(r))
    },
    toggleDetails: function(n) {
        $(".glyphMulti-" + n).toggleClass("glyphicon-triangle-bottom").toggleClass("glyphicon-play");
        $(".bs-" + n).fadeToggle();
        $(".toggleValues-" + n).toggleClass("hidden");
        $(".shortDetails-" + n).fadeToggle()
    },
    toggleConfirmCashout: function(n) {
        $(".cashoutBtn-" + n).is(":visible") ? ($(".confirmCashoutBtns-" + n).show().removeClass("hidden"), $(".cashoutBtn-" + n).addClass("hidden")) : ($(".confirmCashoutBtns-" + n).hide().addClass("hidden"), $(".cashoutBtn-" + n).removeClass("hidden"))
    },
    mybetsSearch: function(n, t) {
        var i = "open";
        if ($("#openTab").hasClass("active") || (i = "settled"), mybets.shouldRedirectCallToNewMyBets()) {
            mybets.getBetslipsForMyBetsView(i, "All", n, !0);
            return
        }
        t ? mybets.getBetslipsToContentByStateForBetslip(i, 1, null, n) : mybets.getBetslipsToContentByState(i, 1, null, n)
    },
    toggleCashoutDebugInfo: function(n) {
        isAdminDebuggingEnabled && (AdminSecret || (AdminSecret = prompt("Who dares pass this domain? Speak the watchword and you may pass;", undefined)), $.ajax({
            url: "/Test/CheckCashoutData",
            type: "POST",
            dataType: "json",
            data: {
                betsequenceId: n,
                secret: AdminSecret
            },
            success: function(t) {
                var i, r, u;
                t && (i = $(".cashoutBtn-" + n)[0].getAttribute("disabled"), i == undefined && (i = !0), r = t, u = t.data[0].CashoutProbability > 0 && t.data[0].IsOutcomeHidden && t.data[0].IsEventBettingAllowed && t.data[0].IsMarketBettingAllowed && t.data[0].IsMarketHidden, alert(`BR Earlycashout API response: ${r.data[0].BRAllowEarlyCashout}

Database Allow Earlycashout: ${r.data[0].AllowEarlyCashout}

UI Allow Early cashout: ${i}

 Our Logic: ${u}

[DEV] Raw XML Response: ${r.data[0].RawBRResponse}`), console.error(t))
            }
        }))
    },
    rebet: function(n) {
        ClearBetslip();
        var t = JSON.parse(localStorage.getItem("rebetBetslips")),
            i = t.find(function(t) {
                return t.betslipSequenceId === n
            });
        i.bets.forEach(function(n) {
            SendToBetslip(n.OutcomeId, n.SelectOutcome, n.PriceDecimal, n.SportTitle, n.MarketTitle, "", n.EventTitle, n.StartDateTimeSAST, n.EventId, !1, n.FeedDataTypeId, !0, !0, n.LeagueFriendlyName, n.IsTrending)
        })
    },
    redirectToEventMoreBets: function(n) {
        var t = window.location.origin;
        homePage.showOverlay();
        pat.get("/Event/GetMoreBetsLinkForEvent", {
            eventId: n
        }, {
            dataType: "json"
        }).done(function(n) {
            if (n && n.Success && n.Url.length > 0) {
                var i = t + n.Url;
                window.location = i
            }
        })
    },
    initializeMyBets: function(n, t, i, r, u, f, e) {
        if (CASHOUTBETS = [], CLIENTSIDE_CASHOUT_ISACTIVE = n, CASHOUT_MARGIN = t, MIN_CASHOUT_LIMIT = i, MAX_CASHOUT_LIMIT = r, (accordionFilter === undefined || accordionFilter == null) && (accordionFilter = {}), accordionFilter.filterTo === undefined && (accordionFilter.filterTo = function(n) {
                accordionFilter.filterSearchMybets(n)
            }), accordionFilter.filterSearchMybets === undefined && (accordionFilter.filterSearchMybets = function(n) {
                var t = u,
                    r = f,
                    i = e;
                n != null && (i = n);
                typeof t != "undefined" && t.length === 0 && (t = ".theFont:first");
                r.children().each(function() {
                    $(this).find(t) != null && typeof $(this).find(t) != "undefined" && $(this).find(t).length > 0 ? $(this).find(t).text().toUpperCase().indexOf(i.toUpperCase()) !== -1 ? $(this).show() : $(this).hide() : $(this).text().toUpperCase().indexOf(i.toUpperCase()) !== -1 ? $(this).show() : $(this).hide()
                })
            }), typeof CLIENTSIDE_CASHOUT_ISACTIVE != "undefined" && CLIENTSIDE_CASHOUT_ISACTIVE) {
            var o = getCashoutBetslipIds();
            mybets.getLatestBetslipDataFromServer(o);
            CASHOUTBETS_INITIALIZED = !1
        }
    },
    mbfilterClick: function() {
        if ($(".mb-search").toggleClass("search-expanded"), $("#searchIcon").toggleClass("search-icon-expanded"), $("#searchIcon").toggleClass("md-toggle-search md-toggle-times"), $(this).hasClass("md-toggle-times")) $(".md-toggle-times").on("click", function() {
            $("#filterSearchMybets").blur()
        });
        else $("#filterSearchMybets").focusout(), $("#filterSearchMybets").val(""), $("#filterSearchMybets").trigger("keyup"), fasearch = !1
    },
    getLatestBetslipDataFromServer: function(n) {
        homePage.showOverlay();
        var t = n.filter(function(n) {
                return console.log($("[data-betid='" + n + "']")), $("[data-betid='" + n + "']")[0] != null
            }),
            u = PlayerAccountID,
            i = currentTimeZone,
            r = Brand;
        console.log("Getting latest!");
        t.length > 0 ? $.ajax({
            url: "/Ajax/GetLatestCashoutDataForBetslips",
            type: "GET",
            dataType: "json",
            traditional: !0,
            data: {
                betslipIds: t,
                timeZone: i,
                BrandId: r
            },
            success: function(n) {
                n && (CASHOUTBETS = n, homePage.closeOverlay())
            },
            complete: function() {
                pollServer = !0
            }
        }) : homePage.closeOverlay()
    },
    betgamesAndVirtualBetsSearch: function() {
        ($("#cat_Betgames").hasClass("active") || $("#cat_VirtualBets").hasClass("active")) && $("#mtSearch").keyup(function() {
            var n = $(this).val();
            $(".srcError").hide();
            $(".pageBtns").hide();
            $(".betSrcCont").hide();
            $(".betSrcCont").each(function() {
                $(this).text().toUpperCase().indexOf(n.toUpperCase()) !== -1 && $(this).show()
            });
            $("#betgames-list-table tbody .row").hide();
            $("#betgames-list-table tbody .row").each(function() {
                $(this).text().toUpperCase().indexOf(n.toUpperCase()) !== -1 && $(this).show()
            });
            $("#virtual-list-table tbody .row").hide();
            $("#virtual-list-table tbody .row").each(function() {
                $(this).text().toUpperCase().indexOf(n.toUpperCase()) !== -1 && $(this).show()
            });
            $("#mtSearch").val() === "" ? $("#page_navigation_open").hide() : $("#page_navigation_open").show();
            $(".betSrcCont").is(":visible") || $("#betgames-list-table tbody .row").is(":visible") || $("#virtual-list-table tbody .row").is(":visible") ? ($(".srcError").hide(), account.togglePagerBtns()) : $(".srcError").show();
            $("#mtSearch").val() ? ($("#searchclear").show(), $(".pageBtns").hide()) : ($("#searchclear").hide(), $(".pageBtns").show());
            ($(this).val() === "" || $(this).val() === null) && ($(".srcError").hide(), account.pager(), account.pagerSettled())
        })
    },
    toggleBetType: function(n) {
        n === "betgames" && ($(".fltrBtns").hide(), $(".betgames-bets").removeClass("hidden"), $(".default-bets").hide(), $(".virtual-bets").hide(), $("#dfBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#vtBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#bgBtn").css({
            "background-color": "#b3114d",
            color: "white"
        }).addClass("active"), mybets.getOpenBetgames("@betGameJsonOpen"));
        n === "virtualgames" && ($(".fltrBtns").hide(), $(".virtual-bets").show(), $(".betgames-bets").addClass("hidden"), $("#settledTab").hasClass("active") ? ($(".VirtualSettledBetsList tr").show(), $(".VirtualOpenBetsList tr").hide()) : ($(".VirtualOpenBetsList tr").show(), $(".VirtualSettledBetsList tr").hide()), $(".default-bets").hide(), $("#dfBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#bgBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#vtBtn").css({
            "background-color": "#439539",
            color: "white"
        }).addClass("active"), mybets.getOpenVirtuals("@virtualJsonOpen"));
        n === "sports" && ($("#settledTab").hasClass("active") ? $(".fltrBtns").show() : $(".fltrBtns").hide(), $(".default-bets").show(), $(".betgames-bets").addClass("hidden"), $(".virtual-bets").hide(), $("#bgBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#vtBtn").css({
            "background-color": "white",
            color: "black"
        }).removeClass("active"), $("#dfBtn").css({
            "background-color": "#439539",
            color: "white"
        }).addClass("active"), mybets.getOpenSportBets("@sportJsonOpen"));
        account.pager();
        account.pagerSettled()
    },
    searchClearMyBets: function() {
        $("#searchclear").click(function() {
            $("#mtSearch").val("");
            $("#searchclear").hide();
            $(".betSrcCont").show();
            $("#betgames-list-table .row").show();
            $("#virtual-list-table .row").show();
            $(".srcError").hide();
            account.pager();
            account.pagerSettled();
            $("#settledTab").hasClass("active") ? account.togglePagerBtns("settled") : $("#openTab").hasClass("active") && account.togglePagerBtns("open")
        })
    },
    voidBetFromMyBets: function(n, t, i) {
        var u = JSON.parse(localStorage.getItem("sportsBonusIsProtected")),
            f = u ? "Please note that removing any selections from this betslip will result in sports bonus playthrough contributions not being made. Are you sure you want to remove this selection?" : "Are you sure you want to remove this selection?",
            r = "Remove Now";
        $("#genericConfirmBtns").find("#btnConfirm").text(r).off("click").on("click", function() {
            mybets.confirmBetVoid(n, t, i)
        });
        this.showAlert("Edit Bet", f, !0);
        language.translateAtRuntime($("#btnConfirm"), "MyBetsContent", {
            "data-translate-key": language.generateKey(r)
        })
    },
    confirmBetVoid: function(n, t, i) {
        console.log(`Removing Bet ID: ${t} From Bet Slip ID: ${n}`);
        homePage.showOverlay();
        $("#generic-modal").modal("hide");
        pat.post("/MyBets/VoidBetFromBetSlip", {
            betslipId: n,
            betId: t
        }).done(function(n) {
            console.log("[VOID BET RES]", n);
            n.success ? (mybets.updateVoidedBetView(t, i), mybets.updateVoidedBetsStorage(t, i)) : mybets.showAlert("Remove Bet", n.message, !1);
            homePage.closeOverlay()
        })
    },
    showAlert: function(n, t, i, r) {
        $("#genericModalHeader").text(n);
        r ? $("#genericMiddleContent").html(t) : $("#genericMiddleContent").text(t);
        i ? $("#genericConfirmBtns").show() : $("#genericConfirmBtns").hide();
        $("#generic-modal").modal("show");
        language.translateAtRuntime($("#genericModalHeader"), "MyBetsContent", {
            "data-translate-key": language.generateKey(n)
        });
        language.translateAtRuntime($("#genericMiddleContent"), "MyBetsContent", {
            "data-translate-key": language.generateKey(t)
        })
    },
    updateVoidedBetView: function(n, t) {
        var r = location.pathname.toLowerCase().indexOf("/mybets") < 0 ? "Widget" : "MyBets",
            u, i;
        r = accountOptionsPopUpEnabled && accountOptionMyBetsEnabled === !0 ? "MyBets" : r;
        accountOptionsPopUpEnabled && accountOptionMyBetsEnabled && (u = $('[data-section="' + r + '"]').find(".betslip-" + t));
        i = $('[data-section="' + r + '"]').find('[data-betid="' + n + '"]');
        i.addClass("voided-tmp");
        i.find(".mybets-betprice").html('<span class="bold player-void-label" data-translate-set="MyBetsContent" data-translate-key="PlayerVoid"><b>Player Void<\/b><\/span>');
        i.find(".void-bet-btn").remove();
        i.find(".multi-edit-btn").remove();
        i.find(".voided-selection-placeholder").html('<span style="color: gray"><span class=".WinningSelection-label" data-translate-set="MyBetsContent" data-translate-key="WinningSelection">Winning Selection<\/span> <strong class="player-void-label" data-translate-set="MyBetsContent" data-translate-key="PlayerVoid" style="color: black">Player Void<\/strong><\/span>');
        this.removeVoidBtn(u);
        language.translateAtRuntime($(".player-void-label"), "MyBetsContent", {
            "data-translate-key": "PlayerVoid"
        });
        language.translateAtRuntime($(".WinningSelection-label"), "MyBetsContent", {
            "data-translate-key": "WinningSelection"
        })
    },
    updateVoidedBetsStorage: function(n, t) {
        var i = this.getVoidedBetsFromStorage();
        i.push({
            BetId: n,
            SequenceId: t
        });
        localStorage.setItem("VoidedBetsIds", JSON.stringify(i))
    },
    removeVoidedBetsFromStorage: function() {
        var n = this.getVoidedBetsFromStorage();
        $(".voided-bet").each(function() {
            var t = $(this).data("betid");
            n = n.filter(n => n.BetId !== t)
        });
        n.forEach(n => {
            mybets.updateVoidedBetView(n.BetId, n.SequenceId)
        });
        localStorage.setItem("VoidedBetsIds", JSON.stringify(n))
    },
    removeVoidBtn: function(n) {
        var t = n.find(".voided-tmp, .voided-bet").length,
            i = n.find(".pre-match").length;
        i - t == 1 && (n.find(".void-bet-btn").remove(), n.find(".multi-edit-btn").remove())
    },
    getVoidedBetsFromStorage: function() {
        var n = localStorage.getItem("VoidedBetsIds");
        return n === null ? [] : JSON.parse(n)
    },
    checkVoidedBets: function() {
        $("[data-betslip-id]").each(function() {
            mybets.removeVoidBtn($(this))
        });
        $(".no-bet-editing").closest(".bet-wager").find(".multi-edit-btn").hide()
    },
    setLatestLiveScore: function() {
        var t, r, n, i, f, u, e, o;
        for (mybets.purgeOldScores(), t = localStorage.getItem("LastScoreUpdate"), t !== null && t.length > 0 ? (document.getElementById("settledTab") != undefined && document.getElementById("settledTab") != null && document.getElementById("settledTab").classList.contains("active") && (t = []), t = JSON.parse(t)) : t = [], r = 0; r < t.length; r++) n = t[r], i = !1, $("#event-score-" + n.EventId).length > 0 && (n.InplayStatus !== null && n.InPlayStatus !== "" && ($("#event-score-" + n.EventId).show(), f = $("#inplay-status-" + n.EventId).html().trim() + " ", f !== n.InPlayStatus + " | " && (i = !0), $("[id='inplay-status-" + n.EventId + "']").html(n.InPlayStatus + " | "), language.translateAtRuntime($("[id='inplay-status-" + n.EventId + "']"), "MyBetsContent", {
            "data-translate-key": language.generateKey(n.InPlayStatus),
            "data-translate-type": "generic-html",
            "data-translate-value-0": " | "
        }), n.InPlayStatus === "Ended" && $("[id='live-indicator-" + n.EventId + "']").html(""), u = $("#event-score-" + n.EventId).closest("[data-betslip-id]"), u.removeClass("pre-match").addClass("LiveInPlay"), mybets.removeVoidBtn(u)), n.InPlayTime !== null && n.InPlayTime.trim() !== "" && (e = $("#inplay-time-" + n.EventId).html().trim() + " ", e !== n.InPlayTime + " | " && (i = !0), $("[id='inplay-time-" + n.EventId + "']").html(n.InPlayTime + " | ")), n.InPlayScore !== null && n.InPlayScore !== "" && (o = $("#inplay-score-" + n.EventId).html().trim(), o !== n.InPlayScore && (i = !0), $("[id='inplay-score-" + n.EventId + "']").html(n.InPlayScore))), i && ($("[id='event-score-" + n.EventId + "']").addClass("blinking"), setTimeout(function() {
            $(".blinking").removeClass("blinking")
        }, 2500))
    },
    purgeOldScores: function() {
        var n = localStorage.getItem("LastScoreUpdate"),
            i, t, r;
        if (n !== null && n.length > 0) {
            for (n = JSON.parse(n), i = [], t = 0; t < n.length; t++) $("#event-score-" + n[t].EventId).length == 0 && mybets.diff_minutes(n[t].LastUpdateDateTime) > 15 && i.push(n[t]);
            r = n.filter(function(n) {
                return !i.map(n => n.EventId).includes(n.EventId)
            });
            n = r;
            localStorage.setItem("LastScoreUpdate", JSON.stringify(n))
        }
    },
    diff_minutes: function(n) {
        var i = new Date(n),
            t;
        return console.log("startDateTime" + i), t = ((new Date).getTime() - i.getTime()) / 1e3, t /= 60, Math.abs(Math.round(t))
    },
    closeMyBets: function() {
        accountOptionsPopUpEnabled && accountOptionMyBetsEnabled ? ($("#accountOptionsModal").css("display", "none"), $("#nav-link-container").css("pointer-events", "initial"), document.querySelector("html").style.overflow = "scroll", document.querySelector("html").removeAttribute("style"), $(".modal-backdrop.fade.in").remove()) : window.location = "/"
    },
    initNewMyBetsMainView: function() {
        mybets.betgamesAndVirtualBetsSearch();
        mybets.searchClearMyBets();
        $(".betgames-bets").addClass("hidden");
        $(".virtual-bets").hide();
        newMyBetsEnabled && isPlayerIdValid() || (account.pager(), account.pagerSettled());
        mybets.removeVoidedBetsFromStorage();
        account.togglePagerBtns("open");
        $(".fltrBtns").hide();
        $("#openTab").addClass("active");
        $("#settledTab").removeClass("active");
        newMyBetsEnabled && (isPlayerIdValid() ? (mybets.getBetslipsForMyBetsView("open", "All", null, !0), mybets.initializeNewMyBetsView()) : mybets.getBetslipsToContentByState("open"))
    },
    initMyBetItems: function() {
        mybets.checkVoidedBets();
        localStorage.setItem("rebetBetslips", rebetData);
        mybets.setLatestLiveScore();
        mybets.removeVoidedBetsFromStorage();
        global.getCookie("oddsFormat") === "fraction" && $(".priceDecimal").each(function() {
            $(this).text(oddsFormatter.convertFromDecimalToFraction($(this).text()))
        })
    }
};
$(document).ready(function() {
    screen.width > 786 && homePage.anchorToTop();
    console.log("location.pathname.toLowerCase", location.pathname.toLowerCase());
    (location.pathname.toLowerCase().indexOf("/mybets") > -1 || location.pathname.toLowerCase().indexOf("betslipsearch") > -1) && $(".betslip-mybetsBtn").hide();
    $(".co-value").html('<img src="/Images/Shared/other/loading.gif" style="width:17px;height:17px" />');
    $(".cashoutBtn").prop("disabled", !0);
    $(".co-progress-bar").css({
        width: "0px"
    });
    window.FetchCurrentCashoutValues = !0;
    window.PollingProbability = !1;
    window.PollingLiveScores = !1;
    global.setCookie("ActivateCashoutPolling", "true")
})