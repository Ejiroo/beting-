(function($) {

    app.partialViews.PaymentMethod = function() {
        var _$partial = null;
        this.init = function(options) {
            _$partial = options.elem;
            let url = "/Deposit/Get_Partial/" + _$partial.find('#brandpayment').val()
            if ($('#directIncludeParentPath').length > 0) {
                url = $('#directIncludeParentPath').val() + url
            }
            if (document.querySelector('#PartialViewScriptLoaderVer') != null) {
                url += '?ver=' + document.querySelector('#PartialViewScriptLoaderVer').value;
            }

            $(_$partial).find('div:first-of-type').html('Loading...');

            $.ajaxSetup({
                crossDomain: true,
                xhrFields: {
                    withCredentials: true
                },
            });

            $.post(url)
                .done(function(response) {
                    response = response.replace(/\$\(document\).ready\(/g, '$(');
                    $(_$partial).html(response);
                    if ($('#directIncludeParentPath').length > 0) {
                        if ($('#directIncludeParentPath').val().length > 0) {
                            let url = $('.recurring-payments-link').attr('href')

                            if (url != null && url != undefined && url.indexOf('vuvu-banking') == -1) {

                                let jwtAuth = '';
                                try {
                                    const params = new Proxy(new URLSearchParams(window.location.search), {
                                        get: (searchParams, prop) => searchParams.get(prop),
                                    });
                                    jwtAuth = url.indexOf('?') == -1 ? '?' : '&';
                                    jwtAuth += 'jwtAuth=' + params.jwtAuth;
                                    if (params.jwtAuth != null) {
                                        url += jwtAuth;
                                    }
                                } catch (e) {

                                }


                                url = $('#directIncludeParentPath').val() + url
                                $('.recurring-payments-link').attr('href', url)
                            }
                        }
                    }
                    $(_$partial).removeAttr('style');
                    $(_$partial).find('.isAmountSelected').addClass('isDefaultAmount');
                    $(_$partial).find('.isAmountSelected').removeClass('isAmountSelected');
                    $(_$partial).find('.isDefaultAmount').each(function() {
                        let amountToSet = $(this).html();
                        $(this).parents('form').eq(0).find('input[name=Amount]').val(amountToSet);
                        $(this).addClass('isAmountSelected');
                    });
                    termsButton = $(_$partial).find('[data-toggle="modal"]');
                    termsModal = $(_$partial).find('.modal');
                    if (termsButton.length >= 1 && termsModal.length >= 1) {
                        termsButton.attr('data-toggle', 'collapse');
                        termsModal.attr('class', 'collapse');
                        termsModal.children().removeClass('modal-content').addClass('well').removeAttr('style');
                        termsModal.find('.close').remove();
                    }
                    account.staticBankingCarousel('#' + _$partial.parent().attr('id'), accNo);
                    replaceAccountNumbers();
                    if ($(window).width() <= 768) {
                        $(_$partial).find('.modal-dialog').attr('style', 'height:100vh; margin: 0 !important');
                        $(_$partial).find('.modal-body').attr('style', 'overflow-x: hidden; overflow-y: scroll');
                    } else {
                        $(_$partial).find('.modal-body').attr('style', 'max-height: 550px; overflow-x: hidden; overflow-y: scroll');
                    }

                    if ($('#hApplePayCheck').length > 0 && $('.ApplePayMessage').length == 0) {
                        onlySafari()
                    }

                })
                .fail(function(xhr, status, error) {
                    $(_$partial).removeAttr('style');
                    $(_$partial).html('<hgroup style="text-align:center">' +
                        '<b style="font-size:28px; margin:0;">Oops,</b>' +
                        '<h2 style="margin:0">Something went wrong.</h2>' +
                        '<br/>' +
                        '<br/>' +
                        '<button class="btn btn-success val-btn" onclick=reloadPartail(' + "'#" + _$partial.parent().attr('id') + "');" + '><i class="fa fa-undo icon-flipped"></i> &nbsp Try Again </button>' +
                        '<br/>' +
                        '<br/>' +
                        '</hgroup>');
                });
        };
    };
})(jQuery);