import {
    p as e,
    b as t
} from "./p-98f35872.js";
(() => {
    const t =
        import.meta.url,
        a = {};
    return "" !== t && (a.resourcesUrl = new URL(".", t).href), e(a)
})().then((e => t([
    ["p-89c85ca8", [
        [1, "notifications-panel", {
                opened: [8],
                isnative: [1],
                colorscheme: [1],
                vertical: [1],
                accesstoken: [1],
                status: [1],
                regioncode: [1],
                culturecode: [1],
                licence: [1],
                enablepushnotifications: [1],
                Total: [32],
                Limit: [32],
                ItemID: [32],
                IsRead: [32],
                RetrySignalR: [32],
                SelectedTheme: [32],
                IsSelected: [32],
                DatePicker: [32],
                PanelStatus: [32],
                SelectedVertical: [32],
                ModalStatus: [32],
                HeaderControl: [32],
                BackDropStatus: [32],
                UnreadNotifications: [32],
                Translations: [32],
                FetchingNotifications: [32],
                NotificationsList: [32],
                PreviouslySelected: [32],
                DateTimes: [32]
            },
            [
                [0, "selectionHandler", "selectionHandler"],
                [0, "optionsStatus", "optionsStatus"],
                [0, "deselectItem", "deselectItem"],
                [0, "markAllAsRead", "markAllAsRead"],
                [0, "updateDateTimes", "updateDateTimes"],
                [0, "removeSelectedItem", "removeSelectedItem"],
                [0, "updateItemReadStatus", "updateItemReadStatus"],
                [0, "updateNotification", "updateNotification"],
                [0, "openDialog", "openDialog"],
                [0, "updatePanelStatus", "updatePanelStatus"],
                [0, "deleteNotification", "deleteNotification"]
            ]
        ],
        [1, "notification-holder", {
                Translations: [16],
                IsSelected: [4, "is-selected"],
                IsReadStatus: [4, "is-read-status"],
                SelectedTheme: [1, "selected-theme"],
                HeaderControl: [4, "header-control"],
                SelectedVertical: [1, "selected-vertical"],
                NotficationsArray: [1040],
                IsRead: [32],
                IsComplete: [32],
                BodyDisplay: [32],
                DisplayOptions: [32]
            },
            [
                [0, "closeOptionsHolder", "closeOptionsHolder"],
                [0, "markItemAsRead", "markItemAsRead"],
                [0, "markItemAsUnRead", "markItemAsUnRead"],
                [0, "removeItem", "removeItem"]
            ]
        ],
        [1, "body-controls", {
            Translations: [16],
            CheckBoxStatus: [32]
        }],
        [2, "dialog-box", {
            IsNative: [1, "is-native"],
            Translations: [16],
            DatePicker: [4, "date-picker"],
            ModalStatus: [4, "modal-status"],
            EndDateTime: [32],
            StartDateTime: [32],
            DateTimes: [32]
        }],
        [1, "header-controls", {
            HeaderControl: [4, "header-control"]
        }],
        [1, "options-holder", {
            notification: [16],
            Translations: [16]
        }]
    ]]
], e)));