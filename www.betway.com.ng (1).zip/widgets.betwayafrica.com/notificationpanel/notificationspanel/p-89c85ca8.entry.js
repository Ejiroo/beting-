import {
    r as t,
    c as e,
    h as i,
    H as n,
    g as s
} from "./p-98f35872.js";
const o = class {
    constructor(i) {
        t(this, i), this.selectionHandler = e(this, "selectionHandler", 7), this.selectAllHandler = t => {
            this.selectionHandler.emit({
                status: t.target.checked
            })
        }, this.translate = t => {
            const e = "sport.notification." + t,
                i = this.Translations.find((t => t.Key == e));
            if (i) return i.Text
        }, this.Translations = void 0, this.CheckBoxStatus = !1
    }
    render() {
        return i(n, null, i("div", {
            class: "panel-body-controls"
        }, i("span", null, i("label", null, this.Translations.length > 0 ? this.translate("selectAll") : "Select All"), i("input", {
            onChange: t => this.selectAllHandler(t),
            type: "checkbox",
            class: "checkbox-round"
        }))))
    }
};
o.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}.checkbox-round{width:1.3em;height:1.3em;background-color:white;border-radius:50%;vertical-align:middle;border:1px solid #505050;appearance:none;-webkit-appearance:none;outline:none;cursor:pointer}.checkbox-round:checked{background-color:#505050}.panel-body-controls{display:flex;font-family:Interface, Arial, sans-serif;justify-content:flex-end;background:#ffffff;width:100%}.panel-body-controls span{margin:10px 10px 10px 0px;display:block;font-family:Interface, Arial, sans-serif}.panel-body-controls span label{font-size:12px;cursor:pointer;padding:0 10px 0 0;font-family:Interface, Arial, sans-serif}.panel-body-controls span:last-child{cursor:pointer;font-family:Interface, Arial, sans-serif}';
const r = class {
    constructor(i) {
        t(this, i), this.openDialog = e(this, "openDialog", 7), this.updateDateTimes = e(this, "updateDateTimes", 7), this.deleteNotification = e(this, "deleteNotification", 7), this.getFullDateTime = () => ((new Date).getDate() > 9 ? (new Date).getDate() : "0" + (new Date).getDate()) + "/" + ((new Date).getMonth() > 9 ? (new Date).getMonth() + 1 : "0" + ((new Date).getMonth() + 1)) + "/" + (new Date).getFullYear() + " " + this.getDateTime(), this.today = () => (new Date).toISOString().split("T")[0], this.twentyTwenty = () => new Date("01/01/2022").toISOString().split("T")[0], this.translate = t => {
            const e = "sport.notification." + t,
                i = this.Translations.find((t => t.Key == e));
            if (i) return i.Text
        }, this.setDateFilters = () => {
            this.updateDateTimes.emit(this.DateTimes), this.closeModal()
        }, this.setStartDate = t => {
            if ("" !== t.target.value) {
                const e = t.target.value + " " + this.getDateTime(),
                    i = new Date(e).toISOString();
                this.DateTimes.StartDate = i
            } else this.DateTimes.StartDate = ""
        }, this.setEndDate = t => {
            if ("" !== t.target.value) {
                const e = t.target.value + " " + this.getDateTime(),
                    i = new Date(e).toISOString();
                this.DateTimes.EndDate = i
            } else this.DateTimes.EndDate = ""
        }, this.getDateTime = () => ((new Date).getHours() > 9 ? (new Date).getHours() : "0" + (new Date).getHours()) + ":" + ((new Date).getMinutes() > 9 ? (new Date).getMinutes() : "0" + (new Date).getMinutes()) + ":" + ((new Date).getSeconds() > 9 ? (new Date).getSeconds() : "0" + (new Date).getSeconds()), this.fieldKeyDown = t => (t.preventDefault(), !1), this.IsNative = void 0, this.Translations = void 0, this.DatePicker = void 0, this.ModalStatus = void 0, this.EndDateTime = "", this.StartDateTime = "", this.DateTimes = {}
    }
    componentDidLoad() {
        const t = this.getFullDateTime();
        this.EndDateTime = t, this.StartDateTime = t;
        const e = this.DialogElement.querySelector(".dialog-box");
        "true" == this.IsNative && e.classList.add("dialog-native")
    }
    closeModal() {
        this.openDialog.emit()
    }
    confirmDeletion() {
        this.deleteNotification.emit()
    }
    render() {
        return i(n, null, i("div", {
            class: this.ModalStatus ? "dialog-box modal-display" : " dialog-box"
        }, i("div", {
            class: "dialog-box-header"
        }, i("h5", null, this.DatePicker ? this.Translations.length > 0 ? this.translate("filter.pickADateRange") : "Pick a Date Range" : this.Translations.length > 0 ? this.translate("deleteNotification") : "Delete Notification"), i("span", {
            onClick: () => this.closeModal()
        }, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-x-lg",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"
        })))), i("div", {
            class: "dialog-box-body"
        }, this.DatePicker ? i("div", null, i("fieldset", {
            class: "form-group"
        }, i("label", null, this.Translations.length > 0 ? this.translate("filter.startDate") : "Start Date"), i("input", {
            value: this.StartDateTime,
            name: "StartDate",
            onKeyDown: t => this.fieldKeyDown(t),
            min: this.twentyTwenty(),
            max: this.today(),
            onChange: t => this.setStartDate(t),
            id: "StartDate",
            type: "date",
            class: "form-control"
        })), i("fieldset", {
            class: "form-group"
        }, i("label", null, this.Translations.length > 0 ? this.translate("filter.endDate") : "End Date"), i("input", {
            value: this.EndDateTime,
            name: "EndDate",
            onKeyDown: t => this.fieldKeyDown(t),
            max: this.today(),
            onChange: t => this.setEndDate(t),
            id: "EndDate",
            type: "date",
            class: "form-control"
        }))) : i("p", null, this.Translations.length > 0 ? this.translate("deleteNotificationConfirm") : "Are you sure you want to delete the notification?")), i("div", {
            class: "dialog-box-footer"
        }, this.DatePicker ? i("button", {
            onClick: () => this.setDateFilters(),
            class: "btn btn-primary"
        }, this.Translations.length > 0 ? this.translate("button.confirm") : "Confirm") : i("button", {
            onClick: () => this.confirmDeletion(),
            class: "btn btn-success"
        }, this.Translations.length > 0 ? this.translate("delete") : "Delete"))))
    }
    get DialogElement() {
        return s(this)
    }
};
r.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}.dialog-box.sc-dialog-box *.sc-dialog-box{box-sizing:border-box}.dialog-box.sc-dialog-box{font-family:Interface, Arial, sans-serif !important;width:20%;background:#ececec;text-align:center;position:fixed;left:-150%;top:10%;display:none;transform:translate(-50%, 10%);-webkit-transform:translate(-50%, 10%);z-index:12;transition:all 0.5s;box-shadow:1px 1px 1px #9e9e9e;z-index:10001;font-weight:bold}.dialog-box.sc-dialog-box .form-group.sc-dialog-box{text-align:left;width:80%;margin:0 auto;background:transparent;border:0px}.dialog-box.sc-dialog-box .form-group.sc-dialog-box .form-control.sc-dialog-box{display:block;width:100%;padding:0.375rem 0.75rem;min-height:36px;font-size:1rem;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:0.25rem;transition:border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;font-weight:bold;-webkit-appearance:textfield;-moz-appearance:textfield}.dialog-box.sc-dialog-box .form-group.sc-dialog-box .form-control.sc-dialog-box input[type=text].sc-dialog-box{font-family:Interface, Arial, sans-serif !important}.dialog-native.sc-dialog-box{left:50;display:none}.modal-display.sc-dialog-box{left:50%;display:block}.dialog-native.sc-dialog-box .dialog-box-body.sc-dialog-box{padding:10px}.dialog-box-header.sc-dialog-box{background:#201d29;color:#ffffff;text-align:left;display:flex;justify-content:space-between;align-items:center}.dialog-box-header.sc-dialog-box h5.sc-dialog-box{padding:10px;margin-block-start:0;margin-block-end:0;margin:0px}.dialog-box-header.sc-dialog-box span.sc-dialog-box{display:block;padding:14px 10px;cursor:pointer}.dialog-box-footer.sc-dialog-box button.sc-dialog-box{margin:10px;cursor:pointer;opacity:0.9}.dialog-box-footer.sc-dialog-box button.sc-dialog-box:hover{opacity:1}.dialog-box-body.sc-dialog-box fieldset.sc-dialog-box{text-align:left;width:80%;margin:0 auto}.dialog-box-body.sc-dialog-box p.sc-dialog-box{padding:10px}.dialog-box-body.sc-dialog-box{padding-top:16px}.dialog-box-body.sc-dialog-box fieldset.sc-dialog-box label.sc-dialog-box{margin:10px 0 10px 0}button.sc-dialog-box{color:#ffffff;padding:10px;border:0;border-radius:5px;display:inline-block;font-weight:400;text-align:center;white-space:nowrap;vertical-align:middle;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;border:1px solid transparent;padding:0.375rem 0.75rem;font-size:1rem;line-height:1.5;border-radius:0.25rem;transition:color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out}.btn-primary.sc-dialog-box,.btn-success.sc-dialog-box{color:#fff;background:#333333 !important;border-color:#333333 !important}.btn-light.sc-dialog-box{color:#212529;background:#f8f9fa !important;border-color:#f8f9fa !important}@media screen and (max-width: 1024px){.dialog-box.sc-dialog-box{width:90%;top:30%;transform:translate(-50%, 10%)}}';
const a = class {
    constructor(i) {
        t(this, i), this.openDialog = e(this, "openDialog", 7), this.markAllAsRead = e(this, "markAllAsRead", 7), this.updatePanelStatus = e(this, "updatePanelStatus", 7), this.closePanel = () => {
            this.updatePanelStatus.emit()
        }, this.toggleDatePicker = () => {
            this.openDialog.emit(!0)
        }, this.HeaderControl = void 0
    }
    toggleDialog() {
        this.openDialog.emit(!1)
    }
    markItemsAsRead() {
        this.markAllAsRead.emit({
            status: !0
        })
    }
    render() {
        return i(n, null, i("div", {
            class: "panel-header-controls"
        }, i("div", {
            class: "filter-option",
            onClick: () => this.toggleDatePicker()
        }, i("span", null, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-funnel",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M1.5 1.5A.5.5 0 0 1 2 1h12a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-.128.334L10 8.692V13.5a.5.5 0 0 1-.342.474l-3 1A.5.5 0 0 1 6 14.5V8.692L1.628 3.834A.5.5 0 0 1 1.5 3.5v-2zm1 .5v1.308l4.372 4.858A.5.5 0 0 1 7 8.5v5.306l2-.666V8.5a.5.5 0 0 1 .128-.334L13.5 3.308V2h-11z"
        })))), this.HeaderControl ? i("div", {
            class: "selection-icons"
        }, i("span", {
            onClick: () => this.markItemsAsRead()
        }, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-envelope-open",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M8.47 1.318a1 1 0 0 0-.94 0l-6 3.2A1 1 0 0 0 1 5.4v.817l5.75 3.45L8 8.917l1.25.75L15 6.217V5.4a1 1 0 0 0-.53-.882l-6-3.2ZM15 7.383l-4.778 2.867L15 13.117V7.383Zm-.035 6.88L8 10.082l-6.965 4.18A1 1 0 0 0 2 15h12a1 1 0 0 0 .965-.738ZM1 13.116l4.778-2.867L1 7.383v5.734ZM7.059.435a2 2 0 0 1 1.882 0l6 3.2A2 2 0 0 1 16 5.4V14a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V5.4a2 2 0 0 1 1.059-1.765l6-3.2Z"
        }))), i("span", {
            onClick: () => this.toggleDialog()
        }, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-trash3-fill",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"
        })))) : "", i("div", {
            class: "close-panel-icon",
            onClick: this.closePanel
        }, i("span", null, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-x-lg",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854Z"
        }))))))
    }
};
a.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}.panel-header-controls{color:#ffffff;display:flex;justify-content:space-between}.panel-header-controls span{margin:10px;display:block;cursor:pointer}.selection-icons{display:flex;padding:5px 0 0 0}.filter-option{padding:5px 0 0 0}.close-panel-icon{padding:5px 0 0 0}';
const c = class {
    constructor(i) {
        t(this, i), this.deselectItem = e(this, "deselectItem", 7), this.optionsStatus = e(this, "optionsStatus", 7), this.closeCurrentOption = e(this, "closeCurrentOption", 7), this.updateNotification = e(this, "updateNotification", 7), this.removeSelectedItem = e(this, "removeSelectedItem", 7), this.updateItemReadStatus = e(this, "updateItemReadStatus", 7), this.handleNotificationActions = e(this, "handleNotificationActions", 7), this.toggleMessage = t => {
            this.updateNotification.emit(t.notificationId)
        }, this.toggleOptions = t => {
            this.optionsStatus.emit(t.notificationId)
        }, this.setCurrentItemStatus = (t, e) => {
            this.deselectItem.emit(e.notificationId), t.currentTarget.style.display = "none"
        }, this.translate = t => {
            const e = "sport.notification." + t,
                i = this.Translations.find((t => t.Key == e));
            if (i) return i.Text
        }, this.handleAnchorClick = t => {
            t.preventDefault();
            const e = t.target.innerHTML,
                i = this.NotficationsArray.find((t => {
                    if (t.notificationActions.length > 0) return t.notificationActions[0].actionText == e
                }));
            i && this.handleNotificationActions.emit(i.notificationActions[0])
        }, this.sendActionData = t => {
            this.handleNotificationActions.emit(t)
        }, this.IsRead = !1, this.IsComplete = !1, this.BodyDisplay = !1, this.DisplayOptions = !1, this.Translations = void 0, this.IsSelected = void 0, this.IsReadStatus = void 0, this.SelectedTheme = void 0, this.HeaderControl = void 0, this.SelectedVertical = void 0, this.NotficationsArray = void 0
    }
    closeOptionsHolder() {
        const t = this.NotficationsArray;
        this.NotficationsArray = [], t.forEach((t => {
            t.optionsDisplay = !1, this.NotficationsArray = [...this.NotficationsArray, t]
        }))
    }
    updateIsRead() {
        this.IsRead = this.IsReadStatus
    }
    markItemAsRead(t) {
        this.updateItemReadStatus.emit({
            id: t.detail.id,
            status: t.detail.status
        })
    }
    markItemAsUnRead(t) {
        this.updateItemReadStatus.emit({
            id: t.detail.id,
            status: t.detail.status
        })
    }
    removeItem(t) {
        this.removeSelectedItem.emit(t.detail)
    }
    componentDidLoad() {
        this.resolveNotificationBody()
    }
    componentWillUpdate() {
        this.resolveNotificationBody()
    }
    resolveNotificationBody() {
        Array.from(this.element.shadowRoot.querySelectorAll(".notifications-holder")).forEach((t => {
            t.childNodes[1].childNodes[0].childNodes.length > 0 && Array.from(t.childNodes[1].childNodes[0].childNodes).forEach((t => {
                if ("A" == t.nodeName) t.setAttribute("data-action", t.innerHTML), t.addEventListener("click", this.handleAnchorClick);
                else if (t.querySelector && t.querySelector("a")) {
                    const e = t.querySelector("a");
                    e.setAttribute("data-action", t.innerHTML), e.addEventListener("click", this.handleAnchorClick)
                }
            }))
        }))
    }
    render() {
        return i(n, null, this.NotficationsArray.length > 0 ? this.NotficationsArray.map(((t, e) => i("div", {
            "data-theme": this.SelectedTheme,
            id: t.notificationId,
            key: e,
            "data-selected": this.IsSelected ? "selected" : "",
            class: t.isRead ? "notifications-holder" : "notifications-holder is-not-read"
        }, i("div", {
            class: "notifications-content"
        }, i("div", {
            class: "notification-content-left " + this.SelectedVertical
        }, i("div", {
            class: "is-selected",
            onClick: e => this.setCurrentItemStatus(e, t),
            style: {
                display: t.isSelected ? "block" : "none"
            }
        }, i("span", {
            class: "span-for-checked"
        }, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "16",
            height: "16",
            fill: "currentColor",
            class: "bi bi-check-circle-fill",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"
        })))), i("div", {
            class: "notification-icon"
        }, i("img", {
            src: "theme-dark" == this.SelectedTheme || "theme-light" == this.SelectedTheme ? "https://cms1.jpc.africa/medialibraries/content.gmgamingsystems.com/jackpotcity/branding/jpc_logo_light.svg" : "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PGRlZnM+PHN0eWxlPi5jbHMtMXtmaWxsOiMyMzFmMjA7fS5jbHMtMntmaWxsOiNmZmY7fTwvc3R5bGU+PC9kZWZzPjxnIGlkPSJMYXllcl8yIiBkYXRhLW5hbWU9IkxheWVyIDIiPjxnIGlkPSJMYXllcl8xLTIiIGRhdGEtbmFtZT0iTGF5ZXIgMSI+PGNpcmNsZSBjbGFzcz0iY2xzLTEiIGN4PSIxMiIgY3k9IjEyIiByPSIxMiIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTE1LjI4LDEwLjU0aC0xczAsMCwwLDBsLS4zMywxLjE5YzAsLjA4LDAsLjE2LS4wNy4yNWEuNjQuNjQsMCwwLDAsMC0uMDdsLS4zOS0xLjM2czAtLjA1LS4wNy0uMDVoLS41NXMtLjA2LDAtLjA3LjA1Yy0uMTEuNC0uMjMuOC0uMzQsMS4yMSwwLC4wNy0uMDUuMTQtLjA3LjIybDAsMGMtLjIzLS43LS40NS0xLjQtLjY4LTIuMDksMCwwLDAtLjA1LS4wNi0uMDVoLS45M2EuMTcuMTcsMCwwLDEsMCwuMDVsLjE0LjM5Yy4zNSwxLC43MSwyLDEuMDYsMywwLDAsMCwuMDUuMDcuMDVoLjY3YS4wNS4wNSwwLDAsMCwuMDYsMGMuMDktLjMyLjE5LS42NC4yOC0xLC4wNS0uMTUuMDktLjMuMTQtLjQ2YS40Mi40MiwwLDAsMCwwLC4wNmMuMTQuNDUuMjcuOTEuNDEsMS4zNiwwLDAsMCwuMDUuMDYuMDVoLjY4YS4wNS4wNSwwLDAsMCwuMDYsMGMuMjYtLjc2LjUzLTEuNTIuOC0yLjI4WiIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTE3LjYxLDEwLjU0bDAsLjA1LjM4Ljg3Yy4yNi41Ny41MSwxLjE0Ljc2LDEuNzJhLjA2LjA2LDAsMCwxLDAsLjA2Yy0uMDUuMTItLjEuMjQtLjE2LjM2YS4yNS4yNSwwLDAsMS0uMjIuMTZoLS4xN0wxOCwxMy42NmMtLjA4LjIyLS4xNi40NC0uMjUuNjZoMGExLjc5LDEuNzksMCwwLDAsLjc5LjE1LDEuNDEsMS40MSwwLDAsMCwuNDktLjEyLDEsMSwwLDAsMCwuNDQtLjUxbDEuMzgtMy4yOHMwLDAsMCwwaC0xczAsMC0uMDUsMGwtLjQ2LDEuMzVjMCwuMDctLjA1LjE1LS4wOS4yNHMwLDAsMC0uMDVjLS4xNy0uNTEtLjM1LTEtLjUzLTEuNTMsMCwwLDAtLjA1LS4wNi0uMDVoLTFaIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNMTAuMjcsMTEuMjRoLjY3djBjLS4wOC0uMjEtLjE1LS40My0uMjMtLjY0LDAsMCwwLDAsMCwwaC0uMzl2LS43aC0xdi43SDguODd2LjdoLjM5djEuMjNhMS42MywxLjYzLDAsMCwwLDAsLjMxLjY2LjY2LDAsMCwwLC41NS41OCwxLjU2LDEuNTYsMCwwLDAsMS0uMTJsLjIxLS4xMWMtLjA5LS4yMS0uMTgtLjQxLS4yNi0uNjFhLjE1LjE1LDAsMCwwLS4wNiwwLC42Mi42MiwwLDAsMS0uMzIuMTEuMTQuMTQsMCwwLDEtLjE0LS4xLDEuMSwxLjEsMCwwLDEsMC0uMThWMTEuMjRaIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNNS44NSwxMS4yMmExLjEsMS4xLDAsMCwwLS43MS0uNjcsMS41OSwxLjU5LDAsMCwwLS43OC0uMDVsLS4yMS4wNXYtMWgtMXYzLjY2aDBhMy40MiwzLjQyLDAsMCwwLC44OC4yMSwyLjU4LDIuNTgsMCwwLDAsLjg4LS4wNiwxLjI0LDEuMjQsMCwwLDAsLjkzLS44QTEuOCwxLjgsMCwwLDAsNS44NSwxMS4yMlptLS45MSwxLjA2YS41My41MywwLDAsMS0uNTcuMzhsLS4xNywwczAsMCwwLS4wNlYxMS4zMnMwLS4wNSwwLS4wNmEuODguODgsMCwwLDEsLjM2LDBBLjUxLjUxLDAsMCwxLDUsMTEuNiwxLjA2LDEuMDYsMCwwLDEsNC45NCwxMi4yOFoiLz48cGF0aCBjbGFzcz0iY2xzLTIiIGQ9Ik0xNy42OSwxMS4zOGEuODkuODksMCwwLDAtLjU4LS43OSwxLjUzLDEuNTMsMCwwLDAtLjY3LS4xMSwxLjY1LDEuNjUsMCwwLDAtLjk0LjI4bC0uMi4xNC40NS41LjExLS4wN2EuODYuODYsMCwwLDEsLjU2LS4xNi4zMy4zMywwLDAsMSwuMjkuNGwtLjQxLDBhMi44NSwyLjg1LDAsMCwwLS41OC4xMi44NS44NSwwLDAsMC0uNjIuODYuOC44LDAsMCwwLC40LjY4LDEuMiwxLjIsMCwwLDAsLjkxLjA3LDEsMSwwLDAsMCwuMzctLjIxbC4wNi4xOGEuMDUuMDUsMCwwLDAsLjA2LDBoLjhWMTEuNjJBMS45MywxLjkzLDAsMCwwLDE3LjY5LDExLjM4Wm0tMSwuODZ2LjMyczAsMCwwLDBhLjU0LjU0LDAsMCwxLS40NC4xMS4yOC4yOCwwLDAsMS0uMi0uMzYuMzIuMzIsMCwwLDEsLjI2LS4yM2wuNC0uMDZaIi8+PHBhdGggY2xhc3M9ImNscy0yIiBkPSJNOC44OSwxMi4xYTIuMiwyLjIsMCwwLDAtLjEzLS44LDEuMTgsMS4xOCwwLDAsMC0uNzEtLjc0LDEuNTgsMS41OCwwLDAsMC0uODEtLjA2LDEuMjQsMS4yNCwwLDAsMC0xLC43NSwxLjYzLDEuNjMsMCwwLDAtLjExLDEsMS4yNSwxLjI1LDAsMCwwLC45NCwxLjA2LDEuODQsMS44NCwwLDAsMCwuNzQuMDUsMS40OCwxLjQ4LDAsMCwwLC43Mi0uMjUsMS43OSwxLjc5LDAsMCwwLC4yOC0uMjdsLS42MS0uNDhoMGwwLDBhLjcuNywwLDAsMS0uNjguMjMuNS41LDAsMCwxLS40LS41Mkg4Ljg5Wm0tMS44MS0uNTFhLjUuNSwwLDAsMSwuNDUtLjQ4LjQ2LjQ2LDAsMCwxLC40Mi40OFoiLz48L2c+PC9nPjwvc3ZnPg=="
        }))), i("div", {
            onClick: () => this.toggleMessage(t),
            class: t.isSelected ? "notification-content-middle notification-middle-selected" : "notification-content-middle notification-middle"
        }, i("div", {
            class: t.bodyDisplay ? "notification-name header-alignment" : "notification-name"
        }, i("h4", {
            class: "noselect"
        }, t.messageHeader)), i("div", {
            class: "notification-time"
        }, i("span", {
            class: this.SelectedVertical
        }, t.timeOnDisplay ? t.notificationDate : ""))), i("div", {
            class: "notification-content-right notification-options",
            "data-status": t.optionsDisplay ? "opened" : "closed",
            onClick: () => this.toggleOptions(t)
        }, i("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            width: "20",
            height: "20",
            fill: "currentColor",
            class: "bi bi-three-dots",
            viewBox: "0 0 16 16"
        }, i("path", {
            d: "M3 9.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"
        })), t.optionsDisplay ? i("options-holder", {
            Translations: this.Translations,
            notification: t
        }) : "")), i("div", {
            class: t.bodyDisplay ? "notification-body notification-body-on noselect" : "notification-body noselect"
        }, t.imageURL ? i("img", {
            src: t.imageURL,
            alt: "notification image"
        }) : "", i("p", {
            class: this.SelectedVertical,
            innerHTML: t.messageBody
        })), i("div", {
            class: "notifications-action-buttons",
            style: {
                display: t.bodyDisplay ? "block" : "none"
            }
        }, t.notificationActions.length > 0 ? t.notificationActions.map(((t, e) => i("button", {
            onClick: () => this.sendActionData(t),
            key: e
        }, t.actionText))) : "")))) : i("p", {
            class: "no-notifications-tag"
        }, this.Translations.length > 0 ? this.translate("noNotifications") : "There are no notifications."))
    }
    get element() {
        return s(this)
    }
    static get watchers() {
        return {
            IsReadStatus: ["updateIsRead"]
        }
    }
};
c.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}.notifications-holder{border-bottom:1px solid #dfdfdf;border-color:rgba(0, 0, 0, 0.12);margin:5px;box-shadow:1px 0px 3px 1px rgba(51, 51, 51, 0.1411764706);border-radius:5px}:host{display:block;font-family:Interface, Arial, sans-serif}div[data-theme=theme-dark] .notification-icon img{width:100%}div[data-theme=theme-light] .notification-icon img{width:100%}.notifications-content{display:flex;justify-content:center;align-items:center;width:100%;margin:5px 0 0 0px;cursor:pointer;font-family:Interface, Arial, sans-serif;padding:5px 0px 5px 0px}.no-notifications-tag{text-align:center}.notifications-content .read-active{width:10px;height:10px;border-radius:50%;background-color:unset;margin:13px 0px 0 0}.is-not-read{background:#f1f1f1;padding:1px 0px 0 0}.is-not-read .notification-time{color:#00a826}.is-not-read .notification-time .casino{color:#0066cc !important}.is-not-read .notification-time .vegas{color:#e60000 !important}.is-not-read .notification-time .live-casino{color:#66cae1 !important}.is-not-read .notification-time .virtual-sport{color:#04a09d !important}.is-not-read .notification-time .esports{color:#833594 !important}.is-not-read .notification-time .sports{color:#00a826 !important}.is-not-read .read-active{display:block;width:10px;height:10px;border-radius:50%;background:#00a826;margin:14px 0px 0px 20px}.is-not-read .notification-middle{width:73%;padding:5px 0 0 0}.is-not-read .spans{width:13%}.is-not-read .casino .green-dot{background:#0066cc !important}.is-not-read .vegas .green-dot{background:#e60000 !important}.is-not-read .live-casino .green-dot{background:#66cae1 !important}.is-not-read .virtual-sport .green-dot{background:#04a09d !important}.is-not-read .esports .green-dot{background:#833594 !important}.is-not-read .sports a.green-dot{background:#00a826 !important}.notification-options{color:#505050;position:relative;cursor:pointer}.notification-options span{display:block;cursor:pointer}.notification-icon{cursor:pointer;text-align:center;min-width:35px;max-height:35px;width:35px;padding:0 5px 0px 5px;align-self:start}.notification-middle{width:100%;height:100%;flex-direction:column;padding:0 0 0 0}.notification-middle-selected{width:67%;padding:0 0 0 0}.notification-body{padding:10px 0 0 55px;font-size:12px;width:75%;display:none;margin:-20px 0px 0px -12px}div[data-selected=selected] .notification-body{margin:-35px 0px 0px 15px}.notification-body-on{display:block;transition:all 0.6s}.notification-body-on img{width:100%;margin:10px 0 10px 0}.notification-name{margin:0;padding:0}.notification-name h4{font-weight:bold;margin:0;padding:0;font-size:14px}.notification-time{margin:0;padding:0;font-size:12px;padding:2px 0 0 0}.spans{display:flex;width:13%;justify-content:space-between}.spans .span-for-checked{display:block;width:10px;height:10px;border-radius:50%;background:unset;margin:11px 2px 0 0}.panel-body-controls span{margin:10px 4px 0 0}.notification-content-right{display:flex;width:20%;justify-content:center;align-items:center}.notification-content-left{width:20%;display:flex;align-items:center;justify-content:start}.notification-content-middle{display:flex;align-items:start;justify-content:start;width:80%}.is-selected{padding:15px 3px 0 5px}.green-dot{background:#00a826;width:10px;height:10px;border-radius:50%;margin:18px 0 0 5px}.casino a{color:#0066cc !important}.vegas a{color:#e60000 !important}.live-casino a{color:#66cae1 !important}.virtual-sport a{color:#04a09d !important}.esports a{color:#833594 !important}.sports a{color:#00a826 !important}.header-alignment{padding:0 0 0 0}.notifications-action-buttons button{list-style-type:none;font-size:12px;padding:10px;border:none;border-radius:5px;background-color:#201d29;color:#ffffff;text-align:center;margin:2px 0 15px 45px;cursor:pointer}.notifications-action-buttons button:hover{background-color:#cccccc;color:#333333}@media screen and (max-width: 1280px){.notification-content-left{width:17%}}@media screen and (max-width: 320px){div[data-selected=selected] .notification-content-left{width:20% !important}.notification-content-left{width:15% !important}}@media screen and (max-width: 280px){div[data-selected=selected] .notification-content-left{width:23% !important}.notification-content-left{width:17% !important}}@media screen and (max-height: 864px){.notification-content-left{width:13%}div[data-selected=selected] .notification-content-left{width:16%}}@media screen and (max-width: 1280px) and (orientation: portrait){.panel-body-controls span{margin:10px 8px 0 0}.notification-body{margin:-20px 0px 0px -9px}.notification-middle-selected{padding:5px 0 0 10px}}@media (min-width: 801px){.notification-content-left{width:8%}.notification-body{margin:-20px 0px 0px -2px}}@media (min-width: 1025px){.notification-content-left{width:8%}.notification-body{margin:-20px 0px 0px -2px}}@media (max-width: 912px) and (min-height: 1000px){.notification-content-left{width:7%}div[data-selected=selected] .notification-content-left{width:10%}.notification-body{margin:-39px 0px 0px -2px}}@media (min-width: 1000px) and (min-height: 600px){.notification-content-left{width:5%}div[data-selected=selected] .notification-content-left{width:7%}.notification-body{margin:-20px 0px 0px -2px}}@media (min-width: 1240px) and (min-height: 720px){.notification-content-left{width:16%}.notification-body{margin:-20px 0px 0px -2px}}@media (min-width: 1280px) and (min-height: 720px){.notification-content-left{width:5%}div[data-selected=selected] .notification-content-left{width:6%}.notification-body{margin:-20px 0px 0px -6px}}@media (min-width: 712px) and (max-height: 1138px){.notification-content-left{width:13%}div[data-selected=selected] .notification-content-left{width:20%}.notification-body{margin:-15px 0px 0px -10px}.noselect{-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}}';
class h extends Error {
    constructor(t, e) {
        const i = new.target.prototype;
        super(`${t}: Status code '${e}'`), this.statusCode = e, this.__proto__ = i
    }
}
class l extends Error {
    constructor(t = "A timeout occurred.") {
        const e = new.target.prototype;
        super(t), this.__proto__ = e
    }
}
class d extends Error {
    constructor(t = "An abort occurred.") {
        const e = new.target.prototype;
        super(t), this.__proto__ = e
    }
}
class u extends Error {
    constructor(t, e) {
        const i = new.target.prototype;
        super(t), this.transport = e, this.errorType = "UnsupportedTransportError", this.__proto__ = i
    }
}
class f extends Error {
    constructor(t, e) {
        const i = new.target.prototype;
        super(t), this.transport = e, this.errorType = "DisabledTransportError", this.__proto__ = i
    }
}
class p extends Error {
    constructor(t, e) {
        const i = new.target.prototype;
        super(t), this.transport = e, this.errorType = "FailedToStartTransportError", this.__proto__ = i
    }
}
class w extends Error {
    constructor(t) {
        const e = new.target.prototype;
        super(t), this.errorType = "FailedToNegotiateWithServerError", this.__proto__ = e
    }
}
class g extends Error {
    constructor(t, e) {
        const i = new.target.prototype;
        super(t), this.innerErrors = e, this.__proto__ = i
    }
}
class m {
    constructor(t, e, i) {
        this.statusCode = t, this.statusText = e, this.content = i
    }
}
class b {
    get(t, e) {
        return this.send({ ...e,
            method: "GET",
            url: t
        })
    }
    post(t, e) {
        return this.send({ ...e,
            method: "POST",
            url: t
        })
    }
    delete(t, e) {
        return this.send({ ...e,
            method: "DELETE",
            url: t
        })
    }
    getCookieString(t) {
        return ""
    }
}
var y, x, v;
! function(t) {
    t[t.Trace = 0] = "Trace", t[t.Debug = 1] = "Debug", t[t.Information = 2] = "Information", t[t.Warning = 3] = "Warning", t[t.Error = 4] = "Error", t[t.Critical = 5] = "Critical", t[t.None = 6] = "None"
}(y || (y = {}));
class L {
    constructor() {}
    log(t, e) {}
}
L.instance = new L;
class M {
    static isRequired(t, e) {
        if (null == t) throw new Error(`The '${e}' argument is required.`)
    }
    static isNotEmpty(t, e) {
        if (!t || t.match(/^\s*$/)) throw new Error(`The '${e}' argument should not be empty.`)
    }
    static isIn(t, e, i) {
        if (!(t in e)) throw new Error(`Unknown ${i} value: ${t}.`)
    }
}
class S {
    static get isBrowser() {
        return "object" == typeof window && "object" == typeof window.document
    }
    static get isWebWorker() {
        return "object" == typeof self && "importScripts" in self
    }
    static get isReactNative() {
        return "object" == typeof window && void 0 === window.document
    }
    static get isNode() {
        return !this.isBrowser && !this.isWebWorker && !this.isReactNative
    }
}

function k(t, e) {
    let i = "";
    return C(t) ? (i = `Binary data of length ${t.byteLength}`, e && (i += `. Content: '${function(t){const e=new Uint8Array(t);let i="";return e.forEach((t=>{i+=`0x${t<16?"0":""}${t.toString(16)} `})),i.substr(0,i.length-1)}(t)}'`)) : "string" == typeof t && (i = `String data of length ${t.length}`, e && (i += `. Content: '${t}'`)), i
}

function C(t) {
    return t && "undefined" != typeof ArrayBuffer && (t instanceof ArrayBuffer || t.constructor && "ArrayBuffer" === t.constructor.name)
}
async function D(t, e, i, n, s, o, r) {
    let a = {};
    if (s) {
        const t = await s();
        t && (a = {
            Authorization: `Bearer ${t}`
        })
    }
    const [c, h] = A();
    a[c] = h, t.log(y.Trace, `(${e} transport) sending data. ${k(o,r.logMessageContent)}.`);
    const l = C(o) ? "arraybuffer" : "text",
        d = await i.post(n, {
            content: o,
            headers: { ...a,
                ...r.headers
            },
            responseType: l,
            timeout: r.timeout,
            withCredentials: r.withCredentials
        });
    t.log(y.Trace, `(${e} transport) request complete. Response status: ${d.statusCode}.`)
}
class E {
    constructor(t, e) {
        this._subject = t, this._observer = e
    }
    dispose() {
        const t = this._subject.observers.indexOf(this._observer);
        t > -1 && this._subject.observers.splice(t, 1), 0 === this._subject.observers.length && this._subject.cancelCallback && this._subject.cancelCallback().catch((() => {}))
    }
}
class I {
    constructor(t) {
        this._minLevel = t, this.out = console
    }
    log(t, e) {
        if (t >= this._minLevel) {
            const i = `[${(new Date).toISOString()}] ${y[t]}: ${e}`;
            switch (t) {
                case y.Critical:
                case y.Error:
                    this.out.error(i);
                    break;
                case y.Warning:
                    this.out.warn(i);
                    break;
                case y.Information:
                    this.out.info(i);
                    break;
                default:
                    this.out.log(i)
            }
        }
    }
}

function A() {
    let t = "X-SignalR-User-Agent";
    return S.isNode && (t = "User-Agent"), [t, j("6.0.10", N(), S.isNode ? "NodeJS" : "Browser", T())]
}

function j(t, e, i, n) {
    let s = "Microsoft SignalR/";
    const o = t.split(".");
    return s += `${o[0]}.${o[1]}`, s += ` (${t}; `, s += e && "" !== e ? `${e}; ` : "Unknown OS; ", s += `${i}`, s += n ? `; ${n}` : "; Unknown Runtime Version", s += ")", s
}

function N() {
    if (!S.isNode) return "";
    switch (process.platform) {
        case "win32":
            return "Windows NT";
        case "darwin":
            return "macOS";
        case "linux":
            return "Linux";
        default:
            return process.platform
    }
}

function T() {
    if (S.isNode) return process.versions.node
}

function $(t) {
    return t.stack ? t.stack : t.message ? t.message : `${t}`
}
class P extends b {
    constructor(t) {
        if (super(), this._logger = t, "undefined" == typeof fetch) {
            const t = "function" == typeof __webpack_require__ ? __non_webpack_require__ : require;
            this._jar = new(t("tough-cookie").CookieJar), this._fetchType = t("node-fetch"), this._fetchType = t("fetch-cookie")(this._fetchType, this._jar)
        } else this._fetchType = fetch.bind(function() {
            if ("undefined" != typeof globalThis) return globalThis;
            if ("undefined" != typeof self) return self;
            if ("undefined" != typeof window) return window;
            if ("undefined" != typeof global) return global;
            throw new Error("could not find global")
        }());
        if ("undefined" == typeof AbortController) {
            const t = "function" == typeof __webpack_require__ ? __non_webpack_require__ : require;
            this._abortControllerType = t("abort-controller")
        } else this._abortControllerType = AbortController
    }
    async send(t) {
        if (t.abortSignal && t.abortSignal.aborted) throw new d;
        if (!t.method) throw new Error("No method defined.");
        if (!t.url) throw new Error("No url defined.");
        const e = new this._abortControllerType;
        let i;
        t.abortSignal && (t.abortSignal.onabort = () => {
            e.abort(), i = new d
        });
        let n, s = null;
        t.timeout && (s = setTimeout((() => {
            e.abort(), this._logger.log(y.Warning, "Timeout from HTTP request."), i = new l
        }), t.timeout));
        try {
            n = await this._fetchType(t.url, {
                body: t.content,
                cache: "no-cache",
                credentials: !0 === t.withCredentials ? "include" : "same-origin",
                headers: {
                    "Content-Type": "text/plain;charset=UTF-8",
                    "X-Requested-With": "XMLHttpRequest",
                    ...t.headers
                },
                method: t.method,
                mode: "cors",
                redirect: "follow",
                signal: e.signal
            })
        } catch (t) {
            if (i) throw i;
            throw this._logger.log(y.Warning, `Error from HTTP request. ${t}.`), t
        } finally {
            s && clearTimeout(s), t.abortSignal && (t.abortSignal.onabort = null)
        }
        if (!n.ok) {
            const t = await _(n, "text");
            throw new h(t || n.statusText, n.status)
        }
        const o = _(n, t.responseType),
            r = await o;
        return new m(n.status, n.statusText, r)
    }
    getCookieString(t) {
        let e = "";
        return S.isNode && this._jar && this._jar.getCookies(t, ((t, i) => e = i.join("; "))), e
    }
}

function _(t, e) {
    let i;
    switch (e) {
        case "arraybuffer":
            i = t.arrayBuffer();
            break;
        case "text":
            i = t.text();
            break;
        case "blob":
        case "document":
        case "json":
            throw new Error(`${e} is not supported.`);
        default:
            i = t.text()
    }
    return i
}
class O extends b {
    constructor(t) {
        super(), this._logger = t
    }
    send(t) {
        return t.abortSignal && t.abortSignal.aborted ? Promise.reject(new d) : t.method ? t.url ? new Promise(((e, i) => {
            const n = new XMLHttpRequest;
            n.open(t.method, t.url, !0), n.withCredentials = void 0 === t.withCredentials || t.withCredentials, n.setRequestHeader("X-Requested-With", "XMLHttpRequest"), n.setRequestHeader("Content-Type", "text/plain;charset=UTF-8");
            const s = t.headers;
            s && Object.keys(s).forEach((t => {
                n.setRequestHeader(t, s[t])
            })), t.responseType && (n.responseType = t.responseType), t.abortSignal && (t.abortSignal.onabort = () => {
                n.abort(), i(new d)
            }), t.timeout && (n.timeout = t.timeout), n.onload = () => {
                t.abortSignal && (t.abortSignal.onabort = null), n.status >= 200 && n.status < 300 ? e(new m(n.status, n.statusText, n.response || n.responseText)) : i(new h(n.response || n.responseText || n.statusText, n.status))
            }, n.onerror = () => {
                this._logger.log(y.Warning, `Error from HTTP request. ${n.status}: ${n.statusText}.`), i(new h(n.statusText, n.status))
            }, n.ontimeout = () => {
                this._logger.log(y.Warning, "Timeout from HTTP request."), i(new l)
            }, n.send(t.content || "")
        })) : Promise.reject(new Error("No url defined.")) : Promise.reject(new Error("No method defined."))
    }
}
class z extends b {
    constructor(t) {
        if (super(), "undefined" != typeof fetch || S.isNode) this._httpClient = new P(t);
        else {
            if ("undefined" == typeof XMLHttpRequest) throw new Error("No usable HttpClient found.");
            this._httpClient = new O(t)
        }
    }
    send(t) {
        return t.abortSignal && t.abortSignal.aborted ? Promise.reject(new d) : t.method ? t.url ? this._httpClient.send(t) : Promise.reject(new Error("No url defined.")) : Promise.reject(new Error("No method defined."))
    }
    getCookieString(t) {
        return this._httpClient.getCookieString(t)
    }
}
class U {
    static write(t) {
        return `${t}${U.RecordSeparator}`
    }
    static parse(t) {
        if (t[t.length - 1] !== U.RecordSeparator) throw new Error("Message is incomplete.");
        const e = t.split(U.RecordSeparator);
        return e.pop(), e
    }
}
U.RecordSeparatorCode = 30, U.RecordSeparator = String.fromCharCode(U.RecordSeparatorCode);
class B {
    writeHandshakeRequest(t) {
        return U.write(JSON.stringify(t))
    }
    parseHandshakeResponse(t) {
        let e, i;
        if (C(t)) {
            const n = new Uint8Array(t),
                s = n.indexOf(U.RecordSeparatorCode);
            if (-1 === s) throw new Error("Message is incomplete.");
            const o = s + 1;
            e = String.fromCharCode.apply(null, Array.prototype.slice.call(n.slice(0, o))), i = n.byteLength > o ? n.slice(o).buffer : null
        } else {
            const n = t,
                s = n.indexOf(U.RecordSeparator);
            if (-1 === s) throw new Error("Message is incomplete.");
            const o = s + 1;
            e = n.substring(0, o), i = n.length > o ? n.substring(o) : null
        }
        const n = U.parse(e),
            s = JSON.parse(n[0]);
        if (s.type) throw new Error("Expected a handshake response from the server.");
        return [i, s]
    }
}! function(t) {
    t[t.Invocation = 1] = "Invocation", t[t.StreamItem = 2] = "StreamItem", t[t.Completion = 3] = "Completion", t[t.StreamInvocation = 4] = "StreamInvocation", t[t.CancelInvocation = 5] = "CancelInvocation", t[t.Ping = 6] = "Ping", t[t.Close = 7] = "Close"
}(x || (x = {}));
class R {
    constructor() {
        this.observers = []
    }
    next(t) {
        for (const e of this.observers) e.next(t)
    }
    error(t) {
        for (const e of this.observers) e.error && e.error(t)
    }
    complete() {
        for (const t of this.observers) t.complete && t.complete()
    }
    subscribe(t) {
        return this.observers.push(t), new E(this, t)
    }
}! function(t) {
    t.Disconnected = "Disconnected", t.Connecting = "Connecting", t.Connected = "Connected", t.Disconnecting = "Disconnecting", t.Reconnecting = "Reconnecting"
}(v || (v = {}));
class H {
    constructor(t, e, i, n) {
        this._nextKeepAlive = 0, this._freezeEventListener = () => {
            this._logger.log(y.Warning, "The page is being frozen, this will likely lead to the connection being closed and messages being lost. For more information see the docs at https://docs.microsoft.com/aspnet/core/signalr/javascript-client#bsleep")
        }, M.isRequired(t, "connection"), M.isRequired(e, "logger"), M.isRequired(i, "protocol"), this.serverTimeoutInMilliseconds = 3e4, this.keepAliveIntervalInMilliseconds = 15e3, this._logger = e, this._protocol = i, this.connection = t, this._reconnectPolicy = n, this._handshakeProtocol = new B, this.connection.onreceive = t => this._processIncomingData(t), this.connection.onclose = t => this._connectionClosed(t), this._callbacks = {}, this._methods = {}, this._closedCallbacks = [], this._reconnectingCallbacks = [], this._reconnectedCallbacks = [], this._invocationId = 0, this._receivedHandshakeResponse = !1, this._connectionState = v.Disconnected, this._connectionStarted = !1, this._cachedPingMessage = this._protocol.writeMessage({
            type: x.Ping
        })
    }
    static create(t, e, i, n) {
        return new H(t, e, i, n)
    }
    get state() {
        return this._connectionState
    }
    get connectionId() {
        return this.connection && this.connection.connectionId || null
    }
    get baseUrl() {
        return this.connection.baseUrl || ""
    }
    set baseUrl(t) {
        if (this._connectionState !== v.Disconnected && this._connectionState !== v.Reconnecting) throw new Error("The HubConnection must be in the Disconnected or Reconnecting state to change the url.");
        if (!t) throw new Error("The HubConnection url must be a valid url.");
        this.connection.baseUrl = t
    }
    start() {
        return this._startPromise = this._startWithStateTransitions(), this._startPromise
    }
    async _startWithStateTransitions() {
        if (this._connectionState !== v.Disconnected) return Promise.reject(new Error("Cannot start a HubConnection that is not in the 'Disconnected' state."));
        this._connectionState = v.Connecting, this._logger.log(y.Debug, "Starting HubConnection.");
        try {
            await this._startInternal(), S.isBrowser && window.document.addEventListener("freeze", this._freezeEventListener), this._connectionState = v.Connected, this._connectionStarted = !0, this._logger.log(y.Debug, "HubConnection connected successfully.")
        } catch (t) {
            return this._connectionState = v.Disconnected, this._logger.log(y.Debug, `HubConnection failed to start successfully because of error '${t}'.`), Promise.reject(t)
        }
    }
    async _startInternal() {
        this._stopDuringStartError = void 0, this._receivedHandshakeResponse = !1;
        const t = new Promise(((t, e) => {
            this._handshakeResolver = t, this._handshakeRejecter = e
        }));
        await this.connection.start(this._protocol.transferFormat);
        try {
            const e = {
                protocol: this._protocol.name,
                version: this._protocol.version
            };
            if (this._logger.log(y.Debug, "Sending handshake request."), await this._sendMessage(this._handshakeProtocol.writeHandshakeRequest(e)), this._logger.log(y.Information, `Using HubProtocol '${this._protocol.name}'.`), this._cleanupTimeout(), this._resetTimeoutPeriod(), this._resetKeepAliveInterval(), await t, this._stopDuringStartError) throw this._stopDuringStartError
        } catch (t) {
            throw this._logger.log(y.Debug, `Hub handshake failed with error '${t}' during start(). Stopping HubConnection.`), this._cleanupTimeout(), this._cleanupPingTimer(), await this.connection.stop(t), t
        }
    }
    async stop() {
        const t = this._startPromise;
        this._stopPromise = this._stopInternal(), await this._stopPromise;
        try {
            await t
        } catch (t) {}
    }
    _stopInternal(t) {
        return this._connectionState === v.Disconnected ? (this._logger.log(y.Debug, `Call to HubConnection.stop(${t}) ignored because it is already in the disconnected state.`), Promise.resolve()) : this._connectionState === v.Disconnecting ? (this._logger.log(y.Debug, `Call to HttpConnection.stop(${t}) ignored because the connection is already in the disconnecting state.`), this._stopPromise) : (this._connectionState = v.Disconnecting, this._logger.log(y.Debug, "Stopping HubConnection."), this._reconnectDelayHandle ? (this._logger.log(y.Debug, "Connection stopped during reconnect delay. Done reconnecting."), clearTimeout(this._reconnectDelayHandle), this._reconnectDelayHandle = void 0, this._completeClose(), Promise.resolve()) : (this._cleanupTimeout(), this._cleanupPingTimer(), this._stopDuringStartError = t || new Error("The connection was stopped before the hub handshake could complete."), this.connection.stop(t)))
    }
    stream(t, ...e) {
        const [i, n] = this._replaceStreamingParams(e), s = this._createStreamInvocation(t, e, n);
        let o;
        const r = new R;
        return r.cancelCallback = () => {
            const t = this._createCancelInvocation(s.invocationId);
            return delete this._callbacks[s.invocationId], o.then((() => this._sendWithProtocol(t)))
        }, this._callbacks[s.invocationId] = (t, e) => {
            e ? r.error(e) : t && (t.type === x.Completion ? t.error ? r.error(new Error(t.error)) : r.complete() : r.next(t.item))
        }, o = this._sendWithProtocol(s).catch((t => {
            r.error(t), delete this._callbacks[s.invocationId]
        })), this._launchStreams(i, o), r
    }
    _sendMessage(t) {
        return this._resetKeepAliveInterval(), this.connection.send(t)
    }
    _sendWithProtocol(t) {
        return this._sendMessage(this._protocol.writeMessage(t))
    }
    send(t, ...e) {
        const [i, n] = this._replaceStreamingParams(e), s = this._sendWithProtocol(this._createInvocation(t, e, !0, n));
        return this._launchStreams(i, s), s
    }
    invoke(t, ...e) {
        const [i, n] = this._replaceStreamingParams(e), s = this._createInvocation(t, e, !1, n);
        return new Promise(((t, e) => {
            this._callbacks[s.invocationId] = (i, n) => {
                n ? e(n) : i && (i.type === x.Completion ? i.error ? e(new Error(i.error)) : t(i.result) : e(new Error(`Unexpected message type: ${i.type}`)))
            };
            const n = this._sendWithProtocol(s).catch((t => {
                e(t), delete this._callbacks[s.invocationId]
            }));
            this._launchStreams(i, n)
        }))
    }
    on(t, e) {
        t && e && (t = t.toLowerCase(), this._methods[t] || (this._methods[t] = []), -1 === this._methods[t].indexOf(e) && this._methods[t].push(e))
    }
    off(t, e) {
        if (!t) return;
        t = t.toLowerCase();
        const i = this._methods[t];
        if (i)
            if (e) {
                const n = i.indexOf(e); - 1 !== n && (i.splice(n, 1), 0 === i.length && delete this._methods[t])
            } else delete this._methods[t]
    }
    onclose(t) {
        t && this._closedCallbacks.push(t)
    }
    onreconnecting(t) {
        t && this._reconnectingCallbacks.push(t)
    }
    onreconnected(t) {
        t && this._reconnectedCallbacks.push(t)
    }
    _processIncomingData(t) {
        if (this._cleanupTimeout(), this._receivedHandshakeResponse || (t = this._processHandshakeResponse(t), this._receivedHandshakeResponse = !0), t) {
            const e = this._protocol.parseMessages(t, this._logger);
            for (const t of e) switch (t.type) {
                case x.Invocation:
                    this._invokeClientMethod(t);
                    break;
                case x.StreamItem:
                case x.Completion:
                    {
                        const e = this._callbacks[t.invocationId];
                        if (e) {
                            t.type === x.Completion && delete this._callbacks[t.invocationId];
                            try {
                                e(t)
                            } catch (t) {
                                this._logger.log(y.Error, `Stream callback threw error: ${$(t)}`)
                            }
                        }
                        break
                    }
                case x.Ping:
                    break;
                case x.Close:
                    {
                        this._logger.log(y.Information, "Close message received from server.");
                        const e = t.error ? new Error("Server returned an error on close: " + t.error) : void 0;!0 === t.allowReconnect ? this.connection.stop(e) : this._stopPromise = this._stopInternal(e);
                        break
                    }
                default:
                    this._logger.log(y.Warning, `Invalid message type: ${t.type}.`)
            }
        }
        this._resetTimeoutPeriod()
    }
    _processHandshakeResponse(t) {
        let e, i;
        try {
            [i, e] = this._handshakeProtocol.parseHandshakeResponse(t)
        } catch (t) {
            const e = "Error parsing handshake response: " + t;
            this._logger.log(y.Error, e);
            const i = new Error(e);
            throw this._handshakeRejecter(i), i
        }
        if (e.error) {
            const t = "Server returned handshake error: " + e.error;
            this._logger.log(y.Error, t);
            const i = new Error(t);
            throw this._handshakeRejecter(i), i
        }
        return this._logger.log(y.Debug, "Server handshake complete."), this._handshakeResolver(), i
    }
    _resetKeepAliveInterval() {
        this.connection.features.inherentKeepAlive || (this._nextKeepAlive = (new Date).getTime() + this.keepAliveIntervalInMilliseconds, this._cleanupPingTimer())
    }
    _resetTimeoutPeriod() {
        if (!(this.connection.features && this.connection.features.inherentKeepAlive || (this._timeoutHandle = setTimeout((() => this.serverTimeout()), this.serverTimeoutInMilliseconds), void 0 !== this._pingServerHandle))) {
            let t = this._nextKeepAlive - (new Date).getTime();
            t < 0 && (t = 0), this._pingServerHandle = setTimeout((async () => {
                if (this._connectionState === v.Connected) try {
                    await this._sendMessage(this._cachedPingMessage)
                } catch {
                    this._cleanupPingTimer()
                }
            }), t)
        }
    }
    serverTimeout() {
        this.connection.stop(new Error("Server timeout elapsed without receiving a message from the server."))
    }
    _invokeClientMethod(t) {
        const e = this._methods[t.target.toLowerCase()];
        if (e) {
            try {
                e.forEach((e => e.apply(this, t.arguments)))
            } catch (e) {
                this._logger.log(y.Error, `A callback for the method ${t.target.toLowerCase()} threw error '${e}'.`)
            }
            if (t.invocationId) {
                const t = "Server requested a response, which is not supported in this version of the client.";
                this._logger.log(y.Error, t), this._stopPromise = this._stopInternal(new Error(t))
            }
        } else this._logger.log(y.Warning, `No client method with the name '${t.target}' found.`)
    }
    _connectionClosed(t) {
        this._logger.log(y.Debug, `HubConnection.connectionClosed(${t}) called while in state ${this._connectionState}.`), this._stopDuringStartError = this._stopDuringStartError || t || new Error("The underlying connection was closed before the hub handshake could complete."), this._handshakeResolver && this._handshakeResolver(), this._cancelCallbacksWithError(t || new Error("Invocation canceled due to the underlying connection being closed.")), this._cleanupTimeout(), this._cleanupPingTimer(), this._connectionState === v.Disconnecting ? this._completeClose(t) : this._connectionState === v.Connected && this._reconnectPolicy ? this._reconnect(t) : this._connectionState === v.Connected && this._completeClose(t)
    }
    _completeClose(t) {
        if (this._connectionStarted) {
            this._connectionState = v.Disconnected, this._connectionStarted = !1, S.isBrowser && window.document.removeEventListener("freeze", this._freezeEventListener);
            try {
                this._closedCallbacks.forEach((e => e.apply(this, [t])))
            } catch (e) {
                this._logger.log(y.Error, `An onclose callback called with error '${t}' threw error '${e}'.`)
            }
        }
    }
    async _reconnect(t) {
        const e = Date.now();
        let i = 0,
            n = void 0 !== t ? t : new Error("Attempting to reconnect due to a unknown error."),
            s = this._getNextRetryDelay(i++, 0, n);
        if (null === s) return this._logger.log(y.Debug, "Connection not reconnecting because the IRetryPolicy returned null on the first reconnect attempt."), void this._completeClose(t);
        if (this._connectionState = v.Reconnecting, this._logger.log(y.Information, t ? `Connection reconnecting because of error '${t}'.` : "Connection reconnecting."), 0 !== this._reconnectingCallbacks.length) {
            try {
                this._reconnectingCallbacks.forEach((e => e.apply(this, [t])))
            } catch (e) {
                this._logger.log(y.Error, `An onreconnecting callback called with error '${t}' threw error '${e}'.`)
            }
            if (this._connectionState !== v.Reconnecting) return void this._logger.log(y.Debug, "Connection left the reconnecting state in onreconnecting callback. Done reconnecting.")
        }
        for (; null !== s;) {
            if (this._logger.log(y.Information, `Reconnect attempt number ${i} will start in ${s} ms.`), await new Promise((t => {
                    this._reconnectDelayHandle = setTimeout(t, s)
                })), this._reconnectDelayHandle = void 0, this._connectionState !== v.Reconnecting) return void this._logger.log(y.Debug, "Connection left the reconnecting state during reconnect delay. Done reconnecting.");
            try {
                if (await this._startInternal(), this._connectionState = v.Connected, this._logger.log(y.Information, "HubConnection reconnected successfully."), 0 !== this._reconnectedCallbacks.length) try {
                    this._reconnectedCallbacks.forEach((t => t.apply(this, [this.connection.connectionId])))
                } catch (t) {
                    this._logger.log(y.Error, `An onreconnected callback called with connectionId '${this.connection.connectionId}; threw error '${t}'.`)
                }
                return
            } catch (t) {
                if (this._logger.log(y.Information, `Reconnect attempt failed because of error '${t}'.`), this._connectionState !== v.Reconnecting) return this._logger.log(y.Debug, `Connection moved to the '${this._connectionState}' from the reconnecting state during reconnect attempt. Done reconnecting.`), void(this._connectionState === v.Disconnecting && this._completeClose());
                n = t instanceof Error ? t : new Error(t.toString()), s = this._getNextRetryDelay(i++, Date.now() - e, n)
            }
        }
        this._logger.log(y.Information, `Reconnect retries have been exhausted after ${Date.now()-e} ms and ${i} failed attempts. Connection disconnecting.`), this._completeClose()
    }
    _getNextRetryDelay(t, e, i) {
        try {
            return this._reconnectPolicy.nextRetryDelayInMilliseconds({
                elapsedMilliseconds: e,
                previousRetryCount: t,
                retryReason: i
            })
        } catch (i) {
            return this._logger.log(y.Error, `IRetryPolicy.nextRetryDelayInMilliseconds(${t}, ${e}) threw error '${i}'.`), null
        }
    }
    _cancelCallbacksWithError(t) {
        const e = this._callbacks;
        this._callbacks = {}, Object.keys(e).forEach((i => {
            const n = e[i];
            try {
                n(null, t)
            } catch (e) {
                this._logger.log(y.Error, `Stream 'error' callback called with '${t}' threw error: ${$(e)}`)
            }
        }))
    }
    _cleanupPingTimer() {
        this._pingServerHandle && (clearTimeout(this._pingServerHandle), this._pingServerHandle = void 0)
    }
    _cleanupTimeout() {
        this._timeoutHandle && clearTimeout(this._timeoutHandle)
    }
    _createInvocation(t, e, i, n) {
        if (i) return 0 !== n.length ? {
            arguments: e,
            streamIds: n,
            target: t,
            type: x.Invocation
        } : {
            arguments: e,
            target: t,
            type: x.Invocation
        }; {
            const i = this._invocationId;
            return this._invocationId++, 0 !== n.length ? {
                arguments: e,
                invocationId: i.toString(),
                streamIds: n,
                target: t,
                type: x.Invocation
            } : {
                arguments: e,
                invocationId: i.toString(),
                target: t,
                type: x.Invocation
            }
        }
    }
    _launchStreams(t, e) {
        if (0 !== t.length) {
            e || (e = Promise.resolve());
            for (const i in t) t[i].subscribe({
                complete: () => {
                    e = e.then((() => this._sendWithProtocol(this._createCompletionMessage(i))))
                },
                error: t => {
                    let n;
                    n = t instanceof Error ? t.message : t && t.toString ? t.toString() : "Unknown error", e = e.then((() => this._sendWithProtocol(this._createCompletionMessage(i, n))))
                },
                next: t => {
                    e = e.then((() => this._sendWithProtocol(this._createStreamItemMessage(i, t))))
                }
            })
        }
    }
    _replaceStreamingParams(t) {
        const e = [],
            i = [];
        for (let n = 0; n < t.length; n++) {
            const s = t[n];
            if (this._isObservable(s)) {
                const o = this._invocationId;
                this._invocationId++, e[o] = s, i.push(o.toString()), t.splice(n, 1)
            }
        }
        return [e, i]
    }
    _isObservable(t) {
        return t && t.subscribe && "function" == typeof t.subscribe
    }
    _createStreamInvocation(t, e, i) {
        const n = this._invocationId;
        return this._invocationId++, 0 !== i.length ? {
            arguments: e,
            invocationId: n.toString(),
            streamIds: i,
            target: t,
            type: x.StreamInvocation
        } : {
            arguments: e,
            invocationId: n.toString(),
            target: t,
            type: x.StreamInvocation
        }
    }
    _createCancelInvocation(t) {
        return {
            invocationId: t,
            type: x.CancelInvocation
        }
    }
    _createStreamItemMessage(t, e) {
        return {
            invocationId: t,
            item: e,
            type: x.StreamItem
        }
    }
    _createCompletionMessage(t, e, i) {
        return e ? {
            error: e,
            invocationId: t,
            type: x.Completion
        } : {
            invocationId: t,
            result: i,
            type: x.Completion
        }
    }
}
const F = [0, 2e3, 1e4, 3e4, null];
class W {
    constructor(t) {
        this._retryDelays = void 0 !== t ? [...t, null] : F
    }
    nextRetryDelayInMilliseconds(t) {
        return this._retryDelays[t.previousRetryCount]
    }
}
class Y {}
var q, V;
Y.Authorization = "Authorization", Y.Cookie = "Cookie",
    function(t) {
        t[t.None = 0] = "None", t[t.WebSockets = 1] = "WebSockets", t[t.ServerSentEvents = 2] = "ServerSentEvents", t[t.LongPolling = 4] = "LongPolling"
    }(q || (q = {})),
    function(t) {
        t[t.Text = 1] = "Text", t[t.Binary = 2] = "Binary"
    }(V || (V = {}));
class G {
    constructor() {
        this._isAborted = !1, this.onabort = null
    }
    abort() {
        this._isAborted || (this._isAborted = !0, this.onabort && this.onabort())
    }
    get signal() {
        return this
    }
    get aborted() {
        return this._isAborted
    }
}
class J {
    constructor(t, e, i, n) {
        this._httpClient = t, this._accessTokenFactory = e, this._logger = i, this._pollAbort = new G, this._options = n, this._running = !1, this.onreceive = null, this.onclose = null
    }
    get pollAborted() {
        return this._pollAbort.aborted
    }
    async connect(t, e) {
        if (M.isRequired(t, "url"), M.isRequired(e, "transferFormat"), M.isIn(e, V, "transferFormat"), this._url = t, this._logger.log(y.Trace, "(LongPolling transport) Connecting."), e === V.Binary && "undefined" != typeof XMLHttpRequest && "string" != typeof(new XMLHttpRequest).responseType) throw new Error("Binary protocols over XmlHttpRequest not implementing advanced features are not supported.");
        const [i, n] = A(), s = {
            [i]: n,
            ...this._options.headers
        }, o = {
            abortSignal: this._pollAbort.signal,
            headers: s,
            timeout: 1e5,
            withCredentials: this._options.withCredentials
        };
        e === V.Binary && (o.responseType = "arraybuffer");
        const r = await this._getAccessToken();
        this._updateHeaderToken(o, r);
        const a = `${t}&_=${Date.now()}`;
        this._logger.log(y.Trace, `(LongPolling transport) polling: ${a}.`);
        const c = await this._httpClient.get(a, o);
        200 !== c.statusCode ? (this._logger.log(y.Error, `(LongPolling transport) Unexpected response code: ${c.statusCode}.`), this._closeError = new h(c.statusText || "", c.statusCode), this._running = !1) : this._running = !0, this._receiving = this._poll(this._url, o)
    }
    async _getAccessToken() {
        return this._accessTokenFactory ? await this._accessTokenFactory() : null
    }
    _updateHeaderToken(t, e) {
        t.headers || (t.headers = {}), e ? t.headers[Y.Authorization] = `Bearer ${e}` : t.headers[Y.Authorization] && delete t.headers[Y.Authorization]
    }
    async _poll(t, e) {
        try {
            for (; this._running;) {
                const i = await this._getAccessToken();
                this._updateHeaderToken(e, i);
                try {
                    const i = `${t}&_=${Date.now()}`;
                    this._logger.log(y.Trace, `(LongPolling transport) polling: ${i}.`);
                    const n = await this._httpClient.get(i, e);
                    204 === n.statusCode ? (this._logger.log(y.Information, "(LongPolling transport) Poll terminated by server."), this._running = !1) : 200 !== n.statusCode ? (this._logger.log(y.Error, `(LongPolling transport) Unexpected response code: ${n.statusCode}.`), this._closeError = new h(n.statusText || "", n.statusCode), this._running = !1) : n.content ? (this._logger.log(y.Trace, `(LongPolling transport) data received. ${k(n.content,this._options.logMessageContent)}.`), this.onreceive && this.onreceive(n.content)) : this._logger.log(y.Trace, "(LongPolling transport) Poll timed out, reissuing.")
                } catch (t) {
                    this._running ? t instanceof l ? this._logger.log(y.Trace, "(LongPolling transport) Poll timed out, reissuing.") : (this._closeError = t, this._running = !1) : this._logger.log(y.Trace, `(LongPolling transport) Poll errored after shutdown: ${t.message}`)
                }
            }
        } finally {
            this._logger.log(y.Trace, "(LongPolling transport) Polling complete."), this.pollAborted || this._raiseOnClose()
        }
    }
    async send(t) {
        return this._running ? D(this._logger, "LongPolling", this._httpClient, this._url, this._accessTokenFactory, t, this._options) : Promise.reject(new Error("Cannot send until the transport is connected"))
    }
    async stop() {
        this._logger.log(y.Trace, "(LongPolling transport) Stopping polling."), this._running = !1, this._pollAbort.abort();
        try {
            await this._receiving, this._logger.log(y.Trace, `(LongPolling transport) sending DELETE request to ${this._url}.`);
            const t = {},
                [e, i] = A();
            t[e] = i;
            const n = {
                    headers: { ...t,
                        ...this._options.headers
                    },
                    timeout: this._options.timeout,
                    withCredentials: this._options.withCredentials
                },
                s = await this._getAccessToken();
            this._updateHeaderToken(n, s), await this._httpClient.delete(this._url, n), this._logger.log(y.Trace, "(LongPolling transport) DELETE request sent.")
        } finally {
            this._logger.log(y.Trace, "(LongPolling transport) Stop finished."), this._raiseOnClose()
        }
    }
    _raiseOnClose() {
        if (this.onclose) {
            let t = "(LongPolling transport) Firing onclose event.";
            this._closeError && (t += " Error: " + this._closeError), this._logger.log(y.Trace, t), this.onclose(this._closeError)
        }
    }
}
class Z {
    constructor(t, e, i, n) {
        this._httpClient = t, this._accessTokenFactory = e, this._logger = i, this._options = n, this.onreceive = null, this.onclose = null
    }
    async connect(t, e) {
        if (M.isRequired(t, "url"), M.isRequired(e, "transferFormat"), M.isIn(e, V, "transferFormat"), this._logger.log(y.Trace, "(SSE transport) Connecting."), this._url = t, this._accessTokenFactory) {
            const e = await this._accessTokenFactory();
            e && (t += (t.indexOf("?") < 0 ? "?" : "&") + `access_token=${encodeURIComponent(e)}`)
        }
        return new Promise(((i, n) => {
            let s, o = !1;
            if (e === V.Text) {
                if (S.isBrowser || S.isWebWorker) s = new this._options.EventSource(t, {
                    withCredentials: this._options.withCredentials
                });
                else {
                    const e = this._httpClient.getCookieString(t),
                        i = {};
                    i.Cookie = e;
                    const [n, o] = A();
                    i[n] = o, s = new this._options.EventSource(t, {
                        withCredentials: this._options.withCredentials,
                        headers: { ...i,
                            ...this._options.headers
                        }
                    })
                }
                try {
                    s.onmessage = t => {
                        if (this.onreceive) try {
                            this._logger.log(y.Trace, `(SSE transport) data received. ${k(t.data,this._options.logMessageContent)}.`), this.onreceive(t.data)
                        } catch (t) {
                            return void this._close(t)
                        }
                    }, s.onerror = () => {
                        o ? this._close() : n(new Error("EventSource failed to connect. The connection could not be found on the server, either the connection ID is not present on the server, or a proxy is refusing/buffering the connection. If you have multiple servers check that sticky sessions are enabled."))
                    }, s.onopen = () => {
                        this._logger.log(y.Information, `SSE connected to ${this._url}`), this._eventSource = s, o = !0, i()
                    }
                } catch (t) {
                    return void n(t)
                }
            } else n(new Error("The Server-Sent Events transport only supports the 'Text' transfer format"))
        }))
    }
    async send(t) {
        return this._eventSource ? D(this._logger, "SSE", this._httpClient, this._url, this._accessTokenFactory, t, this._options) : Promise.reject(new Error("Cannot send until the transport is connected"))
    }
    stop() {
        return this._close(), Promise.resolve()
    }
    _close(t) {
        this._eventSource && (this._eventSource.close(), this._eventSource = void 0, this.onclose && this.onclose(t))
    }
}
class Q {
    constructor(t, e, i, n, s, o) {
        this._logger = i, this._accessTokenFactory = e, this._logMessageContent = n, this._webSocketConstructor = s, this._httpClient = t, this.onreceive = null, this.onclose = null, this._headers = o
    }
    async connect(t, e) {
        if (M.isRequired(t, "url"), M.isRequired(e, "transferFormat"), M.isIn(e, V, "transferFormat"), this._logger.log(y.Trace, "(WebSockets transport) Connecting."), this._accessTokenFactory) {
            const e = await this._accessTokenFactory();
            e && (t += (t.indexOf("?") < 0 ? "?" : "&") + `access_token=${encodeURIComponent(e)}`)
        }
        return new Promise(((i, n) => {
            let s;
            t = t.replace(/^http/, "ws");
            const o = this._httpClient.getCookieString(t);
            let r = !1;
            if (S.isNode) {
                const e = {},
                    [i, n] = A();
                e[i] = n, o && (e[Y.Cookie] = `${o}`), s = new this._webSocketConstructor(t, void 0, {
                    headers: { ...e,
                        ...this._headers
                    }
                })
            }
            s || (s = new this._webSocketConstructor(t)), e === V.Binary && (s.binaryType = "arraybuffer"), s.onopen = () => {
                this._logger.log(y.Information, `WebSocket connected to ${t}.`), this._webSocket = s, r = !0, i()
            }, s.onerror = t => {
                let e = null;
                e = "undefined" != typeof ErrorEvent && t instanceof ErrorEvent ? t.error : "There was an error with the transport", this._logger.log(y.Information, `(WebSockets transport) ${e}.`)
            }, s.onmessage = t => {
                if (this._logger.log(y.Trace, `(WebSockets transport) data received. ${k(t.data,this._logMessageContent)}.`), this.onreceive) try {
                    this.onreceive(t.data)
                } catch (t) {
                    return void this._close(t)
                }
            }, s.onclose = t => {
                if (r) this._close(t);
                else {
                    let e = null;
                    e = "undefined" != typeof ErrorEvent && t instanceof ErrorEvent ? t.error : "WebSocket failed to connect. The connection could not be found on the server, either the endpoint may not be a SignalR endpoint, the connection ID is not present on the server, or there is a proxy blocking WebSockets. If you have multiple servers check that sticky sessions are enabled.", n(new Error(e))
                }
            }
        }))
    }
    send(t) {
        return this._webSocket && this._webSocket.readyState === this._webSocketConstructor.OPEN ? (this._logger.log(y.Trace, `(WebSockets transport) sending data. ${k(t,this._logMessageContent)}.`), this._webSocket.send(t), Promise.resolve()) : Promise.reject("WebSocket is not in the OPEN state")
    }
    stop() {
        return this._webSocket && this._close(void 0), Promise.resolve()
    }
    _close(t) {
        this._webSocket && (this._webSocket.onclose = () => {}, this._webSocket.onmessage = () => {}, this._webSocket.onerror = () => {}, this._webSocket.close(), this._webSocket = void 0), this._logger.log(y.Trace, "(WebSockets transport) socket closed."), this.onclose && (!this._isCloseEvent(t) || !1 !== t.wasClean && 1e3 === t.code ? t instanceof Error ? this.onclose(t) : this.onclose() : this.onclose(new Error(`WebSocket closed with status code: ${t.code} (${t.reason||"no reason given"}).`)))
    }
    _isCloseEvent(t) {
        return t && "boolean" == typeof t.wasClean && "number" == typeof t.code
    }
}
class K {
    constructor(t, e = {}) {
        if (this._stopPromiseResolver = () => {}, this.features = {}, this._negotiateVersion = 1, M.isRequired(t, "url"), this._logger = function(t) {
                return void 0 === t ? new I(y.Information) : null === t ? L.instance : void 0 !== t.log ? t : new I(t)
            }(e.logger), this.baseUrl = this._resolveUrl(t), (e = e || {}).logMessageContent = void 0 !== e.logMessageContent && e.logMessageContent, "boolean" != typeof e.withCredentials && void 0 !== e.withCredentials) throw new Error("withCredentials option was not a 'boolean' or 'undefined' value");
        e.withCredentials = void 0 === e.withCredentials || e.withCredentials, e.timeout = void 0 === e.timeout ? 1e5 : e.timeout;
        let i = null,
            n = null;
        if (S.isNode && "undefined" != typeof require) {
            const t = "function" == typeof __webpack_require__ ? __non_webpack_require__ : require;
            i = t("ws"), n = t("eventsource")
        }
        S.isNode || "undefined" == typeof WebSocket || e.WebSocket ? S.isNode && !e.WebSocket && i && (e.WebSocket = i) : e.WebSocket = WebSocket, S.isNode || "undefined" == typeof EventSource || e.EventSource ? S.isNode && !e.EventSource && void 0 !== n && (e.EventSource = n) : e.EventSource = EventSource, this._httpClient = e.httpClient || new z(this._logger), this._connectionState = "Disconnected", this._connectionStarted = !1, this._options = e, this.onreceive = null, this.onclose = null
    }
    async start(t) {
        if (M.isIn(t = t || V.Binary, V, "transferFormat"), this._logger.log(y.Debug, `Starting connection with transfer format '${V[t]}'.`), "Disconnected" !== this._connectionState) return Promise.reject(new Error("Cannot start an HttpConnection that is not in the 'Disconnected' state."));
        if (this._connectionState = "Connecting", this._startInternalPromise = this._startInternal(t), await this._startInternalPromise, "Disconnecting" === this._connectionState) {
            const t = "Failed to start the HttpConnection before stop() was called.";
            return this._logger.log(y.Error, t), await this._stopPromise, Promise.reject(new Error(t))
        }
        if ("Connected" !== this._connectionState) {
            const t = "HttpConnection.startInternal completed gracefully but didn't enter the connection into the connected state!";
            return this._logger.log(y.Error, t), Promise.reject(new Error(t))
        }
        this._connectionStarted = !0
    }
    send(t) {
        return "Connected" !== this._connectionState ? Promise.reject(new Error("Cannot send data if the connection is not in the 'Connected' State.")) : (this._sendQueue || (this._sendQueue = new X(this.transport)), this._sendQueue.send(t))
    }
    async stop(t) {
        return "Disconnected" === this._connectionState ? (this._logger.log(y.Debug, `Call to HttpConnection.stop(${t}) ignored because the connection is already in the disconnected state.`), Promise.resolve()) : "Disconnecting" === this._connectionState ? (this._logger.log(y.Debug, `Call to HttpConnection.stop(${t}) ignored because the connection is already in the disconnecting state.`), this._stopPromise) : (this._connectionState = "Disconnecting", this._stopPromise = new Promise((t => {
            this._stopPromiseResolver = t
        })), await this._stopInternal(t), void await this._stopPromise)
    }
    async _stopInternal(t) {
        this._stopError = t;
        try {
            await this._startInternalPromise
        } catch (t) {}
        if (this.transport) {
            try {
                await this.transport.stop()
            } catch (t) {
                this._logger.log(y.Error, `HttpConnection.transport.stop() threw error '${t}'.`), this._stopConnection()
            }
            this.transport = void 0
        } else this._logger.log(y.Debug, "HttpConnection.transport is undefined in HttpConnection.stop() because start() failed.")
    }
    async _startInternal(t) {
        let e = this.baseUrl;
        this._accessTokenFactory = this._options.accessTokenFactory;
        try {
            if (this._options.skipNegotiation) {
                if (this._options.transport !== q.WebSockets) throw new Error("Negotiation can only be skipped when using the WebSocket transport directly.");
                this.transport = this._constructTransport(q.WebSockets), await this._startTransport(e, t)
            } else {
                let i = null,
                    n = 0;
                do {
                    if (i = await this._getNegotiationResponse(e), "Disconnecting" === this._connectionState || "Disconnected" === this._connectionState) throw new Error("The connection was stopped during negotiation.");
                    if (i.error) throw new Error(i.error);
                    if (i.ProtocolVersion) throw new Error("Detected a connection attempt to an ASP.NET SignalR Server. This client only supports connecting to an ASP.NET Core SignalR Server. See https://aka.ms/signalr-core-differences for details.");
                    if (i.url && (e = i.url), i.accessToken) {
                        const t = i.accessToken;
                        this._accessTokenFactory = () => t
                    }
                    n++
                } while (i.url && n < 100);
                if (100 === n && i.url) throw new Error("Negotiate redirection limit exceeded.");
                await this._createTransport(e, this._options.transport, i, t)
            }
            this.transport instanceof J && (this.features.inherentKeepAlive = !0), "Connecting" === this._connectionState && (this._logger.log(y.Debug, "The HttpConnection connected successfully."), this._connectionState = "Connected")
        } catch (t) {
            return this._logger.log(y.Error, "Failed to start the connection: " + t), this._connectionState = "Disconnected", this.transport = void 0, this._stopPromiseResolver(), Promise.reject(t)
        }
    }
    async _getNegotiationResponse(t) {
        const e = {};
        if (this._accessTokenFactory) {
            const t = await this._accessTokenFactory();
            t && (e[Y.Authorization] = `Bearer ${t}`)
        }
        const [i, n] = A();
        e[i] = n;
        const s = this._resolveNegotiateUrl(t);
        this._logger.log(y.Debug, `Sending negotiation request: ${s}.`);
        try {
            const t = await this._httpClient.post(s, {
                content: "",
                headers: { ...e,
                    ...this._options.headers
                },
                timeout: this._options.timeout,
                withCredentials: this._options.withCredentials
            });
            if (200 !== t.statusCode) return Promise.reject(new Error(`Unexpected status code returned from negotiate '${t.statusCode}'`));
            const i = JSON.parse(t.content);
            return (!i.negotiateVersion || i.negotiateVersion < 1) && (i.connectionToken = i.connectionId), i
        } catch (t) {
            let e = "Failed to complete negotiation with the server: " + t;
            return t instanceof h && 404 === t.statusCode && (e += " Either this is not a SignalR endpoint or there is a proxy blocking the connection."), this._logger.log(y.Error, e), Promise.reject(new w(e))
        }
    }
    _createConnectUrl(t, e) {
        return e ? t + (-1 === t.indexOf("?") ? "?" : "&") + `id=${e}` : t
    }
    async _createTransport(t, e, i, n) {
        let s = this._createConnectUrl(t, i.connectionToken);
        if (this._isITransport(e)) return this._logger.log(y.Debug, "Connection was provided an instance of ITransport, using that directly."), this.transport = e, await this._startTransport(s, n), void(this.connectionId = i.connectionId);
        const o = [],
            r = i.availableTransports || [];
        let a = i;
        for (const i of r) {
            const r = this._resolveTransportOrError(i, e, n);
            if (r instanceof Error) o.push(`${i.transport} failed:`), o.push(r);
            else if (this._isITransport(r)) {
                if (this.transport = r, !a) {
                    try {
                        a = await this._getNegotiationResponse(t)
                    } catch (t) {
                        return Promise.reject(t)
                    }
                    s = this._createConnectUrl(t, a.connectionToken)
                }
                try {
                    return await this._startTransport(s, n), void(this.connectionId = a.connectionId)
                } catch (t) {
                    if (this._logger.log(y.Error, `Failed to start the transport '${i.transport}': ${t}`), a = void 0, o.push(new p(`${i.transport} failed: ${t}`, q[i.transport])), "Connecting" !== this._connectionState) {
                        const t = "Failed to select transport before stop() was called.";
                        return this._logger.log(y.Debug, t), Promise.reject(new Error(t))
                    }
                }
            }
        }
        return Promise.reject(o.length > 0 ? new g(`Unable to connect to the server with any of the available transports. ${o.join(" ")}`, o) : new Error("None of the transports supported by the client are supported by the server."))
    }
    _constructTransport(t) {
        switch (t) {
            case q.WebSockets:
                if (!this._options.WebSocket) throw new Error("'WebSocket' is not supported in your environment.");
                return new Q(this._httpClient, this._accessTokenFactory, this._logger, this._options.logMessageContent, this._options.WebSocket, this._options.headers || {});
            case q.ServerSentEvents:
                if (!this._options.EventSource) throw new Error("'EventSource' is not supported in your environment.");
                return new Z(this._httpClient, this._accessTokenFactory, this._logger, this._options);
            case q.LongPolling:
                return new J(this._httpClient, this._accessTokenFactory, this._logger, this._options);
            default:
                throw new Error(`Unknown transport: ${t}.`)
        }
    }
    _startTransport(t, e) {
        return this.transport.onreceive = this.onreceive, this.transport.onclose = t => this._stopConnection(t), this.transport.connect(t, e)
    }
    _resolveTransportOrError(t, e, i) {
        const n = q[t.transport];
        if (null == n) return this._logger.log(y.Debug, `Skipping transport '${t.transport}' because it is not supported by this client.`), new Error(`Skipping transport '${t.transport}' because it is not supported by this client.`);
        if (! function(t, e) {
                return !t || 0 != (e & t)
            }(e, n)) return this._logger.log(y.Debug, `Skipping transport '${q[n]}' because it was disabled by the client.`), new f(`'${q[n]}' is disabled by the client.`, n);
        if (!(t.transferFormats.map((t => V[t])).indexOf(i) >= 0)) return this._logger.log(y.Debug, `Skipping transport '${q[n]}' because it does not support the requested transfer format '${V[i]}'.`), new Error(`'${q[n]}' does not support ${V[i]}.`);
        if (n === q.WebSockets && !this._options.WebSocket || n === q.ServerSentEvents && !this._options.EventSource) return this._logger.log(y.Debug, `Skipping transport '${q[n]}' because it is not supported in your environment.'`), new u(`'${q[n]}' is not supported in your environment.`, n);
        this._logger.log(y.Debug, `Selecting transport '${q[n]}'.`);
        try {
            return this._constructTransport(n)
        } catch (t) {
            return t
        }
    }
    _isITransport(t) {
        return t && "object" == typeof t && "connect" in t
    }
    _stopConnection(t) {
        if (this._logger.log(y.Debug, `HttpConnection.stopConnection(${t}) called while in state ${this._connectionState}.`), this.transport = void 0, t = this._stopError || t, this._stopError = void 0, "Disconnected" !== this._connectionState) {
            if ("Connecting" === this._connectionState) throw this._logger.log(y.Warning, `Call to HttpConnection.stopConnection(${t}) was ignored because the connection is still in the connecting state.`), new Error(`HttpConnection.stopConnection(${t}) was called while the connection is still in the connecting state.`);
            if ("Disconnecting" === this._connectionState && this._stopPromiseResolver(), t ? this._logger.log(y.Error, `Connection disconnected with error '${t}'.`) : this._logger.log(y.Information, "Connection disconnected."), this._sendQueue && (this._sendQueue.stop().catch((t => {
                    this._logger.log(y.Error, `TransportSendQueue.stop() threw error '${t}'.`)
                })), this._sendQueue = void 0), this.connectionId = void 0, this._connectionState = "Disconnected", this._connectionStarted) {
                this._connectionStarted = !1;
                try {
                    this.onclose && this.onclose(t)
                } catch (e) {
                    this._logger.log(y.Error, `HttpConnection.onclose(${t}) threw error '${e}'.`)
                }
            }
        } else this._logger.log(y.Debug, `Call to HttpConnection.stopConnection(${t}) was ignored because the connection is already in the disconnected state.`)
    }
    _resolveUrl(t) {
        if (0 === t.lastIndexOf("https://", 0) || 0 === t.lastIndexOf("http://", 0)) return t;
        if (!S.isBrowser) throw new Error(`Cannot resolve '${t}'.`);
        const e = window.document.createElement("a");
        return e.href = t, this._logger.log(y.Information, `Normalizing '${t}' to '${e.href}'.`), e.href
    }
    _resolveNegotiateUrl(t) {
        const e = t.indexOf("?");
        let i = t.substring(0, -1 === e ? t.length : e);
        return "/" !== i[i.length - 1] && (i += "/"), i += "negotiate", i += -1 === e ? "" : t.substring(e), -1 === i.indexOf("negotiateVersion") && (i += -1 === e ? "?" : "&", i += "negotiateVersion=" + this._negotiateVersion), i
    }
}
class X {
    constructor(t) {
        this._transport = t, this._buffer = [], this._executing = !0, this._sendBufferedData = new tt, this._transportResult = new tt, this._sendLoopPromise = this._sendLoop()
    }
    send(t) {
        return this._bufferData(t), this._transportResult || (this._transportResult = new tt), this._transportResult.promise
    }
    stop() {
        return this._executing = !1, this._sendBufferedData.resolve(), this._sendLoopPromise
    }
    _bufferData(t) {
        if (this._buffer.length && typeof this._buffer[0] != typeof t) throw new Error(`Expected data to be of type ${typeof this._buffer} but was of type ${typeof t}`);
        this._buffer.push(t), this._sendBufferedData.resolve()
    }
    async _sendLoop() {
        for (;;) {
            if (await this._sendBufferedData.promise, !this._executing) {
                this._transportResult && this._transportResult.reject("Connection stopped.");
                break
            }
            this._sendBufferedData = new tt;
            const t = this._transportResult;
            this._transportResult = void 0;
            const e = "string" == typeof this._buffer[0] ? this._buffer.join("") : X._concatBuffers(this._buffer);
            this._buffer.length = 0;
            try {
                await this._transport.send(e), t.resolve()
            } catch (e) {
                t.reject(e)
            }
        }
    }
    static _concatBuffers(t) {
        const e = t.map((t => t.byteLength)).reduce(((t, e) => t + e)),
            i = new Uint8Array(e);
        let n = 0;
        for (const e of t) i.set(new Uint8Array(e), n), n += e.byteLength;
        return i.buffer
    }
}
class tt {
    constructor() {
        this.promise = new Promise(((t, e) => [this._resolver, this._rejecter] = [t, e]))
    }
    resolve() {
        this._resolver()
    }
    reject(t) {
        this._rejecter(t)
    }
}
class et {
    constructor() {
        this.name = "json", this.version = 1, this.transferFormat = V.Text
    }
    parseMessages(t, e) {
        if ("string" != typeof t) throw new Error("Invalid input for JSON hub protocol. Expected a string.");
        if (!t) return [];
        null === e && (e = L.instance);
        const i = U.parse(t),
            n = [];
        for (const t of i) {
            const i = JSON.parse(t);
            if ("number" != typeof i.type) throw new Error("Invalid payload.");
            switch (i.type) {
                case x.Invocation:
                    this._isInvocationMessage(i);
                    break;
                case x.StreamItem:
                    this._isStreamItemMessage(i);
                    break;
                case x.Completion:
                    this._isCompletionMessage(i);
                    break;
                case x.Ping:
                case x.Close:
                    break;
                default:
                    e.log(y.Information, "Unknown message type '" + i.type + "' ignored.");
                    continue
            }
            n.push(i)
        }
        return n
    }
    writeMessage(t) {
        return U.write(JSON.stringify(t))
    }
    _isInvocationMessage(t) {
        this._assertNotEmptyString(t.target, "Invalid payload for Invocation message."), void 0 !== t.invocationId && this._assertNotEmptyString(t.invocationId, "Invalid payload for Invocation message.")
    }
    _isStreamItemMessage(t) {
        if (this._assertNotEmptyString(t.invocationId, "Invalid payload for StreamItem message."), void 0 === t.item) throw new Error("Invalid payload for StreamItem message.")
    }
    _isCompletionMessage(t) {
        if (t.result && t.error) throw new Error("Invalid payload for Completion message.");
        !t.result && t.error && this._assertNotEmptyString(t.error, "Invalid payload for Completion message."), this._assertNotEmptyString(t.invocationId, "Invalid payload for Completion message.")
    }
    _assertNotEmptyString(t, e) {
        if ("string" != typeof t || "" === t) throw new Error(e)
    }
}
const it = {
    trace: y.Trace,
    debug: y.Debug,
    info: y.Information,
    information: y.Information,
    warn: y.Warning,
    warning: y.Warning,
    error: y.Error,
    critical: y.Critical,
    none: y.None
};
class nt {
    configureLogging(t) {
        if (M.isRequired(t, "logging"), function(t) {
                return void 0 !== t.log
            }
            (t)) this.logger = t;
        else if ("string" == typeof t) {
            const e = function(t) {
                const e = it[t.toLowerCase()];
                if (void 0 !== e) return e;
                throw new Error(`Unknown log level: ${t}`)
            }(t);
            this.logger = new I(e)
        } else this.logger = new I(t);
        return this
    }
    withUrl(t, e) {
        return M.isRequired(t, "url"), M.isNotEmpty(t, "url"), this.url = t, this.httpConnectionOptions = "object" == typeof e ? { ...this.httpConnectionOptions,
            ...e
        } : { ...this.httpConnectionOptions,
            transport: e
        }, this
    }
    withHubProtocol(t) {
        return M.isRequired(t, "protocol"), this.protocol = t, this
    }
    withAutomaticReconnect(t) {
        if (this.reconnectPolicy) throw new Error("A reconnectPolicy has already been set.");
        return this.reconnectPolicy = t ? Array.isArray(t) ? new W(t) : t : new W, this
    }
    build() {
        const t = this.httpConnectionOptions || {};
        if (void 0 === t.logger && (t.logger = this.logger), !this.url) throw new Error("The 'HubConnectionBuilder.withUrl' method must be called before building the connection.");
        const e = new K(this.url, t);
        return H.create(e, this.logger || L.instance, this.protocol || new et, this.reconnectPolicy)
    }
}
const st = function(t) {
        const e = [];
        let i = 0;
        for (let n = 0; n < t.length; n++) {
            let s = t.charCodeAt(n);
            s < 128 ? e[i++] = s : s < 2048 ? (e[i++] = s >> 6 | 192, e[i++] = 63 & s | 128) : 55296 == (64512 & s) && n + 1 < t.length && 56320 == (64512 & t.charCodeAt(n + 1)) ? (s = 65536 + ((1023 & s) << 10) + (1023 & t.charCodeAt(++n)), e[i++] = s >> 18 | 240, e[i++] = s >> 12 & 63 | 128, e[i++] = s >> 6 & 63 | 128, e[i++] = 63 & s | 128) : (e[i++] = s >> 12 | 224, e[i++] = s >> 6 & 63 | 128, e[i++] = 63 & s | 128)
        }
        return e
    },
    ot = {
        byteToCharMap_: null,
        charToByteMap_: null,
        byteToCharMapWebSafe_: null,
        charToByteMapWebSafe_: null,
        ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        get ENCODED_VALS() {
            return this.ENCODED_VALS_BASE + "+/="
        },
        get ENCODED_VALS_WEBSAFE() {
            return this.ENCODED_VALS_BASE + "-_."
        },
        HAS_NATIVE_SUPPORT: "function" == typeof atob,
        encodeByteArray(t, e) {
            if (!Array.isArray(t)) throw Error("encodeByteArray takes an array as a parameter");
            this.init_();
            const i = e ? this.byteToCharMapWebSafe_ : this.byteToCharMap_,
                n = [];
            for (let e = 0; e < t.length; e += 3) {
                const s = t[e],
                    o = e + 1 < t.length,
                    r = o ? t[e + 1] : 0,
                    a = e + 2 < t.length,
                    c = a ? t[e + 2] : 0;
                let h = (15 & r) << 2 | c >> 6,
                    l = 63 & c;
                a || (l = 64, o || (h = 64)), n.push(i[s >> 2], i[(3 & s) << 4 | r >> 4], i[h], i[l])
            }
            return n.join("")
        },
        encodeString(t, e) {
            return this.HAS_NATIVE_SUPPORT && !e ? btoa(t) : this.encodeByteArray(st(t), e)
        },
        decodeString(t, e) {
            return this.HAS_NATIVE_SUPPORT && !e ? atob(t) : function(t) {
                const e = [];
                let i = 0,
                    n = 0;
                for (; i < t.length;) {
                    const s = t[i++];
                    if (s < 128) e[n++] = String.fromCharCode(s);
                    else if (s > 191 && s < 224) {
                        const o = t[i++];
                        e[n++] = String.fromCharCode((31 & s) << 6 | 63 & o)
                    } else if (s > 239 && s < 365) {
                        const o = ((7 & s) << 18 | (63 & t[i++]) << 12 | (63 & t[i++]) << 6 | 63 & t[i++]) - 65536;
                        e[n++] = String.fromCharCode(55296 + (o >> 10)), e[n++] = String.fromCharCode(56320 + (1023 & o))
                    } else {
                        const o = t[i++],
                            r = t[i++];
                        e[n++] = String.fromCharCode((15 & s) << 12 | (63 & o) << 6 | 63 & r)
                    }
                }
                return e.join("")
            }(this.decodeStringToByteArray(t, e))
        },
        decodeStringToByteArray(t, e) {
            this.init_();
            const i = e ? this.charToByteMapWebSafe_ : this.charToByteMap_,
                n = [];
            for (let e = 0; e < t.length;) {
                const s = i[t.charAt(e++)],
                    o = e < t.length ? i[t.charAt(e)] : 0;
                ++e;
                const r = e < t.length ? i[t.charAt(e)] : 64;
                ++e;
                const a = e < t.length ? i[t.charAt(e)] : 64;
                if (++e, null == s || null == o || null == r || null == a) throw Error();
                n.push(s << 2 | o >> 4), 64 !== r && (n.push(o << 4 & 240 | r >> 2), 64 !== a && n.push(r << 6 & 192 | a))
            }
            return n
        },
        init_() {
            if (!this.byteToCharMap_) {
                this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
                for (let t = 0; t < this.ENCODED_VALS.length; t++) this.byteToCharMap_[t] = this.ENCODED_VALS.charAt(t), this.charToByteMap_[this.byteToCharMap_[t]] = t, this.byteToCharMapWebSafe_[t] = this.ENCODED_VALS_WEBSAFE.charAt(t), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[t]] = t, t >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(t)] = t, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(t)] = t)
            }
        }
    },
    rt = function(t) {
        return function(t) {
            const e = st(t);
            return ot.encodeByteArray(e, !0)
        }(t).replace(/\./g, "")
    },
    at = () => {
        try {
            return function() {
                    if ("undefined" != typeof self) return self;
                    if ("undefined" != typeof window) return window;
                    if ("undefined" != typeof global) return global;
                    throw new Error("Unable to locate global object.")
                }
                ().__FIREBASE_DEFAULTS__ || (() => {
                    if ("undefined" == typeof process || void 0 === process.env) return;
                    const t = process.env.__FIREBASE_DEFAULTS__;
                    return t ? JSON.parse(t) : void 0
                })() || (() => {
                    if ("undefined" == typeof document) return;
                    let t;
                    try {
                        t = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)
                    } catch (t) {
                        return
                    }
                    const e = t && function(t) {
                        try {
                            return ot.decodeString(t, !0)
                        } catch (t) {
                            console.error("base64Decode failed: ", t)
                        }
                        return null
                    }(t[1]);
                    return e && JSON.parse(e)
                })()
        } catch (t) {
            return void console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${t}`)
        }
    };
class ct {
    constructor() {
        this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise(((t, e) => {
            this.resolve = t, this.reject = e
        }))
    }
    wrapCallback(t) {
        return (e, i) => {
            e ? this.reject(e) : this.resolve(i), "function" == typeof t && (this.promise.catch((() => {})), 1 === t.length ? t(e) : t(e, i))
        }
    }
}
class ht extends Error {
    constructor(t, e, i) {
        super(e), this.code = t, this.customData = i, this.name = "FirebaseError", Object.setPrototypeOf(this, ht.prototype), Error.captureStackTrace && Error.captureStackTrace(this, lt.prototype.create)
    }
}
class lt {
    constructor(t, e, i) {
        this.service = t, this.serviceName = e, this.errors = i
    }
    create(t, ...e) {
        const i = e[0] || {},
            n = `${this.service}/${t}`,
            s = this.errors[t],
            o = s ? function(t, e) {
                return t.replace(dt, ((t, i) => {
                    const n = e[i];
                    return null != n ? String(n) : `<${i}?>`
                }))
            }(s, i) : "Error";
        return new ht(n, `${this.serviceName}: ${o} (${n}).`, i)
    }
}
const dt = /\{\$([^}]+)}/g;

function ut(t, e) {
    if (t === e) return !0;
    const i = Object.keys(t),
        n = Object.keys(e);
    for (const s of i) {
        if (!n.includes(s)) return !1;
        const i = t[s],
            o = e[s];
        if (ft(i) && ft(o)) {
            if (!ut(i, o)) return !1
        } else if (i !== o) return !1
    }
    for (const t of n)
        if (!i.includes(t)) return !1;
    return !0
}

function ft(t) {
    return null !== t && "object" == typeof t
}
class pt {
    constructor(t, e, i) {
        this.name = t, this.instanceFactory = e, this.type = i, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null
    }
    setInstantiationMode(t) {
        return this.instantiationMode = t, this
    }
    setMultipleInstances(t) {
        return this.multipleInstances = t, this
    }
    setServiceProps(t) {
        return this.serviceProps = t, this
    }
    setInstanceCreatedCallback(t) {
        return this.onInstanceCreated = t, this
    }
}
class wt {
    constructor(t, e) {
        this.name = t, this.container = e, this.component = null, this.instances = new Map, this.instancesDeferred = new Map, this.instancesOptions = new Map, this.onInitCallbacks = new Map
    }
    get(t) {
        const e = this.normalizeInstanceIdentifier(t);
        if (!this.instancesDeferred.has(e)) {
            const t = new ct;
            if (this.instancesDeferred.set(e, t), this.isInitialized(e) || this.shouldAutoInitialize()) try {
                const i = this.getOrInitializeService({
                    instanceIdentifier: e
                });
                i && t.resolve(i)
            } catch (t) {}
        }
        return this.instancesDeferred.get(e).promise
    }
    getImmediate(t) {
        var e;
        const i = this.normalizeInstanceIdentifier(null == t ? void 0 : t.identifier),
            n = null !== (e = null == t ? void 0 : t.optional) && void 0 !== e && e;
        if (!this.isInitialized(i) && !this.shouldAutoInitialize()) {
            if (n) return null;
            throw Error(`Service ${this.name} is not available`)
        }
        try {
            return this.getOrInitializeService({
                instanceIdentifier: i
            })
        } catch (t) {
            if (n) return null;
            throw t
        }
    }
    getComponent() {
        return this.component
    }
    setComponent(t) {
        if (t.name !== this.name) throw Error(`Mismatching Component ${t.name} for Provider ${this.name}.`);
        if (this.component) throw Error(`Component for ${this.name} has already been provided`);
        if (this.component = t, this.shouldAutoInitialize()) {
            if (function(t) {
                    return "EAGER" === t.instantiationMode
                }
                (t)) try {
                this.getOrInitializeService({
                    instanceIdentifier: "[DEFAULT]"
                })
            } catch (t) {}
            for (const [t, e] of this.instancesDeferred.entries()) {
                const i = this.normalizeInstanceIdentifier(t);
                try {
                    const t = this.getOrInitializeService({
                        instanceIdentifier: i
                    });
                    e.resolve(t)
                } catch (t) {}
            }
        }
    }
    clearInstance(t = "[DEFAULT]") {
        this.instancesDeferred.delete(t), this.instancesOptions.delete(t), this.instances.delete(t)
    }
    async delete() {
        const t = Array.from(this.instances.values());
        await Promise.all([...t.filter((t => "INTERNAL" in t)).map((t => t.INTERNAL.delete())), ...t.filter((t => "_delete" in t)).map((t => t._delete()))])
    }
    isComponentSet() {
        return null != this.component
    }
    isInitialized(t = "[DEFAULT]") {
        return this.instances.has(t)
    }
    getOptions(t = "[DEFAULT]") {
        return this.instancesOptions.get(t) || {}
    }
    initialize(t = {}) {
        const {
            options: e = {}
        } = t, i = this.normalizeInstanceIdentifier(t.instanceIdentifier);
        if (this.isInitialized(i)) throw Error(`${this.name}(${i}) has already been initialized`);
        if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
        const n = this.getOrInitializeService({
            instanceIdentifier: i,
            options: e
        });
        for (const [t, e] of this.instancesDeferred.entries()) i === this.normalizeInstanceIdentifier(t) && e.resolve(n);
        return n
    }
    onInit(t, e) {
        var i;
        const n = this.normalizeInstanceIdentifier(e),
            s = null !== (i = this.onInitCallbacks.get(n)) && void 0 !== i ? i : new Set;
        s.add(t), this.onInitCallbacks.set(n, s);
        const o = this.instances.get(n);
        return o && t(o, n), () => {
            s.delete(t)
        }
    }
    invokeOnInitCallbacks(t, e) {
        const i = this.onInitCallbacks.get(e);
        if (i)
            for (const n of i) try {
                n(t, e)
            } catch (t) {}
    }
    getOrInitializeService({
        instanceIdentifier: t,
        options: e = {}
    }) {
        let i = this.instances.get(t);
        if (!i && this.component && (i = this.component.instanceFactory(this.container, {
                instanceIdentifier: (n = t, "[DEFAULT]" === n ? void 0 : n),
                options: e
            }), this.instances.set(t, i), this.instancesOptions.set(t, e), this.invokeOnInitCallbacks(i, t), this.component.onInstanceCreated)) try {
            this.component.onInstanceCreated(this.container, t, i)
        } catch (t) {}
        var n;
        return i || null
    }
    normalizeInstanceIdentifier(t = "[DEFAULT]") {
        return this.component ? this.component.multipleInstances ? t : "[DEFAULT]" : t
    }
    shouldAutoInitialize() {
        return !!this.component && "EXPLICIT" !== this.component.instantiationMode
    }
}
class gt {
    constructor(t) {
        this.name = t, this.providers = new Map
    }
    addComponent(t) {
        const e = this.getProvider(t.name);
        if (e.isComponentSet()) throw new Error(`Component ${t.name} has already been registered with ${this.name}`);
        e.setComponent(t)
    }
    addOrOverwriteComponent(t) {
        this.getProvider(t.name).isComponentSet() && this.providers.delete(t.name), this.addComponent(t)
    }
    getProvider(t) {
        if (this.providers.has(t)) return this.providers.get(t);
        const e = new wt(t, this);
        return this.providers.set(t, e), e
    }
    getProviders() {
        return Array.from(this.providers.values())
    }
}
var mt;
! function(t) {
    t[t.DEBUG = 0] = "DEBUG", t[t.VERBOSE = 1] = "VERBOSE", t[t.INFO = 2] = "INFO", t[t.WARN = 3] = "WARN", t[t.ERROR = 4] = "ERROR", t[t.SILENT = 5] = "SILENT"
}(mt || (mt = {}));
const bt = {
        debug: mt.DEBUG,
        verbose: mt.VERBOSE,
        info: mt.INFO,
        warn: mt.WARN,
        error: mt.ERROR,
        silent: mt.SILENT
    },
    yt = mt.INFO,
    xt = {
        [mt.DEBUG]: "log",
        [mt.VERBOSE]: "log",
        [mt.INFO]: "info",
        [mt.WARN]: "warn",
        [mt.ERROR]: "error"
    },
    vt = (t, e, ...i) => {
        if (e < t.logLevel) return;
        const n = (new Date).toISOString(),
            s = xt[e];
        if (!s) throw new Error(`Attempted to log a message with an invalid logType (value: ${e})`);
        console[s](`[${n}]  ${t.name}:`, ...i)
    };
let Lt, Mt;
const St = new WeakMap,
    kt = new WeakMap,
    Ct = new WeakMap,
    Dt = new WeakMap,
    Et = new WeakMap;
let It = {
    get(t, e, i) {
        if (t instanceof IDBTransaction) {
            if ("done" === e) return kt.get(t);
            if ("objectStoreNames" === e) return t.objectStoreNames || Ct.get(t);
            if ("store" === e) return i.objectStoreNames[1] ? void 0 : i.objectStore(i.objectStoreNames[0])
        }
        return jt(t[e])
    },
    set: (t, e, i) => (t[e] = i, !0),
    has: (t, e) => t instanceof IDBTransaction && ("done" === e || "store" === e) || e in t
};

function At(t) {
    return "function" == typeof t ? (e = t) !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (Mt || (Mt = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
        return e.apply(Nt(this), t), jt(St.get(this))
    } : function(...t) {
        return jt(e.apply(Nt(this), t))
    } : function(t, ...i) {
        const n = e.call(Nt(this), t, ...i);
        return Ct.set(n, t.sort ? t.sort() : [t]), jt(n)
    } : (t instanceof IDBTransaction && function(t) {
        if (kt.has(t)) return;
        const e = new Promise(((e, i) => {
            const n = () => {
                    t.removeEventListener("complete", s), t.removeEventListener("error", o), t.removeEventListener("abort", o)
                },
                s = () => {
                    e(), n()
                },
                o = () => {
                    i(t.error || new DOMException("AbortError", "AbortError")), n()
                };
            t.addEventListener("complete", s), t.addEventListener("error", o), t.addEventListener("abort", o)
        }));
        kt.set(t, e)
    }(t), i = t, (Lt || (Lt = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some((t => i instanceof t)) ? new Proxy(t, It) : t);
    var e, i
}

function jt(t) {
    if (t instanceof IDBRequest) return function(t) {
        const e = new Promise(((e, i) => {
            const n = () => {
                    t.removeEventListener("success", s), t.removeEventListener("error", o)
                },
                s = () => {
                    e(jt(t.result)), n()
                },
                o = () => {
                    i(t.error), n()
                };
            t.addEventListener("success", s), t.addEventListener("error", o)
        }));
        return e.then((e => {
            e instanceof IDBCursor && St.set(e, t)
        })).catch((() => {})), Et.set(e, t), e
    }(t);
    if (Dt.has(t)) return Dt.get(t);
    const e = At(t);
    return e !== t && (Dt.set(t, e), Et.set(e, t)), e
}
const Nt = t => Et.get(t);

function Tt(t, e, {
    blocked: i,
    upgrade: n,
    blocking: s,
    terminated: o
} = {}) {
    const r = indexedDB.open(t, e),
        a = jt(r);
    return n && r.addEventListener("upgradeneeded", (t => {
        n(jt(r.result), t.oldVersion, t.newVersion, jt(r.transaction))
    })), i && r.addEventListener("blocked", (() => i())), a.then((t => {
        o && t.addEventListener("close", (() => o())), s && t.addEventListener("versionchange", (() => s()))
    })).catch((() => {})), a
}

function $t(t, {
    blocked: e
} = {}) {
    const i = indexedDB.deleteDatabase(t);
    return e && i.addEventListener("blocked", (() => e())), jt(i).then((() => {}))
}
const Pt = ["get", "getKey", "getAll", "getAllKeys", "count"],
    _t = ["put", "add", "delete", "clear"],
    Ot = new Map;

function zt(t, e) {
    if (!(t instanceof IDBDatabase) || e in t || "string" != typeof e) return;
    if (Ot.get(e)) return Ot.get(e);
    const i = e.replace(/FromIndex$/, ""),
        n = e !== i,
        s = _t.includes(i);
    if (!(i in (n ? IDBIndex : IDBObjectStore).prototype) || !s && !Pt.includes(i)) return;
    const o = async function(t, ...e) {
        const o = this.transaction(t, s ? "readwrite" : "readonly");
        let r = o.store;
        return n && (r = r.index(e.shift())), (await Promise.all([r[i](...e), s && o.done]))[0]
    };
    return Ot.set(e, o), o
}
var Ut;
Ut = It, It = { ...Ut,
    get: (t, e, i) => zt(t, e) || Ut.get(t, e, i),
    has: (t, e) => !!zt(t, e) || Ut.has(t, e)
};
class Bt {
    constructor(t) {
        this.container = t
    }
    getPlatformInfoString() {
        return this.container.getProviders().map((t => {
            if (function(t) {
                    const e = t.getComponent();
                    return "VERSION" === (null == e ? void 0 : e.type)
                }(t)) {
                const e = t.getImmediate();
                return `${e.library}/${e.version}`
            }
            return null
        })).filter((t => t)).join(" ")
    }
}
const Rt = "@firebase/app",
    Ht = new class {
        constructor(t) {
            this.name = t, this._logLevel = yt, this._logHandler = vt, this._userLogHandler = null
        }
        get logLevel() {
            return this._logLevel
        }
        set logLevel(t) {
            if (!(t in mt)) throw new TypeError(`Invalid value "${t}" assigned to \`logLevel\``);
            this._logLevel = t
        }
        setLogLevel(t) {
            this._logLevel = "string" == typeof t ? bt[t] : t
        }
        get logHandler() {
            return this._logHandler
        }
        set logHandler(t) {
            if ("function" != typeof t) throw new TypeError("Value assigned to `logHandler` must be a function");
            this._logHandler = t
        }
        get userLogHandler() {
            return this._userLogHandler
        }
        set userLogHandler(t) {
            this._userLogHandler = t
        }
        debug(...t) {
            this._userLogHandler && this._userLogHandler(this, mt.DEBUG, ...t), this._logHandler(this, mt.DEBUG, ...t)
        }
        log(...t) {
            this._userLogHandler && this._userLogHandler(this, mt.VERBOSE, ...t), this._logHandler(this, mt.VERBOSE, ...t)
        }
        info(...t) {
            this._userLogHandler && this._userLogHandler(this, mt.INFO, ...t), this._logHandler(this, mt.INFO, ...t)
        }
        warn(...t) {
            this._userLogHandler && this._userLogHandler(this, mt.WARN, ...t), this._logHandler(this, mt.WARN, ...t)
        }
        error(...t) {
            this._userLogHandler && this._userLogHandler(this, mt.ERROR, ...t), this._logHandler(this, mt.ERROR, ...t)
        }
    }("@firebase/app"),
    Ft = {
        [Rt]: "fire-core",
        "@firebase/app-compat": "fire-core-compat",
        "@firebase/analytics": "fire-analytics",
        "@firebase/analytics-compat": "fire-analytics-compat",
        "@firebase/app-check": "fire-app-check",
        "@firebase/app-check-compat": "fire-app-check-compat",
        "@firebase/auth": "fire-auth",
        "@firebase/auth-compat": "fire-auth-compat",
        "@firebase/database": "fire-rtdb",
        "@firebase/database-compat": "fire-rtdb-compat",
        "@firebase/functions": "fire-fn",
        "@firebase/functions-compat": "fire-fn-compat",
        "@firebase/installations": "fire-iid",
        "@firebase/installations-compat": "fire-iid-compat",
        "@firebase/messaging": "fire-fcm",
        "@firebase/messaging-compat": "fire-fcm-compat",
        "@firebase/performance": "fire-perf",
        "@firebase/performance-compat": "fire-perf-compat",
        "@firebase/remote-config": "fire-rc",
        "@firebase/remote-config-compat": "fire-rc-compat",
        "@firebase/storage": "fire-gcs",
        "@firebase/storage-compat": "fire-gcs-compat",
        "@firebase/firestore": "fire-fst",
        "@firebase/firestore-compat": "fire-fst-compat",
        "fire-js": "fire-js",
        firebase: "fire-js-all"
    },
    Wt = new Map,
    Yt = new Map;

function qt(t, e) {
    try {
        t.container.addComponent(e)
    } catch (i) {
        Ht.debug(`Component ${e.name} failed to register with FirebaseApp ${t.name}`, i)
    }
}

function Vt(t) {
    const e = t.name;
    if (Yt.has(e)) return Ht.debug(`There were multiple attempts to register component ${e}.`), !1;
    Yt.set(e, t);
    for (const e of Wt.values()) qt(e, t);
    return !0
}

function Gt(t, e) {
    const i = t.container.getProvider("heartbeat").getImmediate({
        optional: !0
    });
    return i && i.triggerHeartbeat(), t.container.getProvider(e)
}
const Jt = new lt("app", "Firebase", {
    "no-app": "No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",
    "bad-app-name": "Illegal App name: '{$appName}",
    "duplicate-app": "Firebase App named '{$appName}' already exists with different options or config",
    "app-deleted": "Firebase App named '{$appName}' already deleted",
    "no-options": "Need to provide options, when not being deployed to hosting via source.",
    "invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
    "invalid-log-argument": "First argument to `onLog` must be null or a function.",
    "idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
    "idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
    "idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
    "idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}."
});
class Zt {
    constructor(t, e, i) {
        this._isDeleted = !1, this._options = Object.assign({}, t), this._config = Object.assign({}, e), this._name = e.name, this._automaticDataCollectionEnabled = e.automaticDataCollectionEnabled, this._container = i, this.container.addComponent(new pt("app", (() => this), "PUBLIC"))
    }
    get automaticDataCollectionEnabled() {
        return this.checkDestroyed(), this._automaticDataCollectionEnabled
    }
    set automaticDataCollectionEnabled(t) {
        this.checkDestroyed(), this._automaticDataCollectionEnabled = t
    }
    get name() {
        return this.checkDestroyed(), this._name
    }
    get options() {
        return this.checkDestroyed(), this._options
    }
    get config() {
        return this.checkDestroyed(), this._config
    }
    get container() {
        return this._container
    }
    get isDeleted() {
        return this._isDeleted
    }
    set isDeleted(t) {
        this._isDeleted = t
    }
    checkDestroyed() {
        if (this.isDeleted) throw Jt.create("app-deleted", {
            appName: this._name
        })
    }
}

function Qt(t, e = {}) {
    let i = t;
    "object" != typeof e && (e = {
        name: e
    });
    const n = Object.assign({
            name: "[DEFAULT]",
            automaticDataCollectionEnabled: !1
        }, e),
        s = n.name;
    if ("string" != typeof s || !s) throw Jt.create("bad-app-name", {
        appName: String(s)
    });
    var o;
    if (i || (i = null === (o = at()) || void 0 === o ? void 0 : o.config), !i) throw Jt.create("no-options");
    const r = Wt.get(s);
    if (r) {
        if (ut(i, r.options) && ut(n, r.config)) return r;
        throw Jt.create("duplicate-app", {
            appName: s
        })
    }
    const a = new gt(s);
    for (const t of Yt.values()) a.addComponent(t);
    const c = new Zt(i, n, a);
    return Wt.set(s, c), c
}

function Kt(t, e, i) {
    var n;
    let s = null !== (n = Ft[t]) && void 0 !== n ? n : t;
    i && (s += `-${i}`);
    const o = s.match(/\s|\//),
        r = e.match(/\s|\//);
    if (o || r) {
        const t = [`Unable to register library "${s}" with version "${e}":`];
        return o && t.push(`library name "${s}" contains illegal characters (whitespace or "/")`), o && r && t.push("and"), r && t.push(`version name "${e}" contains illegal characters (whitespace or "/")`), void Ht.warn(t.join(" "))
    }
    Vt(new pt(`${s}-version`, (() => ({
        library: s,
        version: e
    })), "VERSION"))
}
const Xt = "firebase-heartbeat-store";
let te = null;

function ee() {
    return te || (te = Tt("firebase-heartbeat-database", 1, {
        upgrade: (t, e) => {
            switch (e) {
                case 0:
                    t.createObjectStore(Xt)
            }
        }
    }).catch((t => {
        throw Jt.create("idb-open", {
            originalErrorMessage: t.message
        })
    }))), te
}
async function ie(t, e) {
    var i;
    try {
        const i = (await ee()).transaction(Xt, "readwrite"),
            n = i.objectStore(Xt);
        return await n.put(e, ne(t)), i.done
    } catch (t) {
        if (t instanceof ht) Ht.warn(t.message);
        else {
            const e = Jt.create("idb-set", {
                originalErrorMessage: null === (i = t) || void 0 === i ? void 0 : i.message
            });
            Ht.warn(e.message)
        }
    }
}

function ne(t) {
    return `${t.name}!${t.options.appId}`
}
class se {
    constructor(t) {
        this.container = t, this._heartbeatsCache = null;
        const e = this.container.getProvider("app").getImmediate();
        this._storage = new re(e), this._heartbeatsCachePromise = this._storage.read().then((t => (this._heartbeatsCache = t, t)))
    }
    async triggerHeartbeat() {
        const t = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),
            e = oe();
        if (null === this._heartbeatsCache && (this._heartbeatsCache = await this._heartbeatsCachePromise), this._heartbeatsCache.lastSentHeartbeatDate !== e && !this._heartbeatsCache.heartbeats.some((t => t.date === e))) return this._heartbeatsCache.heartbeats.push({
            date: e,
            agent: t
        }), this._heartbeatsCache.heartbeats = this._heartbeatsCache.heartbeats.filter((t => {
            const e = new Date(t.date).valueOf();
            return Date.now() - e <= 2592e6
        })), this._storage.overwrite(this._heartbeatsCache)
    }
    async getHeartbeatsHeader() {
        if (null === this._heartbeatsCache && await this._heartbeatsCachePromise, null === this._heartbeatsCache || 0 === this._heartbeatsCache.heartbeats.length) return "";
        const t = oe(),
            {
                heartbeatsToSend: e,
                unsentEntries: i
            } = function(t, e = 1024) {
                const i = [];
                let n = t.slice();
                for (const s of t) {
                    const t = i.find((t => t.agent === s.agent));
                    if (t) {
                        if (t.dates.push(s.date), ae(i) > e) {
                            t.dates.pop();
                            break
                        }
                    } else if (i.push({
                            agent: s.agent,
                            dates: [s.date]
                        }), ae(i) > e) {
                        i.pop();
                        break
                    }
                    n = n.slice(1)
                }
                return {
                    heartbeatsToSend: i,
                    unsentEntries: n
                }
            }(this._heartbeatsCache.heartbeats),
            n = rt(JSON.stringify({
                version: 2,
                heartbeats: e
            }));
        return this._heartbeatsCache.lastSentHeartbeatDate = t, i.length > 0 ? (this._heartbeatsCache.heartbeats = i, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), n
    }
}

function oe() {
    return (new Date).toISOString().substring(0, 10)
}
class re {
    constructor(t) {
        this.app = t, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck()
    }
    async runIndexedDBEnvironmentCheck() {
        return "object" == typeof indexedDB && new Promise(((t, e) => {
            try {
                let i = !0;
                const n = "validate-browser-context-for-indexeddb-analytics-module",
                    s = self.indexedDB.open(n);
                s.onsuccess = () => {
                    s.result.close(), i || self.indexedDB.deleteDatabase(n), t(!0)
                }, s.onupgradeneeded = () => {
                    i = !1
                }, s.onerror = () => {
                    var t;
                    e((null === (t = s.error) || void 0 === t ? void 0 : t.message) || "")
                }
            } catch (t) {
                e(t)
            }
        })).then((() => !0)).catch((() => !1))
    }
    async read() {
        return await this._canUseIndexedDBPromise && await async function(t) {
            var e;
            try {
                return (await ee()).transaction(Xt).objectStore(Xt).get(ne(t))
            } catch (t) {
                if (t instanceof ht) Ht.warn(t.message);
                else {
                    const i = Jt.create("idb-get", {
                        originalErrorMessage: null === (e = t) || void 0 === e ? void 0 : e.message
                    });
                    Ht.warn(i.message)
                }
            }
        }(this.app) || {
            heartbeats: []
        }
    }
    async overwrite(t) {
        var e;
        if (await this._canUseIndexedDBPromise) {
            const i = await this.read();
            return ie(this.app, {
                lastSentHeartbeatDate: null !== (e = t.lastSentHeartbeatDate) && void 0 !== e ? e : i.lastSentHeartbeatDate,
                heartbeats: t.heartbeats
            })
        }
    }
    async add(t) {
        var e;
        if (await this._canUseIndexedDBPromise) {
            const i = await this.read();
            return ie(this.app, {
                lastSentHeartbeatDate: null !== (e = t.lastSentHeartbeatDate) && void 0 !== e ? e : i.lastSentHeartbeatDate,
                heartbeats: [...i.heartbeats, ...t.heartbeats]
            })
        }
    }
}

function ae(t) {
    return rt(JSON.stringify({
        version: 2,
        heartbeats: t
    })).length
}
Vt(new pt("platform-logger", (t => new Bt(t)), "PRIVATE")), Vt(new pt("heartbeat", (t => new se(t)), "PRIVATE")), Kt(Rt, "0.8.3", ""), Kt(Rt, "0.8.3", "esm2017"), Kt("fire-js", "");
class ce extends Error {
    constructor(t, e, i) {
        super(e), this.code = t, this.customData = i, this.name = "FirebaseError", Object.setPrototypeOf(this, ce.prototype), Error.captureStackTrace && Error.captureStackTrace(this, he.prototype.create)
    }
}
class he {
    constructor(t, e, i) {
        this.service = t, this.serviceName = e, this.errors = i
    }
    create(t, ...e) {
        const i = e[0] || {},
            n = `${this.service}/${t}`,
            s = this.errors[t],
            o = s ? function(t, e) {
                return t.replace(le, ((t, i) => {
                    const n = e[i];
                    return null != n ? String(n) : `<${i}?>`
                }))
            }(s, i) : "Error";
        return new ce(n, `${this.serviceName}: ${o} (${n}).`, i)
    }
}
const le = /\{\$([^}]+)}/g;

function de(t) {
    return t && t._delegate ? t._delegate : t
}
class ue {
    constructor(t, e, i) {
        this.name = t, this.instanceFactory = e, this.type = i, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null
    }
    setInstantiationMode(t) {
        return this.instantiationMode = t, this
    }
    setMultipleInstances(t) {
        return this.multipleInstances = t, this
    }
    setServiceProps(t) {
        return this.serviceProps = t, this
    }
    setInstanceCreatedCallback(t) {
        return this.onInstanceCreated = t, this
    }
}
const fe = "@firebase/installations",
    pe = new he("installations", "Installations", {
        "missing-app-config-values": 'Missing App configuration value: "{$valueName}"',
        "not-registered": "Firebase Installation is not registered.",
        "installation-not-found": "Firebase Installation not found.",
        "request-failed": '{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',
        "app-offline": "Could not process request. Application offline.",
        "delete-pending-registration": "Can't delete installation while there is a pending registration request."
    });

function we(t) {
    return t instanceof ce && t.code.includes("request-failed")
}

function ge({
    projectId: t
}) {
    return `https://firebaseinstallations.googleapis.com/v1/projects/${t}/installations`
}

function me(t) {
    return {
        token: t.token,
        requestStatus: 2,
        expiresIn: (e = t.expiresIn, Number(e.replace("s", "000"))),
        creationTime: Date.now()
    };
    var e
}
async function be(t, e) {
    const i = (await e.json()).error;
    return pe.create("request-failed", {
        requestName: t,
        serverCode: i.code,
        serverMessage: i.message,
        serverStatus: i.status
    })
}

function ye({
    apiKey: t
}) {
    return new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-goog-api-key": t
    })
}
async function xe(t) {
    const e = await t();
    return e.status >= 500 && e.status < 600 ? t() : e
}

function ve(t) {
    return new Promise((e => {
        setTimeout(e, t)
    }))
}
const Le = /^[cdef][\w-]{21}$/;

function Me() {
    try {
        const t = new Uint8Array(17);
        (self.crypto || self.msCrypto).getRandomValues(t), t[0] = 112 + t[0] % 16;
        const e = function(t) {
                return (e = t, btoa(String.fromCharCode(...e)).replace(/\+/g, "-").replace(/\//g, "_")).substr(0, 22);
                var e
            }
            (t);
        return Le.test(e) ? e : ""
    } catch (t) {
        return ""
    }
}

function Se(t) {
    return `${t.appName}!${t.appId}`
}
const ke = new Map;

function Ce(t, e) {
    const i = Se(t);
    De(i, e),
        function(t, e) {
            const i = (!Ee && "BroadcastChannel" in self && (Ee = new BroadcastChannel("[Firebase] FID Change"), Ee.onmessage = t => {
                De(t.data.key, t.data.fid)
            }), Ee);
            i && i.postMessage({
                key: t,
                fid: e
            }), 0 === ke.size && Ee && (Ee.close(), Ee = null)
        }(i, e)
}

function De(t, e) {
    const i = ke.get(t);
    if (i)
        for (const t of i) t(e)
}
let Ee = null;
const Ie = "firebase-installations-store";
let Ae = null;

function je() {
    return Ae || (Ae = Tt("firebase-installations-database", 1, {
        upgrade: (t, e) => {
            switch (e) {
                case 0:
                    t.createObjectStore(Ie)
            }
        }
    })), Ae
}
async function Ne(t, e) {
    const i = Se(t),
        n = (await je()).transaction(Ie, "readwrite"),
        s = n.objectStore(Ie),
        o = await s.get(i);
    return await s.put(e, i), await n.done, o && o.fid === e.fid || Ce(t, e.fid), e
}
async function Te(t) {
    const e = Se(t),
        i = (await je()).transaction(Ie, "readwrite");
    await i.objectStore(Ie).delete(e), await i.done
}
async function $e(t, e) {
    const i = Se(t),
        n = (await je()).transaction(Ie, "readwrite"),
        s = n.objectStore(Ie),
        o = await s.get(i),
        r = e(o);
    return void 0 === r ? await s.delete(i) : await s.put(r, i), await n.done, !r || o && o.fid === r.fid || Ce(t, r.fid), r
}
async function Pe(t) {
    let e;
    const i = await $e(t.appConfig, (i => {
        const n = function(t) {
                return ze(t || {
                    fid: Me(),
                    registrationStatus: 0
                })
            }(i),
            s = function(t, e) {
                if (0 === e.registrationStatus) {
                    if (!navigator.onLine) return {
                        installationEntry: e,
                        registrationPromise: Promise.reject(pe.create("app-offline"))
                    };
                    const i = {
                        fid: e.fid,
                        registrationStatus: 1,
                        registrationTime: Date.now()
                    };
                    return {
                        installationEntry: i,
                        registrationPromise: async function(t, e) {
                            try {
                                const i = await
                                async function({
                                    appConfig: t,
                                    heartbeatServiceProvider: e
                                }, {
                                    fid: i
                                }) {
                                    const n = ge(t),
                                        s = ye(t),
                                        o = e.getImmediate({
                                            optional: !0
                                        });
                                    if (o) {
                                        const t = await o.getHeartbeatsHeader();
                                        t && s.append("x-firebase-client", t)
                                    }
                                    const r = {
                                            method: "POST",
                                            headers: s,
                                            body: JSON.stringify({
                                                fid: i,
                                                authVersion: "FIS_v2",
                                                appId: t.appId,
                                                sdkVersion: "w:0.5.16"
                                            })
                                        },
                                        a = await xe((() => fetch(n, r)));
                                    if (a.ok) {
                                        const t = await a.json();
                                        return {
                                            fid: t.fid || i,
                                            registrationStatus: 2,
                                            refreshToken: t.refreshToken,
                                            authToken: me(t.authToken)
                                        }
                                    }
                                    throw await be("Create Installation", a)
                                }(t, e);
                                return Ne(t.appConfig, i)
                            } catch (i) {
                                throw we(i) && 409 === i.customData.serverCode ? await Te(t.appConfig) : await Ne(t.appConfig, {
                                    fid: e.fid,
                                    registrationStatus: 0
                                }), i
                            }
                        }(t, i)
                    }
                }
                return 1 === e.registrationStatus ? {
                    installationEntry: e,
                    registrationPromise: _e(t)
                } : {
                    installationEntry: e
                }
            }(t, n);
        return e = s.registrationPromise, s.installationEntry
    }));
    return "" === i.fid ? {
        installationEntry: await e
    } : {
        installationEntry: i,
        registrationPromise: e
    }
}
async function _e(t) {
    let e = await Oe(t.appConfig);
    for (; 1 === e.registrationStatus;) await ve(100), e = await Oe(t.appConfig);
    if (0 === e.registrationStatus) {
        const {
            installationEntry: e,
            registrationPromise: i
        } = await Pe(t);
        return i || e
    }
    return e
}

function Oe(t) {
    return $e(t, (t => {
        if (!t) throw pe.create("installation-not-found");
        return ze(t)
    }))
}

function ze(t) {
    return 1 === (e = t).registrationStatus && e.registrationTime + 1e4 < Date.now() ? {
        fid: t.fid,
        registrationStatus: 0
    } : t;
    var e;
}
async function Ue({
    appConfig: t,
    heartbeatServiceProvider: e
}, i) {
    const n = function(t, {
            fid: e
        }) {
            return `${ge(t)}/${e}/authTokens:generate`
        }
        (t, i),
        s = function(t, {
            refreshToken: e
        }) {
            const i = ye(t);
            return i.append("Authorization", function(t) {
                return `FIS_v2 ${t}`
            }(e)), i
        }(t, i),
        o = e.getImmediate({
            optional: !0
        });
    if (o) {
        const t = await o.getHeartbeatsHeader();
        t && s.append("x-firebase-client", t)
    }
    const r = {
            method: "POST",
            headers: s,
            body: JSON.stringify({
                installation: {
                    sdkVersion: "w:0.5.16",
                    appId: t.appId
                }
            })
        },
        a = await xe((() => fetch(n, r)));
    if (a.ok) return me(await a.json());
    throw await be("Generate Auth Token", a)
}
async function Be(t, e = !1) {
    let i;
    const n = await $e(t.appConfig, (n => {
        if (!He(n)) throw pe.create("not-registered");
        const s = n.authToken;
        if (!e && (2 === (o = s).requestStatus && ! function(t) {
                const e = Date.now();
                return e < t.creationTime || t.creationTime + t.expiresIn < e + 36e5
            }(o))) return n;
        var o;
        if (1 === s.requestStatus) return i = async function(t, e) {
            let i = await Re(t.appConfig);
            for (; 1 === i.authToken.requestStatus;) await ve(100), i = await Re(t.appConfig);
            const n = i.authToken;
            return 0 === n.requestStatus ? Be(t, e) : n
        }(t, e), n; {
            if (!navigator.onLine) throw pe.create("app-offline");
            const e = function(t) {
                const e = {
                    requestStatus: 1,
                    requestTime: Date.now()
                };
                return Object.assign(Object.assign({}, t), {
                    authToken: e
                })
            }(n);
            return i = async function(t, e) {
                try {
                    const i = await Ue(t, e),
                        n = Object.assign(Object.assign({}, e), {
                            authToken: i
                        });
                    return await Ne(t.appConfig, n), i
                } catch (i) {
                    if (!we(i) || 401 !== i.customData.serverCode && 404 !== i.customData.serverCode) {
                        const i = Object.assign(Object.assign({}, e), {
                            authToken: {
                                requestStatus: 0
                            }
                        });
                        await Ne(t.appConfig, i)
                    } else await Te(t.appConfig);
                    throw i
                }
            }(t, e), e
        }
    }));
    return i ? await i : n.authToken
}

function Re(t) {
    return $e(t, (t => {
        if (!He(t)) throw pe.create("not-registered");
        return 1 === (e = t.authToken).requestStatus && e.requestTime + 1e4 < Date.now() ? Object.assign(Object.assign({}, t), {
            authToken: {
                requestStatus: 0
            }
        }) : t;
        var e;
    }))
}

function He(t) {
    return void 0 !== t && 2 === t.registrationStatus
}

function Fe(t) {
    return pe.create("missing-app-config-values", {
        valueName: t
    })
}
Vt(new ue("installations", (t => {
    const e = t.getProvider("app").getImmediate();
    return {
        app: e,
        appConfig: function(t) {
            if (!t || !t.options) throw Fe("App Configuration");
            if (!t.name) throw Fe("App Name");
            const e = ["projectId", "apiKey", "appId"];
            for (const i of e)
                if (!t.options[i]) throw Fe(i);
            return {
                appName: t.name,
                projectId: t.options.projectId,
                apiKey: t.options.apiKey,
                appId: t.options.appId
            }
        }(e),
        heartbeatServiceProvider: Gt(e, "heartbeat"),
        _delete: () => Promise.resolve()
    }
}), "PUBLIC")), Vt(new ue("installations-internal", (t => {
    const e = Gt(t.getProvider("app").getImmediate(), "installations").getImmediate();
    return {
        getId: () => async function(t) {
                const e = t,
                    {
                        installationEntry: i,
                        registrationPromise: n
                    } = await Pe(e);
                return n ? n.catch(console.error) : Be(e).catch(console.error), i.fid
            }
            (e),
        getToken: t => async function(t, e = !1) {
            const i = t;
            return await async function(t) {
                const {
                    registrationPromise: e
                } = await Pe(t);
                e && await e
            }(i), (await Be(i, e)).token
        }(e, t)
    }
}), "PRIVATE")), Kt(fe, "0.5.16"), Kt(fe, "0.5.16", "esm2017");
const We = "BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4";
var Ye, qe;

function Ve(t) {
    const e = new Uint8Array(t);
    return btoa(String.fromCharCode(...e)).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
}

function Ge(t) {
    const e = (t + "=".repeat((4 - t.length % 4) % 4)).replace(/\-/g, "+").replace(/_/g, "/"),
        i = atob(e),
        n = new Uint8Array(i.length);
    for (let t = 0; t < i.length; ++t) n[t] = i.charCodeAt(t);
    return n
}! function(t) {
    t[t.DATA_MESSAGE = 1] = "DATA_MESSAGE", t[t.DISPLAY_NOTIFICATION = 3] = "DISPLAY_NOTIFICATION"
}(Ye || (Ye = {})),
function(t) {
    t.PUSH_RECEIVED = "push-received", t.NOTIFICATION_CLICKED = "notification-clicked"
}(qe || (qe = {}));
const Je = "firebase-messaging-store";
let Ze = null;

function Qe() {
    return Ze || (Ze = Tt("firebase-messaging-database", 1, {
        upgrade: (t, e) => {
            switch (e) {
                case 0:
                    t.createObjectStore(Je)
            }
        }
    })), Ze
}
async function Ke(t) {
    const e = ti(t),
        i = await Qe(),
        n = await i.transaction(Je).objectStore(Je).get(e);
    if (n) return n; {
        const e = await async function(t) {
            if ("databases" in indexedDB && !(await indexedDB.databases()).map((t => t.name)).includes("fcm_token_details_db")) return null;
            let e = null;
            return (await Tt("fcm_token_details_db", 5, {
                    upgrade: async (i, n, s, o) => {
                        var r;
                        if (n < 2) return;
                        if (!i.objectStoreNames.contains("fcm_token_object_Store")) return;
                        const a = o.objectStore("fcm_token_object_Store"),
                            c = await a.index("fcmSenderId").get(t);
                        if (await a.clear(), c)
                            if (2 === n) {
                                const t = c;
                                if (!t.auth || !t.p256dh || !t.endpoint) return;
                                e = {
                                    token: t.fcmToken,
                                    createTime: null !== (r = t.createTime) && void 0 !== r ? r : Date.now(),
                                    subscriptionOptions: {
                                        auth: t.auth,
                                        p256dh: t.p256dh,
                                        endpoint: t.endpoint,
                                        swScope: t.swScope,
                                        vapidKey: "string" == typeof t.vapidKey ? t.vapidKey : Ve(t.vapidKey)
                                    }
                                }
                            } else if (3 === n) {
                            const t = c;
                            e = {
                                token: t.fcmToken,
                                createTime: t.createTime,
                                subscriptionOptions: {
                                    auth: Ve(t.auth),
                                    p256dh: Ve(t.p256dh),
                                    endpoint: t.endpoint,
                                    swScope: t.swScope,
                                    vapidKey: Ve(t.vapidKey)
                                }
                            }
                        } else if (4 === n) {
                            const t = c;
                            e = {
                                token: t.fcmToken,
                                createTime: t.createTime,
                                subscriptionOptions: {
                                    auth: Ve(t.auth),
                                    p256dh: Ve(t.p256dh),
                                    endpoint: t.endpoint,
                                    swScope: t.swScope,
                                    vapidKey: Ve(t.vapidKey)
                                }
                            }
                        }
                    }
                })).close(), await $t("fcm_token_details_db"), await $t("fcm_vapid_details_db"), await $t("undefined"),
                function(t) {
                    if (!t || !t.subscriptionOptions) return !1;
                    const {
                        subscriptionOptions: e
                    } = t;
                    return "number" == typeof t.createTime && t.createTime > 0 && "string" == typeof t.token && t.token.length > 0 && "string" == typeof e.auth && e.auth.length > 0 && "string" == typeof e.p256dh && e.p256dh.length > 0 && "string" == typeof e.endpoint && e.endpoint.length > 0 && "string" == typeof e.swScope && e.swScope.length > 0 && "string" == typeof e.vapidKey && e.vapidKey.length > 0
                }(e) ? e : null
        }(t.appConfig.senderId);
        if (e) return await Xe(t, e), e
    }
}
async function Xe(t, e) {
    const i = ti(t),
        n = (await Qe()).transaction(Je, "readwrite");
    return await n.objectStore(Je).put(e, i), await n.done, e
}

function ti({
    appConfig: t
}) {
    return t.appId
}
const ei = new he("messaging", "Messaging", {
    "missing-app-config-values": 'Missing App configuration value: "{$valueName}"',
    "only-available-in-window": "This method is available in a Window context.",
    "only-available-in-sw": "This method is available in a service worker context.",
    "permission-default": "The notification permission was not granted and dismissed instead.",
    "permission-blocked": "The notification permission was not granted and blocked instead.",
    "unsupported-browser": "This browser doesn't support the API's required to use the Firebase SDK.",
    "indexed-db-unsupported": "This browser doesn't support indexedDb.open() (ex. Safari iFrame, Firefox Private Browsing, etc)",
    "failed-service-worker-registration": "We are unable to register the default service worker. {$browserErrorMessage}",
    "token-subscribe-failed": "A problem occurred while subscribing the user to FCM: {$errorInfo}",
    "token-subscribe-no-token": "FCM returned no token when subscribing the user to push.",
    "token-unsubscribe-failed": "A problem occurred while unsubscribing the user from FCM: {$errorInfo}",
    "token-update-failed": "A problem occurred while updating the user from FCM: {$errorInfo}",
    "token-update-no-token": "FCM returned no token when updating the user to push.",
    "use-sw-after-get-token": "The useServiceWorker() method may only be called once and must be called before calling getToken() to ensure your service worker is used.",
    "invalid-sw-registration": "The input to useServiceWorker() must be a ServiceWorkerRegistration.",
    "invalid-bg-handler": "The input to setBackgroundMessageHandler() must be a function.",
    "invalid-vapid-key": "The public VAPID key must be a string.",
    "use-vapid-key-after-get-token": "The usePublicVapidKey() method may only be called once and must be called before calling getToken() to ensure your VAPID key is used."
});
async function ii(t, e) {
    var i;
    const n = {
        method: "DELETE",
        headers: await si(t)
    };
    try {
        const i = await fetch(`${ni(t.appConfig)}/${e}`, n),
            s = await i.json();
        if (s.error) throw ei.create("token-unsubscribe-failed", {
            errorInfo: s.error.message
        })
    } catch (t) {
        throw ei.create("token-unsubscribe-failed", {
            errorInfo: null === (i = t) || void 0 === i ? void 0 : i.toString()
        })
    }
}

function ni({
    projectId: t
}) {
    return `https://fcmregistrations.googleapis.com/v1/projects/${t}/registrations`
}
async function si({
    appConfig: t,
    installations: e
}) {
    const i = await e.getToken();
    return new Headers({
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-goog-api-key": t.apiKey,
        "x-goog-firebase-installations-auth": `FIS ${i}`
    })
}

function oi({
    p256dh: t,
    auth: e,
    endpoint: i,
    vapidKey: n
}) {
    const s = {
        web: {
            endpoint: i,
            auth: e,
            p256dh: t
        }
    };
    return n !== We && (s.web.applicationPubKey = n), s
}
async function ri(t, e) {
    const i = {
        token: await
        async function(t, e) {
            var i;
            const n = await si(t),
                s = oi(e),
                o = {
                    method: "POST",
                    headers: n,
                    body: JSON.stringify(s)
                };
            let r;
            try {
                const e = await fetch(ni(t.appConfig), o);
                r = await e.json()
            } catch (t) {
                throw ei.create("token-subscribe-failed", {
                    errorInfo: null === (i = t) || void 0 === i ? void 0 : i.toString()
                })
            }
            if (r.error) throw ei.create("token-subscribe-failed", {
                errorInfo: r.error.message
            });
            if (!r.token) throw ei.create("token-subscribe-no-token");
            return r.token
        }(t, e),
        createTime: Date.now(),
        subscriptionOptions: e
    };
    return await Xe(t, i), i.token
}

function ai(t) {
    const e = {
        from: t.from,
        collapseKey: t.collapse_key,
        messageId: t.fcmMessageId
    };
    return function(t, e) {
            if (!e.notification) return;
            t.notification = {};
            const i = e.notification.title;
            i && (t.notification.title = i);
            const n = e.notification.body;
            n && (t.notification.body = n);
            const s = e.notification.image;
            s && (t.notification.image = s);
            const o = e.notification.icon;
            o && (t.notification.icon = o)
        }(e, t),
        function(t, e) {
            e.data && (t.data = e.data)
        }(e, t),
        function(t, e) {
            var i, n, s, o, r;
            if (!e.fcmOptions && !(null === (i = e.notification) || void 0 === i ? void 0 : i.click_action)) return;
            t.fcmOptions = {};
            const a = null !== (s = null === (n = e.fcmOptions) || void 0 === n ? void 0 : n.link) && void 0 !== s ? s : null === (o = e.notification) || void 0 === o ? void 0 : o.click_action;
            a && (t.fcmOptions.link = a);
            const c = null === (r = e.fcmOptions) || void 0 === r ? void 0 : r.analytics_label;
            c && (t.fcmOptions.analyticsLabel = c)
        }
        (e, t), e
}

function ci(t, e) {
    const i = [];
    for (let n = 0; n < t.length; n++) i.push(t.charAt(n)), n < e.length && i.push(e.charAt(n));
    return i.join("")
}

function hi(t) {
    return ei.create("missing-app-config-values", {
        valueName: t
    })
}
ci("hts/frbslgigp.ogepscmv/ieo/eaylg", "tp:/ieaeogn-agolai.o/1frlglgc/o"), ci("AzSCbw63g1R0nCw85jG8", "Iaya3yLKwmgvh7cF0q4");
class li {
    constructor(t, e, i) {
        this.deliveryMetricsExportedToBigQueryEnabled = !1, this.onBackgroundMessageHandler = null, this.onMessageHandler = null, this.logEvents = [], this.isLogServiceStarted = !1;
        const n = function(t) {
            if (!t || !t.options) throw hi("App Configuration Object");
            if (!t.name) throw hi("App Name");
            const e = ["projectId", "apiKey", "appId", "messagingSenderId"],
                {
                    options: i
                } = t;
            for (const t of e)
                if (!i[t]) throw hi(t);
            return {
                appName: t.name,
                projectId: i.projectId,
                apiKey: i.apiKey,
                appId: i.appId,
                senderId: i.messagingSenderId
            }
        }(t);
        this.firebaseDependencies = {
            app: t,
            appConfig: n,
            installations: e,
            analyticsProvider: i
        }
    }
    _delete() {
        return Promise.resolve()
    }
}
async function di(t, e) {
    if (!navigator) throw ei.create("only-available-in-window");
    if ("default" === Notification.permission && await Notification.requestPermission(), "granted" !== Notification.permission) throw ei.create("permission-blocked");
    return await
    async function(t, e) {
        e ? t.vapidKey = e : t.vapidKey || (t.vapidKey = We)
    }(t, null == e ? void 0 : e.vapidKey), await
    async function(t, e) {
        if (e || t.swRegistration || await async function(t) {
                var e;
                try {
                    t.swRegistration = await navigator.serviceWorker.register("/firebase-messaging-sw.js", {
                        scope: "/firebase-cloud-messaging-push-scope"
                    }), t.swRegistration.update().catch((() => {}))
                } catch (t) {
                    throw ei.create("failed-service-worker-registration", {
                        browserErrorMessage: null === (e = t) || void 0 === e ? void 0 : e.message
                    })
                }
            }(t), e || !t.swRegistration) {
            if (!(e instanceof ServiceWorkerRegistration)) throw ei.create("invalid-sw-registration");
            t.swRegistration = e
        }
    }(t, null == e ? void 0 : e.serviceWorkerRegistration), async function(t) {
        const e = await async function(t, e) {
                return await t.pushManager.getSubscription() || t.pushManager.subscribe({
                    userVisibleOnly: !0,
                    applicationServerKey: Ge(e)
                })
            }(t.swRegistration, t.vapidKey),
            i = {
                vapidKey: t.vapidKey,
                swScope: t.swRegistration.scope,
                endpoint: e.endpoint,
                auth: Ve(e.getKey("auth")),
                p256dh: Ve(e.getKey("p256dh"))
            },
            n = await Ke(t.firebaseDependencies);
        if (n) {
            if ((o = i).vapidKey === (s = n.subscriptionOptions).vapidKey && o.endpoint === s.endpoint && o.auth === s.auth && o.p256dh === s.p256dh) return Date.now() >= n.createTime + 6048e5 ? async function(t, e) {
                try {
                    const i = await async function(t, e) {
                            var i;
                            const n = await si(t),
                                s = oi(e.subscriptionOptions),
                                o = {
                                    method: "PATCH",
                                    headers: n,
                                    body: JSON.stringify(s)
                                };
                            let r;
                            try {
                                const i = await fetch(`${ni(t.appConfig)}/${e.token}`, o);
                                r = await i.json()
                            } catch (t) {
                                throw ei.create("token-update-failed", {
                                    errorInfo: null === (i = t) || void 0 === i ? void 0 : i.toString()
                                })
                            }
                            if (r.error) throw ei.create("token-update-failed", {
                                errorInfo: r.error.message
                            });
                            if (!r.token) throw ei.create("token-update-no-token");
                            return r.token
                        }(t.firebaseDependencies, e),
                        n = Object.assign(Object.assign({}, e), {
                            token: i,
                            createTime: Date.now()
                        });
                    return await Xe(t.firebaseDependencies, n), i
                } catch (e) {
                    throw await async function(t) {
                        const e = await Ke(t.firebaseDependencies);
                        e && (await ii(t.firebaseDependencies, e.token), await async function(t) {
                            const e = ti(t),
                                i = (await Qe()).transaction(Je, "readwrite");
                            await i.objectStore(Je).delete(e), await i.done
                        }(t.firebaseDependencies));
                        const i = await t.swRegistration.pushManager.getSubscription();
                        return !i || i.unsubscribe()
                    }(t), e
                }
            }(t, {
                token: n.token,
                createTime: Date.now(),
                subscriptionOptions: i
            }) : n.token;
            try {
                await ii(t.firebaseDependencies, n.token)
            } catch (t) {
                console.warn(t)
            }
            return ri(t.firebaseDependencies, i)
        }
        var s, o;
        return ri(t.firebaseDependencies, i)
    }(t)
}
const ui = "@firebase/messaging";
async function fi() {
    try {
        await new Promise(((t, e) => {
            try {
                let i = !0;
                const n = "validate-browser-context-for-indexeddb-analytics-module",
                    s = self.indexedDB.open(n);
                s.onsuccess = () => {
                    s.result.close(), i || self.indexedDB.deleteDatabase(n), t(!0)
                }, s.onupgradeneeded = () => {
                    i = !1
                }, s.onerror = () => {
                    var t;
                    e((null === (t = s.error) || void 0 === t ? void 0 : t.message) || "")
                }
            } catch (t) {
                e(t)
            }
        }))
    } catch (t) {
        return !1
    }
    return "undefined" != typeof window && "object" == typeof indexedDB && !("undefined" == typeof navigator || !navigator.cookieEnabled) && "serviceWorker" in navigator && "PushManager" in window && "Notification" in window && "fetch" in window && ServiceWorkerRegistration.prototype.hasOwnProperty("showNotification") && PushSubscription.prototype.hasOwnProperty("getKey")
}
Vt(new ue("messaging", (t => {
    const e = new li(t.getProvider("app").getImmediate(), t.getProvider("installations-internal").getImmediate(), t.getProvider("analytics-internal"));
    return navigator.serviceWorker.addEventListener("message", (t => async function(t, e) {
        const i = e.data;
        if (!i.isFirebaseMessaging) return;
        t.onMessageHandler && i.messageType === qe.PUSH_RECEIVED && ("function" == typeof t.onMessageHandler ? t.onMessageHandler(ai(i)) : t.onMessageHandler.next(ai(i)));
        const n = i.data;
        var s;
        "object" == typeof(s = n) && s && "google.c.a.c_id" in s && "1" === n["google.c.a.e"] && await async function(t, e, i) {
            const n = function(t) {
                switch (t) {
                    case qe.NOTIFICATION_CLICKED:
                        return "notification_open";
                    case qe.PUSH_RECEIVED:
                        return "notification_foreground";
                    default:
                        throw new Error
                }
            }(e);
            (await t.firebaseDependencies.analyticsProvider.get()).logEvent(n, {
                message_id: i["google.c.a.c_id"],
                message_name: i["google.c.a.c_l"],
                message_time: i["google.c.a.ts"],
                message_device_time: Math.floor(Date.now() / 1e3)
            })
        }(t, i.messageType, n)
    }(e, t))), e
}), "PUBLIC")), Vt(new ue("messaging-internal", (t => {
    const e = t.getProvider("messaging").getImmediate();
    return {
        getToken: t => di(e, t)
    }
}), "PRIVATE")), Kt(ui, "0.10.0"), Kt(ui, "0.10.0", "esm2017");
const pi = {
    vuvuzela: {
        signalR: "https://signalrapi.betwayafrica.com",
        apiUrl: "https://api.betwayafrica.com",
        cmsUrl: "https://cms1.betwayafrica.com"
    },
    synapse: {
        signalR: "https://signalrapi.betwayafrica.com",
        apiUrl: "https://api.betwayafrica.com",
        cmsUrl: "https://cms1.betwayafrica.com"
    },
    gmgamingsystems: {
        signalR: "https://signalrapi.gmgamingsystems.com",
        apiUrl: "https://rowapi.gmgamingsystems.com",
        cmsUrl: "https://cms1.gmgamingsystems.com"
    },
    easterndawn: {
        signalR: "https://signalrapi.jpc.africa",
        apiUrl: "https://api.jpc.africa",
        cmsUrl: "https://cms1.jpc.africa"
    },
    jackpotcityafrica: {
        signalR: "https://signalrapi.jpc.africa",
        apiUrl: "https://api.jpc.africa",
        cmsUrl: "https://cms1.jpc.africa"
    }
};
class wi {
    constructor(t) {
        this.appData = t, this.headers = {
            "Content-Type": "application/json"
        }, this.notificationsKey = "notifications", this.translationsKey = "notifications-translations"
    }
    async getNotifications(t, e = 0, i = 10, n, s) {
        let o = `${this.appData.apiUrl}/api/v1/Notification?skip=${e}&limit=${i}&cultureCode=${n}`;
        for (let t in s) s.hasOwnProperty(t) && ("" !== s[t] && "StartDate" == t && (o += "&startDate=" + s[t]), "" !== s[t] && "EndDate" == t && (o += "&endDate=" + s[t]));
        const r = sessionStorage.getItem(this.notificationsKey);
        return r ? JSON.parse(r) : await fetch(o, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${t}`,
                "Content-Type": "application/json"
            },
            body: null
        }).then((async t => {
            const e = await t.json();
            return sessionStorage.setItem(this.notificationsKey, JSON.stringify(e)), e
        })).catch((t => console.error(t)))
    }
    updateNotificationStatus(t, e, i) {
        return fetch(`${this.appData.apiUrl}/api/v1/Notification/Status?isRead=${e}`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${t}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(i)
        }).then((t => t))
    }
    deleteNotification(t, e) {
        return fetch(`${this.appData.apiUrl}/api/v1/Notification/Delete`, {
            method: "POST",
            headers: {
                Authorization: `Bearer ${t}`,
                "Content-Type": "application/json"
            },
            body: JSON.stringify(e)
        }).then((t => t))
    }
    subscribeToTopic(t, e) {
        return fetch(`${this.appData.apiUrl}/api/v1/Notification/Firebase/Subscribe/Topic?cultureCode=${e.cultureCode}`, {
            method: "POST",
            headers: {
                "x-pushtoken": e.registrationToken,
                Authorization: `Bearer ${t}`,
                "Content-Type": "application/json"
            },
            body: null
        }).then((t => t))
    }
    getTranslations(t, e) {
        const i = sessionStorage.getItem(this.translationsKey);
        return i ? JSON.parse(i) : fetch(`${this.appData.cmsUrl}/gmapi/Resource/GetByCulture?culture=${t}&key=${e}`).then((async t => {
            const e = await t.json();
            return sessionStorage.setItem(this.translationsKey, JSON.stringify(null == e ? void 0 : e.resourceStringInfo)), null == e ? void 0 : e.resourceStringInfo
        })).catch((t => console.error(t)))
    }
    getVuvuzelaAuthToken() {
        return fetch("/HorseRacing/GetuserData", {
            method: "GET"
        }).then((t => t.json()))
    }
}
Kt("firebase", "9.13.0", "app");
const gi = class {
    constructor(i) {
        t(this, i), this.signalRConnected = e(this, "signalRConnected", 7), this.signalConnectionError = e(this, "signalConnectionError", 7), this.updateNotificationsCount = e(this, "updateNotificationsCount", 7), this.countUnreadNotifications = t => {
            const e = t.filter((t => !t.isRead));
            this.UnreadNotifications = e.length
        }, this.getCookie = ({
            key: t
        }) => {
            const e = `; ${null===document||void 0===document?void 0:document.cookie}`.split(`; ${t}=`);
            if (2 === e.length) return e.pop().split(";").shift()
        }, this.startPanelProcess = () => {
            this.accesstoken || (this.accesstoken = this.getCookie({
                key: "Syn"
            })), this.licence.match(/(vuvuzela)/gi) ? this.Services.getVuvuzelaAuthToken().then((t => {
                this.accesstoken = t.Token, this.getTranslation()
            })) : this.getTranslation()
        }, this.getTranslation = () => {
            this.Translations = this.Services.getTranslations(this.culturecode, "sport.notification")
        }, this.monitorScrollPosition = () => {
            if (this.Limit < this.Total) return this.Limit = this.Limit + 2, void this.getNotifications()
        }, this.getNotifications = () => {
            this.Services.getNotifications(this.accesstoken, 0, this.Limit, this.culturecode, this.DateTimes).then((t => {
                if (this.NotificationsList = [], t.notifications.length > 0) {
                    this.Total = t.total, this.PreviouslySelected.length < 1 && (this.PreviouslySelected = t.notifications), t.notifications.forEach((t => {
                        let e = "";
                        t.messageBody.indexOf("<p>") > -1 && (e = t.messageBody.replace("<p>", ""), e = e.replace("</p>", ""), t.messageBody = e), t.isSelected = !1, t.bodyDisplay = !1, t.timeOnDisplay = !0, t.optionsDisplay = !1, t.notificationDate = this.timeSince(new Date(t.notificationDate)), this.NotificationsList = [...this.NotificationsList, t]
                    })), this.NotificationsList.length == t.notifications.length && (this.FetchingNotifications = !1);
                    const e = t.notifications.filter((t => !t.isRead));
                    this.UnreadNotifications = e.length, this.IsSelected && this.PreviouslySelected.forEach((t => {
                        this.NotificationsList.forEach((e => {
                            t.notificationId == e.notificationId && (e.isSelected = t.isSelected)
                        }))
                    }))
                } else this.FetchingNotifications = !1, this.NotificationsList = []
            })).catch((t => {
                this.FetchingNotifications = !1, console.error(t)
            }))
        }, this.startSignalR = () => {
            this.hubConnection = (new nt).withUrl(`${this.AppData[this.licence].signalR}/hubs/notificationpanel`, {
                withCredentials: !0,
                skipNegotiation: !0,
                accessTokenFactory: () => this.accesstoken,
                transport: q.WebSockets
            }).withAutomaticReconnect([0, 1e3, 2e3]).build(), this.hubConnection.on("NotificationPanelMessage", (t => {
                this.PreviouslySelected = [...this.NotificationsList, t], this.getNotifications()
            })), this.hubConnection.start().then((() => {
                this.signalRConnected.emit()
            })).catch((t => {
                this.RetrySignalR <= 3 ? this.RetrySignalR++ : this.signalConnectionError.emit(t)
            }))
        }, this.closeAllOptions = () => {
            const t = this.NotificationsList;
            this.ItemID = 0, this.NotificationsList = [], t.forEach((t => {
                t.optionsDisplay = !1, this.NotificationsList = [...this.NotificationsList, t]
            }))
        }, this.notificationDeletion = t => {
            this.Services.deleteNotification(this.accesstoken, t).then((e => {
                if (200 == e.status) {
                    let e = this.NotificationsList;
                    this.NotificationsList = [], this.ItemID > 0 && e.forEach((t => {
                        t.notificationId !== this.ItemID && (this.NotificationsList = [...this.NotificationsList, t])
                    })), t.length > 0 && this.ItemID < 1 && e.forEach((t => {
                        t.isSelected || (this.NotificationsList = [...this.NotificationsList, t])
                    })), this.countUnreadNotifications(this.NotificationsList), this.ItemID = 0
                }
            })).catch((t => {
                console.error(t)
            }))
        }, this.updateNotifcations = (t, e) => {
            this.Services.updateNotificationStatus(this.accesstoken, e, t).then((() => {})).catch((t => {
                console.error(t)
            }))
        }, this.timeSince = t => {
            let e = new Date,
                i = Math.floor((e - t) / 1e3),
                n = i / 31536e3;
            return n > 1 ? Math.floor(n) > 1 ? Math.floor(n) + " " + this.translate("years") + " " + this.translate("ago") : Math.floor(n) + " " + this.translate("year") + " " + this.translate("ago") : (n = i / 2592e3, n > 1 ? Math.floor(n) > 1 ? Math.floor(n) + " " + this.translate("months") + " " + this.translate("ago") : Math.floor(n) + " " + this.translate("month") + " " + this.translate("ago") : (n = i / 86400, n > 1 ? Math.floor(n) > 1 ? Math.floor(n) + " " + this.translate("days") + " " + this.translate("ago") : Math.floor(n) + " " + this.translate("day") + " " + this.translate("ago") : (n = i / 3600, n > 1 ? Math.floor(n) > 1 ? Math.floor(n) + " " + this.translate("hours") + " " + this.translate("ago") : Math.floor(n) + " " + this.translate("hour") + " " + this.translate("ago") : (n = i / 60, n > 1 ? Math.floor(n) > 1 ? Math.floor(n) + " " + this.translate("minutes") + " " + this.translate("ago") : Math.floor(n) + " " + this.translate("minute") + " " + this.translate("ago") : this.translate("justNow")))))
        }, this.translate = t => {
            if (!this.Translations.length) return t;
            const e = "sport.notification." + t,
                i = this.Translations.find((t => t.Key == e));
            return i ? i.Text : void 0
        }, this.opened = void 0, this.isnative = void 0, this.colorscheme = void 0, this.vertical = void 0, this.accesstoken = void 0, this.status = void 0, this.regioncode = void 0, this.culturecode = void 0, this.licence = "betwayafrica", this.enablepushnotifications = "off", this.Total = 0, this.Limit = 16, this.ItemID = 0, this.IsRead = !1, this.RetrySignalR = 0, this.SelectedTheme = "", this.IsSelected = !1, this.DatePicker = !1, this.PanelStatus = !0, this.SelectedVertical = "", this.ModalStatus = !1, this.HeaderControl = !1, this.BackDropStatus = !1, this.UnreadNotifications = 0, this.Translations = [], this.FetchingNotifications = !0, this.NotificationsList = [], this.PreviouslySelected = [], this.DateTimes = {
            StartDate: "",
            EndDate: ""
        }, this.AppData = pi, this.Services = new wi(this.AppData[this.licence]), window.addEventListener("message", (() => {}))
    }
    updateVerticalColor() {
        this.SelectedVertical = "" == this.vertical || "/" == this.vertical ? "sports" : this.vertical
    }
    onCulturecode() {
        this.startPanelProcess(), this.getNotifications()
    }
    updateColorScheme() {
        this.SelectedTheme = "auto" == this.colorscheme ? "theme-light" : "dark" == this.colorscheme ? "theme-dark" : ""
    }
    sendDataToParent() {
        const t = {
            unread: this.UnreadNotifications,
            total: this.NotificationsList.length
        };
        this.nativeMessageHandler(this.definePostMessage(JSON.stringify(t))), this.updateNotificationsCount.emit(t)
    }
    selectionHandler(t) {
        this.IsSelected = t.detail.status, this.HeaderControl = t.detail.status;
        const e = this.NotificationsList;
        this.NotificationsList = [], e.forEach((e => {
            e.bodyDisplay = !1, e.timeOnDisplay = !0, e.isSelected = t.detail.status, this.NotificationsList = [...this.NotificationsList, e]
        }))
    }
    optionsStatus(t) {
        const e = this.NotificationsList;
        this.NotificationsList = [], e.forEach((e => {
            e.optionsDisplay = e.notificationId == t.detail && !e.optionsDisplay, this.NotificationsList = [...this.NotificationsList, e]
        }))
    }
    deselectItem(t) {
        const e = this.NotificationsList;
        this.NotificationsList = [], e.forEach((e => {
            e.notificationId == t.detail && (e.isSelected = !1), this.NotificationsList = [...this.NotificationsList, e]
        })), this.countUnreadNotifications(e)
    }
    markAllAsRead(t) {
        const e = [],
            i = this.NotificationsList;
        this.NotificationsList = [], i.forEach((i => {
            i.isRead || e.push(i.notificationId), i.isSelected = !1, i.isRead = t.detail.status, this.NotificationsList = [...this.NotificationsList, i]
        })), this.countUnreadNotifications(this.NotificationsList), e.length > 0 && this.updateNotifcations(e, !0)
    }
    updateDateTimes(t) {
        this.DatePicker = !0, this.DateTimes = t.detail, this.getNotifications()
    }
    removeSelectedItem(t) {
        this.DatePicker = !1, this.ModalStatus = !0, this.BackDropStatus = !0, this.ItemID = t.detail
    }
    updateItemReadStatus(t) {
        const e = [],
            i = this.NotificationsList;
        this.NotificationsList = [], e.push(t.detail.id), i.forEach((i => {
            i.notificationId == t.detail.id && (i.isRead ? (i.isRead = !1, this.updateNotifcations(e, !1)) : (i.isRead = !0, this.updateNotifcations(e, !0))), this.NotificationsList = [...this.NotificationsList, i]
        })), this.countUnreadNotifications(i)
    }
    updateNotification(t) {
        const e = [],
            i = this.NotificationsList;
        this.NotificationsList = [];
        const n = i.find((e => e.notificationId == t.detail));
        e.push(t.detail), n.isRead || this.updateNotifcations(e, !0), i.forEach((e => {
            e.notificationId == t.detail ? (e.isRead = !0, e.timeOnDisplay = !e.timeOnDisplay, e.bodyDisplay = !e.bodyDisplay) : (e.bodyDisplay = !1, e.timeOnDisplay = !0), this.NotificationsList = [...this.NotificationsList, e]
        })), this.countUnreadNotifications(i)
    }
    openDialog(t) {
        this.ModalStatus = !this.ModalStatus, this.BackDropStatus = !this.BackDropStatus, this.ItemID ? (this.optionsStatus({
            detail: this.ItemID
        }), this.closeAllOptions()) : this.DatePicker = t.detail
    }
    updatePanelStatus() {
        this.element.removeAttribute("opened")
    }
    deleteNotification() {
        this.DatePicker = !1, this.ModalStatus = !1, this.BackDropStatus = !1;
        let t = [];
        this.ItemID > 0 ? t.push(this.ItemID) : this.NotificationsList.forEach((e => {
            e.isSelected && t.push(e.notificationId)
        })), t.length > 0 && this.notificationDeletion(t)
    }
    componentWillLoad() {
        this.startPanelProcess()
    }
    componentDidLoad() {
        "on" == this.enablepushnotifications && this.startFirebaseMessaging(), this.getNotifications(), this.startSignalR(), this.element.shadowRoot.querySelector(".notifications-panel").querySelector(".panel-body").addEventListener("scroll", (() => {
            this.monitorScrollPosition()
        }))
    }
    getMobileOperatingSystem() {
        var t = navigator.userAgent;
        return /windows phone/i.test(t) ? "Windows Phone" : /Android|android/i.test(t) ? "Android" : /iPad|iPhone|iPod|AppleWebKit|Safari/.test(t) && !/macintosh|Macintosh/.test(t) ? "iOS" : "unknown"
    }
    definePostMessage(t) {
        return {
            data: {
                notificationsCount: t
            }
        }
    }
    nativeMessageHandler(t) {
        var e, i, n, s;
        const o = this.getMobileOperatingSystem();
        "ios" === o.toLowerCase() ? null === (n = null === (i = null === (e = null === window || void 0 === window ? void 0 : window.webkit) || void 0 === e ? void 0 : e.messageHandlers) || void 0 === i ? void 0 : i.PostData) || void 0 === n || n.postMessage(JSON.stringify(t.data)) : "android" === o.toLowerCase() || "huawei" === o.toLowerCase() ? null === (s = null === window || void 0 === window ? void 0 : window.Data) || void 0 === s || s.postData(JSON.stringify(t.data)) : window.postMessage(t.data)
    }
    startFirebaseMessaging() {
        fi().then((t => {
            if (!t) return;
            let e, i;
            switch (this.licence) {
                case "betwayafrica":
                case "synapse":
                case "vuvuzela":
                    e = {
                        apiKey: "AIzaSyAgHC0zlE1Jc27a5AEp6wVq_nw7dYSeE4s",
                        projectId: "betway-push-messaging",
                        messagingSenderId: "800034018324",
                        appId: "1:800034018324:web:150b89e5b12d2d363f4301"
                    }, i = "BJAYT9Z6csXoIOWfQifv2dR-EAaUzmW7gwO0YEPGEMPDy5teLXMimtukEd0lp19jtOUKcAG4cCgg16vB7ZSlSaI";
                    break;
                case "jackpotcityafrica":
                case "easterndawn":
                    e = {
                        apiKey: "AIzaSyD1AwLRbbllLKPd11rvU1EUF4qpzyKYhF0",
                        projectId: "jackpot-city-e728f",
                        messagingSenderId: "70165644592",
                        appId: "1:70165644592:web:fa261e154f812755e074f5"
                    }, i = "BM9oCn7LTzELRKeegQQVZo_0gRcTQtoouxHAtYMHLp9GdFjUNj7anmBK1qWbP226mh3bAje2FoskzTzAqnUkLfs";
                    break;
                default:
                    e = {
                        apiKey: "AIzaSyAgHC0zlE1Jc27a5AEp6wVq_nw7dYSeE4s",
                        projectId: "betway-push-messaging",
                        messagingSenderId: "800034018324",
                        appId: "1:800034018324:web:150b89e5b12d2d363f4301"
                    }, i = "BJAYT9Z6csXoIOWfQifv2dR-EAaUzmW7gwO0YEPGEMPDy5teLXMimtukEd0lp19jtOUKcAG4cCgg16vB7ZSlSaI"
            }
            const n = function(t = function(t = "[DEFAULT]") {
                const e = Wt.get(t);
                if (!e && "[DEFAULT]" === t) return Qt();
                if (!e) throw Jt.create("no-app", {
                    appName: t
                });
                return e
            }()) {
                return fi().then((t => {
                    if (!t) throw ei.create("unsupported-browser")
                }), (() => {
                    throw ei.create("indexed-db-unsupported")
                })), Gt(de(t), "messaging").getImmediate()
            }(Qt(e));
            navigator.serviceWorker.register("/firebase-messaging-sw.js", {
                type: "module",
                scope: "__"
            }).then((t => {
                (async function(t, e) {
                    return di(t = de(t), e)
                })(n, {
                    vapidKey: i,
                    serviceWorkerRegistration: t
                }).then((t => {
                    if (console.log({
                            currentToken: t
                        }), t) {
                        const e = sessionStorage.getItem("notification-token");
                        e && e !== t && this.Services.subscribeToTopic(this.accesstoken, {
                            registrationToken: t,
                            cultureCode: this.culturecode
                        }), sessionStorage.setItem("notification-token", t)
                    } else console.log("No registration token available. Request permission to generate one.")
                })).catch((t => {
                    console.error("An error occurred while retrieving token. ", t)
                }))
            }))
        }))
    }
    render() {
        return this.SelectedTheme = `theme-${this.colorscheme}`, i(n, null, i("div", {
            class: this.BackDropStatus ? "back-drop back-drop-display" : "back-drop"
        }), i("dialog-box", {
            Translations: this.Translations,
            ModalStatus: this.ModalStatus,
            DatePicker: this.DatePicker,
            IsNative: this.isnative
        }), i("div", {
            class: "true" == this.isnative ? "panel-native notifications-panel " + this.SelectedTheme : this.SelectedTheme + " notifications-panel "
        }, i("div", {
            class: "panel-content"
        }, i("div", {
            class: "panel-header"
        }, i("div", {
            class: "panel-name"
        }, i("h4", null, this.Translations.length > 0 ? this.translate("heading") : "Notifications")), i("header-controls", {
            HeaderControl: this.HeaderControl
        })), this.NotificationsList.length > 1 && i("body-controls", {
            Translations: this.Translations
        }), i("div", {
            class: "panel-body"
        }, this.FetchingNotifications ? i("div", {
            class: "loader"
        }) : i("notification-holder", {
            SelectedTheme: this.SelectedTheme,
            SelectedVertical: this.SelectedVertical,
            Translations: this.Translations,
            HeaderControl: this.HeaderControl,
            NotficationsArray: this.NotificationsList,
            IsReadStatus: this.IsRead,
            IsSelected: this.IsSelected
        })))))
    }
    get element() {
        return s(this)
    }
    static get watchers() {
        return {
            vertical: ["updateVerticalColor"],
            culturecode: ["onCulturecode"],
            colorscheme: ["updateColorScheme"],
            UnreadNotifications: ["sendDataToParent"],
            NotificationsList: ["sendDataToParent"]
        }
    }
};
gi.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}:host([opened]) .notifications-panel{right:44px;font-family:Interface, Arial, sans-serif}:host([opened]) .panel-native{right:44px;transition:unset;display:block;font-family:Interface, Arial, sans-serif}:host{display:block;font-family:Interface, Arial, sans-serif}:host .theme-dark .panel-header{background-color:#201d29}.back-drop{background:rgba(204, 204, 204, 0.3294117647);position:fixed;width:100%;height:100%;z-index:12;display:none;z-index:10001;top:0}.back-drop-display{display:block}.notifications-panel{width:370px;overflow:hidden;background:#ffffff;box-shadow:1px 1px 4px grey;height:100vh;color:#505050;position:fixed;right:10px;transition:all 0.5s;font-family:Interface, Arial, sans-serif;transform:translate(11%, 0px);right:-50%;z-index:10000;top:0}.panel-native{display:none;right:44px !important;transition:unset !important}.panel-on-display{right:44px}.panel-body{overflow:hidden;overflow-y:scroll;height:87vh}.notifications-fetch{margin:50% 0 0 0%;text-align:center;font-size:14px}.panel-footer{padding:10px;cursor:pointer;background:#00a826}.panel-header{background:#232323;color:#ffffff;display:flex;font-family:Interface, Arial, sans-serif;box-shadow:1px 1px 4px grey;justify-content:space-between}.panel-name h4{margin:10px;font-size:1.3rem}.loading-text{color:red;float:right;margin:5px;font-size:12px}::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background-color:transparent}::-webkit-scrollbar-thumb{background-color:#d6dee1;border-radius:2px;border:2px solid transparent;background-clip:content-box}::-webkit-scrollbar-thumb:hover{background-color:#a8bbbf}.loader{border:5px solid #f3f3f3;border-top:5px solid #3498db;border-radius:50%;width:50px;height:50px;animation:spin 2s linear infinite;position:relative;left:50%;transform:translate(-50%, 0px);top:45%}@media screen and (max-width: 768px){.panel-native{right:0 !important}.notifications-panel{right:-100%;width:100%;height:100vh}}@media screen and (max-width: 1280px){:host([opened]) .notifications-panel{right:0;transform:translate(0px, 0px)}.loading-text{color:red;float:right;margin:0px;font-size:12px;position:fixed;right:10px}.panel-on-display{right:0;transform:translate(0px, 0px)}.panel-body{height:91vh}.panel-footer{position:absolute;bottom:5px;width:100%;background:#ffffff}.panel-native{right:0 !important}.panel .is-not-read .read-active{display:block;width:50px;height:50px;border-radius:50%;background:#00a826;margin:14px 0px 0px 36px}}@media screen and (max-height: 1080px){.panel-body{height:87vh}}@media screen and (max-height: 736px){.panel-body{height:85vh}}@media screen and (max-height: 864px){.panel-body{height:85vh}}';
const mi = class {
    constructor(i) {
        t(this, i), this.removeItem = e(this, "removeItem", 7), this.closeOptionsHolder = e(this, "closeOptionsHolder", 7), this.updateItemReadStatus = e(this, "updateItemReadStatus", 7), this.markItemAsRead = () => {
            this.updateItemReadStatus.emit({
                id: this.notification.notificationId,
                status: !0
            })
        }, this.markItemAsUnRead = () => {
            this.updateItemReadStatus.emit({
                id: this.notification.notificationId,
                status: !1
            })
        }, this.deleteItem = () => {
            this.removeItem.emit(this.notification.notificationId)
        }, this.translate = t => {
            const e = "sport.notification." + t,
                i = this.Translations.find((t => t.Key == e));
            if (i) return i.Text
        }, this.lostFocus = t => {
            t.preventDefault(), this.closeOptionsHolder.emit()
        }, this.notification = void 0, this.Translations = void 0
    }
    componentWillLoad() {
        console.log(this.notification)
    }
    componentDidLoad() {
        this.optionsHolder.shadowRoot.querySelector(".options-holder").focus()
    }
    render() {
        return i(n, null, i("div", {
            tabindex: "0",
            class: "options-holder",
            onBlur: t => this.lostFocus(t)
        }, !1 === this.notification.isRead ? i("span", {
            onClick: () => this.markItemAsRead()
        }, this.Translations.length > 0 ? this.translate("markAsRead") : "Mark as Read") : i("span", {
            onClick: () => this.markItemAsUnRead()
        }, this.Translations.length > 0 ? this.translate("markAsUnRead") : "Mark as Unread"), i("span", {
            onClick: () => this.deleteItem()
        }, this.Translations.length > 0 ? this.translate("delete") : "Delete")))
    }
    get optionsHolder() {
        return s(this)
    }
};
mi.style = '@font-face{font-family:Interface, Arial, sans-serif;src:url("../../assets/fonts/Interface_Normal.woff2") format("woff2"), url("../../assets/fonts/InterFaceCorp-Light.ttf") format("ttf")}.theme-dark{background:#201d29;color:#ffffff}.options-holder{position:absolute;width:100px;right:15px;top:30px;font-size:14px;background:#ffffff;box-shadow:1px 1px 4px grey;padding:10px;text-align:right;display:grid;z-index:10;cursor:pointer;z-index:5000;border-radius:5px}.options-holder:focus{outline:none;border:none}span{margin:0px 0 5px 0 !important;cursor:pointer;font-size:13px;color:#201d29;padding-top:5px;padding-bottom:5px}span:hover{color:#00a826}';
export {
    o as body_controls, r as dialog_box, a as header_controls, c as notification_holder, gi as notifications_panel, mi as options_holder
}