let e, t, n = !1,
    l = !1;
const s = {},
    o = e => "object" == (e = typeof e) || "function" === e,
    i = (e, t, ...n) => {
        let l = null,
            s = null,
            i = !1,
            r = !1;
        const u = [],
            a = t => {
                for (let n = 0; n < t.length; n++) l = t[n], Array.isArray(l) ? a(l) : null != l && "boolean" != typeof l && ((i = "function" != typeof e && !o(l)) && (l += ""), i && r ? u[u.length - 1].t += l : u.push(i ? c(null, l) : l), r = i)
            };
        if (a(n), t) {
            t.key && (s = t.key); {
                const e = t.className || t.class;
                e && (t.class = "object" != typeof e ? e : Object.keys(e).filter((t => e[t])).join(" "))
            }
        }
        const f = c(e, null);
        return f.l = t, u.length > 0 && (f.o = u), f.i = s, f
    },
    c = (e, t) => ({
        u: 0,
        h: e,
        t,
        p: null,
        o: null,
        l: null,
        i: null
    }),
    r = {},
    u = e => q(e).$,
    a = (e, t, n) => {
        const l = u(e);
        return {
            emit: e => f(l, t, {
                bubbles: !!(4 & n),
                composed: !!(2 & n),
                cancelable: !!(1 & n),
                detail: e
            })
        }
    },
    f = (e, t, n) => {
        const l = K.ce(t, n);
        return e.dispatchEvent(l), l
    },
    h = new WeakMap,
    p = e => "sc-" + e.m,
    y = (e, t, n, l, s, i) => {
        if (n !== l) {
            let c = V(e, t),
                r = t.toLowerCase();
            if ("class" === t) {
                const t = e.classList,
                    s = $(n),
                    o = $(l);
                t.remove(...s.filter((e => e && !o.includes(e)))), t.add(...o.filter((e => e && !s.includes(e))))
            } else if ("style" === t) {
                for (const t in n) l && null != l[t] || (t.includes("-") ? e.style.removeProperty(t) : e.style[t] = "");
                for (const t in l) n && l[t] === n[t] || (t.includes("-") ? e.style.setProperty(t, l[t]) : e.style[t] = l[t])
            } else if ("key" === t);
            else if (c || "o" !== t[0] || "n" !== t[1]) {
                const r = o(l);
                if ((c || r && null !== l) && !s) try {
                    if (e.tagName.includes("-")) e[t] = l;
                    else {
                        const s = null == l ? "" : l;
                        "list" === t ? c = !1 : null != n && e[t] == s || (e[t] = s)
                    }
                } catch (e) {}
                null == l || !1 === l ? !1 === l && "" !== e.getAttribute(t) || e.removeAttribute(t) : (!c || 4 & i || s) && !r && e.setAttribute(t, l = !0 === l ? "" : l)
            } else t = "-" === t[2] ? t.slice(3) : V(I, r) ? r.slice(2) : r[2] + t.slice(3), n && K.rel(e, t, n, !1), l && K.ael(e, t, l, !1)
        }
    },
    d = /\s/,
    $ = e => e ? e.split(d) : [],
    m = (e, t, n, l) => {
        const o = 11 === t.p.nodeType && t.p.host ? t.p.host : t.p,
            i = e && e.l || s,
            c = t.l || s;
        for (l in i) l in c || y(o, l, i[l], void 0, n, t.u);
        for (l in c) y(o, l, i[l], c[l], n, t.u)
    },
    b = (t, l, s) => {
        const o = l.o[s];
        let i, c, r = 0;
        if (null !== o.t) i = o.p = J.createTextNode(o.t);
        else {
            if (n || (n = "svg" === o.h), i = o.p = J.createElementNS(n ? "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml", o.h), n && "foreignObject" === o.h && (n = !1), m(null, o, n), null != e && i["s-si"] !== e && i.classList.add(i["s-si"] = e), o.o)
                for (r = 0; r < o.o.length; ++r) c = b(t, o, r), c && i.appendChild(c);
            "svg" === o.h ? n = !1 : "foreignObject" === i.tagName && (n = !0)
        }
        return i
    },
    w = (e, n, l, s, o, i) => {
        let c, r = e;
        for (r.shadowRoot && r.tagName === t && (r = r.shadowRoot); o <= i; ++o) s[o] && (c = b(null, l, o), c && (s[o].p = c, r.insertBefore(c, n)))
    },
    g = (e, t, n, l) => {
        for (; t <= n; ++t)(l = e[t]) && l.p.remove()
    },
    v = (e, t) => e.h === t.h && e.i === t.i,
    S = (e, t) => {
        const l = t.p = e.p,
            s = e.o,
            o = t.o,
            i = t.h,
            c = t.t;
        null === c ? (n = "svg" === i || "foreignObject" !== i && n, m(e, t, n), null !== s && null !== o ? ((e, t, n, l) => {
            let s, o, i = 0,
                c = 0,
                r = 0,
                u = 0,
                a = t.length - 1,
                f = t[0],
                h = t[a],
                p = l.length - 1,
                y = l[0],
                d = l[p];
            for (; i <= a && c <= p;)
                if (null == f) f = t[++i];
                else if (null == h) h = t[--a];
            else if (null == y) y = l[++c];
            else if (null == d) d = l[--p];
            else if (v(f, y)) S(f, y), f = t[++i], y = l[++c];
            else if (v(h, d)) S(h, d), h = t[--a], d = l[--p];
            else if (v(f, d)) S(f, d), e.insertBefore(f.p, h.p.nextSibling), f = t[++i], d = l[--p];
            else if (v(h, y)) S(h, y), e.insertBefore(h.p, f.p), h = t[--a], y = l[++c];
            else {
                for (r = -1, u = i; u <= a; ++u)
                    if (t[u] && null !== t[u].i && t[u].i === y.i) {
                        r = u;
                        break
                    }
                r >= 0 ? (o = t[r], o.h !== y.h ? s = b(t && t[c], n, r) : (S(o, y), t[r] = void 0, s = o.p), y = l[++c]) : (s = b(t && t[c], n, c), y = l[++c]), s && f.p.parentNode.insertBefore(s, f.p)
            }
            i > a ? w(e, null == l[p + 1] ? null : l[p + 1].p, n, l, c, p) : c > p && g(t, i, a)
        })(l, s, t, o) : null !== o ? (null !== e.t && (l.textContent = ""), w(l, null, t, o, 0, o.length - 1)) : null !== s && g(s, 0, s.length - 1), n && "svg" === i && (n = !1)) : e.t !== c && (l.data = c)
    },
    j = (e, t) => {
        t && !e.g && t["s-p"] && t["s-p"].push(new Promise((t => e.g = t)))
    },
    k = (e, t) => {
        if (e.u |= 16, !(4 & e.u)) return j(e, e.v), se((() => O(e, t)));
        e.u |= 512
    },
    O = (e, t) => {
        const n = e.S;
        let l;
        return t ? (e.u |= 256, e.j && (e.j.map((([e, t]) => P(n, e, t))), e.j = null), l = P(n, "componentWillLoad")) : l = P(n, "componentWillUpdate"), W(l, (() => M(e, n, t)))
    },
    M = async (e, t, n) => {
        const l = e.$,
            s = l["s-rc"];
        n && (e => {
            const t = e.k,
                n = e.$,
                l = t.u,
                s = ((e, t) => {
                    let n = p(t);
                    const l = G.get(n);
                    if (e = 11 === e.nodeType ? e : J, l)
                        if ("string" == typeof l) {
                            let t, s = h.get(e = e.head || e);
                            s || h.set(e, s = new Set), s.has(n) || (t = J.createElement("style"), t.innerHTML = l, e.insertBefore(t, e.querySelector("link")), s && s.add(n))
                        } else e.adoptedStyleSheets.includes(l) || (e.adoptedStyleSheets = [...e.adoptedStyleSheets, l]);
                    return n
                })(n.shadowRoot ? n.shadowRoot : n.getRootNode(), t);
            10 & l && (n["s-sc"] = s, n.classList.add(s + "-h"), 2 & l && n.classList.add(s + "-s"))
        })(e);
        C(e, t), s && (s.map((e => e())), l["s-rc"] = void 0); {
            const t = l["s-p"],
                n = () => x(e);
            0 === t.length ? n() : (Promise.all(t).then(n), e.u |= 4, t.length = 0)
        }
    },
    C = (n, l) => {
        try {
            l = l.render(), n.u &= -17, n.u |= 2, ((n, l) => {
                const s = n.$,
                    o = n.O || c(null, null),
                    u = (e => e && e.h === r)(l) ? l : i(null, null, l);
                t = s.tagName, u.h = null, u.u |= 4, n.O = u, u.p = o.p = s.shadowRoot || s, e = s["s-sc"], S(o, u)
            })(n, l)
        } catch (e) {
            _(e, n.$)
        }
        return null
    },
    x = e => {
        const t = e.$,
            n = e.S,
            l = e.v;
        64 & e.u || (e.u |= 64, E(t), P(n, "componentDidLoad"), e.M(t), l || L()), e.g && (e.g(), e.g = void 0), 512 & e.u && le((() => k(e, !1))), e.u &= -517
    },
    L = () => {
        E(J.documentElement), le((() => f(I, "appload", {
            detail: {
                namespace: "notificationspanel"
            }
        })))
    },
    P = (e, t, n) => {
        if (e && e[t]) try {
            return e[t](n)
        } catch (e) {
            _(e)
        }
    },
    W = (e, t) => e && e.then ? e.then(t) : t(),
    E = e => e.classList.add("hydrated"),
    N = (e, t, n) => {
        if (t.C) {
            e.watchers && (t.L = e.watchers);
            const l = Object.entries(t.C),
                s = e.prototype;
            if (l.map((([e, [l]]) => {
                    (31 & l || 2 & n && 32 & l) && Object.defineProperty(s, e, {
                        get() {
                            return ((e, t) => q(this).P.get(t))(0, e)
                        },
                        set(n) {
                            ((e, t, n, l) => {
                                const s = q(e),
                                    i = s.$,
                                    c = s.P.get(t),
                                    r = s.u,
                                    u = s.S;
                                if (n = ((e, t) => null == e || o(e) ? e : 4 & t ? "false" !== e && ("" === e || !!e) : 1 & t ? e + "" : e)(n, l.C[t][0]), (!(8 & r) || void 0 === c) && n !== c && (!Number.isNaN(c) || !Number.isNaN(n)) && (s.P.set(t, n), u)) {
                                    if (l.L && 128 & r) {
                                        const e = l.L[t];
                                        e && e.map((e => {
                                            try {
                                                u[e](n, c, t)
                                            } catch (e) {
                                                _(e, i)
                                            }
                                        }))
                                    }
                                    2 == (18 & r) && k(s, !1)
                                }
                            })(this, e, n, t)
                        },
                        configurable: !0,
                        enumerable: !0
                    })
                })), 1 & n) {
                const t = new Map;
                s.attributeChangedCallback = function(e, n, l) {
                    K.jmp((() => {
                        const n = t.get(e);
                        if (this.hasOwnProperty(n)) l = this[n], delete this[n];
                        else if (s.hasOwnProperty(n) && "number" == typeof this[n] && this[n] == l) return;
                        this[n] = (null !== l || "boolean" != typeof this[n]) && l
                    }))
                }, e.observedAttributes = l.filter((([e, t]) => 15 & t[0])).map((([e, n]) => {
                    const l = n[1] || e;
                    return t.set(l, e), l
                }))
            }
        }
        return e
    },
    T = (e, t = {}) => {
        const n = [],
            l = t.exclude || [],
            s = I.customElements,
            o = J.head,
            i = o.querySelector("meta[charset]"),
            c = J.createElement("style"),
            r = [];
        let u, a = !0;
        Object.assign(K, t), K.W = new URL(t.resourcesUrl || "./", J.baseURI).href, e.map((e => {
            e[1].map((t => {
                const o = {
                    u: t[0],
                    m: t[1],
                    C: t[2],
                    N: t[3]
                };
                o.C = t[2], o.N = t[3], o.L = {};
                const i = o.m,
                    c = class extends HTMLElement {
                        constructor(e) {
                            super(e), F(e = this, o), 1 & o.u && e.attachShadow({
                                mode: "open"
                            })
                        }
                        connectedCallback() {
                            u && (clearTimeout(u), u = null), a ? r.push(this) : K.jmp((() => (e => {
                                if (0 == (1 & K.u)) {
                                    const t = q(e),
                                        n = t.k,
                                        l = () => {};
                                    if (1 & t.u) U(e, t, n.N);
                                    else {
                                        t.u |= 1; {
                                            let n = e;
                                            for (; n = n.parentNode || n.host;)
                                                if (n["s-p"]) {
                                                    j(t, t.v = n);
                                                    break
                                                }
                                        }
                                        n.C && Object.entries(n.C).map((([t, [n]]) => {
                                            if (31 & n && e.hasOwnProperty(t)) {
                                                const n = e[t];
                                                delete e[t], e[t] = n
                                            }
                                        })), (async (e, t, n, l, s) => {
                                            if (0 == (32 & t.u)) {
                                                {
                                                    if (t.u |= 32, (s = B(n)).then) {
                                                        const e = () => {};
                                                        s = await s, e()
                                                    }
                                                    s.isProxied || (n.L = s.watchers, N(s, n, 2), s.isProxied = !0);
                                                    const e = () => {};
                                                    t.u |= 8;
                                                    try {
                                                        new s(t)
                                                    } catch (e) {
                                                        _(e)
                                                    }
                                                    t.u &= -9, t.u |= 128, e()
                                                }
                                                if (s.style) {
                                                    let e = s.style;
                                                    const t = p(n);
                                                    if (!G.has(t)) {
                                                        const l = () => {};
                                                        ((e, t, n) => {
                                                            let l = G.get(e);
                                                            X && n ? (l = l || new CSSStyleSheet, "string" == typeof l ? l = t : l.replaceSync(t)) : l = t, G.set(e, l)
                                                        })(t, e, !!(1 & n.u)), l()
                                                    }
                                                }
                                            }
                                            const o = t.v,
                                                i = () => k(t, !0);
                                            o && o["s-rc"] ? o["s-rc"].push(i) : i()
                                        })(0, t, n)
                                    }
                                    l()
                                }
                            })(this)))
                        }
                        disconnectedCallback() {
                            K.jmp((() => (() => {
                                if (0 == (1 & K.u)) {
                                    const e = q(this);
                                    e.T && (e.T.map((e => e())), e.T = void 0)
                                }
                            })()))
                        }
                        componentOnReady() {
                            return q(this).U
                        }
                    };
                o.A = e[0], l.includes(i) || s.get(i) || (n.push(i), s.define(i, N(c, o, 1)))
            }))
        })), c.innerHTML = n + "{visibility:hidden}.hydrated{visibility:inherit}", c.setAttribute("data-styles", ""), o.insertBefore(c, i ? i.nextSibling : o.firstChild), a = !1, r.length ? r.map((e => e.connectedCallback())) : K.jmp((() => u = setTimeout(L, 30)))
    },
    U = (e, t, n) => {
        n && n.map((([n, l, s]) => {
            const o = e,
                i = A(t, s),
                c = H(n);
            K.ael(o, l, i, c), (t.T = t.T || []).push((() => K.rel(o, l, i, c)))
        }))
    },
    A = (e, t) => n => {
        try {
            256 & e.u ? e.S[t](n) : (e.j = e.j || []).push([t, n])
        } catch (e) {
            _(e)
        }
    },
    H = e => 0 != (2 & e),
    R = new WeakMap,
    q = e => R.get(e),
    D = (e, t) => R.set(t.S = e, t),
    F = (e, t) => {
        const n = {
            u: 0,
            $: e,
            k: t,
            P: new Map
        };
        return n.U = new Promise((e => n.M = e)), e["s-p"] = [], e["s-rc"] = [], U(e, n, t.N), R.set(e, n)
    },
    V = (e, t) => t in e,
    _ = (e, t) => (0, console.error)(e, t),
    z = new Map,
    B = e => {
        const t = e.m.replace(/-/g, "_"),
            n = e.A,
            l = z.get(n);
        return l ? l[t] : import (`./${n}.entry.js`).then((e => (z.set(n, e), e[t])), _) /*!__STENCIL_STATIC_IMPORT_SWITCH__*/
    },
    G = new Map,
    I = "undefined" != typeof window ? window : {},
    J = I.document || {
        head: {}
    },
    K = {
        u: 0,
        W: "",
        jmp: e => e(),
        raf: e => requestAnimationFrame(e),
        ael: (e, t, n, l) => e.addEventListener(t, n, l),
        rel: (e, t, n, l) => e.removeEventListener(t, n, l),
        ce: (e, t) => new CustomEvent(e, t)
    },
    Q = e => Promise.resolve(e),
    X = (() => {
        try {
            return new CSSStyleSheet, "function" == typeof(new CSSStyleSheet).replaceSync
        } catch (e) {}
        return !1
    })(),
    Y = [],
    Z = [],
    ee = (e, t) => n => {
        e.push(n), l || (l = !0, t && 4 & K.u ? le(ne) : K.raf(ne))
    },
    te = e => {
        for (let t = 0; t < e.length; t++) try {
            e[t](performance.now())
        } catch (e) {
            _(e)
        }
        e.length = 0
    },
    ne = () => {
        te(Y), te(Z), (l = Y.length > 0) && K.raf(ne)
    },
    le = e => Q().then(e),
    se = ee(Z, !0);
export {
    r as H, T as b, a as c, u as g, i as h, Q as p, D as r
}